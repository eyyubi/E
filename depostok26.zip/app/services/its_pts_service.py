"""
Sağlık Bakanlığı İlaç Takip Sistemi (İTS) ve Paket Transfer Sistemi (PTS) REST API Servisi
Kılavuz Standartları:
- Token Alma: POST {base_url}/token/app/token/
- Paydaş Listesi (20): POST {base_url}/reference/app/stakeholder/
- PTS Paket Sorgulama (44): POST {base_url}/pts/app/search
- PTS Paket Alım (43): POST {base_url}/pts/app/GetPackage
"""
import base64
import datetime
from datetime import date, timedelta
import hashlib
import json
import ssl
import time
import urllib.error
import urllib.request
from typing import Any, Dict, List, Optional, Tuple
from sqlalchemy import or_
from sqlalchemy.orm import Session

from app.database import engine
from app.models import ItsApiAyarlari, ItsPaydas, StokHareketi, DepoKarekod
from app.pts_parser import parse_pts_xml


class ItsPtsService:
    TEST_BASE_URL = "https://itstest2.saglik.gov.tr"
    PROD_BASE_URL = "https://its.saglik.gov.tr"

    # Bellek içi (in-memory) Token önbelleği
    _cached_token: Optional[str] = None
    _cached_token_exp: float = 0.0
    _cached_credentials_hash: Optional[str] = None

    @staticmethod
    def _ensure_table():
        try:
            ItsApiAyarlari.__table__.create(bind=engine, checkfirst=True)
            ItsPaydas.__table__.create(bind=engine, checkfirst=True)
        except Exception:
            pass

    @classmethod
    def get_settings(cls, db: Session) -> ItsApiAyarlari:
        cls._ensure_table()
        settings = db.query(ItsApiAyarlari).order_by(ItsApiAyarlari.id.asc()).first()
        if not settings:
            settings = ItsApiAyarlari(
                ortam="test",
                base_url=cls.TEST_BASE_URL,
                username="",
                password="",
                gln_no=""
            )
            db.add(settings)
            db.commit()
            db.refresh(settings)
        return settings

    @classmethod
    def save_settings(
        cls,
        db: Session,
        ortam: str,
        username: str,
        password: Optional[str] = None,
        gln_no: Optional[str] = None,
        custom_base_url: Optional[str] = None
    ) -> ItsApiAyarlari:
        settings = cls.get_settings(db)
        ortam_clean = (ortam or "test").strip().lower()
        settings.ortam = ortam_clean

        if ortam_clean == "test":
            settings.base_url = cls.TEST_BASE_URL
        elif ortam_clean == "prod":
            settings.base_url = cls.PROD_BASE_URL
        else:
            url_val = (custom_base_url or settings.base_url or cls.TEST_BASE_URL).strip().rstrip("/")
            settings.base_url = url_val

        settings.username = (username or "").strip()
        if password is not None and password != "********":
            settings.password = password.strip()

        # Eğer GLN girilmemişse ve username 13+ haneli GLN formatındaysa ilk 13 haneyi otomatik çıkar
        gln_clean = (gln_no or "").strip()
        if not gln_clean and settings.username and len(settings.username) >= 13 and settings.username[:13].isdigit():
            gln_clean = settings.username[:13]
        settings.gln_no = gln_clean
        settings.updated_at = datetime.datetime.now(datetime.timezone.utc).replace(tzinfo=None)

        db.commit()
        db.refresh(settings)

        # Ayarlar değiştiğinde önbellekteki token'ı sıfırla
        cls._cached_token = None
        cls._cached_token_exp = 0.0
        cls._cached_credentials_hash = None
        return settings

    @staticmethod
    def _extract_jwt_exp(token_str: str) -> Optional[float]:
        """JWT payload kısmından 'exp' zaman damgasını (varsa) çözer."""
        try:
            parts = token_str.split(".")
            if len(parts) >= 2:
                payload_b64 = parts[1]
                padding = "=" * ((4 - len(payload_b64) % 4) % 4)
                decoded = base64.urlsafe_b64decode(payload_b64 + padding).decode("utf-8", errors="ignore")
                data = json.loads(decoded)
                if "exp" in data and isinstance(data["exp"], (int, float)):
                    return float(data["exp"])
        except Exception:
            pass
        return None

    @staticmethod
    def _http_post_json(
        url: str,
        payload: Dict[str, Any],
        bearer_token: Optional[str] = None,
        timeout: int = 30
    ) -> Tuple[int, str, Any]:
        """
        İTS / PTS REST API servislerine JSON POST isteği gönderir.
        Dönüş: (http_status_code, raw_body_text, parsed_json_or_none)
        """
        body_bytes = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        headers = {
            "Content-Type": "application/json; charset=utf-8",
            "Accept": "application/json",
            "User-Agent": "IlacStok-ITS-PTS-Client/1.0"
        }
        if bearer_token:
            headers["Authorization"] = f"Bearer {bearer_token}"

        req = urllib.request.Request(url, data=body_bytes, headers=headers, method="POST")

        # Önce standart SSL, sertifika hatası olursa unverified SSL context fallback
        contexts = [ssl.create_default_context(), ssl._create_unverified_context()]
        last_err = None

        for ctx in contexts:
            try:
                with urllib.request.urlopen(req, timeout=timeout, context=ctx) as resp:
                    status_code = resp.getcode()
                    raw_text = resp.read().decode("utf-8", errors="replace").strip()
                    parsed_json = None
                    if raw_text:
                        try:
                            parsed_json = json.loads(raw_text)
                        except Exception:
                            parsed_json = None
                    return status_code, raw_text, parsed_json
            except urllib.error.HTTPError as http_err:
                status_code = http_err.code
                try:
                    err_text = http_err.read().decode("utf-8", errors="replace").strip()
                except Exception:
                    err_text = str(http_err)
                parsed_err = None
                if err_text:
                    try:
                        parsed_err = json.loads(err_text)
                    except Exception:
                        parsed_err = None
                return status_code, err_text, parsed_err
            except urllib.error.URLError as url_err:
                last_err = url_err
                if isinstance(getattr(url_err, "reason", None), ssl.SSLError):
                    continue
                break
            except Exception as ex:
                last_err = ex
                break

        raise RuntimeError(f"İTS sunucusuna bağlanılamadı ({url}): {last_err}")

    @classmethod
    def request_access_token(
        cls,
        username: str,
        password: str,
        base_url: str = TEST_BASE_URL,
        force_refresh: bool = False
    ) -> str:
        """
        İTS Token Servisinden (POST {base_url}/token/app/token/) JWT Bearer Token alır.
        İstek: {"username": "...", "password": "..."}
        Cevap: {"token": "eyJhbG..."}
        """
        u_clean = (username or "").strip()
        p_clean = (password or "").strip()
        b_url = (base_url or cls.TEST_BASE_URL).strip().rstrip("/")

        if not u_clean or not p_clean:
            raise ValueError("İTS kullanıcı adı (username) ve şifre (password) girilmelidir.")

        cred_hash = hashlib.sha256(f"{b_url}|{u_clean}|{p_clean}".encode("utf-8")).hexdigest()
        now = time.time()

        if (
            not force_refresh
            and cls._cached_token
            and cls._cached_credentials_hash == cred_hash
            and now < cls._cached_token_exp
        ):
            return cls._cached_token

        token_url = f"{b_url}/token/app/token/"
        payload = {
            "username": u_clean,
            "password": p_clean
        }

        status_code, raw_text, parsed_json = cls._http_post_json(token_url, payload, bearer_token=None, timeout=25)

        if status_code not in (200, 201):
            err_detail = ""
            if isinstance(parsed_json, dict):
                err_detail = (
                    parsed_json.get("message")
                    or parsed_json.get("error_description")
                    or parsed_json.get("error")
                    or parsed_json.get("faultstring")
                    or ""
                )
            raise ValueError(
                f"İTS Token alınamadı (HTTP {status_code}). "
                f"{err_detail or raw_text[:250] or 'Kullanıcı adı veya şifre hatalı olabilir.'}"
            )

        token_val = None
        if isinstance(parsed_json, dict):
            token_val = parsed_json.get("token") or parsed_json.get("access_token")
        elif isinstance(parsed_json, str):
            token_val = parsed_json.strip()
        elif raw_text and not raw_text.startswith("{"):
            token_val = raw_text.strip().strip('"')

        if not token_val:
            raise ValueError(f"İTS Token yanıtında 'token' alanı bulunamadı. Yanıt: {raw_text[:200]}")

        jwt_exp = cls._extract_jwt_exp(token_val)
        # JWT'de exp varsa 60 sn güvenlik payı bırak, yoksa 20 dakika önbellekle
        cls._cached_token = token_val
        cls._cached_credentials_hash = cred_hash
        cls._cached_token_exp = (jwt_exp - 60) if (jwt_exp and jwt_exp > now + 60) else (now + 1200)

        return token_val

    @classmethod
    def get_token_from_db(cls, db: Session, force_refresh: bool = False) -> Tuple[str, ItsApiAyarlari]:
        settings = cls.get_settings(db)
        if not settings.username or not settings.password:
            raise ValueError("İTS API kullanıcı adı ve şifresi tanımlanmamış. Lütfen önce 'İTS API Ayarları' bölümünden bilgilerinizi kaydedin.")
        token = cls.request_access_token(
            username=settings.username,
            password=settings.password,
            base_url=settings.base_url or cls.TEST_BASE_URL,
            force_refresh=force_refresh
        )
        return token, settings

    @staticmethod
    def _parse_iso_date(d_str: str) -> date:
        s = (d_str or "").strip()[:10]
        return datetime.datetime.strptime(s, "%Y-%m-%d").date()

    @classmethod
    def _split_date_ranges_max_31_days(cls, start_date_str: str, end_date_str: str) -> List[Tuple[str, str]]:
        """
        Kılavuz Madde 44:
        'Servisin başarılı bir şekilde çalışabilmesi için sorgulanan tarih aralığı en fazla 31 gün olarak tanımlanmıştır.'
        Tarih aralığı 31 günü aşarsa otomatik 30 günlük pencerelere böler.
        """
        try:
            d_start = cls._parse_iso_date(start_date_str)
            d_end = cls._parse_iso_date(end_date_str)
        except Exception:
            raise ValueError("Başlangıç ve bitiş tarihleri YYYY-AA-GG (Örn: 2026-03-01) formatında olmalıdır.")

        if d_start > d_end:
            d_start, d_end = d_end, d_start

        ranges = []
        curr = d_start
        while curr <= d_end:
            chunk_end = min(curr + timedelta(days=30), d_end)
            ranges.append((curr.strftime("%Y-%m-%d"), chunk_end.strftime("%Y-%m-%d")))
            curr = chunk_end + timedelta(days=1)
        return ranges

    @classmethod
    def search_packages(
        cls,
        db: Session,
        start_date: str,
        end_date: str,
        source_gln: str = "",
        destination_gln: str = "",
        bring_not_received: int = 1
    ) -> Dict[str, Any]:
        """
        44. PAKET TRANSFER SERVİSİ – PAKET SORGULAMA
        POST {base_url}/pts/app/search
        İstek:
        {
            "sourceGln": "8680001000012",
            "destinationGln": "8680001000022",
            "bringNotReceivedTransferInfo": 1,
            "startDate": "2022-03-01",
            "endDate": "2022-03-30"
        }
        Cevap:
        {
            "transferDetails": [
                {
                    "sourceGln": "8680001000012",
                    "destinationGln": "8680001000022",
                    "transferId": 100006426,
                    "transferDate": "2022-03-29T13:32:58.085081Z"
                }
            ]
        }
        """
        token, settings = cls.get_token_from_db(db)
        base_url = (settings.base_url or cls.TEST_BASE_URL).strip().rstrip("/")
        search_url = f"{base_url}/pts/app/search"

        dest_gln = (destination_gln or settings.gln_no or "").strip()
        if not dest_gln and settings.username and len(settings.username) >= 13 and settings.username[:13].isdigit():
            dest_gln = settings.username[:13]

        src_gln = (source_gln or "").strip()
        flag_val = 1 if int(bring_not_received) == 1 else 0

        date_chunks = cls._split_date_ranges_max_31_days(start_date, end_date)
        all_transfers: List[Dict[str, Any]] = []
        seen_transfer_ids = set()

        for s_date, e_date in date_chunks:
            payload = {
                "sourceGln": src_gln,
                "destinationGln": dest_gln,
                "bringNotReceivedTransferInfo": flag_val,
                "startDate": s_date,
                "endDate": e_date
            }

            status_code, raw_text, parsed_json = cls._http_post_json(search_url, payload, bearer_token=token, timeout=30)

            # Token süresi dolmuşsa 1 kez yenileyip tekrar dene
            if status_code == 401:
                token, _ = cls.get_token_from_db(db, force_refresh=True)
                status_code, raw_text, parsed_json = cls._http_post_json(search_url, payload, bearer_token=token, timeout=30)

            if status_code not in (200, 201):
                err_msg = ""
                if isinstance(parsed_json, dict):
                    err_msg = (
                        parsed_json.get("message")
                        or parsed_json.get("faultstring")
                        or parsed_json.get("error")
                        or ""
                    )
                raise ValueError(
                    f"PTS Paket Sorgulama hatası (HTTP {status_code}): {err_msg or raw_text[:250]}"
                )

            details = []
            if isinstance(parsed_json, dict):
                details = parsed_json.get("transferDetails") or parsed_json.get("transfers") or []
            elif isinstance(parsed_json, list):
                details = parsed_json

            if isinstance(details, list):
                for item in details:
                    if not isinstance(item, dict):
                        continue
                    t_id = str(item.get("transferId") or "").strip()
                    if not t_id or t_id in seen_transfer_ids:
                        continue
                    seen_transfer_ids.add(t_id)
                    all_transfers.append({
                        "transferId": t_id,
                        "sourceGln": str(item.get("sourceGln") or src_gln or "").strip(),
                        "destinationGln": str(item.get("destinationGln") or dest_gln or "").strip(),
                        "transferDate": str(item.get("transferDate") or "").strip()
                    })

        # Depoya daha önce kaydedilmiş PTS numaralarını işaretle ve GLN -> Paydaş Adı eşleştir
        if all_transfers:
            t_id_list = [t["transferId"] for t in all_transfers]
            existing_mov_pts = {
                str(r[0]).strip()
                for r in db.query(StokHareketi.pts_no).filter(StokHareketi.pts_no.in_(t_id_list)).distinct().all()
                if r[0]
            }
            existing_depo_pts = {
                str(r[0]).strip()
                for r in db.query(DepoKarekod.pts_no).filter(DepoKarekod.pts_no.in_(t_id_list)).distinct().all()
                if r[0]
            }
            imported_set = existing_mov_pts | existing_depo_pts

            gln_set = set()
            for t in all_transfers:
                if t.get("sourceGln"):
                    gln_set.add(t["sourceGln"])
                if t.get("destinationGln"):
                    gln_set.add(t["destinationGln"])
            gln_name_map = cls.resolve_gln_map(db, list(gln_set))

            for t in all_transfers:
                t["already_imported"] = t["transferId"] in imported_set
                t["sourceCompanyName"] = gln_name_map.get(t.get("sourceGln", ""), "")
                t["destinationCompanyName"] = gln_name_map.get(t.get("destinationGln", ""), "")

        # Tarihe veya transferId'ye göre yeniden eskiye sırala
        all_transfers.sort(key=lambda x: (x.get("transferDate") or "", x.get("transferId") or ""), reverse=True)

        return {
            "status": "success",
            "success": True,
            "count": len(all_transfers),
            "destinationGln": dest_gln,
            "sourceGln": src_gln,
            "startDate": start_date,
            "endDate": end_date,
            "bringNotReceivedTransferInfo": flag_val,
            "transferDetails": all_transfers
        }

    @classmethod
    def download_package(
        cls,
        db: Session,
        transfer_id: str,
        source_gln: str = "",
        transfer_date: str = ""
    ) -> Dict[str, Any]:
        """
        43. PAKET TRANSFER SERVİSİ – PAKET ALIM
        POST {base_url}/pts/app/GetPackage
        İstek:
        {
            "transferId": "100004870"
        }
        Cevap:
        {
            "fileStream": "UEsDBBQAAAAIAKRRb1QMfn...",
            "streamMD5checksum": "2a9bbf159005adb3e6d769a381c14780"
        }
        """
        t_id = str(transfer_id or "").strip()
        if not t_id:
            raise ValueError("Geçerli bir transferId (Transfer Numarası) belirtilmelidir.")

        token, settings = cls.get_token_from_db(db)
        base_url = (settings.base_url or cls.TEST_BASE_URL).strip().rstrip("/")
        get_pkg_url = f"{base_url}/pts/app/GetPackage"

        payload = {
            "transferId": t_id
        }

        status_code, raw_text, parsed_json = cls._http_post_json(get_pkg_url, payload, bearer_token=token, timeout=45)

        if status_code == 401:
            token, _ = cls.get_token_from_db(db, force_refresh=True)
            status_code, raw_text, parsed_json = cls._http_post_json(get_pkg_url, payload, bearer_token=token, timeout=45)

        if status_code not in (200, 201):
            err_msg = ""
            if isinstance(parsed_json, dict):
                err_msg = (
                    parsed_json.get("message")
                    or parsed_json.get("faultstring")
                    or parsed_json.get("error")
                    or ""
                )
            raise ValueError(
                f"PTS Paket Alım hatası (Transfer ID: {t_id}, HTTP {status_code}): {err_msg or raw_text[:250]}"
            )

        if not isinstance(parsed_json, dict):
            raise ValueError(f"PTS GetPackage servisinden geçersiz JSON yanıtı döndü: {raw_text[:200]}")

        file_stream_b64 = parsed_json.get("fileStream")
        expected_md5 = str(parsed_json.get("streamMD5checksum") or "").strip().lower()

        if not file_stream_b64:
            err_msg = parsed_json.get("message") or parsed_json.get("error") or "fileStream alanı boş döndü."
            raise ValueError(f"PTS paketi alınamadı ({t_id}): {err_msg}")

        # Base64 decode (.zip byte array)
        clean_b64 = "".join(str(file_stream_b64).split())
        try:
            zip_bytes = base64.b64decode(clean_b64)
        except Exception as b64_err:
            raise ValueError(f"PTS fileStream Base64 çözümlenemedi: {b64_err}")

        if not zip_bytes:
            raise ValueError("PTS paketinden boş dosya akışı (0 byte) döndü.")

        calculated_md5 = hashlib.md5(zip_bytes).hexdigest().lower()
        md5_verified = True
        if expected_md5 and expected_md5 != calculated_md5:
            md5_verified = False
            raise ValueError(
                f"PTS Paket MD5 bütünlük doğrulaması başarısız! "
                f"(Beklenen: {expected_md5}, Hesaplanan: {calculated_md5})"
            )

        # ZIP içindeki PTS XML verisini ayrıştır
        parsed_pts = parse_pts_xml(zip_bytes)

        # Eksik başlık alanlarını PTS zarf bilgileriyle tamamla
        if not parsed_pts.get("document_number"):
            parsed_pts["document_number"] = t_id
        if not parsed_pts.get("sender") and source_gln:
            parsed_pts["sender"] = source_gln
        if not parsed_pts.get("document_date") and transfer_date:
            parsed_pts["document_date"] = transfer_date[:10]

        # Gönderici GLN numarası Paydaş Rehberinde kayıtlıysa kurum adını ekle
        sender_val = str(parsed_pts.get("sender") or "").strip()
        check_gln = source_gln or (sender_val if sender_val.isdigit() else "")
        if check_gln:
            gln_map = cls.resolve_gln_map(db, [check_gln])
            comp_name = gln_map.get(check_gln)
            if comp_name and comp_name not in sender_val:
                parsed_pts["sender"] = f"{comp_name} ({check_gln})"

        return {
            "transfer_id": t_id,
            "zip_bytes": zip_bytes,
            "stream_md5": expected_md5,
            "calculated_md5": calculated_md5,
            "md5_verified": md5_verified,
            "parsed_data": parsed_pts
        }

    # ==========================================================================
    # 20. PAYDAŞ LİSTESİ SERVİSİ (/reference/app/stakeholder/)
    # ==========================================================================

    @classmethod
    def resolve_gln_map(cls, db: Session, glns: List[str]) -> Dict[str, str]:
        cls._ensure_table()
        clean_glns = [str(g).strip() for g in glns if g and str(g).strip()]
        if not clean_glns:
            return {}
        try:
            rows = db.query(ItsPaydas.gln, ItsPaydas.company_name).filter(
                ItsPaydas.gln.in_(clean_glns)
            ).all()
            return {str(r[0]): str(r[1] or "") for r in rows if r[0] and r[1]}
        except Exception:
            return {}

    @staticmethod
    def _normalize_stakeholder_type(st_type: str) -> str:
        s = (st_type or "depo").strip().lower()
        tr_map = str.maketrans("çğıöşü", "cgiosu")
        s = s.translate(tr_map)
        if s in ("uretici", "depo", "eczane", "hastane", "hastan", "ihracatci"):
            return s
        return "depo"

    @classmethod
    def fetch_stakeholders(
        cls,
        db: Session,
        stakeholder_type: str = "depo",
        get_all: bool = True,
        city_plate: Optional[int] = None,
        save_to_db: bool = True,
        force_refresh: bool = False
    ) -> Dict[str, Any]:
        """
        20. PAYDAŞ LİSTESİ SERVİSİ (Tek Seferlik Çekim Korumalı)
        POST {base_url}/reference/app/stakeholder/
        - Eğer seçilen paydaş tipi (ve plaka) için veritabanında zaten kayıt varsa ve force_refresh=False ise
          İTS sunucusuna tekrar istek ATMAZ; mevcut veritabanı kayıtlarını ve 'already_fetched=True' bilgisini döner.
        """
        cls._ensure_table()
        norm_type = cls._normalize_stakeholder_type(stakeholder_type)
        plate_int: Optional[int] = None
        if city_plate is not None and str(city_plate).strip().isdigit():
            p_val = int(str(city_plate).strip())
            if 1 <= p_val <= 81:
                plate_int = p_val

        # Tek seferlik çekim kontrolü: Veritabanında bu kriterde kayıt varsa İTS'ye istek atma!
        existing_q = db.query(ItsPaydas).filter(ItsPaydas.stakeholder_type == norm_type)
        if plate_int is not None:
            existing_q = existing_q.filter(ItsPaydas.city_plate == plate_int)
        existing_count = existing_q.count()

        if existing_count > 0 and not force_refresh:
            latest_row = existing_q.order_by(ItsPaydas.updated_at.desc()).first()
            last_updated_str = (
                latest_row.updated_at.strftime("%Y-%m-%d %H:%M")
                if (latest_row and latest_row.updated_at)
                else "-"
            )
            local_res = cls.search_local_stakeholders(
                db=db,
                stakeholder_type=norm_type,
                city_plate=plate_int,
                limit=1000
            )
            return {
                "status": "already_fetched",
                "success": True,
                "already_fetched": True,
                "existing_count": existing_count,
                "last_updated": last_updated_str,
                "stakeholderType": norm_type,
                "cityPlate": plate_int,
                "getAll": bool(get_all),
                "count": local_res["count"],
                "companyList": local_res["companyList"],
                "message": (
                    f"Bu kriterlere ait {existing_count} paydaş zaten veritabanında kayıtlı "
                    f"(Son çekim: {last_updated_str}). İTS sunucusuna yeni istek gönderilmedi."
                )
            }

        token, settings = cls.get_token_from_db(db)
        base_url = (settings.base_url or cls.TEST_BASE_URL).strip().rstrip("/")
        stakeholder_url = f"{base_url}/reference/app/stakeholder/"

        payload: Dict[str, Any] = {
            "stakeholderType": norm_type,
            "getAll": bool(get_all)
        }
        if plate_int is not None:
            payload["cityPlate"] = plate_int

        status_code, raw_text, parsed_json = cls._http_post_json(
            stakeholder_url, payload, bearer_token=token, timeout=40
        )

        if status_code == 401:
            token, _ = cls.get_token_from_db(db, force_refresh=True)
            status_code, raw_text, parsed_json = cls._http_post_json(
                stakeholder_url, payload, bearer_token=token, timeout=40
            )

        # Kılavuzda hastane tipi 'hastan' olarak da geçebildiği için 400 durumunda alternatifini dene
        if status_code not in (200, 201) and norm_type in ("hastane", "hastan"):
            alt_type = "hastan" if norm_type == "hastane" else "hastane"
            payload["stakeholderType"] = alt_type
            status_code, raw_text, parsed_json = cls._http_post_json(
                stakeholder_url, payload, bearer_token=token, timeout=40
            )

        if status_code not in (200, 201):
            err_msg = ""
            if isinstance(parsed_json, dict):
                err_msg = (
                    parsed_json.get("message")
                    or parsed_json.get("faultstring")
                    or parsed_json.get("error")
                    or ""
                )
            raise ValueError(
                f"İTS Paydaş Listesi sorgulama hatası (HTTP {status_code}): {err_msg or raw_text[:250]}"
            )

        raw_list = []
        if isinstance(parsed_json, dict):
            raw_list = parsed_json.get("companyList") or parsed_json.get("stakeholderList") or parsed_json.get("companies") or []
        elif isinstance(parsed_json, list):
            raw_list = parsed_json

        company_list: List[Dict[str, Any]] = []
        if isinstance(raw_list, list):
            for c in raw_list:
                if not isinstance(c, dict):
                    continue
                gln_val = str(c.get("gln") or "").strip()
                if not gln_val:
                    continue
                act_raw = c.get("active", True)
                is_act = act_raw if isinstance(act_raw, bool) else (str(act_raw).lower() not in ("false", "0", "pasif"))
                item_dict = {
                    "gln": gln_val,
                    "companyName": str(c.get("companyName") or "").strip(),
                    "stakeholderType": norm_type,
                    "authorized": str(c.get("authorized") or "").strip(),
                    "email": str(c.get("email") or "").strip(),
                    "phone": str(c.get("phone") or "").strip(),
                    "city": str(c.get("city") or "").strip(),
                    "town": str(c.get("town") or "").strip(),
                    "address": str(c.get("address") or "").strip(),
                    "active": is_act
                }
                company_list.append(item_dict)

        saved_count = 0
        now_dt = datetime.datetime.now(datetime.timezone.utc).replace(tzinfo=None)
        if save_to_db and company_list:
            plate_val = payload.get("cityPlate")
            glns_in_batch = [c["gln"] for c in company_list]
            existing_map: Dict[str, ItsPaydas] = {}
            for i in range(0, len(glns_in_batch), 900):
                chunk = glns_in_batch[i:i + 900]
                for row in db.query(ItsPaydas).filter(ItsPaydas.gln.in_(chunk)).all():
                    existing_map[row.gln] = row

            for c in company_list:
                existing_obj = existing_map.get(c["gln"])
                if existing_obj:
                    existing_obj.company_name = c["companyName"] or existing_obj.company_name
                    existing_obj.stakeholder_type = norm_type
                    existing_obj.authorized = c["authorized"]
                    existing_obj.email = c["email"]
                    existing_obj.phone = c["phone"]
                    existing_obj.city = c["city"] or existing_obj.city
                    if plate_val:
                        existing_obj.city_plate = plate_val
                    existing_obj.town = c["town"]
                    existing_obj.address = c["address"]
                    existing_obj.active = c["active"]
                    existing_obj.updated_at = now_dt
                else:
                    new_obj = ItsPaydas(
                        gln=c["gln"],
                        company_name=c["companyName"],
                        stakeholder_type=norm_type,
                        authorized=c["authorized"],
                        email=c["email"],
                        phone=c["phone"],
                        city=c["city"],
                        city_plate=plate_val,
                        town=c["town"],
                        address=c["address"],
                        active=c["active"],
                        updated_at=now_dt
                    )
                    db.add(new_obj)
                    existing_map[c["gln"]] = new_obj
                saved_count += 1
            db.commit()

        return {
            "status": "success",
            "success": True,
            "already_fetched": False,
            "count": len(company_list),
            "saved_to_db": saved_count,
            "last_updated": now_dt.strftime("%Y-%m-%d %H:%M"),
            "stakeholderType": norm_type,
            "cityPlate": payload.get("cityPlate"),
            "getAll": payload["getAll"],
            "companyList": company_list
        }

    @classmethod
    def search_local_stakeholders(
        cls,
        db: Session,
        search: str = "",
        stakeholder_type: str = "",
        city_plate: Optional[int] = None,
        active_only: bool = False,
        limit: int = 300
    ) -> Dict[str, Any]:
        cls._ensure_table()
        db_total_all = db.query(ItsPaydas).count()
        latest_all = db.query(ItsPaydas).order_by(ItsPaydas.updated_at.desc()).first()
        last_updated_str = (
            latest_all.updated_at.strftime("%Y-%m-%d %H:%M")
            if (latest_all and latest_all.updated_at)
            else ""
        )

        q = db.query(ItsPaydas)
        if stakeholder_type and stakeholder_type.strip() and stakeholder_type != "all":
            norm_t = cls._normalize_stakeholder_type(stakeholder_type)
            q = q.filter(ItsPaydas.stakeholder_type == norm_t)
        if city_plate is not None and str(city_plate).strip().isdigit():
            p_int = int(str(city_plate).strip())
            if 1 <= p_int <= 81:
                q = q.filter(ItsPaydas.city_plate == p_int)
        if active_only:
            q = q.filter(ItsPaydas.active == True)
        if search and search.strip():
            term = f"%{search.strip()}%"
            q = q.filter(
                or_(
                    ItsPaydas.gln.ilike(term),
                    ItsPaydas.company_name.ilike(term),
                    ItsPaydas.city.ilike(term),
                    ItsPaydas.town.ilike(term),
                    ItsPaydas.authorized.ilike(term)
                )
            )
        total = q.count()
        rows = q.order_by(ItsPaydas.company_name.asc()).limit(limit).all()
        items = [
            {
                "gln": r.gln,
                "companyName": r.company_name or "",
                "stakeholderType": r.stakeholder_type or "",
                "authorized": r.authorized or "",
                "email": r.email or "",
                "phone": r.phone or "",
                "city": r.city or "",
                "cityPlate": r.city_plate,
                "town": r.town or "",
                "address": r.address or "",
                "active": bool(r.active)
            }
            for r in rows
        ]
        return {
            "status": "success",
            "success": True,
            "db_total_all": db_total_all,
            "last_updated": last_updated_str,
            "total": total,
            "count": len(items),
            "companyList": items
        }

