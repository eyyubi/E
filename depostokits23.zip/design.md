# İlaçStok — Design Specification v2.0
> Kapsamlı tasarım rehberi. Stitch ile yeni arayüz geliştirmek için referans belge.

---

## 1. Genel Bakış & Uygulama Bağlamı

**İlaçStok**, hastane / klinik ortamında ilaç depolarını yöneten bir **web tabanlı stok operasyon sistemi**dir.

- **Backend:** FastAPI + Jinja2 şablon motoru (SSR)
- **Mevcut CSS:** Bootstrap 5.3 + `app.css` (custom override)
- **Font:** Inter (Google Fonts)
- **İkonlar:** Font Awesome 6.4
- **Kullanıcı tipleri:** `admin`, `user`
- **Kullanım ortamı:** Masaüstü öncelikli, tablet desteği zorunlu, mobil ikincil

### Sayfa Envanteri

| Rota | Şablon | Açıklama |
|------|--------|----------|
| `/login` | `login.html` | Kimlik doğrulama |
| `/` | `dashboard.html` | Genel bakış & KPI'lar |
| `/drugs` | `drugs.html` | İlaç kataloğu |
| `/drugs/add` | `drug_form.html` | Yeni ilaç ekle |
| `/drugs/edit/:id` | `drug_edit_form.html` | İlaç düzenle |
| `/drugs/import` | `drug_import.html` | CSV'den ilaç aktar |
| `/drugs/bulk-entry` | `drug_bulk_entry.html` | Toplu stok girişi / PTS |
| `/drugs/bulk-exit` | `drug_bulk_exit.html` | Toplu stok çıkışı |
| `/drugs/generic-limits` | `generic_limits.html` | Jenerik kritik stok sınırları |
| `/warehouses` | `warehouses.html` | Depo yönetimi |
| `/stock` | `stock.html` | Stok durumu (jenerik/müstahzar) |
| `/movements` | `movements.html` | Stok hareketleri geçmişi |

---

## 2. Marka & Kimlik

### 2.1 Uygulama Adı & Logo
- **Ad:** `İlaçStok`
- **Slogan / Eyebrow:** "OPERASYON MERKEZİ"
- **İkon:** `fa-capsules` (Font Awesome Solid)
- **Logo kompozisyonu:** Küçük gradient rozet (kapsül ikonu) + "İlaç**Stok**" bold text (accent rengi: teal)

### 2.2 Ton ve Dil
- **Dil:** Türkçe (tüm UI metinleri)
- **Ton:** Profesyonel, güvenilir, klinik — gereksiz süsleme yok
- **Eyebrow label'lar:** ALL CAPS, harf aralığı geniş (`letter-spacing: 0.13em`), teal renk
- **Hata mesajları:** Kullanıcı dostu Türkçe açıklamalar (kısa, net)

---

## 3. Renk Sistemi

### 3.1 Temel Palet (HSL Tabanlı)

```css
/* Ana renkler */
--color-primary:        hsl(194, 72%, 31%);   /* #176b87 — Teal */
--color-primary-dark:   hsl(194, 72%, 24%);   /* #105165 */
--color-primary-light:  hsl(194, 50%, 94%);   /* #e7f3f4 */
--color-primary-glow:   hsla(194, 72%, 40%, 0.18);

/* Nötr / Zemin */
--color-bg:             hsl(200, 18%, 96%);   /* #f4f7f8 */
--color-surface:        hsl(0, 0%, 100%);     /* #ffffff */
--color-border:         hsl(200, 14%, 89%);   /* #e4ebed */
--color-border-muted:   hsl(200, 10%, 92%);   /* #edf1f2 */
--color-text:           hsl(200, 35%, 14%);   /* #16262d */
--color-text-muted:     hsl(200, 16%, 50%);   /* #667b84 */

/* Semantik renkler */
--color-success:        hsl(163, 55%, 38%);
--color-success-bg:     hsl(163, 55%, 94%);
--color-danger:         hsl(357, 55%, 58%);
--color-danger-bg:      hsl(357, 55%, 95%);
--color-warning:        hsl(38, 58%, 55%);
--color-warning-bg:     hsl(38, 100%, 93%);
--color-info:           hsl(199, 76%, 55%);
--color-info-bg:        hsl(199, 76%, 93%);

/* Stat kart gradientleri */
--grad-primary: linear-gradient(135deg, hsl(194,72%,31%), hsl(194,72%,22%));
--grad-danger:  linear-gradient(135deg, hsl(357,55%,58%), hsl(348,47%,49%));
--grad-warning: linear-gradient(135deg, hsl(38,58%,55%),  hsl(32,72%,42%));
--grad-success: linear-gradient(135deg, hsl(163,55%,38%), hsl(168,67%,27%));
```

### 3.2 Arkaplan
- **Body:** `radial-gradient(circle at 100% 0%, hsl(194,40%,88%) 0, transparent 26rem), hsl(200,18%,96%)`
- **Navbar:** `rgba(255,255,255,0.91)` + `backdrop-filter: blur(10px)`
- **Card:** `#ffffff`

### 3.3 Reçete Türü Renk Haritası

| Reçete Tipi | Arka Plan | Yazı Rengi |
|-------------|-----------|------------|
| Normal | `hsl(194,40%,93%)` | `hsl(194,72%,31%)` |
| Mor | `hsl(270,40%,93%)` | `hsl(270,50%,45%)` |
| Turuncu | `hsl(38,100%,92%)` | `hsl(30,90%,38%)` |
| Yeşil | `hsl(140,50%,93%)` | `hsl(153,60%,30%)` |
| Kırmızı | `hsl(357,55%,93%)` | `hsl(355,60%,43%)` |
| Tanımsız | `hsl(200,10%,92%)` | `hsl(200,20%,42%)` |

### 3.4 İlaç Özellik (Bilgi Kartı) Renk Haritası

```
info      → teal (#176b87)
danger    → red  (#d95f5f)
warning   → amber (#dba43e)
dark      → slate (#2b3e4a)
secondary → gray  (#667b84)
primary   → teal-dark (#125165)
success   → green (#2c957b)
```

---

## 4. Tipografi

### 4.1 Font Stack
```css
font-family: 'Inter', system-ui, -apple-system, sans-serif;
/* Google Fonts: Inter:wght@300;400;500;600;700;800 */
```

### 4.2 Tip Hiyerarşisi

| Kullanım | Boyut | Ağırlık | Notlar |
|---------|-------|---------|--------|
| Page Title (h1/h2) | `clamp(1.55rem, 3vw, 2rem)` | 720 | `letter-spacing: -0.04em` |
| Section Heading (h3) | `1.15rem` | 700 | |
| Card Title | `0.95rem` | 600 | |
| Body | `0.875rem` | 400 | |
| Small / Caption | `0.78rem` | 400 | |
| Eyebrow Label | `0.68rem` | 800 | ALL CAPS, `letter-spacing: 0.13em`, teal |
| Table Header | `0.68rem` | 600 | ALL CAPS, `letter-spacing: 0.055em`, muted |
| Monospace (Barkod/NFC) | `font-family: monospace` | 600 | |

---

## 5. Layout Sistemi

### 5.1 Grid & Kapsayıcı
- **Kapsayıcı:** `container-fluid` — padding: `0 1rem` (mobile) → `0 1.5rem` (desktop)
- **Ana grid:** Bootstrap 12 kolon
- **Gutter:** `g-3` varsayılan, `g-4` büyük bölümler arası

### 5.2 Sayfa Yapısı (Wireframe)

```
┌─────────────────────────────────────────────────────┐
│  STICKY NAVBAR (60px yükseklik)                     │
│  [logo]  nav links...            [kullanıcı ▼]      │
├─────────────────────────────────────────────────────┤
│  PAGE HEADER                                        │
│  eyebrow + h2 title        [aksiyon butonları]      │
├─────────────────────────────────────────────────────┤
│  FILTER TOOLBAR (opsiyonel)                         │
│  [filtre 1] [filtre 2] [filtre 3]    [Ara] [Temizle]│
├─────────────────────────────────────────────────────┤
│  MAIN CONTENT                                       │
│  (tablolar, kartlar, formlar — sayfa bazlı)         │
└─────────────────────────────────────────────────────┘
```

### 5.3 Sidebar (Alternatif Konsept)
Büyük ekranlarda kalıcı sol panel düşünülebilir:
- Genişlik: `240px` (açık) / `64px` (collapsed, ikon only)
- Arka plan: `var(--color-surface)` + `border-right: 1px solid var(--color-border)`
- Nav item yüksekliği: `44px`, `border-radius: 8px`
- Active: sol kenar `3px solid var(--color-primary)` + `background: var(--color-primary-light)`

---

## 6. Bileşen Kütüphanesi

### 6.1 Navbar

```
Görsel özellikler:
- Arka plan: rgba(255,255,255,0.91) + backdrop-filter: blur(10px)
- Alt kenarlık: 1px solid var(--color-border)
- Box-shadow: 0 1px 12px rgba(20,58,70,0.06)
- Yükseklik: 60px

Logo:
- Rozet: 2.1rem × 2.1rem, border-radius: 0.68rem
- Gradient: linear-gradient(135deg, #1b8397, #15596d)
- İkon: fa-capsules, white
- Metin: "İlaç" (dark) + "Stok" (teal), font-weight: 700

Nav linkler:
- Padding: 0.52rem 0.7rem, border-radius: 0.55rem
- Font-size: 0.88rem, font-weight: 500
- Hover/Active: background hsl(194,40%,93%), renk teal

Dropdown menü:
- border: none, box-shadow: 0 8px 24px rgba(0,0,0,0.1)
- border-radius: 0.75rem

Sağ: Kullanıcı dropdown → Çıkış Yap (danger icon)
```

### 6.2 Stat Kartları (KPI)

```
Boyut: min-height 120px, padding 1.35rem, border-radius: 1rem
Arka plan: gradient (--grad-primary, --grad-danger, --grad-warning, --grad-success)
İçerik:
  - Eyebrow: 0.7rem, CAPS, %50 beyaz opacity, letter-spacing: 0.08em
  - Büyük sayı: display-5, font-weight: 800
  - Sağ: büyük ikon (3rem, opacity: 0.2, absolute konumlu)

Animasyon:
  - Sayfa yüklenirken: sayaç efekti (0 → hedef değer, 1.2s)
  - Hover: scale(1.02) + box-shadow artışı
```

### 6.3 Genel Kartlar

```css
.card {
  background: var(--color-surface);
  border: 1px solid var(--color-border);
  border-radius: 1rem;
  box-shadow: 0 5px 20px rgba(17,56,67,0.045);
  transition: box-shadow 0.25s ease;
}
.card:hover { box-shadow: 0 9px 28px rgba(17,56,67,0.08); }

.card-header {
  padding: 1rem 1.25rem;
  background: transparent;
  border-bottom: 1px solid var(--color-border-muted);
  font-weight: 600;
  font-size: 0.88rem;
}
```

### 6.4 Tablolar

```
Thead:
  - background: hsl(200,15%,96%)
  - font-size: 0.68rem, ALL CAPS, muted
  - letter-spacing: 0.055em
  - padding: 0.8rem 0.75rem
  - border-bottom: 2px solid var(--color-border)

Tbody tr:
  - border-bottom: 1px solid var(--color-border-muted)
  - transition: background 0.15s

Tbody tr:hover:
  - background: hsl(194,40%,98%)

Tbody td:
  - padding: 0.8rem 0.75rem
  - vertical-align: middle
  - font-size: 0.875rem

Özel sütunlar:
  - İlaç adı: font-weight 600, clamp 2 satır
  - Miad: renk kodlamalı (kırmızı/turuncu/yeşil)
  - Barkod: monospace, 0.78rem
  - Aksiyonlar: sağa yaslanmış, icon butonlar
  - Miktar: metin merkez, bold
```

### 6.5 Butonlar

```css
/* Base */
.btn {
  border-radius: 0.62rem;
  padding: 0.55rem 1rem;
  font-size: 0.88rem;
  font-weight: 500;
  transition: all 0.2s ease;
}

/* Primary */
.btn-primary { background: #176b87; border-color: #176b87; }
.btn-primary:hover {
  background: #10576e;
  box-shadow: 0 5px 14px rgba(23,107,135,0.22);
  transform: translateY(-1px);
}

/* Small */
.btn-sm { padding: 0.38rem 0.7rem; font-size: 0.8rem; border-radius: 0.5rem; }

/* Large */
.btn-lg { padding: 0.75rem 1.5rem; font-size: 1rem; border-radius: 0.75rem; }

/* Icon-only */
.btn-icon { width: 34px; height: 34px; padding: 0; border-radius: 8px; }
```

### 6.6 Form Elemanları

```css
.form-control, .form-select {
  border: 1px solid var(--color-border);
  border-radius: 0.62rem;
  padding: 0.62rem 0.8rem;
  font-size: 0.88rem;
  transition: border-color 0.2s, box-shadow 0.2s;
}
.form-control:focus, .form-select:focus {
  border-color: var(--color-primary);
  box-shadow: 0 0 0 3px var(--color-primary-glow);
  outline: none;
}
.form-label {
  font-size: 0.8rem;
  font-weight: 600;
  color: var(--color-text-muted);
  margin-bottom: 0.35rem;
}
```

### 6.7 Badge'ler

```css
/* Temel */
.badge { border-radius: 0.45rem; padding: 0.3em 0.65em; font-weight: 600; font-size: 0.72rem; }

/* Soft (pastel) */
.badge-soft-primary { background: hsl(194,50%,94%); color: #176b87; }
.badge-soft-success { background: hsl(163,55%,94%); color: #2c957b; }
.badge-soft-danger  { background: hsl(357,55%,95%); color: #d95f5f; }
.badge-soft-warning { background: hsl(38,100%,93%); color: #dba43e; }

/* NFC Badge */
.nfc-badge {
  font-family: monospace; font-size: 0.62rem; font-weight: 700;
  padding: 0.12em 0.4em; border-radius: 4px;
  background: hsl(45,100%,93%); color: hsl(30,80%,38%);
  border: 1px solid hsl(45,80%,75%);
}

/* ATC Badge */
.atc-badge { font-size: 0.78rem; font-weight: 700; letter-spacing: 0.4px; border-radius: 6px; }

/* Reçete Badge */
.recete-badge { font-size: 0.67rem; border-radius: 4px; padding: 0.2em 0.5em; }
```

### 6.8 Alert'ler

```css
.alert { border-radius: 0.75rem; border: none; box-shadow: 0 4px 12px rgba(0,0,0,0.06); font-size: 0.875rem; }
.alert-success { background: hsl(163,55%,94%); color: hsl(163,60%,24%); }
.alert-danger  { background: hsl(357,55%,95%); color: hsl(357,60%,35%); }
.alert-warning { background: hsl(38,100%,93%); color: hsl(30,80%,30%); }
```

### 6.9 Modal'lar

```css
.modal-content {
  border: none; border-radius: 1rem;
  box-shadow: 0 20px 60px rgba(0,0,0,0.15);
}
.modal-header { border-bottom: 1px solid var(--color-border); padding: 1.25rem 1.5rem; }
.modal-footer { border-top: 1px solid var(--color-border); padding: 1rem 1.5rem; }
/* Z-index: modal 1060, backdrop 1050 */
```

### 6.10 Filter Toolbar Kartı

```
Birçok sayfada tekrarlanan filtre çubuğu:
- background: white, border-radius: 0.75rem
- padding: 0.75rem 1rem
- box-shadow: 0 2px 8px rgba(0,0,0,0.05)
- Yatay flex, gap: 0.75rem, align-items: flex-end
- Her filtre: label (0.75rem, semibold, muted) + input/select (height: 36px)
- Sağda: Ara butonu + Temizle linki
```

---

## 7. Sayfa Detayları

### 7.1 Login (`/login`)

```
Layout: Tam ekran, dikey + yatay ortalanmış

Kart:
  - Genişlik: 400px, max-width: 100%
  - Padding: 2.5rem, border-radius: 1.25rem
  - Box-shadow: 0 20px 55px rgba(17,56,67,0.13)

Sıralama (yukarıdan aşağı):
  1. Logo rozet (3.8rem, merkez, gradient teal)
  2. Eyebrow: "GÜVENLİ OPERASYON"
  3. H3: "İlaçStok" (bold)
  4. P: "Stok operasyonunuza devam edin." (muted)
  5. [Opsiyonel hata alert]
  6. Form:
     - Kullanıcı Adı (lg input)
     - Parola (lg input)
     - "Giriş Yap →" (btn-primary, full-width, lg)
```

### 7.2 Dashboard (`/`)

**Sayfa Başlığı:**
```
Sol: Eyebrow "OPERASYON MERKEZİ" + H2 "Stok Görünümü"
Sağ: "Stok Hareketleri" butonu
```

**4 KPI Stat Kartı:**

| # | Başlık | Renk | İkon | Veri |
|---|--------|------|------|------|
| 1 | Toplam Stok | primary (teal) | fa-boxes-stacked | Tüm depolardaki toplam adet |
| 2 | Kritik Stoklar | danger | fa-triangle-exclamation | Eşik altı jenerik grup sayısı |
| 3 | Miadı Yaklaşanlar | warning | fa-clock-rotate-left | 90 gün içindeki parti sayısı |
| 4 | Depo Sayısı | success | fa-warehouse | Aktif depo sayısı |

**İki Tablo Bölümü (2×6 kolon):**

```
Sol: KRİTİK STOKLAR
  Sütunlar: İlaç Adı | Mevcut Miktar | Kritik Sınır
  Header sağ: "Tümü" → /stock

Sağ: MİADI YAKLAŞANLAR (Son 90 Gün)
  Sütunlar: İlaç | Parti | Miad | Miktar (Depo)
  Miad renk: <30g kırmızı, <90g turuncu
  Header sağ: "Tümü" → /stock
```

### 7.3 İlaç Kataloğu (`/drugs`)

**Başlık:**
```
Sol: H2 "İlaç Kataloğu" + badge "[N] İlaç"
Sağ: Bilgi Kartı Yönetimi | CSV'den Aktar | Jenerik Kritik Stok | Yeni İlaç Ekle
```

**Filter Toolbar (7 filtre):**
1. Hızlı Arama (text, debounced)
2. Reçete Türü (multi-select dropdown, checkbox)
3. Bilgi Kartı / Özellik (multi-select dropdown)
4. ATC Kodu (text veya dropdown)
5. Sıralama (select: A→Z, Z→A, Stok Azalan/Artan)
6. Ara butonu
7. Temizle linki

**İlaç Tablosu sütunları:**
```
#  | İlaç Adı (bold) + Etken madde (muted, küçük)
   | Barkod (monospace)
   | NFC Kodu (nfc-badge, opsiyonel)
   | ATC Kodu (atc-badge)
   | Reçete Türü (recete-badge)
   | Bilgi Kartları (özellik badge'leri)
   | Raf Konumu (muted)
   | Kritik Stok (sayısal)
   | Aksiyonlar: [Düzenle] [Sil]
```

**Modal'lar:**
- Bilgi Kartı Yönetimi (CRUD — ikon, isim, renk, açıklama)
- Silme Onayı

### 7.4 Yeni İlaç / Düzenle (`/drugs/add`, `/drugs/edit/:id`)

**Layout:** Tek kolon, centered (max-width: 860px)

**Form Bölümleri (her biri ayrı kart):**

```
[1] TEMEL BİLGİLER
    - Barkod* (input + "Master'dan Ara" butonu)
    - İlaç Adı* (text)
    - Etken Madde (text)
    - Üretici (text)
    - Birim* (select: Kutu, Ampul, Flakon, Tablet...)

[2] SINIFLANDIRMA
    - Jenerik Kodu / Adı / Grubu (3 input)
    - ATC Kodu (text)
    - NFC Kodu (monospace input)
    - Reçete Türü (select)

[3] AMBALAJ & DEPOLAMA
    - Ambalaj (text)
    - Koli İçi Adet (number)
    - Raf Konumu (text)

[4] STOK AYARLARI
    - Kritik Stok Sınırı (number, default: 10)

[5] BİLGİ KARTLARI
    - Checkbox group (ikon + isim + renk rozet)

[Kaydet / Güncelle butonu — primary, lg]
```

### 7.5 Stok Durumu (`/stock`)

**Başlık:**
```
Sol: H2 (görünüm moduna göre)
     "Jenerik Bazlı Stok Durumu" veya "Müstahzar (Marka) Bazlı Stok Durumu"
Sağ: Excel'e Aktar | Yedekle | Toplu Giriş | Toplu Çıkış | Hareketler
```

**Görünüm Mod Toggle:**
```
[ Jenerik Bazlı | Müstahzar (Marka) Bazlı ]
Segmented button group, active: solid primary
```

**Filter Toolbar (6 filtre):**
1. Depo (select)
2. Kritik stok toggle (checkbox)
3. Miad uyarısı (select)
4. Sıralama (select)
5. Metin arama
6. Ara + Temizle

**Stok Tablosu — Jenerik Görünüm:**
```
Sütunlar:
  Grup Adı (bold) | Markalar (muted) | Toplam Stok | Kritik Sınır | Durum | Aksiyonlar

Kritik satır:
  - sol kenar: 3px solid var(--color-danger)
  - arkaplan: hsl(357,55%,98%)

Durum badge:
  - Yeterli → soft-success
  - Kritik  → soft-warning
  - Kritik Altı → soft-danger
```

**Stok Tablosu — Müstahzar Görünüm:**
```
Sütunlar: İlaç Adı + Barkod | Parti No | Miad | Depo | Miktar | Aksiyonlar
```

### 7.6 Stok Hareketleri (`/movements`)

**Başlık:**
```
Sol: H2 "Stok Hareketleri Geçmişi"
Sağ: Manuel Hareket Ekle | Toplu Giriş (PTS) | Toplu Çıkış
```

**Filter Toolbar (5 filtre):**
1. İşlem Tipi (select)
2. Depo (select)
3. Başlangıç Tarihi (date)
4. Bitiş Tarihi (date)
5. İlaç Arama (text)

**Hareket Tipi Renk Haritası:**

| Tip | İkon | Renk |
|-----|------|------|
| Toplu Giriş | fa-boxes-packing | success |
| Toplu Çıkış | fa-dolly | danger |
| Tekli Giriş | fa-arrow-down | success |
| Tekli Çıkış | fa-arrow-up | danger |
| Transfer | fa-arrows-left-right | info |
| Düzeltme | fa-pen-to-square | warning |
| Çapraz Depo | fa-building | purple |
| Çapraz Jenerik | fa-shuffle | teal |

**Hareket Tablosu:**
```
Sütunlar:
  - Tarih & Saat (monospace, 0.78rem)
  - İşlem Tipi (colored badge)
  - İlaç (bold) + Parti No (secondary badge)
  - Kaynak Depo → Hedef Depo (arrow)
  - Miktar (+N yeşil / -N kırmızı formatında)
  - Kullanıcı (muted)
  - Açıklama (truncate)
  - Toplu İşlem Kodu (monospace badge, opsiyonel)
```

### 7.7 Toplu Stok Girişi — PTS (`/drugs/bulk-entry`)

**Layout:** İki panel yatay (sol 7, sağ 5)

```
Sol Panel — İşlem Formu:
  - Depo seçimi (select, required)
  - Barkod alanı (büyük input, otofokus, tarayıcı dostu)
  - Auto-fill: İlaç adı, etken madde, NFC kodu
  - Parti No (text)
  - Miad (date)
  - Koli İçi Adet (number)
  - Miktar (büyük number input)
  - [Sepete Ekle] butonu (primary, lg)

Sağ Panel — Sepet:
  - Eklenmiş kalemler tablosu (scrollable)
  - Her satır: İlaç adı | Parti | Miad | Miktar | [Sil]
  - Alt: Toplam özeti
  - [Tüm Girişi Kaydet] (success, lg, full-width)
```

### 7.8 Toplu Stok Çıkışı (`/drugs/bulk-exit`)

Benzer iki-panel layout, farklılıklar:
- Depo: **kaynak** seçimi
- Stok yetersizse uyarı badge
- FEFO (First Expired First Out) otomatik öneri
- Çapraz Depo çıkışı seçeneği
- Çapraz Jenerik (muadil) çıkışı seçeneği

### 7.9 Depo Yönetimi (`/warehouses`)

**Layout:** 8+4 kolon

```
Sol (8) — Depo Listesi:
  Başlık: H2 "Depo Yönetimi" + "[N] Depo Mevcut" badge

  Her depo için kart:
    - Kodu badge (primary pill) + Adı (h4) + Açıklama
    - Kabul Edilen Özellikler (bilgi kartı badge'leri)
    - Butonlar: [Stoklar] [Düzenle] [Sil]

Sağ (4) — Yeni Depo Formu:
  Kart:
    - Eyebrow: "YENİ DEPO EKLE"
    - Depo Kodu* (uppercase hint)
    - Depo Adı*
    - Açıklama (textarea)
    - Kabul Edilen Özellikler (checkbox group)
    - [Kaydet] butonu
```

---

## 8. Özel UI Desenleri

### 8.1 Miad Renk Sistemi
```
Geçmiş miad:  → kırmızı bold, danger-bg satır
0–30 gün:     → danger badge
31–90 gün:    → warning badge
90+ gün:      → success badge veya varsayılan
Belirtilmemiş → gri muted
```

### 8.2 Stok Durum Progress Mini
```
Yüzde = mevcut / kritik_sınır × 100
0–25%:   danger (kırmızı)
26–75%:  warning (turuncu)
76%+:    success (yeşil)
```

### 8.3 Sayı Formatlaması
- Stok adetleri: `1.234` (Türkçe nokta ayracı)
- Tarihler: `DD.MM.YYYY`
- Saat: `HH:mm` (24 saat)

### 8.4 Boş Durum (Empty State)
```
<tr>
  <td colspan="N" class="empty-state text-center py-5 text-muted">
    <i class="fa-solid fa-circle-info fs-2 d-block mb-2"></i>
    [Açıklama metni]
  </td>
</tr>
```

### 8.5 Yükleme Durumu
- Sayfa girişi: `fade-in` (opacity + translateY, 0.4s)
- Buton submit: spinner + "Yükleniyor..."
- Tablo yüklenirken: skeleton shimmer satırlar

### 8.6 Toplu İşlem Kodu Badge
```
toplu_islem_kodu → küçük monospace badge
Aynı kod → hover'da ilgili satırlar vurgulanır
```

---

## 9. Animasyon & Etkileşim

### 9.1 Geçişler
```css
transition: all 0.2s ease;                    /* tüm interaktif elementler */
.btn:hover      { transform: translateY(-1px); }
.card:hover     { box-shadow: 0 9px 28px rgba(17,56,67,0.08); }
table tr:hover  { background: hsl(194,40%,98%); } /* transform yok */
```

### 9.2 Sayfa Girişi
```css
@keyframes fadeIn {
  from { opacity: 0; transform: translateY(8px); }
  to   { opacity: 1; transform: translateY(0); }
}
main { animation: fadeIn 0.4s ease forwards; }
```

### 9.3 Stat Kart Sayaç
- 0 → hedef değer animasyonu
- Duration: 1.2s, easing: `cubic-bezier(0.2, 0.6, 0.4, 1)`

### 9.4 Toast Bildirimleri
- Sağ üstten kayan toast (yerine form alert gelebilir)
- 4 saniye sonra otomatik kapanır
- Tipler: success, danger, warning

---

## 10. Duyarlılık (Responsive)

### 10.1 Breakpoint'ler
```
xs  < 576px  — mobil
md  ≥ 768px  — tablet
lg  ≥ 992px  — küçük laptop
xl  ≥ 1200px — desktop (birincil hedef)
```

### 10.2 Navbar
- `lg` altında: hamburger menü, linkler dikey

### 10.3 Tablolar
- `table-responsive` div içinde (yatay scroll)
- `md` altında gizlenen sütunlar: Üretici, Raf Konumu, ATC Kodu
- Her zaman görünür: İlaç Adı, Miktar, Aksiyonlar

### 10.4 Form Layout
- `lg`+: 2–3 kolon
- `md`-: tek kolon

### 10.5 Stat Kartlar
```
xl: col-xl-3 (4'lü)
md: col-md-6 (2'li)
xs: col-12  (1'li)
```

---

## 11. Erişilebilirlik

- `aria-label` ve `role` tüm interaktif elemanlarda
- WCAG AA kontrast (≥ 4.5:1 metin)
- Klavye navigasyonu: Tab sırası mantıklı, focus ring görünür
- Form `for`/`id` eşleşmesi
- Hata durumu: `aria-invalid`, `aria-describedby`
- Ekran okuyucu için `sr-only` gizli metinler

---

## 12. Teknik Kısıtlar & Notlar

1. **SSR:** Jinja2 şablon motoru. Sayfa geçişleri tam reload. SPA değil.
2. **Bootstrap 5.3** bağımlılığı aktif — kolon sistemi, yardımcı sınıflar kullanılıyor.
3. **FontAwesome 6.4** ikon seti.
4. **JavaScript:** Vanilla JS (`app.js`). Büyük framework yok.
5. **Z-index:** modal `1060`, backdrop `1050` (dropdown çakışması önlemi).
6. **Form submit:** Standart HTML POST, filtreler GET.
7. **SQLite** backend — yüksek eşzamanlılık senaryosu yok.

---

## 13. Stitch İçin Öneriler

### 13.1 Tasarım Direktifleri
- **Tema:** Açık mod (light) öncelikli
- **Karmaşıklık:** Orta-yüksek — tablolar, modallar, formlar, filtreleme
- **Hissettirme:** Premium klinik yazılım — sade ama güçlü
- **Stil referansı:** Linear.app, Vercel Dashboard, Notion (minimal + işlevsel)

### 13.2 Korunacak Kritik Özellikler
1. Teal `#176b87` primary rengi (marka rengi)
2. Navbar'daki gradient rozet logo
3. Stat kartlarındaki gradient arka planlar
4. Reçete türü renk sistemi (5 renk)
5. NFC ve ATC badge stilleri
6. `eyebrow` label komponenti (small CAPS, teal, letter-spacing)
7. `clamp-2-lines` / `clamp-1-line` metin kısaltma sınıfları

### 13.3 İyileştirme Fırsatları
1. Dashboard: Stok trend grafiği (son 30 gün giriş/çıkış)
2. Dashboard: Hızlı barkod tarama kısayolu
3. İlaç arama: Debounce + otomatik suggest
4. Toplu işlemler: Sepet durumunu localStorage'a kaydet (sayfa reload dayanıklı)
5. Toast notification merkezi
6. Büyük ekranlarda kalıcı sol sidebar navigasyonu

### 13.4 Dosya Referansları
```
app/static/css/app.css        ← Tüm custom CSS
app/templates/base.html       ← Navbar + layout shell
app/templates/dashboard.html  ← Dashboard KPI + tablolar
app/templates/drugs.html      ← İlaç kataloğu (en karmaşık)
app/templates/stock.html      ← Stok durumu
app/templates/movements.html  ← Hareket geçmişi
app/templates/warehouses.html ← Depo yönetimi
app/models.py                 ← Veri modelleri (alan referansı)
```

---

## 14. Veri Modeli Özeti (UI Açısından)

```
Ilac (İlaç)
  ├── id, barkod, ad, etken_madde
  ├── jenerik_kodu, jenerik_adi, jenerik_grubu
  ├── atc_kodu, nfc_kodu, recete_turu
  ├── ambalaj, birim, koli_ici_adet
  ├── raf_konumu, uretici, kritik_stok
  ├── partiler → Parti[]
  └── ozellikler → IlacOzellik[]

Parti (Lot/Batch)
  ├── parti_no, miad, koli_ici_adet
  ├── ilac → Ilac
  └── stoklar → Stok[]

Stok
  ├── depo_id → Depo
  ├── parti_id → Parti
  └── miktar, raf_konumu, koli_ici_adet

Depo
  ├── kod, ad, aciklama
  └── ozellikler → IlacOzellik[] (kabul kısıtları)

StokHareketi
  ├── tarih, hareket_tipi
  ├── depo_id, hedef_depo_id (transfer için)
  ├── parti_id, miktar, aciklama
  └── kullanici_id, toplu_islem_kodu

IlacOzellik (Bilgi Kartı)
  └── kod, ad, renk, ikon, aciklama, resim_url

JenerikKritikStok
  └── grup_kodu, grup_adi, kritik_stok
```

---

*Bu belge İlaçStok v2.0 Stitch yeniden tasarımı için kaynak dokümandır.*
*Kod referansı: `/home/yusuf/Projeler/myp/ilac-stok/app/`*
