import sqlite3
import os

ATC_TREE = []
ATC_MAP = {}
ATC_BY_PARENT = {}
ATC_BY_LEVEL = {1: [], 2: [], 3: [], 4: [], 5: []}

LEVEL_NAMES = {
    1: "root",
    2: "iki",
    3: "uc",
    4: "dort",
    5: "bes"
}

def _load_atc_from_db():
    global ATC_TREE, ATC_MAP, ATC_BY_PARENT, ATC_BY_LEVEL

    base_dir = os.path.dirname(os.path.abspath(__file__))
    master_db_path = os.path.join(base_dir, "..", "masterdrugs", "medication_db.sqlite")
    if not os.path.exists(master_db_path):
        master_db_path = os.path.join("masterdrugs", "medication_db.sqlite")

    if not os.path.exists(master_db_path):
        print(f"Warning: Master DB not found at {master_db_path}")
        return

    try:
        conn = sqlite3.connect(master_db_path)
        cur = conn.cursor()
        cur.execute("SELECT atc_kodu, atc_adi, ust_kod, seviye, seviye_ad, tam_metin FROM atc_codes;")
        rows = cur.fetchall()
        conn.close()

        atc_map = {}
        by_parent = {}
        by_level = {1: [], 2: [], 3: [], 4: [], 5: []}

        for code, name, parent, seviye, seviye_ad, tam_metin in rows:
            code_clean = (code or "").strip().upper()
            name_clean = (name or "").strip()
            parent_clean = (parent or "").strip().upper() if parent else ""
            seviye_int = int(seviye) if seviye else 1
            seviye_ad_clean = (seviye_ad or LEVEL_NAMES.get(seviye_int, "root")).strip()

            if code_clean:
                info = {
                    "code": code_clean,
                    "name": name_clean,
                    "parent": parent_clean,
                    "level": seviye_int,
                    "level_name": seviye_ad_clean,
                    "tam_metin": tam_metin or f"{code_clean} - {name_clean}"
                }
                atc_map[code_clean] = info

                if parent_clean not in by_parent:
                    by_parent[parent_clean] = []
                by_parent[parent_clean].append(info)

                if seviye_int in by_level:
                    by_level[seviye_int].append(info)

        # Build full breadcrumb path & parent_path (skeleton)
        for code_clean, info in atc_map.items():
            curr = info
            path_parts = []
            visited = set()
            while curr and curr["code"] not in visited:
                visited.add(curr["code"])
                path_parts.append(f"{curr['code']} - {curr['name']}")
                p_code = curr["parent"]
                curr = atc_map.get(p_code) if p_code else None

            path_parts.reverse()
            info["full_path"] = " > ".join(path_parts)
            info["parent_path"] = " > ".join(path_parts[:-1]) if len(path_parts) > 1 else ""

        # Build nested tree hierarchy for get_atc_tree()
        def build_tree(parent_code=""):
            nodes = []
            children = by_parent.get(parent_code, [])
            for child in sorted(children, key=lambda x: x["code"]):
                node = {
                    "code": child["code"],
                    "name": child["name"],
                    "level": child["level"],
                    "level_name": child["level_name"],
                    "children": build_tree(child["code"])
                }
                nodes.append(node)
            return nodes

        ATC_TREE = build_tree("")
        ATC_MAP = atc_map
        ATC_BY_PARENT = by_parent
        ATC_BY_LEVEL = by_level

        level_summary = ", ".join([f"L{l}:{len(by_level[l])}" for l in sorted(by_level.keys())])
        print(f"Loaded {len(ATC_MAP)} ATC codes across 5 levels ({level_summary}) from master database ({master_db_path}).")
    except Exception as e:
        print(f"Error loading ATC codes from master database: {e}")

# Initialize on module import
_load_atc_from_db()

def get_atc_tree():
    """Returns the full 5-level ATC hierarchy tree parsed from master database."""
    return ATC_TREE

def get_atc_by_level(level: int) -> list:
    """Returns all ATC codes for a specific level (1=root, 2=iki, 3=uc, 4=dort, 5=bes)."""
    return ATC_BY_LEVEL.get(level, [])

def get_atc_children(parent_code: str = "") -> list:
    """Returns direct children of a given ATC parent code."""
    p_code = (parent_code or "").strip().upper()
    return ATC_BY_PARENT.get(p_code, [])

def get_atc_info(atc_kodu: str) -> dict:
    """
    Returns detailed ATC info for a code across all 5 levels of the skeleton hierarchy:
    1. Seviye (root): 14 kayıt (Örn: A - SİNDİRİM SİSTEMİ VE METABOLİZMA)
    2. Seviye (iki): 94 kayıt (Örn: A01 - AĞIZ PREPARATLARI)
    3. Seviye (uc): 269 kayıt (Örn: A01A)
    4. Seviye (dort): 923 kayıt (Örn: A01AA)
    5. Seviye (bes): 5.037 kayıt (Örn: A01AA01 - SODYUM FLORÜR)
    """
    if not atc_kodu or not isinstance(atc_kodu, str):
        return {
            "code": "",
            "name": "",
            "level": 0,
            "level_name": "",
            "level1_code": "",
            "level1_name": "",
            "level2_code": "",
            "level2_name": "",
            "level3_code": "",
            "level3_name": "",
            "level4_code": "",
            "level4_name": "",
            "level5_code": "",
            "level5_name": "",
            "skeleton": "",
            "full_path": "",
            "display_name": ""
        }

    code_clean = atc_kodu.strip().upper()

    # Determine 5-level codes by string lengths
    l1_c = code_clean[:1] if len(code_clean) >= 1 else ""
    l2_c = code_clean[:3] if len(code_clean) >= 3 else ""
    l3_c = code_clean[:4] if len(code_clean) >= 4 else ""
    l4_c = code_clean[:5] if len(code_clean) >= 5 else ""
    l5_c = code_clean[:7] if len(code_clean) >= 7 else ""

    item_info = ATC_MAP.get(code_clean)

    l1_info = ATC_MAP.get(l1_c)
    l2_info = ATC_MAP.get(l2_c)
    l3_info = ATC_MAP.get(l3_c)
    l4_info = ATC_MAP.get(l4_c)
    l5_info = ATC_MAP.get(l5_c)

    name = item_info["name"] if item_info else (
        l5_info["name"] if l5_info else (
            l4_info["name"] if l4_info else (
                l3_info["name"] if l3_info else (
                    l2_info["name"] if l2_info else (
                        l1_info["name"] if l1_info else ""
                    )
                )
            )
        )
    )

    skeleton = item_info["parent_path"] if item_info else (
        l1_info["full_path"] if l1_info else ""
    )

    full_path = item_info["full_path"] if item_info else (
        f"{l1_c} - {name}" if name else code_clean
    )

    display_name = f"{code_clean} - {name}" if name else code_clean

    return {
        "code": code_clean,
        "name": name,
        "level": item_info["level"] if item_info else (
            5 if len(code_clean) >= 7 else (
                4 if len(code_clean) >= 5 else (
                    3 if len(code_clean) >= 4 else (
                        2 if len(code_clean) >= 3 else (
                            1 if len(code_clean) >= 1 else 0
                        )
                    )
                )
            )
        ),
        "level_name": item_info["level_name"] if item_info else LEVEL_NAMES.get(
            5 if len(code_clean) >= 7 else (
                4 if len(code_clean) >= 5 else (
                    3 if len(code_clean) >= 4 else (
                        2 if len(code_clean) >= 3 else 1
                    )
                )
            ), "root"
        ),
        "level1_code": l1_c,
        "level1_name": l1_info["name"] if l1_info else "",
        "level2_code": l2_c,
        "level2_name": l2_info["name"] if l2_info else "",
        "level3_code": l3_c,
        "level3_name": l3_info["name"] if l3_info else "",
        "level4_code": l4_c,
        "level4_name": l4_info["name"] if l4_info else "",
        "level5_code": l5_c,
        "level5_name": l5_info["name"] if l5_info else "",
        "skeleton": skeleton,
        "full_path": full_path,
        "display_name": display_name
    }

def search_atc_codes(query: str, limit: int = 50) -> list:
    """Searches ATC codes and names across all 5 levels."""
    if not query or not isinstance(query, str):
        return []

    q = query.strip().upper()
    results = []
    for code, info in ATC_MAP.items():
        if q in code or q in info["name"].upper() or q in info["tam_metin"].upper():
            results.append(get_atc_info(code))
            if len(results) >= limit:
                break
    return results
