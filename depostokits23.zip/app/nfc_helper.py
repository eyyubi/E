import sqlite3
import os
import json

NFC_TREE = []
NFC_MAP = {}
BARCODE_NFC_MAP = {}

def _load_nfc_from_db():
    global NFC_TREE, NFC_MAP, BARCODE_NFC_MAP

    base_dir = os.path.dirname(os.path.abspath(__file__))
    master_db_path = os.path.join(base_dir, "..", "masterdrugs", "medication_db.sqlite")
    if not os.path.exists(master_db_path):
        master_db_path = os.path.join("masterdrugs", "medication_db.sqlite")

    if not os.path.exists(master_db_path):
        print(f"Warning: Master DB not found at {master_db_path}")
        return

    try:
        conn = sqlite3.connect(master_db_path)
        cur = conn.cursor()

        # 1. Load nfc_codes table
        cur.execute("SELECT nfc_kodu, nfc_adi, ust_kod FROM nfc_codes;")
        rows = cur.fetchall()

        nfc_map = {}
        for code, name, parent in rows:
            code_clean = (code or "").strip().upper()
            name_clean = (name or "").strip()
            parent_clean = (parent or "").strip().upper()
            if code_clean:
                nfc_map[code_clean] = {
                    "code": code_clean,
                    "name": name_clean,
                    "parent": parent_clean
                }

        # Build breadcrumbs and parent_path (skeleton)
        for code_clean, info in nfc_map.items():
            curr = info
            path_parts = []
            visited = set()
            while curr and curr["code"] not in visited:
                visited.add(curr["code"])
                path_parts.append(f"{curr['code']} - {curr['name']}")
                p_code = curr["parent"]
                curr = nfc_map.get(p_code) if p_code else None
            path_parts.reverse()
            info["full_path"] = " > ".join(path_parts)
            info["parent_path"] = " > ".join(path_parts[:-1]) if len(path_parts) > 1 else ""
            info["level"] = len(path_parts)

        # Build nested hierarchy tree
        def build_tree(parent_code="", level=1):
            nodes = []
            for code_clean, info in sorted(nfc_map.items(), key=lambda x: x[0]):
                if info["parent"] == parent_code:
                    children = build_tree(code_clean, level + 1)
                    nodes.append({
                        "code": code_clean,
                        "name": info["name"],
                        "level": level,
                        "children": children
                    })
            return nodes

        NFC_TREE = build_tree("", 1)
        NFC_MAP = nfc_map

        # 2. Load barcode to NFC mapping from master database products table
        b_map = {}
        try:
            from .pts_parser import clean_gtin
        except Exception:
            clean_gtin = None

        cur.execute("SELECT barkod, nfc FROM products WHERE nfc IS NOT NULL AND nfc != '';")
        for barkod, nfc in cur.fetchall():
            raw_b = str(barkod).replace("'", "").replace('"', '').strip()
            primary_nfc = str(nfc).strip().upper()
            if raw_b and primary_nfc:
                b_map[raw_b] = primary_nfc
                if clean_gtin:
                    cb = clean_gtin(raw_b)
                    if cb:
                        b_map[cb] = primary_nfc

        conn.close()

        # 3. Fallback to nfc-barkod-urunler.json if exists
        barcode_json_path = os.path.join(base_dir, "..", "nfc-barkod-urunler.json")
        if not os.path.exists(barcode_json_path):
            barcode_json_path = "nfc-barkod-urunler.json"

        if os.path.exists(barcode_json_path):
            try:
                with open(barcode_json_path, "r", encoding="utf-8") as f:
                    b_data = json.load(f)
                if isinstance(b_data, list):
                    for item in b_data:
                        raw_b = str(item.get("barkod", "")).replace("'", "").replace('"', '').strip()
                        nfc_list = item.get("nfc_kodlari", [])
                        if raw_b and nfc_list and len(nfc_list) > 0:
                            primary_nfc = str(nfc_list[0]).strip().upper()
                            if primary_nfc and raw_b not in b_map:
                                b_map[raw_b] = primary_nfc
                                if clean_gtin:
                                    cb = clean_gtin(raw_b)
                                    if cb:
                                        b_map[cb] = primary_nfc
            except Exception as e:
                print(f"Error reading nfc-barkod-urunler.json fallback: {e}")

        BARCODE_NFC_MAP = b_map
        print(f"Loaded {len(NFC_MAP)} NFC codes and {len(BARCODE_NFC_MAP)} barcode mappings from master database.")
    except Exception as e:
        print(f"Error loading NFC codes from master database: {e}")

# Initialize on module import
_load_nfc_from_db()

def get_nfc_tree():
    """Returns full NFC hierarchy tree parsed from master database."""
    return NFC_TREE

def get_nfc_code_by_barcode(barkod: str) -> str:
    """Returns primary NFC code associated with a barcode."""
    if not barkod:
        return ""
    clean_b = str(barkod).replace("'", "").replace('"', '').strip()
    if clean_b in BARCODE_NFC_MAP:
        return BARCODE_NFC_MAP[clean_b]
    try:
        from .pts_parser import clean_gtin
        cb = clean_gtin(clean_b)
        if cb in BARCODE_NFC_MAP:
            return BARCODE_NFC_MAP[cb]
    except Exception:
        pass
    return ""

def get_nfc_info(nfc_kodu: str) -> dict:
    """Returns detailed NFC info (code, name, skeleton, display_name)."""
    if not nfc_kodu or not isinstance(nfc_kodu, str):
        return {
            "code": "",
            "name": "",
            "skeleton": "",
            "display_name": ""
        }

    code_clean = nfc_kodu.strip().upper()
    info = NFC_MAP.get(code_clean)
    if info:
        full_path = info.get("full_path", "")
        parts = full_path.split(" > ")
        skeleton = " > ".join(parts[:-1]) if len(parts) > 1 else ""
        return {
            "code": code_clean,
            "name": info["name"],
            "skeleton": skeleton,
            "full_name": full_path,
            "display_name": f"{code_clean} - {info['name']}"
        }
    else:
        return {
            "code": code_clean,
            "name": "Tanımsız NFC",
            "skeleton": "",
            "full_name": code_clean,
            "display_name": f"{code_clean}"
        }
