from typing import Annotated
from fastapi import APIRouter, Request, Depends
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session, joinedload
import datetime
from sqlalchemy import func
from .. import database, models, auth

router = APIRouter(tags=["dashboard"])
templates = Jinja2Templates(directory="app/templates")

DbSession = Annotated[Session, Depends(database.get_db)]

@router.get("/", response_class=HTMLResponse)
async def dashboard(request: Request, db: DbSession):
    # Miadı yaklaşanlar (önümüzdeki 90 gün) - joinedload to eliminate N+1 queries
    today = datetime.date.today()
    ninety_days = today + datetime.timedelta(days=90)
    
    miadi_yaklasan_partiler = db.query(models.Parti).options(
        joinedload(models.Parti.ilac),
        joinedload(models.Parti.stoklar).joinedload(models.Stok.depo)
    ).filter(
        models.Parti.miad <= ninety_days,
        models.Parti.miad >= today
    ).all()
    
    yaklasanlar = []
    for parti in miadi_yaklasan_partiler:
        for stok in parti.stoklar:
            if stok.miktar > 0:
                yaklasanlar.append({
                    "ilac": parti.ilac.ad if parti.ilac else "Bilinmeyen İlaç",
                    "parti": parti.parti_no,
                    "miad": parti.miad,
                    "miktar": stok.miktar,
                    "depo": stok.depo.ad if stok.depo else "Bilinmeyen Depo"
                })
    
    # Kritik stoklar (Jenerik Grubu ve JenerikKritikStok bazlı hesaplama) - joinedload partiler & stoklar
    all_ilaclar = db.query(models.Ilac).options(
        joinedload(models.Ilac.partiler).joinedload(models.Parti.stoklar)
    ).all()
    jenerik_limits = db.query(models.JenerikKritikStok).all()
    limits_map = {l.grup_kodu: l.kritik_stok for l in jenerik_limits}
    
    jenerik_groups = {}
    for ilac in all_ilaclar:
        grup_kodu = ilac.jenerik_grubu if (ilac.jenerik_grubu and ilac.jenerik_grubu.strip()) else (ilac.jenerik_adi if (ilac.jenerik_adi and ilac.jenerik_adi.strip()) else (ilac.jenerik_kodu if (ilac.jenerik_kodu and ilac.jenerik_kodu.strip()) else (ilac.etken_madde if (ilac.etken_madde and ilac.etken_madde.strip()) else ilac.ad)))
        grup_adi = ilac.jenerik_grubu if (ilac.jenerik_grubu and ilac.jenerik_grubu.strip()) else (ilac.jenerik_adi if (ilac.jenerik_adi and ilac.jenerik_adi.strip()) else (ilac.etken_madde if (ilac.etken_madde and ilac.etken_madde.strip()) else ilac.ad))
        
        if grup_kodu not in jenerik_groups:
            jenerik_groups[grup_kodu] = {
                "grup_adi": grup_adi,
                "grup_kodu": grup_kodu,
                "ilaclar": [],
                "toplam_stok": 0,
                "default_sinir": 0
            }
        jenerik_groups[grup_kodu]["ilaclar"].append(ilac)
        jenerik_groups[grup_kodu]["default_sinir"] += (ilac.kritik_stok or 0)
        
        toplam_ilac_stok = sum([sum([s.miktar for s in p.stoklar]) for p in ilac.partiler])
        jenerik_groups[grup_kodu]["toplam_stok"] += toplam_ilac_stok
        
    kritik_stoklar = []
    kritik_stok_sayisi = 0
    for g_kodu, group in jenerik_groups.items():
        sinir = limits_map.get(g_kodu, group["default_sinir"])
        if sinir > 0 and group["toplam_stok"] <= sinir:
            kritik_stok_sayisi += 1
            markalar_str = ", ".join(list(set([i.ad for i in group["ilaclar"]])))
            kritik_stoklar.append({
                "ilac": f"{group['grup_adi']} ({markalar_str})",
                "toplam": group["toplam_stok"],
                "sinir": sinir
            })
            
    depo_sayisi = db.query(models.Depo).count()
    ilac_sayisi = len(all_ilaclar)
    jenerik_sayisi = len(jenerik_groups)
    
    return templates.TemplateResponse(
        request=request,
        name="dashboard.html",
        context={
            "request": request,
            "ilac_sayisi": ilac_sayisi,
            "jenerik_sayisi": jenerik_sayisi,
            "kritik_stok_sayisi": kritik_stok_sayisi,
            "miadi_yaklasan_sayisi": len(yaklasanlar),
            "depo_sayisi": depo_sayisi,
            "yaklasanlar": yaklasanlar,
            "kritik_stoklar": kritik_stoklar,
            "user": getattr(request.state, "user", None)
        }
    )


