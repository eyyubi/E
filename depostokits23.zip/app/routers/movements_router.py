from typing import Annotated, Optional
from fastapi import APIRouter, Request, Depends, Query
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session, joinedload
import datetime
from .. import database, models

router = APIRouter(prefix="/movements", tags=["movements"], strict_content_type=False)
templates = Jinja2Templates(directory="app/templates")

DbSession = Annotated[Session, Depends(database.get_db)]

@router.get("", response_class=HTMLResponse)
async def list_movements(
    request: Request,
    db: DbSession,
    depo_id: Annotated[Optional[str], Query()] = None,
    hareket_tipi: Annotated[Optional[str], Query()] = None,
    baslangic_tarihi: Annotated[Optional[str], Query()] = None,
    bitis_tarihi: Annotated[Optional[str], Query()] = None,
    q: Annotated[Optional[str], Query()] = None,
):
    bugun = datetime.date.today()
    on_gun_once = bugun - datetime.timedelta(days=10)

    bugun_str = bugun.strftime("%Y-%m-%d")
    on_gun_once_str = on_gun_once.strftime("%Y-%m-%d")

    clean_baslangic = baslangic_tarihi.strip() if (baslangic_tarihi and baslangic_tarihi.strip()) else on_gun_once_str
    clean_bitis = bitis_tarihi.strip() if (bitis_tarihi and bitis_tarihi.strip()) else bugun_str

    # Enforce max limit: end date cannot be in the future
    try:
        dt_bitis_check = datetime.datetime.strptime(clean_bitis, "%Y-%m-%d").date()
        if dt_bitis_check > bugun:
            clean_bitis = bugun_str
    except Exception:
        clean_bitis = bugun_str

    query = db.query(models.StokHareketi).options(
        joinedload(models.StokHareketi.parti).joinedload(models.Parti.ilac),
        joinedload(models.StokHareketi.depo),
        joinedload(models.StokHareketi.hedef_depo),
        joinedload(models.StokHareketi.kullanici)
    )

    clean_depo_id = int(depo_id) if (depo_id and str(depo_id).isdigit()) else None
    if clean_depo_id:
        query = query.filter((models.StokHareketi.depo_id == clean_depo_id) | (models.StokHareketi.hedef_depo_id == clean_depo_id))

    if hareket_tipi and hareket_tipi.strip():
        clean_tip = hareket_tipi.strip()
        if clean_tip == "Çapraz Depo":
            query = query.filter(models.StokHareketi.aciklama.ilike("%Çapraz Depo%"))
        elif clean_tip in ["Çapraz Jenerik", "Çapraz FEFO"]:
            query = query.filter((models.StokHareketi.aciklama.ilike("%Çapraz FEFO%")) | (models.StokHareketi.aciklama.ilike("%Muadil%")))
        else:
            query = query.filter(models.StokHareketi.hareket_tipi == clean_tip)

    if clean_baslangic:
        try:
            dt_start = datetime.datetime.strptime(clean_baslangic, "%Y-%m-%d")
            query = query.filter(models.StokHareketi.tarih >= dt_start)
        except Exception:
            pass

    if clean_bitis:
        try:
            dt_end = datetime.datetime.strptime(clean_bitis, "%Y-%m-%d").replace(hour=23, minute=59, second=59)
            query = query.filter(models.StokHareketi.tarih <= dt_end)
        except Exception:
            pass

    if q and q.strip():
        q_clean = f"%{q.strip()}%"
        # joinedload ile çakışmayı önlemek için arama ID'lerini alt sorguyla bul
        matching_ids = db.query(models.StokHareketi.id)\
            .join(models.Parti, models.StokHareketi.parti_id == models.Parti.id)\
            .join(models.Ilac, models.Parti.ilac_id == models.Ilac.id)\
            .filter(
                (models.Ilac.ad.ilike(q_clean)) |
                (models.Ilac.barkod.ilike(q_clean)) |
                (models.StokHareketi.aciklama.ilike(q_clean)) |
                (models.Parti.parti_no.ilike(q_clean))
            ).subquery()
        query = query.filter(models.StokHareketi.id.in_(matching_ids))

    all_movements = query.order_by(models.StokHareketi.tarih.desc()).limit(500).all()

    # Hareket ID bazında karekod sayılarını çek
    from sqlalchemy import func
    mov_ids = [m.id for m in all_movements]
    qr_giris_map = {}
    qr_cikis_map = {}
    if mov_ids:
        giris_rows = db.query(
            models.DepoKarekod.giris_hareket_id,
            func.count(models.DepoKarekod.id)
        ).filter(models.DepoKarekod.giris_hareket_id.in_(mov_ids)).group_by(models.DepoKarekod.giris_hareket_id).all()
        qr_giris_map = {r[0]: int(r[1] or 0) for r in giris_rows if r[0]}

        cikis_rows = db.query(
            models.DepoKarekod.cikis_hareket_id,
            func.count(models.DepoKarekod.id)
        ).filter(models.DepoKarekod.cikis_hareket_id.in_(mov_ids)).group_by(models.DepoKarekod.cikis_hareket_id).all()
        qr_cikis_map = {r[0]: int(r[1] or 0) for r in cikis_rows if r[0]}

    grouped_items = []
    bulk_groups = {}

    for h in all_movements:
        if h.hareket_tipi in ["Toplu Giriş", "Toplu Çıkış"]:
            if h.toplu_islem_kodu:
                group_key = h.toplu_islem_kodu
            else:
                dt_str = h.tarih.strftime("%Y-%m-%d %H:%M") if h.tarih else ""
                group_key = f"{h.hareket_tipi}_{h.depo_id}_{h.aciklama}_{dt_str}"

            if group_key not in bulk_groups:
                bulk_groups[group_key] = []
            bulk_groups[group_key].append(h)
        else:
            h_aciklama = h.aciklama or ""
            is_cross_depot = ("Çapraz Depo" in h_aciklama) or (h.hedef_depo_id is not None and h.hareket_tipi == "Transfer")
            is_cross_generic = ("Çapraz FEFO" in h_aciklama) or ("Muadil" in h_aciklama)
            ilac_obj = h.parti.ilac if (h.parti and h.parti.ilac) else None
            kutu_ici = getattr(h, "kutu_ici_adet", None) or (getattr(ilac_obj, "kutu_ici_adet", None) if ilac_obj else None) or 1
            kutu_sayisi = getattr(h, "kutu_sayisi", None) or (abs(h.miktar) // max(1, kutu_ici) if kutu_ici > 1 else abs(h.miktar))
            qr_cnt = qr_giris_map.get(h.id, 0) + qr_cikis_map.get(h.id, 0)

            grouped_items.append({
                "is_bulk": False,
                "id": h.id,
                "toplu_islem_kodu": h.toplu_islem_kodu or "",
                "pts_no": getattr(h, "pts_no", None) or "",
                "koli_no": getattr(h, "koli_no", None) or "",
                "kutu_sayisi": kutu_sayisi,
                "kutu_ici_adet": kutu_ici,
                "qr_count": qr_cnt,
                "tarih_iso": h.tarih.isoformat() if h.tarih else "",
                "tarih": h.tarih.strftime("%d.%m.%Y %H:%M:%S") if h.tarih else "-",
                "tarih_short": h.tarih.strftime("%d.%m.%Y") if h.tarih else "-",
                "saat_short": h.tarih.strftime("%H:%M:%S") if h.tarih else "",
                "hareket_tipi": h.hareket_tipi,
                "depo_ad": h.depo.ad if h.depo else "-",
                "hedef_depo_ad": h.hedef_depo.ad if h.hedef_depo else "-",
                "ilac_ad": ilac_obj.ad if ilac_obj else "Bilinmeyen İlaç",
                "barkod": ilac_obj.barkod if ilac_obj else "-",
                "jenerik": (ilac_obj.jenerik_grubu or ilac_obj.jenerik_adi or ilac_obj.jenerik_kodu or "-") if ilac_obj else "-",
                "atc": ilac_obj.atc_kodu if (ilac_obj and ilac_obj.atc_kodu) else "-",
                "nfc": ilac_obj.nfc_kodu if (ilac_obj and ilac_obj.nfc_kodu) else "-",
                "parti_no": h.parti.parti_no if h.parti else "-",
                "miad": h.parti.miad.strftime("%d.%m.%Y") if (h.parti and h.parti.miad) else "Belirtilmedi",
                "miktar": h.miktar,
                "koli_ici_adet": h.parti.koli_ici_adet if (h.parti and h.parti.koli_ici_adet) else (ilac_obj.koli_ici_adet if ilac_obj else 1),
                "raf_konumu": (ilac_obj.raf_konumu or "-") if ilac_obj else "-",
                "kullanici": h.kullanici.kullanici_adi if h.kullanici else "Sistem",
                "aciklama": h.aciklama or "Açıklama girilmedi.",
                "ilac_sayisi": 1,
                "ilaclar": [],
                "is_cross_depot": is_cross_depot,
                "is_cross_generic": is_cross_generic
            })

    for group_key, logs in bulk_groups.items():
        first = logs[0]
        toplam_miktar = sum(l.miktar for l in logs)
        toplam_kutu = 0
        toplam_qr = 0
        pts_set = set()
        koli_set = set()
        
        ilaclar_list = []
        has_bulk_cross_depot = False
        has_bulk_cross_generic = False

        for l in logs:
            ilac_obj = l.parti.ilac if (l.parti and l.parti.ilac) else None
            koli_ici = l.parti.koli_ici_adet if (l.parti and l.parti.koli_ici_adet) else (ilac_obj.koli_ici_adet if ilac_obj else 1)
            koli_parca = round(abs(l.miktar) / (koli_ici or 1), 2)
            l_aciklama = l.aciklama or ""
            kutu_ici = getattr(l, "kutu_ici_adet", None) or (getattr(ilac_obj, "kutu_ici_adet", None) if ilac_obj else None) or 1
            kutu_sayisi = getattr(l, "kutu_sayisi", None) or (abs(l.miktar) // max(1, kutu_ici) if kutu_ici > 1 else abs(l.miktar))
            qr_cnt = qr_giris_map.get(l.id, 0) + qr_cikis_map.get(l.id, 0)
            toplam_kutu += kutu_sayisi
            toplam_qr += qr_cnt
            if getattr(l, "pts_no", None):
                pts_set.add(l.pts_no)
            if getattr(l, "koli_no", None):
                koli_set.add(l.koli_no)

            is_item_cross_depot = ("Çapraz Depo" in l_aciklama) or (first.depo_id and l.depo_id != first.depo_id)
            is_item_cross_generic = ("Çapraz FEFO" in l_aciklama) or ("Muadil" in l_aciklama)

            if is_item_cross_depot:
                has_bulk_cross_depot = True
            if is_item_cross_generic:
                has_bulk_cross_generic = True

            ilaclar_list.append({
                "id": l.id,
                "ilac_ad": ilac_obj.ad if ilac_obj else "Bilinmeyen İlaç",
                "barkod": ilac_obj.barkod if ilac_obj else "-",
                "jenerik": (ilac_obj.jenerik_grubu or ilac_obj.jenerik_adi or ilac_obj.jenerik_kodu or "-") if ilac_obj else "-",
                "atc": ilac_obj.atc_kodu if (ilac_obj and ilac_obj.atc_kodu) else "-",
                "nfc": ilac_obj.nfc_kodu if (ilac_obj and ilac_obj.nfc_kodu) else "-",
                "parti_no": l.parti.parti_no if l.parti else "-",
                "miad": l.parti.miad.strftime("%d.%m.%Y") if (l.parti and l.parti.miad) else "-",
                "depo_ad": l.depo.ad if l.depo else "-",
                "miktar": l.miktar,
                "kutu_sayisi": kutu_sayisi,
                "kutu_ici_adet": kutu_ici,
                "pts_no": getattr(l, "pts_no", None) or "",
                "koli_no": getattr(l, "koli_no", None) or "",
                "qr_count": qr_cnt,
                "koli_parca": koli_parca,
                "koli_ici_adet": koli_ici,
                "raf_konumu": (ilac_obj.raf_konumu or "-") if ilac_obj else "-",
                "is_cross_depot": is_item_cross_depot,
                "is_cross_generic": is_item_cross_generic,
                "aciklama": l_aciklama
            })

        summary_title = f"{first.aciklama or first.hareket_tipi} ({len(logs)} Kalem İlaç)"

        grouped_items.append({
            "is_bulk": True,
            "id": first.id,
            "toplu_islem_kodu": first.toplu_islem_kodu or "",
            "pts_no": ", ".join(sorted(pts_set)),
            "koli_no": ", ".join(sorted(koli_set)),
            "kutu_sayisi": toplam_kutu,
            "kutu_ici_adet": 1,
            "qr_count": toplam_qr,
            "tarih_iso": first.tarih.isoformat() if first.tarih else "",
            "tarih": first.tarih.strftime("%d.%m.%Y %H:%M:%S") if first.tarih else "-",
            "tarih_short": first.tarih.strftime("%d.%m.%Y") if first.tarih else "-",
            "saat_short": first.tarih.strftime("%H:%M:%S") if first.tarih else "",
            "hareket_tipi": first.hareket_tipi,
            "depo_ad": first.depo.ad if first.depo else "-",
            "hedef_depo_ad": first.hedef_depo.ad if first.hedef_depo else "-",
            "ilac_ad": summary_title,
            "barkod": f"{len(logs)} Kalem İlaç",
            "jenerik": "-",
            "atc": "-",
            "nfc": "-",
            "parti_no": f"{len(logs)} Parti",
            "miad": "-",
            "miktar": toplam_miktar,
            "koli_ici_adet": 1,
            "raf_konumu": "-",
            "kullanici": first.kullanici.kullanici_adi if first.kullanici else "Sistem",
            "aciklama": first.aciklama or "Toplu İşlem",
            "ilac_sayisi": len(logs),
            "ilaclar": ilaclar_list,
            "is_cross_depot": has_bulk_cross_depot or ("Çapraz Depo" in (first.aciklama or "")),
            "is_cross_generic": has_bulk_cross_generic or ("Çapraz FEFO" in (first.aciklama or ""))
        })

    grouped_items.sort(key=lambda x: x["tarih_iso"], reverse=True)


    depolar = db.query(models.Depo).all()

    return templates.TemplateResponse(
        request=request,
        name="movements.html",
        context={
            "request": request,
            "hareketler": grouped_items,
            "depolar": depolar,
            "secili_depo": clean_depo_id,
            "secili_tip": hareket_tipi or "",
            "baslangic_tarihi": clean_baslangic,
            "bitis_tarihi": clean_bitis,
            "bugun_str": bugun_str,
            "q": q or "",
            "user": getattr(request.state, "user", None)
        }
    )

