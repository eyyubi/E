import csv
import io
import zipfile
import datetime
from datetime import date, timedelta
from typing import Annotated, List, Dict, Any, Optional
from fastapi import APIRouter, Depends, Request, UploadFile, File, Form, HTTPException, Response, Query, Body
from fastapi.responses import HTMLResponse, StreamingResponse, JSONResponse
from pydantic import BeforeValidator
from sqlalchemy.orm import Session, joinedload
from sqlalchemy import or_
import openpyxl

from app.database import get_db
from app.auth import get_current_user_from_cookie
from app.models import (
    Depo, Kullanici, ItsTransferKarekod, ItsKullanilanKarekod,
    DepoKarekod, ItsKarekod, ItsMiadiGecenKarekod, WarehouseLocation
)
from app.services.qr_basket_service import QRBasketService, ZintQRService, MedicineCodeService, GS1DataMatrixParser
from app.services.its_pts_service import ItsPtsService
from app.qr_parser import parse_qr_code
from fastapi.templating import Jinja2Templates

templates = Jinja2Templates(directory="app/templates")

router = APIRouter(prefix="/qr-basket", tags=["Karekod Yönetimi"], strict_content_type=False)


def _rows_to_csv_str(rows: List[Dict[str, Any]], sep: str = ";") -> str:
    if not rows:
        return ""
    output = io.StringIO()
    writer = csv.DictWriter(output, fieldnames=list(rows[0].keys()), delimiter=sep, lineterminator="\r\n")
    writer.writeheader()
    writer.writerows(rows)
    return output.getvalue()


def _rows_to_excel_bytes(rows: List[Dict[str, Any]], sheet_name: str = "Veri") -> io.BytesIO:
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = sheet_name
    if rows:
        headers = list(rows[0].keys())
        ws.append(headers)
        for r in rows:
            ws.append([r.get(h, "") for h in headers])
    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    return buf


def _parse_optional_int(v: Any) -> Optional[int]:
    if v is None or v == "" or str(v).lower() in ("none", "null", "undefined", "all"):
        return None
    if isinstance(v, int):
        return v
    s = str(v).strip()
    return int(s) if s.lstrip("-").isdigit() else None


DbSession = Annotated[Session, Depends(get_db)]
OptionalIntQuery = Annotated[Optional[int], BeforeValidator(_parse_optional_int), Query()]
JsonPayload = Annotated[Dict[str, Any], Body(default_factory=dict)]


def get_current_user_req(request: Request, db: DbSession) -> Kullanici:
    user = getattr(request.state, "user", None)
    if not user:
        user = get_current_user_from_cookie(request, db)
    if not user:
        raise HTTPException(status_code=401, detail="Oturum bulunamadı. Lütfen giriş yapınız.")
    return user


CurrentUser = Annotated[Kullanici, Depends(get_current_user_req)]


@router.get("", response_class=HTMLResponse)
def get_qr_basket_page(
    request: Request,
    db: DbSession,
    user: CurrentUser,
):
    depolar = db.query(Depo).order_by(Depo.ad.asc()).all()
    aktif_lokasyonlar = (
        db.query(WarehouseLocation)
        .filter(WarehouseLocation.is_active == True)
        .order_by(WarehouseLocation.pick_sequence.asc(), WarehouseLocation.code.asc())
        .all()
    )
    depo_lokasyonlar_map: Dict[int, List[str]] = {}
    for loc in aktif_lokasyonlar:
        if loc.depo_id and loc.code:
            depo_lokasyonlar_map.setdefault(loc.depo_id, []).append(loc.code)

    return templates.TemplateResponse(
        request=request,
        name="qr_basket.html",
        context={
            "request": request,
            "user": user,
            "depolar": depolar,
            "depo_lokasyonlar_map": depo_lokasyonlar_map
        }
    )


# =========================================================================
# 1. İTS KAREKOD ENVANTERİ ENDPOINT'LERİ (Masaüstü Uygulaması Karşılığı)
# =========================================================================

@router.get("/api/its/inventory")
def api_its_inventory(
    request: Request,
    db: DbSession,
    user: CurrentUser,
    page: Annotated[int, Query(ge=1)] = 1,
    limit: Annotated[Optional[int], Query(ge=1, le=500)] = None,
    per_page: Annotated[Optional[int], Query(ge=1, le=500)] = None,
    search: Annotated[str, Query()] = "",
    expiry_filter: Annotated[str, Query()] = "",
    sort: Annotated[str, Query()] = "expiry ASC",
):
    eff_limit = per_page or limit or 50
    res = QRBasketService.get_its_inventory_paginated(
        db=db,
        page=page,
        limit=eff_limit,
        search=search,
        expiry_filter=expiry_filter,
        sort=sort
    )
    return {"status": "success", "success": True, **res}


@router.post("/api/its/upload-sync")
@router.post("/api/its/sync-file", include_in_schema=False)
async def api_its_sync_file(
    request: Request,
    file: Annotated[UploadFile, File(...)],
    db: DbSession,
    user: CurrentUser,
    move_missing_to_used: Annotated[Optional[str], Form()] = None,
):
    content = await file.read()
    if not content:
        raise HTTPException(status_code=400, detail="Dosya içeriği boş.")

    should_move = True
    if move_missing_to_used is not None:
        should_move = str(move_missing_to_used).strip().lower() not in ("false", "0", "no", "off")

    res = QRBasketService.sync_its_inventory_from_file(
        db=db,
        file_bytes=content,
        filename=file.filename or "its.csv",
        move_missing_to_used=should_move
    )
    return res


@router.post("/api/its/move-to-transfer")
@router.post("/api/its/transfer", include_in_schema=False)
@router.post("/api/its/transfer-batch", include_in_schema=False)
def api_its_transfer(
    request: Request,
    payload: JsonPayload,
    db: DbSession,
    user: CurrentUser,
):
    ids = payload.get("ids")
    uids = payload.get("uids")
    gtin = payload.get("gtin")
    batch = payload.get("batch") or payload.get("bn")
    expiry = payload.get("expiry") or payload.get("xd")
    count = payload.get("count")
    ok, msg, moved = QRBasketService.transfer_its_to_pool(
        db=db,
        uids=uids,
        ids=ids,
        gtin=gtin,
        batch=batch,
        expiry=expiry,
        count=int(count) if count else None
    )
    return {
        "status": "success" if ok else "error",
        "success": ok,
        "moved": moved,
        "message": msg
    }


@router.get("/api/its/transfer")
@router.get("/api/its/transfer-pool", include_in_schema=False)
def api_its_transfer_pool(
    request: Request,
    db: DbSession,
    user: CurrentUser,
    show_exported: Annotated[bool, Query()] = False,
    search: Annotated[str, Query()] = "",
    page: Annotated[int, Query(ge=1)] = 1,
    limit: Annotated[Optional[int], Query(ge=0, le=1000)] = None,
    per_page: Annotated[Optional[int], Query(ge=0, le=1000)] = None,
):
    eff_limit = per_page if per_page is not None else (limit if limit is not None else 100)
    res = QRBasketService.get_its_transfer_pool(
        db=db,
        show_exported=show_exported,
        search=search,
        page=page,
        limit=eff_limit
    )
    return {"status": "success", "success": True, **res}


@router.post("/api/its/transfer/rollback")
@router.post("/api/its/transfer-rollback", include_in_schema=False)
def api_its_transfer_rollback(
    request: Request,
    payload: JsonPayload,
    db: DbSession,
    user: CurrentUser,
):
    ids = payload.get("ids")
    uids = payload.get("uids")
    ok, msg, restored = QRBasketService.rollback_transfer_pool_to_its(db, uids=uids, ids=ids)
    return {
        "status": "success" if ok else "error",
        "success": ok,
        "restored": restored,
        "message": msg
    }


@router.post("/api/its/transfer/clear-exported")
@router.post("/api/its/transfer-clear-exported", include_in_schema=False)
def api_its_transfer_clear_exported(
    request: Request,
    db: DbSession,
    user: CurrentUser,
):
    ok, msg = QRBasketService.clear_exported_transfer_pool(db)
    return {"status": "success" if ok else "error", "success": ok, "message": msg}


def _export_transfer_pool_response(
    db: Session,
    uids: Optional[List[str]] = None,
    ids: Optional[List[int]] = None,
    export_format: str = "csv",
    chunk_size: int = 1000
):
    query = db.query(ItsTransferKarekod)
    if ids:
        clean_ids = [int(x) for x in ids if str(x).isdigit()]
        query = query.filter(ItsTransferKarekod.id.in_(clean_ids))
    elif uids:
        query = query.filter(ItsTransferKarekod.uid.in_(uids))
    else:
        unexported = query.filter(ItsTransferKarekod.is_exported == False).all()
        if unexported:
            rows = unexported
        else:
            rows = query.order_by(ItsTransferKarekod.id.asc()).all()
        if not rows:
            raise HTTPException(status_code=400, detail="Dışa aktarılacak transfer kaydı bulunamadı.")
        query = None

    if query is not None:
        rows = query.order_by(ItsTransferKarekod.id.asc()).all()
        if not rows:
            raise HTTPException(status_code=400, detail="Dışa aktarılacak transfer kaydı bulunamadı.")

    ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")

    for r in rows:
        r.is_exported = True
    db.commit()

    if export_format == "excel":
        drug_map = QRBasketService.build_gtin_to_drug_map(db, [r.gtin for r in rows])
        excel_rows = []
        for r in rows:
            ilac = drug_map.get(r.gtin) or drug_map.get(MedicineCodeService.to_catalog_barcode(r.gtin))
            excel_rows.append({
                "GTIN": MedicineCodeService.normalize_gtin(r.gtin),
                "URUN_ADI": ilac.ad if ilac else f"Tanımsız İlaç ({r.gtin})",
                "SN": str(r.serial or "").strip(),
                "BN": str(r.batch or "").strip(),
                "EXP_DATE": r.expiry.strftime("%Y-%m-%d") if r.expiry else "",
                "TRANSFER_TARIHI": r.transfer_date.strftime("%Y-%m-%d") if r.transfer_date else ""
            })
        buf = _rows_to_excel_bytes(excel_rows, sheet_name="Transfer Havuzu")
        return StreamingResponse(
            buf,
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            headers={"Content-Disposition": f"attachment; filename=ITS_Transfer_{ts}.xlsx"}
        )

    # İTS Standart CSV: GTIN;SN;BN;EXP_DATE (YYYY-MM-DD)
    csv_rows = []
    for r in rows:
        exp_val = r.expiry
        if isinstance(exp_val, (datetime.date, datetime.datetime)):
            exp_str = exp_val.strftime("%Y-%m-%d")
        elif exp_val:
            parsed = QRBasketService.parse_expiry_date(str(exp_val))
            exp_str = parsed.strftime("%Y-%m-%d") if parsed else str(exp_val).strip()
        else:
            exp_str = ""

        csv_rows.append({
            "GTIN": MedicineCodeService.normalize_gtin(r.gtin),
            "SN": str(r.serial or "").strip(),
            "BN": str(r.batch or "").strip(),
            "EXP_DATE": exp_str
        })

    # 1000'erli Parçalı CSV İndir (.zip)
    if chunk_size and chunk_size > 0:
        zip_buf = io.BytesIO()
        num_chunks = max(1, (len(csv_rows) + chunk_size - 1) // chunk_size)
        with zipfile.ZipFile(zip_buf, "w", zipfile.ZIP_DEFLATED) as zf:
            for idx in range(num_chunks):
                chunk_rows = csv_rows[idx * chunk_size:(idx + 1) * chunk_size]
                csv_str = _rows_to_csv_str(chunk_rows, sep=";")
                zf.writestr(f"ITS_Transfer_{ts}_Part{idx + 1}.csv", csv_str.encode("utf-8"))
        zip_buf.seek(0)
        return StreamingResponse(
            zip_buf,
            media_type="application/zip",
            headers={"Content-Disposition": f"attachment; filename=ITS_Transfer_{ts}_Parcali.zip"}
        )
    else:
        # Tekli CSV İndir
        csv_str = _rows_to_csv_str(csv_rows, sep=";")
        return Response(
            content=csv_str.encode("utf-8"),
            media_type="text/csv; charset=utf-8",
            headers={"Content-Disposition": f"attachment; filename=ITS_Transfer_{ts}.csv"}
        )


@router.get("/api/its/transfer/export-csv")
def api_its_transfer_export_get(
    request: Request,
    db: DbSession,
    user: CurrentUser,
    chunk_size: Annotated[int, Query()] = 1000,
    format: Annotated[str, Query()] = "csv",
    ids: Annotated[Optional[str], Query()] = None,
):
    clean_ids = [int(x) for x in ids.split(",") if x.strip().isdigit()] if ids else None
    return _export_transfer_pool_response(
        db=db,
        ids=clean_ids,
        export_format=format.lower(),
        chunk_size=chunk_size
    )


@router.post("/api/its/transfer-export")
def api_its_transfer_export_post(
    request: Request,
    payload: JsonPayload,
    db: DbSession,
    user: CurrentUser,
):
    uids = payload.get("uids")
    ids = payload.get("ids")
    export_format = (payload.get("format") or "csv").lower()
    chunked = bool(payload.get("chunked", True))
    return _export_transfer_pool_response(
        db=db,
        uids=uids,
        ids=ids,
        export_format=export_format,
        chunk_size=1000 if chunked else 0
    )


@router.get("/api/its/used")
def api_its_used_list(
    request: Request,
    db: DbSession,
    user: CurrentUser,
    search: Annotated[str, Query()] = "",
    page: Annotated[int, Query(ge=1)] = 1,
    limit: Annotated[Optional[int], Query(ge=0, le=1000)] = None,
    per_page: Annotated[Optional[int], Query(ge=0, le=1000)] = None,
):
    eff_limit = per_page if per_page is not None else (limit if limit is not None else 100)
    res = QRBasketService.get_its_used_list(db, search=search, page=page, limit=eff_limit)
    return {"status": "success", "success": True, **res}


@router.post("/api/its/used/rollback")
@router.post("/api/its/used-rollback", include_in_schema=False)
def api_its_used_rollback(
    request: Request,
    payload: JsonPayload,
    db: DbSession,
    user: CurrentUser,
):
    ids = payload.get("ids")
    uids = payload.get("uids")
    ok, msg, restored = QRBasketService.rollback_used_to_its(db, uids=uids, ids=ids)
    return {
        "status": "success" if ok else "error",
        "success": ok,
        "restored": restored,
        "message": msg
    }


@router.post("/api/its/used/delete")
def api_its_used_delete(
    request: Request,
    payload: JsonPayload,
    db: DbSession,
    user: CurrentUser,
):
    ids = payload.get("ids")
    uids = payload.get("uids")
    ok, msg, deleted = QRBasketService.delete_its_used_items(db, uids=uids, ids=ids)
    return {
        "status": "success" if ok else "error",
        "success": ok,
        "deleted": deleted,
        "message": msg
    }


@router.post("/api/its/used/clear")
def api_its_used_clear(
    request: Request,
    db: DbSession,
    user: CurrentUser,
):
    ok, msg = QRBasketService.clear_all_its_used(db)
    return {"status": "success" if ok else "error", "success": ok, "message": msg}


@router.get("/api/its/used/export-csv")
def api_its_used_export(
    request: Request,
    db: DbSession,
    user: CurrentUser,
    search: Annotated[str, Query()] = "",
    format: Annotated[str, Query()] = "csv",
):
    res = QRBasketService.get_its_used_list(db, search=search, page=1, limit=0)
    items = res.get("items", [])
    if not items:
        raise HTTPException(status_code=400, detail="Dışa aktarılacak kullanılan karekod kaydı bulunamadı.")
    export_rows = [
        {
            "UID": it.get("uid", ""),
            "GTIN": it.get("gtin", ""),
            "URUN_ADI": it.get("drug_name", ""),
            "SERIAL": it.get("sn", ""),
            "BATCH": it.get("bn", ""),
            "EXPIRY": it.get("xd", ""),
            "TESPIT_TARIHI": it.get("used_at", "")
        }
        for it in items
    ]
    ts = datetime.datetime.now().strftime("%Y%m%d_%H%M")
    if format.lower() == "excel":
        buf = _rows_to_excel_bytes(export_rows, sheet_name="Kullanılan Karekodlar")
        return StreamingResponse(
            buf,
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            headers={"Content-Disposition": f"attachment; filename=ITS_Kullanilan_Karekodlar_{ts}.xlsx"}
        )
    csv_str = _rows_to_csv_str(export_rows, sep=";")
    return Response(
        content=csv_str.encode("utf-8-sig"),
        media_type="text/csv",
        headers={"Content-Disposition": f"attachment; filename=ITS_Kullanilan_Karekodlar_{ts}.csv"}
    )


@router.post("/api/its/delete")
def api_its_delete(
    request: Request,
    payload: JsonPayload,
    db: DbSession,
    user: CurrentUser,
):
    ids = payload.get("ids")
    uids = payload.get("uids")
    ok, msg, deleted = QRBasketService.delete_its_items(db, uids=uids, ids=ids)
    return {
        "status": "success" if ok else "error",
        "success": ok,
        "deleted": deleted,
        "message": msg
    }


@router.post("/api/its/reset")
def api_its_reset(
    request: Request,
    db: DbSession,
    user: CurrentUser,
):
    ok, msg = QRBasketService.reset_its_inventory(db)
    return {"status": "success" if ok else "error", "success": ok, "message": msg}


@router.get("/api/its/dashboard")
def api_its_dashboard(
    request: Request,
    db: DbSession,
    user: CurrentUser,
    filter_key: Annotated[Optional[str], Query()] = None,
    filter_type: Annotated[Optional[str], Query()] = None,
    search: Annotated[str, Query()] = "",
    sort: Annotated[str, Query()] = "name ASC",
):
    fk = filter_type or filter_key or "all_valid"
    if fk == "all":
        fk = "all_valid"
    res = QRBasketService.get_its_dashboard(db, filter_key=fk, search=search, sort=sort)
    return {"status": "success", "success": True, **res}


@router.get("/api/its/batch-detail")
def api_its_batch_detail_query(
    request: Request,
    gtin: Annotated[str, Query(...)],
    db: DbSession,
    user: CurrentUser,
    filter_key: Annotated[str, Query()] = "all_valid",
):
    batches = QRBasketService.get_its_gtin_batch_detail(db, gtin=gtin, filter_key=filter_key)
    norm_gtin = MedicineCodeService.normalize_gtin(gtin)
    drug_map = QRBasketService.build_gtin_to_drug_map(db, [norm_gtin])
    info = QRBasketService.resolve_drug_info(norm_gtin, drug_map)
    return {
        "status": "success",
        "success": True,
        "gtin": norm_gtin,
        "barkod": info["barkod"],
        "drug_name": info["drug_name"],
        "in_catalog": info["in_catalog"],
        "ilac_id": info["ilac_id"],
        "kutu_ici_adet": info["kutu_ici_adet"],
        "filter_key": filter_key,
        "batches": batches
    }


@router.get("/api/its/gtin-detail/{gtin}")
def api_its_gtin_detail(
    gtin: str,
    request: Request,
    db: DbSession,
    user: CurrentUser,
    filter_key: Annotated[str, Query()] = "all_valid",
):
    batches = QRBasketService.get_its_gtin_batch_detail(db, gtin=gtin, filter_key=filter_key)
    norm_gtin = MedicineCodeService.normalize_gtin(gtin)
    drug_map = QRBasketService.build_gtin_to_drug_map(db, [norm_gtin])
    info = QRBasketService.resolve_drug_info(norm_gtin, drug_map)
    return {
        "status": "success",
        "success": True,
        "gtin": norm_gtin,
        "barkod": info["barkod"],
        "drug_name": info["drug_name"],
        "in_catalog": info["in_catalog"],
        "ilac_id": info["ilac_id"],
        "kutu_ici_adet": info["kutu_ici_adet"],
        "filter_key": filter_key,
        "batches": batches
    }



@router.post("/api/pts/parse-for-print")
async def api_pts_parse_for_print(
    request: Request,
    file: Annotated[UploadFile, File(...)],
    db: DbSession,
    user: CurrentUser,
):
    content = await file.read()
    if not content:
        raise HTTPException(status_code=400, detail="Dosya içeriği boş.")
    return QRBasketService.parse_pts_for_printing(db, content, file.filename or "pts.xml")


@router.post("/api/its/get-boxes-by-gtins")
def api_its_get_boxes_by_gtins(
    request: Request,
    payload: JsonPayload,
    db: DbSession,
    user: CurrentUser,
):
    gtins = payload.get("gtins", [])
    filter_key = payload.get("filter_key", "all_valid")
    batch = payload.get("batch") or payload.get("bn")
    expiry = payload.get("expiry") or payload.get("xd")
    limit_count = int(payload.get("count") or payload.get("limit") or 3000)

    if not gtins:
        return {"status": "error", "success": False, "message": "GTIN listesi boş.", "items": []}

    QRBasketService._consolidate_expired_into_its_inventory(db)
    norm_gtins = [MedicineCodeService.normalize_gtin(g) for g in gtins if g]
    drug_map = QRBasketService.build_gtin_to_drug_map(db, norm_gtins)

    today = date.today()
    items = []
    exp_date = MedicineCodeService.parse_expiry_date(expiry) if expiry else None

    q = db.query(ItsKarekod).filter(ItsKarekod.gtin.in_(norm_gtins))
    if batch is not None and str(batch).strip() != "":
        q = q.filter(ItsKarekod.batch == str(batch).strip())
    if exp_date:
        q = q.filter(ItsKarekod.expiry == exp_date)
    else:
        if filter_key == "expired":
            q = q.filter(ItsKarekod.expiry < today)
        elif filter_key == "1m":
            q = q.filter(ItsKarekod.expiry >= today, ItsKarekod.expiry <= today + timedelta(days=30))
        elif filter_key == "3m":
            q = q.filter(ItsKarekod.expiry >= today, ItsKarekod.expiry <= today + timedelta(days=90))
        elif filter_key == "6m":
            q = q.filter(ItsKarekod.expiry >= today, ItsKarekod.expiry <= today + timedelta(days=180))
        elif filter_key != "all":
            q = q.filter(ItsKarekod.expiry >= today)
    all_rows = q.order_by(ItsKarekod.expiry.asc(), ItsKarekod.id.asc()).limit(limit_count).all()

    for b in all_rows:
        info = QRBasketService.resolve_drug_info(b.gtin, drug_map)
        d_name = info["drug_name"]
        items.append({
            "id": getattr(b, "id", None),
            "uid": getattr(b, "uid", ""),
            "gtin": b.gtin,
            "barkod": info["barkod"],
            "sn": b.serial,
            "serial": b.serial,
            "bn": b.batch or "",
            "batch": b.batch or "",
            "xd": b.expiry.strftime("%Y-%m-%d") if b.expiry else "",
            "expiry": b.expiry.strftime("%Y-%m-%d") if b.expiry else "",
            "drug_name": d_name,
            "product_name": d_name,
            "ad": d_name,
            "in_catalog": info["in_catalog"],
            "ilac_id": info["ilac_id"],
            "kutu_ici_adet": info["kutu_ici_adet"]
        })

    return {"status": "success", "success": True, "count": len(items), "items": items}


@router.post("/api/cart/quick-add")
def api_cart_quick_add(
    request: Request,
    payload: JsonPayload,
    db: DbSession,
    user: CurrentUser,
):
    scan_text = str(payload.get("scan_text") or "").strip()
    if not scan_text:
        return {"status": "error", "success": False, "message": "Okutulan metin boş."}

    # 1. Depo / Koli / Paket kontrolü
    depo_res = QRBasketService.lookup_depo_qr_or_koli(db, scan_text=scan_text)
    if depo_res.get("status") == "success" and depo_res.get("items"):
        gtins = [it.get("gtin", "") for it in depo_res["items"] if it.get("gtin")]
        drug_map = QRBasketService.build_gtin_to_drug_map(db, gtins)
        items = []
        for it in depo_res["items"]:
            info = QRBasketService.resolve_drug_info(it.get("gtin", ""), drug_map)
            items.append({
                "gtin": it.get("gtin", ""),
                "barkod": info["barkod"],
                "sn": it.get("sn") or it.get("serial", ""),
                "bn": it.get("bn") or it.get("batch", ""),
                "xd": it.get("xd") or it.get("expiry", ""),
                "drug_name": it.get("drug_name") or it.get("product_name") or info["drug_name"],
                "in_catalog": info["in_catalog"],
                "ilac_id": info["ilac_id"],
                "kutu_ici_adet": info["kutu_ici_adet"],
                "source": "depo"
            })
        return {
            "status": "success",
            "success": True,
            "count": len(items),
            "items": items,
            "message": f"Koli/Depodan {len(items)} adet kutu sepete eklendi."
        }

    # 2. GS1 DataMatrix Ayrıştırma
    parsed = GS1DataMatrixParser.parse(scan_text)
    if parsed.get("gtin") and parsed.get("serial"):
        drug_map = QRBasketService.build_gtin_to_drug_map(db, [parsed["gtin"]])
        info = QRBasketService.resolve_drug_info(parsed["gtin"], drug_map)
        d_name = info["drug_name"]
        return {
            "status": "success",
            "success": True,
            "count": 1,
            "items": [{
                "gtin": parsed["gtin"],
                "barkod": info["barkod"],
                "sn": parsed["serial"],
                "bn": parsed.get("batch", ""),
                "xd": parsed.get("expiry", ""),
                "drug_name": d_name,
                "in_catalog": info["in_catalog"],
                "ilac_id": info["ilac_id"],
                "kutu_ici_adet": info["kutu_ici_adet"],
                "source": "gs1"
            }],
            "message": f"Karekod sepete eklendi: {d_name}"
        }

    # 3. İlaç Kataloğu veya GTIN kontrolü
    norm_gtin = MedicineCodeService.normalize_gtin(scan_text)
    if norm_gtin:
        boxes = db.query(ItsKarekod).filter(ItsKarekod.gtin == norm_gtin).limit(100).all()
        if boxes:
            drug_map = QRBasketService.build_gtin_to_drug_map(db, [norm_gtin])
            info = QRBasketService.resolve_drug_info(norm_gtin, drug_map)
            d_name = info["drug_name"]
            items = []
            for b in boxes:
                items.append({
                    "gtin": b.gtin,
                    "barkod": info["barkod"],
                    "sn": b.serial,
                    "bn": b.batch or "",
                    "xd": b.expiry.strftime("%Y-%m-%d") if b.expiry else "",
                    "drug_name": d_name,
                    "in_catalog": info["in_catalog"],
                    "ilac_id": info["ilac_id"],
                    "kutu_ici_adet": info["kutu_ici_adet"],
                    "source": "its"
                })
            return {
                "status": "success",
                "success": True,
                "count": len(items),
                "items": items,
                "message": f"{d_name} için {len(items)} kutu sepete eklendi."
            }

    return {"status": "error", "success": False, "message": "Karekod veya koli kaydı bulunamadı."}


# =========================================================================
# 2. FİZİKSEL DEPO KAREKOD STOĞU & KOLİ/FEFO ÇIKIŞ ENDPOINT'LERİ
# =========================================================================

@router.get("/api/depo/inventory")
@router.get("/api/depo/qrcodes", include_in_schema=False)
def api_depo_qrcodes(
    request: Request,
    db: DbSession,
    user: CurrentUser,
    durum: Annotated[str, Query()] = "depoda",
    depo_id: Annotated[Optional[str], Query()] = None,
    parti_id: Annotated[Optional[str], Query()] = None,
    ilac_id: Annotated[Optional[str], Query()] = None,
    koli_no: Annotated[Optional[str], Query()] = None,
    pts_no: Annotated[Optional[str], Query()] = None,
    box_state: Annotated[Optional[str], Query()] = None,
    open_box_filter: Annotated[Optional[str], Query()] = None,
    search: Annotated[str, Query()] = "",
    page: Annotated[int, Query(ge=1)] = 1,
    limit: Annotated[Optional[int], Query(ge=1, le=500)] = None,
    per_page: Annotated[Optional[int], Query(ge=1, le=500)] = None,
):
    eff_limit = per_page or limit or 50
    eff_box_state = open_box_filter or box_state
    eff_depo_id = int(depo_id) if (depo_id and str(depo_id).isdigit()) else None
    eff_parti_id = int(parti_id) if (parti_id and str(parti_id).isdigit()) else None
    eff_ilac_id = int(ilac_id) if (ilac_id and str(ilac_id).isdigit()) else None

    res = QRBasketService.get_depo_qrcodes_paginated(
        db=db,
        durum=durum,
        depo_id=eff_depo_id,
        parti_id=eff_parti_id,
        ilac_id=eff_ilac_id,
        koli_no=koli_no,
        pts_no=pts_no,
        box_state=eff_box_state,
        search=search,
        page=page,
        limit=eff_limit
    )
    return {"status": "success", "success": True, **res}


@router.get("/api/depo/by-batch")
def api_depo_by_batch(
    request: Request,
    depo_id: Annotated[int, Query(...)],
    parti_id: Annotated[int, Query(...)],
    db: DbSession,
    user: CurrentUser,
):
    res = QRBasketService.get_depo_qrcodes_paginated(
        db=db,
        durum="all",
        depo_id=depo_id,
        parti_id=parti_id,
        page=1,
        limit=500
    )
    return {"status": "success", "success": True, **res}


@router.get("/api/depo/by-pts-or-koli")
def api_depo_by_pts_or_koli(
    request: Request,
    db: DbSession,
    user: CurrentUser,
    pts_no: Annotated[Optional[str], Query()] = None,
    koli_no: Annotated[Optional[str], Query()] = None,
    depo_id: Annotated[Optional[str], Query()] = None,
):
    """Depoya yüklenmiş bir PTS paketinin veya Kolinin (iç paketler dahil) tüm karekodlarını etiket basımı için getirir."""
    query = db.query(DepoKarekod).options(
        joinedload(DepoKarekod.ilac),
        joinedload(DepoKarekod.depo),
        joinedload(DepoKarekod.parti)
    )
    if depo_id and str(depo_id).isdigit():
        query = query.filter(DepoKarekod.depo_id == int(depo_id))
    if pts_no and pts_no.strip():
        query = query.filter(DepoKarekod.pts_no == pts_no.strip())
    if koli_no and koli_no.strip():
        k_clean = koli_no.strip()
        query = query.filter(or_(
            DepoKarekod.koli_no == k_clean,
            DepoKarekod.paket_no == k_clean,
            DepoKarekod.carrier_path.contains(f"|{k_clean}|")
        ))

    rows = query.order_by(DepoKarekod.id.asc()).limit(2000).all()
    items = []
    for b in rows:
        d_name = b.ilac.ad if b.ilac else f"Tanımsız İlaç ({b.gtin})"
        exp_s = b.expiry.strftime("%Y-%m-%d") if b.expiry else ""
        items.append({
            "id": b.id,
            "uid": b.uid,
            "gtin": b.gtin,
            "drug_name": d_name,
            "product_name": d_name,
            "ad": d_name,
            "sn": b.serial,
            "serial": b.serial,
            "bn": b.batch,
            "batch": b.batch,
            "xd": exp_s,
            "expiry": exp_s,
            "koli_no": b.koli_no or "",
            "paket_no": b.paket_no or "",
            "carrier_path": b.carrier_path or "",
            "pts_no": b.pts_no or "",
            "depo_ad": b.depo.ad if b.depo else "-",
            "kutu_ici_adet": b.kutu_ici_adet,
            "kalan_doz": b.kalan_doz,
            "durum": b.durum
        })
    return {"status": "success", "success": True, "count": len(items), "items": items}


@router.post("/api/depo/lookup-scan")
def api_depo_lookup_scan(
    request: Request,
    payload: JsonPayload,
    db: DbSession,
    user: CurrentUser,
):
    scan_text = payload.get("scan_text", "")
    depo_id = payload.get("depo_id")
    res = QRBasketService.lookup_depo_qr_or_koli(
        db=db,
        scan_text=scan_text,
        depo_id=int(depo_id) if (depo_id and str(depo_id).isdigit()) else None
    )
    return res


@router.post("/api/depo/exit-selected")
@router.post("/api/depo/exit-qrcodes", include_in_schema=False)
def api_depo_exit_qrcodes(
    request: Request,
    payload: JsonPayload,
    db: DbSession,
    user: CurrentUser,
):
    qr_ids = payload.get("qr_ids", [])
    aciklama = payload.get("aciklama", "")
    also_send_to_its_transfer = bool(payload.get("also_send_to_its_transfer", False))
    res = QRBasketService.execute_depo_qr_exit(
        db=db,
        user_id=user.id,
        qr_ids=[int(x) for x in qr_ids if str(x).isdigit()],
        aciklama=aciklama,
        also_send_to_its_transfer=also_send_to_its_transfer
    )
    return res


@router.get("/api/depo/by-movement")
def api_depo_by_movement(
    request: Request,
    db: DbSession,
    user: CurrentUser,
    hareket_id: OptionalIntQuery = None,
    toplu_islem_kodu: Annotated[Optional[str], Query()] = None,
):
    res = QRBasketService.get_qrcodes_for_movement(
        db=db,
        hareket_id=hareket_id,
        toplu_islem_kodu=toplu_islem_kodu
    )
    return {"status": "success", "success": True, **res}


# =========================================================================
# 3. ZINT GS1 DATAMATRIX ÖNİZLEME & ETİKET YAZDIRMA ENDPOINT'LERİ
# =========================================================================

@router.get("/api/preview-png")
def api_preview_png_get(
    user: CurrentUser,
    gtin: Annotated[str, Query()] = "",
    serial: Annotated[Optional[str], Query()] = None,
    sn: Annotated[Optional[str], Query()] = None,
    expiry: Annotated[Optional[str], Query()] = None,
    xd: Annotated[Optional[str], Query()] = None,
    batch: Annotated[Optional[str], Query()] = None,
    bn: Annotated[Optional[str], Query()] = None,
):
    png_bytes = ZintQRService.generate_datamatrix_png(
        gtin=gtin,
        serial=serial or sn or "",
        expiry=expiry or xd or "",
        batch=batch or bn or ""
    )
    return Response(content=png_bytes, media_type="image/png")


@router.post("/api/preview-png")
def api_preview_png_post(
    payload: JsonPayload,
    user: CurrentUser,
):
    png_bytes = ZintQRService.generate_datamatrix_png(
        gtin=str(payload.get("gtin") or ""),
        serial=str(payload.get("serial") or payload.get("sn") or ""),
        expiry=str(payload.get("expiry") or payload.get("xd") or ""),
        batch=str(payload.get("batch") or payload.get("bn") or "")
    )
    return Response(content=png_bytes, media_type="image/png")


@router.post("/api/print-zpl")
def print_zpl_code(
    request: Request,
    payload: JsonPayload,
    user: CurrentUser,
):
    items = payload.get("items", [])
    if not items:
        return JSONResponse({"status": "error", "success": False, "message": "Yazdırılacak ürün bulunamadı."})

    zpl_code = QRBasketService.generate_zpl(items)
    return {"status": "success", "success": True, "zpl": zpl_code}


@router.get("/api/printers")
def api_get_printers(
    request: Request,
    user: CurrentUser,
):
    return {"status": "success", "printers": ZintQRService.list_printers()}


@router.post("/api/send-zpl-printer")
def send_zpl_printer(
    request: Request,
    payload: JsonPayload,
    user: CurrentUser,
):
    items = payload.get("items", [])
    printer_name = payload.get("printer_name") or payload.get("printer") or ""
    zpl_code = payload.get("zpl") or (QRBasketService.generate_zpl(items) if items else "")
    if not zpl_code:
        return JSONResponse({"status": "error", "success": False, "message": "Yazdırılacak ZPL verisi bulunamadı."})

    ok, msg = ZintQRService.send_zpl_to_printer(zpl_code, printer_name=printer_name or None)
    return {"status": "success" if ok else "error", "success": ok, "message": msg}


@router.post("/api/print-pdf")
def print_pdf_labels(
    request: Request,
    payload: JsonPayload,
    user: CurrentUser,
):
    items = payload.get("items", [])
    mode = str(payload.get("mode") or "").lower()
    multi = bool(payload.get("multi", False)) or (mode == "multi")
    inline = bool(payload.get("inline", False))
    if not items:
        raise HTTPException(status_code=400, detail="Yazdırılacak ürün bulunamadı.")

    pdf_bytes = QRBasketService.generate_pdf_labels(items, multi=multi)
    disposition = "inline" if inline else "attachment"
    filename = "karekod_etiketleri_A4.pdf" if multi else "karekod_etiketleri_60x30mm.pdf"
    return StreamingResponse(
        io.BytesIO(pdf_bytes),
        media_type="application/pdf",
        headers={"Content-Disposition": f"{disposition}; filename={filename}"}
    )


# =========================================================================
# 4. MEVCUT / GENEL KAREKOD SEPETİ ENDPOINT'LERİ (Geriye Dönük Uyumlu)
# =========================================================================

@router.post("/api/parse")
def parse_qr_text(
    request: Request,
    payload: JsonPayload,
    db: DbSession,
    user: CurrentUser,
):
    text = payload.get("input_text", "")
    if not text:
        return JSONResponse({"status": "error", "success": False, "message": "Okunacak metin girilmedi."})

    result = QRBasketService.parse_input_string(db, text)
    return {"status": "success", "success": True, "item": result}


@router.post("/api/parse-file")
async def parse_qr_file(
    request: Request,
    file: Annotated[UploadFile, File(...)],
    db: DbSession,
    user: CurrentUser,
):
    content = await file.read()
    if not content:
        raise HTTPException(status_code=400, detail="Dosya içeriği boş.")

    items = QRBasketService.parse_file(db, content, file.filename or "upload.xml")
    return {"status": "success", "success": True, "count": len(items), "items": items}


@router.post("/api/bulk-stock-in")
def bulk_stock_in(
    request: Request,
    payload: JsonPayload,
    db: DbSession,
    user: CurrentUser,
):
    depo_id = payload.get("depo_id")
    items = payload.get("items", [])
    aciklama = payload.get("aciklama", "")
    pts_no = payload.get("pts_no", "")
    raf_konumu = payload.get("raf_konumu", "")

    if not depo_id:
        return JSONResponse({"status": "error", "success": False, "message": "Hedef depo seçilmelidir."})
    if not items:
        return JSONResponse({"status": "error", "success": False, "message": "Sepette işlenecek ürün bulunamadı."})

    res = QRBasketService.execute_bulk_stock_in(
        db=db,
        user_id=user.id,
        depo_id=int(depo_id),
        items=items,
        aciklama=aciklama,
        pts_no=pts_no,
        raf_konumu=raf_konumu
    )
    return res


@router.post("/api/bulk-stock-out")
def bulk_stock_out(
    request: Request,
    payload: JsonPayload,
    db: DbSession,
    user: CurrentUser,
):
    depo_id = payload.get("depo_id")
    items = payload.get("items", [])
    aciklama = payload.get("aciklama", "")

    if not depo_id:
        return JSONResponse({"status": "error", "success": False, "message": "Hedef depo seçilmelidir."})
    if not items:
        return JSONResponse({"status": "error", "success": False, "message": "Sepette işlenecek ürün bulunamadı."})

    res = QRBasketService.execute_bulk_stock_out(db, user.id, int(depo_id), items, aciklama)
    return res


@router.post("/api/export")
def export_basket(
    request: Request,
    payload: JsonPayload,
    user: CurrentUser,
):
    items = payload.get("items", [])
    export_format = payload.get("format", "excel").lower()

    if not items:
        raise HTTPException(status_code=400, detail="Dışa aktarılacak veri bulunamadı.")

    export_data = []
    for idx, item in enumerate(items, 1):
        export_data.append({
            "No": idx,
            "Barkod / GTIN": item.get("gtin") or item.get("barkod") or "",
            "İlaç Adı": item.get("ad") or item.get("product_name") or item.get("drug_name") or "",
            "Parti / Lot No": item.get("batch") or item.get("bn") or item.get("parti_no") or "",
            "Seri No": item.get("serial") or item.get("sn") or "",
            "Son Kullanma Tarihi": item.get("expiry") or item.get("xd") or item.get("skt") or "",
            "Koli No": item.get("koli_no") or "",
            "Paket No": item.get("paket_no") or "",
            "Miktar": item.get("miktar") or 1,
            "Kutu İçi Adet": item.get("kutu_ici_adet") or 1
        })

    if export_format == "csv":
        csv_str = _rows_to_csv_str(export_data, sep=";")
        return Response(
            content=csv_str.encode("utf-8-sig"),
            media_type="text/csv",
            headers={"Content-Disposition": "attachment; filename=karekod_sepeti.csv"}
        )
    else:
        buffer = _rows_to_excel_bytes(export_data, sheet_name="Sepet Verisi")
        return StreamingResponse(
            buffer,
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            headers={"Content-Disposition": "attachment; filename=karekod_sepeti.xlsx"}
        )


# ==============================================================================
# İTS & PTS REST API SERVİSLERİ (TOKEN, PAKET SORGULAMA 44, PAKET ALIM 43)
# ==============================================================================

@router.get("/api/its-pts/settings")
def api_get_its_pts_settings(
    request: Request,
    db: DbSession,
    user: CurrentUser,
):
    s = ItsPtsService.get_settings(db)
    return {
        "status": "success",
        "success": True,
        "ortam": s.ortam or "test",
        "base_url": s.base_url or ItsPtsService.TEST_BASE_URL,
        "username": s.username or "",
        "gln_no": s.gln_no or "",
        "has_password": bool(s.password),
        "password_masked": "********" if s.password else ""
    }


@router.post("/api/its-pts/settings")
def api_save_its_pts_settings(
    request: Request,
    payload: JsonPayload,
    db: DbSession,
    user: CurrentUser,
):
    ortam = payload.get("ortam", "test")
    username = payload.get("username", "")
    password = payload.get("password")
    gln_no = payload.get("gln_no", "")
    custom_base_url = payload.get("base_url")

    s = ItsPtsService.save_settings(
        db=db,
        ortam=ortam,
        username=username,
        password=password,
        gln_no=gln_no,
        custom_base_url=custom_base_url
    )
    return {
        "status": "success",
        "success": True,
        "message": "İTS / PTS bağlantı ayarları kaydedildi.",
        "ortam": s.ortam,
        "base_url": s.base_url,
        "username": s.username,
        "gln_no": s.gln_no,
        "has_password": bool(s.password)
    }


@router.post("/api/its-pts/test-token")
def api_test_its_pts_token(
    request: Request,
    payload: JsonPayload,
    db: DbSession,
    user: CurrentUser,
):
    try:
        # Eğer payload içinde yeni bilgiler gönderilmişse önce kaydet veya onları test et
        if payload.get("username"):
            s = ItsPtsService.save_settings(
                db=db,
                ortam=payload.get("ortam", "test"),
                username=payload.get("username", ""),
                password=payload.get("password"),
                gln_no=payload.get("gln_no", ""),
                custom_base_url=payload.get("base_url")
            )
        token, settings = ItsPtsService.get_token_from_db(db, force_refresh=True)
        token_preview = f"{token[:28]}...{token[-12:]}" if len(token) > 45 else token
        return {
            "status": "success",
            "success": True,
            "message": f"İTS Token başarıyla alındı! ({settings.base_url}/token/app/token/)",
            "token_preview": token_preview,
            "gln_no": settings.gln_no
        }
    except Exception as e:
        return JSONResponse(
            status_code=400,
            content={"status": "error", "success": False, "message": str(e), "detail": str(e)}
        )


@router.post("/api/its-pts/search")
def api_its_pts_search_packages(
    request: Request,
    payload: JsonPayload,
    db: DbSession,
    user: CurrentUser,
):
    today = date.today()
    start_date = payload.get("startDate") or (today - timedelta(days=30)).strftime("%Y-%m-%d")
    end_date = payload.get("endDate") or today.strftime("%Y-%m-%d")
    source_gln = payload.get("sourceGln") or ""
    destination_gln = payload.get("destinationGln") or ""
    bring_not_received = payload.get("bringNotReceivedTransferInfo", 1)

    try:
        res = ItsPtsService.search_packages(
            db=db,
            start_date=start_date,
            end_date=end_date,
            source_gln=source_gln,
            destination_gln=destination_gln,
            bring_not_received=int(bring_not_received)
        )
        return res
    except Exception as e:
        return JSONResponse(
            status_code=400,
            content={"status": "error", "success": False, "message": str(e), "detail": str(e)}
        )


@router.post("/api/its-pts/get-package-for-print")
def api_its_pts_get_package_for_print(
    request: Request,
    payload: JsonPayload,
    db: DbSession,
    user: CurrentUser,
):
    transfer_id = str(payload.get("transferId") or "").strip()
    source_gln = str(payload.get("sourceGln") or "").strip()
    transfer_date = str(payload.get("transferDate") or "").strip()

    try:
        pkg = ItsPtsService.download_package(
            db=db,
            transfer_id=transfer_id,
            source_gln=source_gln,
            transfer_date=transfer_date
        )
        print_res = QRBasketService.parse_pts_for_printing(
            db=db,
            file_bytes=pkg["zip_bytes"],
            filename=f"PTS_{transfer_id}.zip"
        )
        print_res["transfer_id"] = transfer_id
        print_res["md5_verified"] = pkg["md5_verified"]
        print_res["stream_md5"] = pkg["stream_md5"]
        if not print_res.get("pts_no"):
            print_res["pts_no"] = transfer_id
        return print_res
    except Exception as e:
        return JSONResponse(
            status_code=400,
            content={"status": "error", "success": False, "message": str(e), "detail": str(e)}
        )


@router.get("/api/its-pts/download-zip/{transfer_id}")
def api_its_pts_download_zip(
    transfer_id: str,
    request: Request,
    db: DbSession,
    user: CurrentUser,
):
    try:
        pkg = ItsPtsService.download_package(db=db, transfer_id=transfer_id)
        return Response(
            content=pkg["zip_bytes"],
            media_type="application/zip",
            headers={"Content-Disposition": f"attachment; filename=PTS_{transfer_id}.zip"}
        )
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))
