from fastapi import APIRouter, Request, Depends, Form, Query, status, File, UploadFile
from fastapi.responses import HTMLResponse, RedirectResponse, JSONResponse, Response
from fastapi.templating import Jinja2Templates
from pydantic import BeforeValidator
from sqlalchemy.orm import Session, joinedload
from typing import Annotated, Any, List, Optional
from .. import database, models
from ..atc_helper import get_atc_info, get_atc_tree
from ..nfc_helper import get_nfc_info, get_nfc_code_by_barcode, get_nfc_tree
from ..pts_parser import parse_pts_xml, clean_gtin, parse_skt, parse_package_dose_count
from ..services.qr_basket_service import QRBasketService
from ..crud import check_depo_drug_compatibility
from sqlalchemy import or_, text
import json, csv, io, datetime, re

router = APIRouter(prefix="/drugs", tags=["drugs"], strict_content_type=False)
templates = Jinja2Templates(directory="app/templates")


def _parse_optional_int(v: Any) -> Optional[int]:
    if v is None or v == "":
        return None
    if isinstance(v, int):
        return v
    s = str(v).strip()
    if not s or s.lower() in ("none", "null", "all"):
        return None
    return int(s)


DbSession = Annotated[Session, Depends(database.get_db)]
MasterDbSession = Annotated[Optional[Session], Depends(database.get_master_db)]
OptionalIntQuery = Annotated[Optional[int], BeforeValidator(_parse_optional_int), Query()]
OptionalIntForm = Annotated[Optional[int], BeforeValidator(_parse_optional_int), Form()]

def resolve_recete_turleri(ilac: models.Ilac) -> list[str]:
    if ilac and ilac.recete_turu and ilac.recete_turu.strip():
        return [t.strip() for t in ilac.recete_turu.split(",") if t.strip()]
    return ["Normal"]

def normalize_recete_turu(raw_recete: Optional[str]) -> str:
    if not raw_recete:
        return ""
    r = str(raw_recete).upper()
    if "KIRMIZI" in r:
        return "Kırmızı"
    elif "YEŞİL" in r or "YESIL" in r:
        return "Yeşil"
    elif "TURUNCU" in r:
        return "Turuncu"
    elif "MOR" in r:
        return "Mor"
    elif "BEYAZ" in r or "REÇETESİZ" in r or "TAKİBİ" in r:
        return "Normal"
    return "Normal"

def build_atc_nfc_grouped_lists(available_atc_set, available_nfc_set, fetch_atc, fetch_nfc):
    # Build grouped ATC tree (only for existing ATC codes in DB)
    atc_tree_dict = {}
    for code in sorted(list(available_atc_set)):
        info = fetch_atc(code)
        l1_code = info.get("level1_code") or "OTHER"
        l1_name = info.get("level1_name") or "Diğer ATC"
        l1_key = f"{l1_code} - {l1_name}" if l1_code != "OTHER" and l1_name else (l1_code if l1_code != "OTHER" else "Diğer ATC")
        
        l2_code = info.get("level2_code") or l1_code
        l2_name = info.get("level2_name") or l1_name
        l2_key = f"{l2_code} - {l2_name}" if l2_code != l1_code and l2_name else (l2_code if l2_code != l1_code else l1_key)

        if l1_key not in atc_tree_dict:
            atc_tree_dict[l1_key] = {
                "l1_code": l1_code,
                "l1_name": l1_name,
                "display": l1_key,
                "subgroups": {}
            }

        if l2_key not in atc_tree_dict[l1_key]["subgroups"]:
            atc_tree_dict[l1_key]["subgroups"][l2_key] = {
                "l2_code": l2_code,
                "l2_name": l2_name,
                "display": l2_key,
                "codes": []
            }

        atc_tree_dict[l1_key]["subgroups"][l2_key]["codes"].append(info)

    atc_grouped_list = []
    for l1_key, l1_val in atc_tree_dict.items():
        subgroups_list = []
        for l2_key, l2_val in l1_val["subgroups"].items():
            subgroups_list.append({
                "l2_code": l2_val["l2_code"],
                "l2_name": l2_val["l2_name"],
                "display": l2_val["display"],
                "codes": l2_val["codes"]
            })
        atc_grouped_list.append({
            "l1_code": l1_val["l1_code"],
            "l1_name": l1_val["l1_name"],
            "display": l1_val["display"],
            "subgroups": subgroups_list
        })

    # Build grouped NFC tree (only for existing NFC codes in DB)
    nfc_tree_dict = {}
    for code in sorted(list(available_nfc_set)):
        info = fetch_nfc(code)
        full_path = info.get("full_name", "")
        parts = full_path.split(" > ") if full_path else []

        l1_key = parts[0] if len(parts) >= 1 else "Diğer NFC"
        l2_key = parts[1] if len(parts) >= 2 else l1_key

        l1_code_clean = l1_key.split(" - ")[0].strip() if " - " in l1_key else l1_key
        l1_name_clean = l1_key.split(" - ")[1].strip() if " - " in l1_key else ""
        l2_code_clean = l2_key.split(" - ")[0].strip() if " - " in l2_key else l2_key
        l2_name_clean = l2_key.split(" - ")[1].strip() if " - " in l2_key else ""

        if l1_key not in nfc_tree_dict:
            nfc_tree_dict[l1_key] = {
                "l1_code": l1_code_clean,
                "l1_name": l1_name_clean,
                "display": l1_key,
                "subgroups": {}
            }

        if l2_key not in nfc_tree_dict[l1_key]["subgroups"]:
            nfc_tree_dict[l1_key]["subgroups"][l2_key] = {
                "l2_code": l2_code_clean,
                "l2_name": l2_name_clean,
                "display": l2_key,
                "codes": []
            }

        nfc_tree_dict[l1_key]["subgroups"][l2_key]["codes"].append(info)

    nfc_grouped_list = []
    for l1_key, l1_val in nfc_tree_dict.items():
        subgroups_list = []
        for l2_key, l2_val in l1_val["subgroups"].items():
            subgroups_list.append({
                "l2_code": l2_val["l2_code"],
                "l2_name": l2_val["l2_name"],
                "display": l2_val["display"],
                "codes": l2_val["codes"]
            })
        nfc_grouped_list.append({
            "l1_code": l1_val["l1_code"],
            "l1_name": l1_val["l1_name"],
            "display": l1_val["display"],
            "subgroups": subgroups_list
        })

    return atc_grouped_list, nfc_grouped_list

def seed_default_features(db: Session):
    if db.query(models.IlacOzellik).count() == 0:
        defaults = [
            models.IlacOzellik(
                kod="soguk_zincir",
                ad="Soğuk Zincir Uygulaması",
                renk="info",
                ikon="fa-snowflake",
                aciklama="2-8°C soğuk zincir saklama ve nakliye koşuluna tabidir."
            ),
            models.IlacOzellik(
                kod="narkotik",
                ad="Narkotik / Kontrole Tabi",
                renk="danger",
                ikon="fa-shield-halved",
                aciklama="Narkotik veya psikotrop kontrole tabi (Kırmızı/Yeşil reçete) ilaç."
            ),
            models.IlacOzellik(
                kod="isik_duyarli",
                ad="Işıktan Etkilenen İlaç",
                renk="warning",
                ikon="fa-sun",
                aciklama="Doğrudan ışıktan korunması ve koyu ambalajda saklanması gereken ilaç."
            ),
            models.IlacOzellik(
                kod="yuksek_risk",
                ad="Yüksek Riskli İlaç",
                renk="danger",
                ikon="fa-triangle-exclamation",
                aciklama="Hazırlama, dozaj ve uygulamada yüksek riskli ilaç uyarısı."
            ),
            models.IlacOzellik(
                kod="sitotoksik",
                ad="Sitotoksik İlaç",
                renk="dark",
                ikon="fa-biohazard",
                aciklama="Sitotoksik / Antineoplastik ve tehlikeli tıbbi ürün."
            ),
            models.IlacOzellik(
                kod="gebelik_laktasyon",
                ad="Gebelik / Emzirme Kontrendike",
                renk="secondary",
                ikon="fa-person-breastfeeding",
                aciklama="Hamilelik ve emzirme (laktasyon) döneminde kullanılmamalıdır."
            )
        ]
        db.add_all(defaults)
        db.commit()

@router.get("", response_class=HTMLResponse)
async def list_drugs(
    request: Request,
    db: DbSession,
    q: Annotated[Optional[str], Query()] = None,
    atc_group: Annotated[Optional[str], Query()] = None,
    nfc_group: Annotated[Optional[str], Query()] = None,
    sort_by: Annotated[str, Query()] = "ad",
    msg: Annotated[Optional[str], Query()] = None,
    error: Annotated[Optional[str], Query()] = None,
):
    query = db.query(models.Ilac).options(
        joinedload(models.Ilac.partiler).joinedload(models.Parti.stoklar),
        joinedload(models.Ilac.ozellikler)
    )
    if q and q.strip():
        q_strip = f"%{q.strip()}%"
        query = query.filter(
            or_(
                models.Ilac.ad.ilike(q_strip),
                models.Ilac.barkod.ilike(q_strip),
                models.Ilac.jenerik_adi.ilike(q_strip),
                models.Ilac.jenerik_kodu.ilike(q_strip),
                models.Ilac.jenerik_grubu.ilike(q_strip),
                models.Ilac.atc_kodu.ilike(q_strip),
                models.Ilac.nfc_kodu.ilike(q_strip),
                models.Ilac.etken_madde.ilike(q_strip)
            )
        )
        
    if atc_group and atc_group.strip():
        query = query.filter(models.Ilac.atc_kodu.ilike(f"{atc_group.strip()}%"))

    if nfc_group and nfc_group.strip():
        query = query.filter(models.Ilac.nfc_kodu.ilike(f"{nfc_group.strip()}%"))

    if sort_by == "atc":
        query = query.order_by(models.Ilac.atc_kodu.asc(), models.Ilac.ad.asc())
    elif sort_by == "nfc":
        query = query.order_by(models.Ilac.nfc_kodu.asc(), models.Ilac.ad.asc())
    elif sort_by == "id":
        query = query.order_by(models.Ilac.id.asc())
    else:
        query = query.order_by(models.Ilac.ad.asc())

    ilaclar = query.all()

    if not (q or atc_group or nfc_group):
        all_ilaclar = ilaclar
    else:
        all_ilaclar = db.query(models.Ilac).options(
            joinedload(models.Ilac.partiler).joinedload(models.Parti.stoklar)
        ).all()

    jenerik_limits = db.query(models.JenerikKritikStok).all()
    limits_map = {l.grup_kodu: l.kritik_stok for l in jenerik_limits}
    tum_ozellikler = db.query(models.IlacOzellik).all()
    
    atc_memo = {}
    nfc_memo = {}

    def fetch_atc(c):
        if not c:
            return get_atc_info("")
        if c not in atc_memo:
            atc_memo[c] = get_atc_info(c)
        return atc_memo[c]

    def fetch_nfc(c):
        if not c:
            return get_nfc_info("")
        if c not in nfc_memo:
            nfc_memo[c] = get_nfc_info(c)
        return nfc_memo[c]

    generic_group_stocks = {}
    available_atc_set = set()
    available_nfc_set = set()

    for i in all_ilaclar:
        if i.atc_kodu and i.atc_kodu.strip():
            available_atc_set.add(i.atc_kodu.strip())
        if i.nfc_kodu and i.nfc_kodu.strip():
            available_nfc_set.add(i.nfc_kodu.strip())

        g_kodu = i.jenerik_grubu if (i.jenerik_grubu and i.jenerik_grubu.strip()) else (i.jenerik_adi if (i.jenerik_adi and i.jenerik_adi.strip()) else (i.jenerik_kodu if (i.jenerik_kodu and i.jenerik_kodu.strip()) else (i.etken_madde if (i.etken_madde and i.etken_madde.strip()) else i.ad)))
        if g_kodu not in generic_group_stocks:
            generic_group_stocks[g_kodu] = {
                "toplam_stok": 0,
                "default_sinir": 0
            }
        generic_group_stocks[g_kodu]["default_sinir"] += (i.kritik_stok or 0)
        toplam_i_stok = sum(s.miktar for p in i.partiler for s in p.stoklar)
        generic_group_stocks[g_kodu]["toplam_stok"] += toplam_i_stok

    for ilac in ilaclar:
        g_kodu = ilac.jenerik_grubu if (ilac.jenerik_grubu and ilac.jenerik_grubu.strip()) else (ilac.jenerik_adi if (ilac.jenerik_adi and ilac.jenerik_adi.strip()) else (ilac.jenerik_kodu if (ilac.jenerik_kodu and ilac.jenerik_kodu.strip()) else (ilac.etken_madde if (ilac.etken_madde and ilac.etken_madde.strip()) else ilac.ad)))
        grp_data = generic_group_stocks.get(g_kodu, {"toplam_stok": 0, "default_sinir": 0})
        ilac.jenerik_kritik_sinir = limits_map.get(g_kodu, grp_data["default_sinir"])
        ilac.jenerik_toplam_stok = grp_data["toplam_stok"]
        ilac.is_jenerik_kritik = ilac.jenerik_toplam_stok <= ilac.jenerik_kritik_sinir
        ilac.atc_info = fetch_atc(ilac.atc_kodu)
        ilac.recete_turleri = resolve_recete_turleri(ilac)
        ilac.recete_turleri_text = ", ".join(ilac.recete_turleri)
        
        # Auto-fill nfc_kodu if missing
        if not ilac.nfc_kodu:
            ilac.nfc_kodu = get_nfc_code_by_barcode(ilac.barkod)
        ilac.nfc_info = fetch_nfc(ilac.nfc_kodu)

    atc_grouped_list, nfc_grouped_list = build_atc_nfc_grouped_lists(available_atc_set, available_nfc_set, fetch_atc, fetch_nfc)
    tum_lokasyonlar = db.query(models.WarehouseLocation).options(
        joinedload(models.WarehouseLocation.depo)
    ).filter(models.WarehouseLocation.is_active == True).order_by(
        models.WarehouseLocation.depo_id.asc(),
        models.WarehouseLocation.pick_sequence.asc(),
        models.WarehouseLocation.code.asc()
    ).all()

    return templates.TemplateResponse(
        request=request,
        name="drugs.html",
        context={
            "ilaclar": ilaclar,
            "q": q or "",
            "secili_atc_group": atc_group or "",
            "secili_nfc_group": nfc_group or "",
            "sort_by": sort_by,
            "msg": msg,
            "error": error,
            "atc_grouped_list": atc_grouped_list,
            "nfc_grouped_list": nfc_grouped_list,
            "recete_turleri": ["Normal", "Mor", "Turuncu", "Yeşil", "Kırmızı", "Tanımsız"],
            "tum_ozellikler": tum_ozellikler,
            "tum_lokasyonlar": tum_lokasyonlar,
            "user": request.state.user,
        },
    )

@router.get("/export/excel")
@router.post("/export/excel", include_in_schema=False)
async def export_drugs_excel(
    request: Request,
    db: DbSession,
    q: Annotated[Optional[str], Query()] = None,
    atc_group: Annotated[Optional[str], Query()] = None,
    nfc_group: Annotated[Optional[str], Query()] = None,
    sort_by: Annotated[str, Query()] = "ad",
):
    """Filtrelenmiş veya ekranda görüntülenen ilaç listesini Excel dosyası olarak indirir."""
    import openpyxl
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
    from fastapi.responses import Response

    ids = None
    if request.method == "POST":
        try:
            body = await request.json()
            if isinstance(body, dict):
                ids = body.get("ids")
                sort_by = body.get("sort_by", sort_by)
        except Exception:
            pass

    query = db.query(models.Ilac).options(
        joinedload(models.Ilac.partiler).joinedload(models.Parti.stoklar).joinedload(models.Stok.depo)
    )

    if ids is not None:
        if not ids:
            ilaclar = []
        else:
            fetched = query.filter(models.Ilac.id.in_(ids)).all()
            ilac_map = {i.id: i for i in fetched}
            # Ekranda görüntülenen sıra ne ise birebir koru
            ilaclar = [ilac_map[i_id] for i_id in ids if i_id in ilac_map]
    else:
        if q and q.strip():
            q_strip = f"%{q.strip()}%"
            query = query.filter(
                or_(
                    models.Ilac.ad.ilike(q_strip),
                    models.Ilac.barkod.ilike(q_strip),
                    models.Ilac.jenerik_adi.ilike(q_strip),
                    models.Ilac.jenerik_kodu.ilike(q_strip),
                    models.Ilac.jenerik_grubu.ilike(q_strip),
                    models.Ilac.atc_kodu.ilike(q_strip),
                    models.Ilac.nfc_kodu.ilike(q_strip),
                    models.Ilac.etken_madde.ilike(q_strip)
                )
            )
        if atc_group and atc_group.strip():
            query = query.filter(models.Ilac.atc_kodu.ilike(f"{atc_group.strip()}%"))
        if nfc_group and nfc_group.strip():
            query = query.filter(models.Ilac.nfc_kodu.ilike(f"{nfc_group.strip()}%"))
        if sort_by == "atc":
            query = query.order_by(models.Ilac.atc_kodu.asc(), models.Ilac.ad.asc())
        elif sort_by == "nfc":
            query = query.order_by(models.Ilac.nfc_kodu.asc(), models.Ilac.ad.asc())
        elif sort_by == "id":
            query = query.order_by(models.Ilac.id.asc())
        else:
            query = query.order_by(models.Ilac.ad.asc())

        ilaclar = query.all()

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "İlaç Kataloğu"

    # Header styling
    header_font = Font(bold=True, color="FFFFFF", size=11)
    header_fill = PatternFill("solid", fgColor="1D4ED8")
    header_align = Alignment(horizontal="center", vertical="center", wrap_text=True)
    thin = Side(style="thin", color="D1D5DB")
    border = Border(left=thin, right=thin, top=thin, bottom=thin)

    headers = [
        "Barkod", "İlaç Adı", "Etken Madde", "Jenerik Kodu", "Jenerik Adı", "Jenerik Grubu",
        "ATC Kodu", "NFC Kodu", "Reçete Türü", "Ambalaj", "Birim", "Koli İçi Adet",
        "Üretici", "Raf Konumu", "Kritik Stok", "Toplam Stok", "Stok Detayları"
    ]
    col_widths = [16, 32, 24, 14, 24, 22, 10, 10, 14, 18, 10, 12, 20, 14, 12, 12, 40]

    for col_idx, (hdr, width) in enumerate(zip(headers, col_widths), 1):
        cell = ws.cell(row=1, column=col_idx, value=hdr)
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = header_align
        cell.border = border
        ws.column_dimensions[ws.cell(row=1, column=col_idx).column_letter].width = width

    ws.row_dimensions[1].height = 24
    ws.freeze_panes = "A2"

    # Data rows
    alt_fill = PatternFill("solid", fgColor="EFF6FF")
    data_align_wrap = Alignment(vertical="center", wrap_text=True)
    data_align = Alignment(vertical="center")
    data_align_center = Alignment(horizontal="center", vertical="center")

    for row_idx, ilac in enumerate(ilaclar, 2):
        # Hesapla toplam stok (sadece is_toplam_depo=False olan depolar)
        toplam_stok = sum(
            s.miktar for p in ilac.partiler for s in p.stoklar
            if s.miktar > 0 and s.depo and not s.depo.is_toplam_depo
        )
        # Stok detayları (depo bazlı)
        depo_stok_map = {}
        for p in ilac.partiler:
            for s in p.stoklar:
                if s.miktar > 0 and s.depo and not s.depo.is_toplam_depo:
                    dn = s.depo.ad
                    depo_stok_map[dn] = depo_stok_map.get(dn, 0) + s.miktar
        stok_detay = ", ".join(f"{dn}: {mkt}" for dn, mkt in depo_stok_map.items()) if depo_stok_map else "-"

        row_fill = alt_fill if row_idx % 2 == 0 else None

        values = [
            ilac.barkod or "",
            ilac.ad or "",
            ilac.etken_madde or "",
            ilac.jenerik_kodu or "",
            ilac.jenerik_adi or "",
            ilac.jenerik_grubu or "",
            ilac.atc_kodu or "",
            ilac.nfc_kodu or "",
            ilac.recete_turu or "",
            ilac.ambalaj or "",
            ilac.birim or "Adet",
            ilac.koli_ici_adet or 1,
            ilac.uretici or "",
            ilac.raf_konumu or "",
            ilac.kritik_stok or 0,
            toplam_stok,
            stok_detay
        ]
        for col_idx, val in enumerate(values, 1):
            cell = ws.cell(row=row_idx, column=col_idx, value=val)
            cell.border = border
            if col_idx in (12, 15, 16):
                cell.alignment = data_align_center
            elif col_idx == 17:
                cell.alignment = data_align_wrap
            else:
                cell.alignment = data_align
            if row_fill:
                cell.fill = row_fill

    ws.auto_filter.ref = f"A1:{ws.cell(row=1, column=len(headers)).coordinate}"

    output = io.BytesIO()
    wb.save(output)
    output.seek(0)

    from datetime import datetime
    filename = f"ilac_katalogu_{datetime.now().strftime('%Y%m%d_%H%M')}.xlsx"
    return Response(
        content=output.getvalue(),
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'}
    )

@router.post("/print-view", response_class=HTMLResponse)
async def print_view_drugs(
    request: Request,
    db: DbSession,
):
    """Ekranda filtrelenmiş ilaçların tüm detaylarını (Excel kapsamındaki gibi) A4 formatında basıma hazırlar."""
    ids = []
    sort_by = "ad"
    try:
        body = await request.json()
        if isinstance(body, dict):
            ids = body.get("ids", [])
            sort_by = body.get("sort_by", "ad")
    except Exception:
        pass

    query = db.query(models.Ilac).options(
        joinedload(models.Ilac.partiler).joinedload(models.Parti.stoklar).joinedload(models.Stok.depo),
        joinedload(models.Ilac.ozellikler)
    )

    if ids:
        fetched = query.filter(models.Ilac.id.in_(ids)).all()
        ilac_map = {i.id: i for i in fetched}
        ilaclar = [ilac_map[i_id] for i_id in ids if i_id in ilac_map]
    else:
        ilaclar = query.order_by(models.Ilac.ad.asc()).all()

    prepared_ilaclar = []
    toplam_katalog_stok = 0

    for idx, ilac in enumerate(ilaclar, 1):
        depo_stok_map = {}
        for p in ilac.partiler:
            for s in p.stoklar:
                if s.miktar > 0 and s.depo and not s.depo.is_toplam_depo:
                    dn = s.depo.ad
                    depo_stok_map[dn] = depo_stok_map.get(dn, 0) + s.miktar

        toplam_stok = sum(depo_stok_map.values())
        toplam_katalog_stok += toplam_stok
        stok_detay = ", ".join(f"{dn}: {mkt}" for dn, mkt in depo_stok_map.items()) if depo_stok_map else "-"

        recete_turleri = resolve_recete_turleri(ilac)

        prepared_ilaclar.append({
            "idx": idx,
            "ilac": ilac,
            "toplam_stok": toplam_stok,
            "stok_detay": stok_detay,
            "depo_stok_map": depo_stok_map,
            "recete_str": ", ".join(recete_turleri) if recete_turleri else "Normal",
            "jenerik_str": ilac.jenerik_kodu or ilac.jenerik_grubu or ilac.jenerik_adi or "-"
        })

    import datetime
    now_str = datetime.datetime.now().strftime("%d.%m.%Y %H:%M")

    return templates.TemplateResponse(
        request=request,
        name="drug_print_view.html",
        context={
            "prepared_ilaclar": prepared_ilaclar,
            "toplam_kayit": len(prepared_ilaclar),
            "toplam_katalog_stok": toplam_katalog_stok,
            "print_date": now_str,
            "user": getattr(request.state, "user", None),
        },
    )

@router.get("/add", response_class=HTMLResponse)
async def add_drug_form(request: Request, db: DbSession):
    tum_ozellikler = db.query(models.IlacOzellik).all()
    tum_lokasyonlar = db.query(models.WarehouseLocation).options(
        joinedload(models.WarehouseLocation.depo)
    ).filter(models.WarehouseLocation.is_active == True).order_by(
        models.WarehouseLocation.depo_id.asc(),
        models.WarehouseLocation.pick_sequence.asc(),
        models.WarehouseLocation.code.asc()
    ).all()
    return templates.TemplateResponse(
        request=request,
        name="drug_form.html",
        context={
            "tum_ozellikler": tum_ozellikler,
            "tum_lokasyonlar": tum_lokasyonlar,
            "user": request.state.user,
        },
    )

@router.post("/add")
async def add_drug(
    request: Request,
    barkod: Annotated[str, Form(...)],
    ad: Annotated[str, Form(...)],
    db: DbSession,
    master_db: MasterDbSession,
    etken_madde: Annotated[str, Form()] = "",
    jenerik_kodu: Annotated[str, Form()] = "",
    jenerik_adi: Annotated[str, Form()] = "",
    jenerik_grubu: Annotated[str, Form()] = "",
    atc_kodu: Annotated[str, Form()] = "",
    nfc_kodu: Annotated[str, Form()] = "",
    recete_turu: Annotated[str, Form()] = "",
    ambalaj: Annotated[str, Form()] = "",
    birim: Annotated[str, Form()] = "",
    kutu_ici_adet: Annotated[int, Form()] = 0,
    koli_ici_adet: Annotated[int, Form()] = 1,
    raf_konumu: Annotated[str, Form()] = "",
    uretici: Annotated[str, Form()] = "",
    kritik_stok: Annotated[int, Form()] = 0,
):
    form_data = await request.form()
    ozellik_ids = [int(v) for k, v in form_data.multi_items() if k == "ozellik_ids"]

    barkod_clean = barkod.replace("'", "").strip()
    if db.query(models.Ilac).filter(models.Ilac.barkod == barkod_clean).first():
        return RedirectResponse(url="/drugs?error=Bu+barkoda+ait+bir+ilaç+kartı+zaten+var.", status_code=status.HTTP_302_FOUND)

    m_info = lookup_master_drug(barkod_clean, master_db) if master_db else None

    clean_jen_kodu = jenerik_kodu.strip() if jenerik_kodu and jenerik_kodu.strip() else (m_info.get("jenerik_kodu") if m_info else "")
    clean_jen_adi = jenerik_adi.strip() if jenerik_adi and jenerik_adi.strip() else (m_info.get("jenerik_adi") if m_info else "")
    clean_atc = atc_kodu.strip().upper() if atc_kodu and atc_kodu.strip() else (m_info.get("atc_kodu") if m_info else "")
    clean_nfc = nfc_kodu.strip().upper() if nfc_kodu and nfc_kodu.strip() else (m_info.get("nfc_kodu") if m_info else "") or get_nfc_code_by_barcode(barkod_clean)
    clean_recete = recete_turu.strip() if recete_turu and recete_turu.strip() else (m_info.get("recete_turu") if m_info else None)
    clean_uretici = uretici.strip() if uretici and uretici.strip() else (m_info.get("uretici") if m_info else "")
    clean_etken = etken_madde.strip() if etken_madde and etken_madde.strip() else (m_info.get("etken_madde") if m_info else "")
    clean_ambalaj = ambalaj.strip() if ambalaj and ambalaj.strip() else (m_info.get("ambalaj") if m_info else "")
    resolved_kutu_ici = int(kutu_ici_adet) if kutu_ici_adet and int(kutu_ici_adet) > 0 else parse_package_dose_count(clean_ambalaj, ad)

    yeni_ilac = models.Ilac(
        barkod=barkod_clean, ad=ad, etken_madde=clean_etken, 
        jenerik_kodu=clean_jen_kodu, jenerik_adi=clean_jen_adi, jenerik_grubu=jenerik_grubu,
        atc_kodu=clean_atc, nfc_kodu=clean_nfc, recete_turu=clean_recete, ambalaj=clean_ambalaj,
        birim=birim or "Adet", kutu_ici_adet=resolved_kutu_ici, koli_ici_adet=koli_ici_adet, raf_konumu=raf_konumu, uretici=clean_uretici, kritik_stok=kritik_stok
    )
    if ozellik_ids:
        yeni_ilac.ozellikler = db.query(models.IlacOzellik).filter(models.IlacOzellik.id.in_(ozellik_ids)).all()

    db.add(yeni_ilac)
    db.commit()
    return RedirectResponse(url="/drugs?msg=Yeni+ilaç+başarıyla+eklendi.", status_code=status.HTTP_302_FOUND)

@router.get("/edit/{ilac_id}", response_class=HTMLResponse)
async def edit_drug_form(ilac_id: int, request: Request, db: DbSession):
    ilac = db.query(models.Ilac).options(joinedload(models.Ilac.ozellikler)).filter(models.Ilac.id == ilac_id).first()
    if not ilac:
        return RedirectResponse(url="/drugs", status_code=status.HTTP_302_FOUND)
    if not ilac.nfc_kodu:
        ilac.nfc_kodu = get_nfc_code_by_barcode(ilac.barkod)
    ilac.recete_turleri = resolve_recete_turleri(ilac)
    tum_ozellikler = db.query(models.IlacOzellik).all()
    tum_lokasyonlar = db.query(models.WarehouseLocation).options(
        joinedload(models.WarehouseLocation.depo)
    ).filter(models.WarehouseLocation.is_active == True).order_by(
        models.WarehouseLocation.depo_id.asc(),
        models.WarehouseLocation.pick_sequence.asc(),
        models.WarehouseLocation.code.asc()
    ).all()
    return templates.TemplateResponse(
        request=request,
        name="drug_edit_form.html",
        context={
            "ilac": ilac,
            "tum_ozellikler": tum_ozellikler,
            "tum_lokasyonlar": tum_lokasyonlar,
            "user": request.state.user,
        },
    )

@router.get("/api/{ilac_id}")
async def get_drug_json(ilac_id: int, db: DbSession):
    ilac = db.query(models.Ilac).options(joinedload(models.Ilac.ozellikler)).filter(models.Ilac.id == ilac_id).first()
    if not ilac:
        return JSONResponse(status_code=404, content={"error": "İlaç bulunamadı"})
    
    recete_turleri = resolve_recete_turleri(ilac)
    return JSONResponse(content={
        "id": ilac.id,
        "barkod": ilac.barkod or "",
        "ad": ilac.ad or "",
        "etken_madde": ilac.etken_madde or "",
        "jenerik_kodu": ilac.jenerik_kodu or "",
        "jenerik_adi": ilac.jenerik_adi or "",
        "jenerik_grubu": ilac.jenerik_grubu or "",
        "atc_kodu": ilac.atc_kodu or "",
        "nfc_kodu": ilac.nfc_kodu or "",
        "recete_turu": ilac.recete_turu or "",
        "ambalaj": ilac.ambalaj or "",
        "raf_konumu": ilac.raf_konumu or "",
        "uretici": ilac.uretici or "",
        "kutu_ici_adet": ilac.kutu_ici_adet or 1,
        "koli_ici_adet": ilac.koli_ici_adet or 1,
        "recete_turleri": recete_turleri,
        "ozellik_ids": [oz.id for oz in ilac.ozellikler]
    })

@router.post("/edit/{ilac_id}")
async def edit_drug(
    ilac_id: int,
    request: Request,
    barkod: Annotated[str, Form(...)],
    ad: Annotated[str, Form(...)],
    db: DbSession,
    master_db: MasterDbSession,
    etken_madde: Annotated[str, Form()] = "",
    jenerik_kodu: Annotated[str, Form()] = "",
    jenerik_adi: Annotated[str, Form()] = "",
    jenerik_grubu: Annotated[str, Form()] = "",
    atc_kodu: Annotated[str, Form()] = "",
    nfc_kodu: Annotated[str, Form()] = "",
    recete_turu: Annotated[str, Form()] = "",
    ambalaj: Annotated[str, Form()] = "",
    birim: Annotated[str, Form()] = "",
    kutu_ici_adet: Annotated[int, Form()] = 0,
    koli_ici_adet: Annotated[int, Form()] = 1,
    raf_konumu: Annotated[str, Form()] = "",
    uretici: Annotated[str, Form()] = "",
    kritik_stok: Annotated[int, Form()] = 10,
):
    form_data = await request.form()
    ozellik_ids = [int(v) for k, v in form_data.multi_items() if k == "ozellik_ids"]

    ilac = db.query(models.Ilac).filter(models.Ilac.id == ilac_id).first()
    if ilac:
        barkod_clean = barkod.replace("'", "").strip()
        m_info = lookup_master_drug(barkod_clean, master_db) if master_db else None

        clean_jen_kodu = jenerik_kodu.strip() if jenerik_kodu and jenerik_kodu.strip() else (ilac.jenerik_kodu or (m_info.get("jenerik_kodu") if m_info else ""))
        clean_jen_adi = jenerik_adi.strip() if jenerik_adi and jenerik_adi.strip() else (ilac.jenerik_adi or (m_info.get("jenerik_adi") if m_info else ""))
        clean_atc = atc_kodu.strip().upper() if atc_kodu and atc_kodu.strip() else (ilac.atc_kodu or (m_info.get("atc_kodu") if m_info else ""))
        clean_nfc = nfc_kodu.strip().upper() if nfc_kodu and nfc_kodu.strip() else (ilac.nfc_kodu or (m_info.get("nfc_kodu") if m_info else "") or get_nfc_code_by_barcode(barkod_clean))

        ilac.barkod = barkod_clean
        ilac.ad = ad
        ilac.etken_madde = etken_madde or ilac.etken_madde or (m_info.get("etken_madde") if m_info else "")
        ilac.jenerik_kodu = clean_jen_kodu
        ilac.jenerik_adi = clean_jen_adi
        ilac.jenerik_grubu = jenerik_grubu
        ilac.atc_kodu = clean_atc
        ilac.nfc_kodu = clean_nfc
        ilac.recete_turu = recete_turu.strip() if recete_turu and recete_turu.strip() else (ilac.recete_turu or (m_info.get("recete_turu") if m_info else None))
        ilac.ambalaj = ambalaj or ilac.ambalaj or (m_info.get("ambalaj") if m_info else "")
        ilac.birim = birim
        if kutu_ici_adet and int(kutu_ici_adet) > 0:
            ilac.kutu_ici_adet = int(kutu_ici_adet)
        elif not ilac.kutu_ici_adet or ilac.kutu_ici_adet <= 1:
            ilac.kutu_ici_adet = parse_package_dose_count(ilac.ambalaj, ilac.ad)
        ilac.koli_ici_adet = koli_ici_adet
        ilac.raf_konumu = raf_konumu
        ilac.uretici = uretici or ilac.uretici or (m_info.get("uretici") if m_info else "")
        ilac.kritik_stok = kritik_stok
        
        ilac.ozellikler = db.query(models.IlacOzellik).filter(models.IlacOzellik.id.in_(ozellik_ids)).all() if ozellik_ids else []
        db.commit()

        if request.headers.get("x-requested-with") == "XMLHttpRequest" or "application/json" in request.headers.get("accept", "") or request.query_params.get("format") == "json":
            recete_turleri = resolve_recete_turleri(ilac)
            return JSONResponse(content={
                "success": True,
                "msg": f"'{ilac.ad}' başarıyla güncellendi.",
                "ilac": {
                    "id": ilac.id,
                    "barkod": ilac.barkod,
                    "ad": ilac.ad,
                    "etken_madde": ilac.etken_madde or "",
                    "jenerik_kodu": ilac.jenerik_kodu or "",
                    "jenerik_adi": ilac.jenerik_adi or "",
                    "jenerik_grubu": ilac.jenerik_grubu or "",
                    "atc_kodu": ilac.atc_kodu or "",
                    "nfc_kodu": ilac.nfc_kodu or "",
                    "recete_turu": ilac.recete_turu or "",
                    "ambalaj": ilac.ambalaj or "",
                    "raf_konumu": ilac.raf_konumu or "",
                    "uretici": ilac.uretici or "",
                    "kutu_ici_adet": ilac.kutu_ici_adet or 1,
                    "koli_ici_adet": ilac.koli_ici_adet or 1,
                    "recete_turleri": recete_turleri,
                    "ozellikler": [
                        {
                            "id": oz.id,
                            "ad": oz.ad,
                            "kod": oz.kod,
                            "renk": oz.renk,
                            "ikon": oz.ikon,
                            "aciklama": oz.aciklama or ""
                        } for oz in ilac.ozellikler
                    ]
                }
            })

    return RedirectResponse(url=f"/drugs?msg=İlaç+kartı+güncellendi.&edited_id={ilac_id}#drug-{ilac_id}", status_code=status.HTTP_302_FOUND)

@router.post("/features/add")
async def add_feature(
    request: Request,
    ad: Annotated[str, Form(...)],
    db: DbSession,
    kod: Annotated[str, Form()] = "",
    renk: Annotated[str, Form()] = "info",
    ikon: Annotated[str, Form()] = "fa-shield-halved",
    aciklama: Annotated[str, Form()] = "",
):
    clean_kod = (kod.strip().lower() if kod and kod.strip() else ad.strip().lower().replace(" ", "_"))
    clean_kod = "".join(c for c in clean_kod if c.isalnum() or c == "_")
    existing = db.query(models.IlacOzellik).filter(models.IlacOzellik.kod == clean_kod).first()
    if existing:
        return RedirectResponse(url="/drugs?error=Bu+kodlu+veya+isimli+bilgi+kartı+zaten+var.", status_code=status.HTTP_302_FOUND)
    new_feat = models.IlacOzellik(
        kod=clean_kod,
        ad=ad.strip(),
        renk=renk,
        ikon=ikon.strip(),
        aciklama=aciklama.strip()
    )
    db.add(new_feat)
    db.commit()
    return RedirectResponse(url="/drugs?msg=Yeni+bilgi+kartı+başarıyla+tanımlandı.", status_code=status.HTTP_302_FOUND)

@router.post("/features/edit/{feat_id}")
async def edit_feature(
    feat_id: int,
    request: Request,
    ad: Annotated[str, Form(...)],
    db: DbSession,
    renk: Annotated[str, Form()] = "info",
    ikon: Annotated[str, Form()] = "fa-shield-halved",
    aciklama: Annotated[str, Form()] = "",
):
    feat = db.query(models.IlacOzellik).filter(models.IlacOzellik.id == feat_id).first()
    if feat:
        feat.ad = ad.strip()
        feat.renk = renk
        feat.ikon = ikon.strip()
        feat.aciklama = aciklama.strip()
        db.commit()
    return RedirectResponse(url="/drugs?msg=Bilgi+kartı+güncellendi.", status_code=status.HTTP_302_FOUND)

@router.post("/features/delete/{feat_id}")
async def delete_feature(
    feat_id: int,
    request: Request,
    db: DbSession,
):
    feat = db.query(models.IlacOzellik).filter(models.IlacOzellik.id == feat_id).first()
    if feat:
        db.delete(feat)
        db.commit()
    return RedirectResponse(url="/drugs?msg=Bilgi+kartı+silindi.", status_code=status.HTTP_302_FOUND)

@router.post("/assign-features/{ilac_id}")
async def assign_drug_features(
    ilac_id: int,
    request: Request,
    db: DbSession,
):
    ilac = db.query(models.Ilac).filter(models.Ilac.id == ilac_id).first()
    if not ilac:
        return RedirectResponse(url="/drugs?error=İlaç+bulunamadı.", status_code=status.HTTP_302_FOUND)
    form_data = await request.form()
    feat_ids = [int(v) for k, v in form_data.multi_items() if k == "ozellik_ids"]
    feats = db.query(models.IlacOzellik).filter(models.IlacOzellik.id.in_(feat_ids)).all() if feat_ids else []
    ilac.ozellikler = feats
    db.commit()
    return RedirectResponse(url=f"/drugs?msg=İlaç+bilgi+kartları+güncellendi.&edited_id={ilac_id}#drug-{ilac_id}", status_code=status.HTTP_302_FOUND)

@router.post("/delete/{ilac_id}")
@router.get("/delete/{ilac_id}", include_in_schema=False)
async def delete_drug(ilac_id: int, request: Request, db: DbSession):
    is_ajax = request.headers.get("x-requested-with") == "XMLHttpRequest" or "application/json" in request.headers.get("accept", "")
    ilac = db.query(models.Ilac).filter(models.Ilac.id == ilac_id).first()
    if not ilac:
        if is_ajax:
            return JSONResponse(status_code=404, content={"success": False, "msg": "Silinecek ilaç bulunamadı."})
        return RedirectResponse(url="/drugs?error=Silinecek+ilaç+bulunamadı.", status_code=status.HTTP_302_FOUND)
        
    toplam_stok = sum([sum([s.miktar for s in p.stoklar]) for p in ilac.partiler])
    if toplam_stok > 0:
        msg = f"'{ilac.ad}' ilacına ait mevcut stok ({toplam_stok} Adet) bulunmaktadır. Silmeden önce stok çıkışı yapılmalıdır."
        if is_ajax:
            return JSONResponse(status_code=400, content={"success": False, "msg": msg})
        return RedirectResponse(url=f"/drugs?error={msg}", status_code=status.HTTP_302_FOUND)

    hareket_count = 0
    for p in ilac.partiler:
        hareket_count += len(p.hareketler)
    if hareket_count > 0:
        msg = f"'{ilac.ad}' ilacına ait stok hareket kayıtları bulunduğundan silinemez."
        if is_ajax:
            return JSONResponse(status_code=400, content={"success": False, "msg": msg})
        return RedirectResponse(url=f"/drugs?error={msg}", status_code=status.HTTP_302_FOUND)

    ilac_adi = ilac.ad
    db.delete(ilac)
    db.commit()

    if is_ajax:
        return JSONResponse(content={"success": True, "msg": f"'{ilac_adi}' ilaç kartı başarıyla silindi."})
    return RedirectResponse(url=f"/drugs?msg={ilac_adi}+başarıyla+silindi.", status_code=status.HTTP_302_FOUND)

@router.get("/generic-limits", response_class=HTMLResponse)
async def generic_limits_page(request: Request, db: DbSession):
    msg = request.query_params.get("msg")
    error = request.query_params.get("error")

    # Eager load partiler and stoklar to avoid N+1 queries
    ilaclar = db.query(models.Ilac).options(
        joinedload(models.Ilac.partiler).joinedload(models.Parti.stoklar)
    ).all()

    jenerik_limits = db.query(models.JenerikKritikStok).all()
    limits_map = {l.grup_kodu: l.kritik_stok for l in jenerik_limits}
    
    # Memoization caches for ATC and NFC lookups
    atc_memo = {}
    nfc_memo = {}

    def fetch_atc(c):
        if not c:
            return get_atc_info("")
        if c not in atc_memo:
            atc_memo[c] = get_atc_info(c)
        return atc_memo[c]

    def fetch_nfc(c):
        if not c:
            return get_nfc_info("")
        if c not in nfc_memo:
            nfc_memo[c] = get_nfc_info(c)
        return nfc_memo[c]

    # Pre-calculate default kritik_stok per group in single pass (O(N) instead of O(N^2))
    group_default_stok = {}
    for i in ilaclar:
        is_custom = True if (i.jenerik_grubu and i.jenerik_grubu.strip()) else False
        g_kodu = i.jenerik_grubu.strip() if is_custom else (i.jenerik_adi.strip() if (i.jenerik_adi and i.jenerik_adi.strip()) else (i.jenerik_kodu.strip() if (i.jenerik_kodu and i.jenerik_kodu.strip()) else (i.etken_madde.strip() if (i.etken_madde and i.etken_madde.strip()) else i.ad)))
        group_default_stok[g_kodu] = group_default_stok.get(g_kodu, 0) + (i.kritik_stok or 0)

    custom_groups_set = set()
    available_atc_set = set()
    available_nfc_set = set()
    all_ilaclar_list = []
    
    jenerik_map = {}
    groups = {}

    for i in ilaclar:
        if i.jenerik_grubu and i.jenerik_grubu.strip():
            custom_groups_set.add(i.jenerik_grubu.strip())
        if i.atc_kodu and i.atc_kodu.strip():
            available_atc_set.add(i.atc_kodu.strip())
        if i.nfc_kodu and i.nfc_kodu.strip():
            available_nfc_set.add(i.nfc_kodu.strip())
            
        std_jenerik_name = i.jenerik_adi.strip() if (i.jenerik_adi and i.jenerik_adi.strip()) else (i.jenerik_kodu.strip() if (i.jenerik_kodu and i.jenerik_kodu.strip()) else i.ad)
        std_jenerik_code = i.jenerik_kodu.strip() if (i.jenerik_kodu and i.jenerik_kodu.strip()) else ""

        if std_jenerik_name not in jenerik_map:
            jenerik_map[std_jenerik_name] = {
                "name": std_jenerik_name,
                "code": std_jenerik_code,
                "atc_kodlari": set(),
                "nfc_kodlari": set(),
                "ilac_ids": [],
                "jenerik_grubu": i.jenerik_grubu or ""
            }
        jenerik_map[std_jenerik_name]["ilac_ids"].append(i.id)
        if i.atc_kodu and i.atc_kodu.strip():
            jenerik_map[std_jenerik_name]["atc_kodlari"].add(i.atc_kodu.strip())
        if i.nfc_kodu and i.nfc_kodu.strip():
            jenerik_map[std_jenerik_name]["nfc_kodlari"].add(i.nfc_kodu.strip())

        all_ilaclar_list.append({
            "id": i.id,
            "barkod": i.barkod,
            "ad": i.ad,
            "etken_madde": i.etken_madde or "",
            "jenerik_kodu": i.jenerik_kodu or "",
            "jenerik_adi": std_jenerik_name,
            "jenerik_grubu": i.jenerik_grubu or "",
            "atc_kodu": i.atc_kodu or "",
            "nfc_kodu": i.nfc_kodu or "",
        })

        # Group calculation
        is_custom = True if (i.jenerik_grubu and i.jenerik_grubu.strip()) else False
        grup_kodu = i.jenerik_grubu.strip() if is_custom else (i.jenerik_adi.strip() if (i.jenerik_adi and i.jenerik_adi.strip()) else (i.jenerik_kodu.strip() if (i.jenerik_kodu and i.jenerik_kodu.strip()) else (i.etken_madde.strip() if (i.etken_madde and i.etken_madde.strip()) else i.ad)))
        grup_adi = grup_kodu
        ozel_jenerik_grubu = i.jenerik_grubu.strip() if is_custom else ""

        if grup_kodu not in groups:
            groups[grup_kodu] = {
                "grup_kodu": grup_kodu,
                "grup_adi": grup_adi,
                "ozel_jenerik_grubu": ozel_jenerik_grubu,
                "is_custom": is_custom,
                "kapsanan_jenerikler_dict": {},
                "atc_kodlari": set(),
                "nfc_kodlari": set(),
                "ilaclar": [],
                "kritik_stok": limits_map.get(grup_kodu, group_default_stok.get(grup_kodu, 10))
            }

        groups[grup_kodu]["kapsanan_jenerikler_dict"][std_jenerik_name] = {
            "name": std_jenerik_name,
            "code": std_jenerik_code
        }
        if i.atc_kodu and i.atc_kodu.strip():
            groups[grup_kodu]["atc_kodlari"].add(i.atc_kodu.strip())
        if i.nfc_kodu and i.nfc_kodu.strip():
            groups[grup_kodu]["nfc_kodlari"].add(i.nfc_kodu.strip())

        toplam_stok_ilac = sum((s.miktar or 0) for p in i.partiler for s in p.stoklar)

        groups[grup_kodu]["ilaclar"].append({
            "id": i.id,
            "barkod": i.barkod,
            "ad": i.ad,
            "etken_madde": i.etken_madde or "",
            "jenerik_kodu": i.jenerik_kodu or "",
            "jenerik_adi": std_jenerik_name,
            "jenerik_grubu": i.jenerik_grubu or "",
            "atc_kodu": i.atc_kodu or "",
            "nfc_kodu": i.nfc_kodu or "",
            "toplam_stok": toplam_stok_ilac
        })

    all_jenerikler_list = [
        {
            "name": j_name,
            "code": j_info["code"],
            "atc": ", ".join(sorted(list(j_info["atc_kodlari"]))),
            "nfc": ", ".join(sorted(list(j_info["nfc_kodlari"]))),
            "ilac_sayisi": len(j_info["ilac_ids"]),
            "ilac_ids": j_info["ilac_ids"],
            "jenerik_grubu": j_info["jenerik_grubu"]
        }
        for j_name, j_info in jenerik_map.items()
    ]

    available_atc_info_list = [fetch_atc(code) for code in sorted(list(available_atc_set))]
    available_nfc_info_list = [fetch_nfc(code) for code in sorted(list(available_nfc_set))]

    atc_grouped_list, nfc_grouped_list = build_atc_nfc_grouped_lists(available_atc_set, available_nfc_set, fetch_atc, fetch_nfc)

    for g_kodu, grp in groups.items():
        grp["kapsanan_jenerikler"] = sorted(list(grp["kapsanan_jenerikler_dict"].values()), key=lambda x: x["name"])
        grp["jenerik_kodlari"] = sorted(list(set(kj["code"] for kj in grp["kapsanan_jenerikler"] if kj.get("code"))))
        grp["atc_list"] = sorted(list(grp["atc_kodlari"]))
        grp["nfc_list"] = sorted(list(grp["nfc_kodlari"]))
        grp["atc_info_list"] = [fetch_atc(c) for c in grp["atc_list"]]
        grp["nfc_info_list"] = [fetch_nfc(c) for c in grp["nfc_list"]]
        grp["grup_toplam_stok"] = sum(i["toplam_stok"] for i in grp["ilaclar"])

    return templates.TemplateResponse(
        request=request,
        name="generic_limits.html",
        context={
            "groups": list(groups.values()),
            "all_ilaclar": all_ilaclar_list,
            "all_jenerikler": sorted(all_jenerikler_list, key=lambda x: x["name"]),
            "custom_groups": sorted(list(custom_groups_set)),
            "available_atc_list": available_atc_info_list,
            "available_nfc_list": available_nfc_info_list,
            "atc_grouped_list": atc_grouped_list,
            "nfc_grouped_list": nfc_grouped_list,
            "msg": msg,
            "error": error,
            "user": request.state.user,
        },
    )

@router.post("/generic-limits/update")
async def update_generic_limit(
    request: Request,
    grup_kodu: Annotated[str, Form(...)],
    kritik_stok: Annotated[int, Form(...)],
    db: DbSession,
    grup_adi: Annotated[str, Form()] = "",
):
    limit_rec = db.query(models.JenerikKritikStok).filter(models.JenerikKritikStok.grup_kodu == grup_kodu).first()
    if not limit_rec:
        limit_rec = models.JenerikKritikStok(grup_kodu=grup_kodu, grup_adi=grup_adi, kritik_stok=kritik_stok)
        db.add(limit_rec)
    else:
        limit_rec.kritik_stok = kritik_stok
        if grup_adi:
            limit_rec.grup_adi = grup_adi
    db.commit()
    return RedirectResponse(url="/drugs/generic-limits?msg=Kritik+stok+eşiği+güncellendi.", status_code=status.HTTP_302_FOUND)

@router.post("/generic-limits/assign-group")
async def assign_generic_group(
    request: Request,
    grup_adi: Annotated[str, Form(...)],
    db: DbSession,
    old_grup_adi: Annotated[Optional[str], Form()] = None,
    jenerik_names: Annotated[List[str], Form()] = [],
    ilac_ids: Annotated[List[int], Form()] = [],
    kritik_stok: OptionalIntForm = None,
):
    grup_adi_clean = grup_adi.strip() if grup_adi else ""
    old_grup_clean = old_grup_adi.strip() if old_grup_adi else ""

    if not grup_adi_clean:
        return RedirectResponse(url="/drugs/generic-limits?error=Lütfen+geçerli+bir+Özel+Jenerik+Grubu+adı+girin.", status_code=status.HTTP_302_FOUND)
    
    target_ilac_ids = set(ilac_ids)

    if jenerik_names:
        matching_drugs = db.query(models.Ilac).filter(
            or_(
                models.Ilac.jenerik_adi.in_(jenerik_names),
                models.Ilac.jenerik_kodu.in_(jenerik_names),
                models.Ilac.ad.in_(jenerik_names)
            )
        ).all()
        for md in matching_drugs:
            target_ilac_ids.add(md.id)

    if not target_ilac_ids:
        return RedirectResponse(url="/drugs/generic-limits?error=En+az+bir+jenerik+grup+veya+ilaç+seçmelisiniz.", status_code=status.HTTP_302_FOUND)

    final_drug_ids = list(target_ilac_ids)

    if old_grup_clean:
        db.query(models.Ilac).filter(
            models.Ilac.jenerik_grubu == old_grup_clean,
            models.Ilac.id.not_in(final_drug_ids)
        ).update({models.Ilac.jenerik_grubu: None}, synchronize_session=False)

    db.query(models.Ilac).filter(models.Ilac.id.in_(final_drug_ids)).update(
        {models.Ilac.jenerik_grubu: grup_adi_clean},
        synchronize_session=False
    )
    
    if kritik_stok is not None and kritik_stok >= 0:
        if old_grup_clean and old_grup_clean != grup_adi_clean:
            db.query(models.JenerikKritikStok).filter(models.JenerikKritikStok.grup_kodu == old_grup_clean).delete(synchronize_session=False)

        limit_rec = db.query(models.JenerikKritikStok).filter(models.JenerikKritikStok.grup_kodu == grup_adi_clean).first()
        if not limit_rec:
            limit_rec = models.JenerikKritikStok(grup_kodu=grup_adi_clean, grup_adi=grup_adi_clean, kritik_stok=kritik_stok)
            db.add(limit_rec)
        else:
            limit_rec.kritik_stok = kritik_stok
            limit_rec.grup_adi = grup_adi_clean

    db.commit()
    return RedirectResponse(url=f"/drugs/generic-limits?msg='{grup_adi_clean}'+özel+grubu+başarıyla+güncellendi+({len(final_drug_ids)}+ilaç+birleştirildi).", status_code=status.HTTP_302_FOUND)

@router.post("/generic-limits/unassign-group")
async def unassign_generic_group(
    request: Request,
    grup_kodu: Annotated[str, Form(...)],
    db: DbSession,
):
    grup_kodu_clean = grup_kodu.strip() if grup_kodu else ""
    if not grup_kodu_clean:
        return RedirectResponse(url="/drugs/generic-limits", status_code=status.HTTP_302_FOUND)
        
    updated_count = db.query(models.Ilac).filter(models.Ilac.jenerik_grubu == grup_kodu_clean).update(
        {models.Ilac.jenerik_grubu: None},
        synchronize_session=False
    )
    db.commit()
    return RedirectResponse(url=f"/drugs/generic-limits?msg='{grup_kodu_clean}'+özel+grubu+kaldırıldı+({updated_count}+ilaç+serbest+bırakıldı).", status_code=status.HTTP_302_FOUND)

@router.get("/search_master")
async def search_master(q: Annotated[str, Query()], db: MasterDbSession):
    if not q or len(q) < 2:
        return JSONResponse({"results": []})
        
    query = text("""
        SELECT 
            REPLACE(p.barkod, "'", "") AS clean_barkod,
            p.urun_adi,
            p.firma_adi,
            p.ambalaj,
            p.etkin_maddeler,
            p.jenerik_kodu,
            p.recete_turu,
            p.nfc,
            g.jenerik_adi,
            g.atc_kodu
        FROM products p
        LEFT JOIN generics g ON p.jenerik_kodu = g.jenerik_kodu
        WHERE REPLACE(p.barkod, "'", "") LIKE :q_start
           OR p.urun_adi LIKE :q_like
           OR g.jenerik_adi LIKE :q_like
           OR g.jenerik_kodu LIKE :q_like
           OR g.atc_kodu LIKE :q_like
           OR p.etkin_maddeler LIKE :q_like
        LIMIT 15
    """)
    
    result = db.execute(query, {"q_start": f"{q}%", "q_like": f"%{q}%"}).fetchall()
    
    results_list = []
    for row in result:
        etken_maddeler = ""
        try:
            if row.etkin_maddeler:
                parsed = json.loads(row.etkin_maddeler)
                if isinstance(parsed, list):
                    etken_maddeler = ", ".join(parsed)
                elif isinstance(parsed, dict):
                    etken_maddeler = ", ".join([v for k,v in parsed.items()])
                else:
                    etken_maddeler = str(parsed)
        except Exception:
            etken_maddeler = str(row.etkin_maddeler) if row.etkin_maddeler else ""
            
        nfc_k = str(row.nfc).strip().upper() if getattr(row, 'nfc', None) and str(row.nfc).strip() else get_nfc_code_by_barcode(row.clean_barkod)
        results_list.append({
            "barkod": row.clean_barkod,
            "ad": row.urun_adi,
            "uretici": row.firma_adi or "",
            "etken_madde": etken_maddeler,
            "ambalaj": row.ambalaj or "",
            "jenerik_kodu": row.jenerik_kodu or "",
            "jenerik_adi": row.jenerik_adi or etken_maddeler or row.urun_adi,
            "atc_kodu": row.atc_kodu or "",
            "nfc_kodu": nfc_k or "",
            "recete_turu": normalize_recete_turu(row.recete_turu)
        })
        
    return JSONResponse({"results": results_list})

@router.get("/search_generics")
async def search_generics(q: Annotated[str, Query()], db: MasterDbSession):
    if not q or len(q) < 1:
        return JSONResponse({"results": []})
        
    query = text("""
        SELECT DISTINCT jenerik_kodu, jenerik_adi, atc_kodu
        FROM generics
        WHERE jenerik_kodu LIKE :q
           OR jenerik_adi LIKE :q
           OR atc_kodu LIKE :q
        ORDER BY jenerik_kodu ASC
        LIMIT 25
    """)
    
    result = db.execute(query, {"q": f"%{q}%"}).fetchall()
    results_list = []
    for r in result:
        results_list.append({
            "jenerik_kodu": r.jenerik_kodu or "",
            "jenerik_adi": r.jenerik_adi or "",
            "atc_kodu": r.atc_kodu or ""
        })
    return JSONResponse({"results": results_list})

@router.get("/get_generic_detail")
async def get_generic_detail(code: Annotated[str, Query()], db: MasterDbSession):
    if not code or not code.strip():
        return JSONResponse({"found": False})
    clean_code = code.strip().upper()
    query = text("""
        SELECT jenerik_kodu, jenerik_adi, atc_kodu
        FROM generics
        WHERE UPPER(jenerik_kodu) = :c OR UPPER(jenerik_adi) = :c
        LIMIT 1
    """)
    r = db.execute(query, {"c": clean_code}).fetchone()
    if r:
        return JSONResponse({
            "found": True,
            "jenerik_kodu": r.jenerik_kodu or "",
            "jenerik_adi": r.jenerik_adi or "",
            "atc_kodu": r.atc_kodu or ""
        })
    return JSONResponse({"found": False})

@router.get("/search_ingredients")
async def search_ingredients(q: Annotated[str, Query()], db: MasterDbSession):
    if not q or len(q) < 2:
        return JSONResponse({"results": []})
        
    query = text("""
        SELECT DISTINCT etkin_madde
        FROM teb_active_ingredients
        WHERE etkin_madde LIKE :q
        ORDER BY etkin_madde ASC
        LIMIT 20
    """)
    
    result = db.execute(query, {"q": f"%{q}%"}).fetchall()
    return JSONResponse({"results": [r.etkin_madde for r in result if r.etkin_madde]})

def map_row_columns(row_dict: dict) -> dict:
    mapped = {
        "barkod": "",
        "ad": "",
        "atc_kodu": "",
        "jenerik_kodu": "",
        "jenerik_adi": "",
        "uretici": "",
        "etken_madde": "",
        "recete_turu": ""
    }
    
    for key, val in row_dict.items():
        if not key or val is None:
            continue
        k = str(key).strip().upper().replace("İ", "I").replace("Ç", "C").replace("Ğ", "G").replace("Ö", "O").replace("Ş", "S").replace("Ü", "U")
        v = str(val).strip()
        if not v:
            continue
        
        if any(b in k for b in ["BARKOD", "BARCODE", "GTIN", "ORJKOD", "ORJ KOD", "ORJ_KOD"]):
            mapped["barkod"] = clean_gtin(v)
        elif any(a in k for a in ["ILACADI", "ILAC ADI", "ILAC_ADI", "DRUG_NAME", "URUN_ADI", "URUN ADI"]):
            mapped["ad"] = v
        elif k in ["ATCKODU", "ATC_KODU", "ATC KODU"]:
            mapped["atc_kodu"] = v.upper()
        elif any(j in k for j in ["ILACJENERIKKODU", "ILAC JENERIK KODU", "JENERIKKODU", "JENERIK KODU", "GENERIC_CODE"]):
            mapped["jenerik_kodu"] = v
        elif any(j in k for j in ["ILACJENERIKADI", "ILAC JENERIK ADI", "JENERIKADI", "JENERIK ADI", "GENERIC_NAME"]):
            mapped["jenerik_adi"] = v
        elif any(u in k for u in ["URETICI", "FIRMA", "MANUFACTURER"]):
            mapped["uretici"] = v
        elif any(e in k for e in ["ETKEN MADDE", "ETKIN MADDE", "ETKEN_MADDE", "INGREDIENT"]):
            mapped["etken_madde"] = v
        elif any(n in k for n in ["NFCKODU", "NFC KODU", "NFC_KODU", "NFC"]):
            mapped["nfc_kodu"] = v.upper()

    return mapped

@router.get("/import", response_class=HTMLResponse)
async def import_drugs_page(request: Request, db: DbSession):
    depolar = db.query(models.Depo).all()
    return templates.TemplateResponse(
        request=request,
        name="drug_import.html",
        context={
            "depolar": depolar,
            "user": request.state.user,
        },
    )

@router.get("/import/sample")
async def download_sample_csv():
    sample_content = "BARKOD;İlaç Adı;ATCKODU;ILACJENERIKKODU;ILACJENERIKADI;NFCKODU\n8699606692195;Polifleks %5 Dekstroz;B05BB02;J5898;Dekstroz Solüsyonu;FQE\n8699500000001;Özel İlaç Örneği;A01AA01;J0001;Parasetamol Jenerik;A01\n"
    return Response(
        content=sample_content.encode("utf-8-sig"),
        media_type="text/csv",
        headers={"Content-Disposition": "attachment; filename=ornek_ilac_aktarim_sablonu.csv"}
    )

@router.post("/import", response_class=HTMLResponse)
async def process_import_csv(
    request: Request,
    file: Annotated[UploadFile, File(...)],
    db: DbSession,
    master_db: MasterDbSession,
    aktar_stok: Annotated[Optional[str], Form()] = None,
    stok_depo_id: Annotated[Optional[str], Form()] = None,
):
    do_stok = bool(aktar_stok and aktar_stok.strip() in ("1", "on", "true", "yes"))
    clean_stok_depo_id = int(stok_depo_id) if (do_stok and stok_depo_id and str(stok_depo_id).isdigit()) else None
    stok_depo = None
    if do_stok and clean_stok_depo_id:
        stok_depo = db.query(models.Depo).filter(models.Depo.id == clean_stok_depo_id).first()
        if not stok_depo:
            do_stok = False

    depolar = db.query(models.Depo).all()
    if not file or not file.filename:
        return templates.TemplateResponse(
            request=request,
            name="drug_import.html",
            context={
                "error_msg": "Lütfen geçerli bir Excel (.xlsx) veya CSV dosyası seçiniz.",
                "depolar": depolar,
                "user": request.state.user,
            },
        )
        
    filename = file.filename.lower()
    content_bytes = await file.read()
    
    rows_data = []
    
    if filename.endswith(".xlsx") or filename.endswith(".xls"):
        try:
            import openpyxl
            wb = openpyxl.load_workbook(io.BytesIO(content_bytes), data_only=True)
            ws = wb.active
            excel_rows = list(ws.iter_rows(values_only=True))
            if not excel_rows or len(excel_rows) < 2:
                return templates.TemplateResponse(
                    request=request,
                    name="drug_import.html",
                    context={
                        "error_msg": "Excel dosyası boş veya sadece başlık satırı içeriyor.",
                        "depolar": depolar,
                        "user": request.state.user,
                    },
                )
            
            headers = [str(h).strip().upper() if h is not None else "" for h in excel_rows[0]]
            for r in excel_rows[1:]:
                if not r or not any(r):
                    continue
                rdict = {}
                for idx, cell in enumerate(r):
                    if idx < len(headers) and headers[idx] and cell is not None:
                        rdict[headers[idx]] = str(cell).strip()
                if rdict:
                    rows_data.append(rdict)
        except Exception as e:
            return templates.TemplateResponse(
                request=request,
                name="drug_import.html",
                context={
                    "error_msg": f"Excel dosyası okunamadı: {str(e)}",
                    "depolar": depolar,
                    "user": request.state.user,
                },
            )
    else:
        content_str = None
        for encoding in ["utf-8-sig", "utf-8", "iso-8859-9", "latin-1"]:
            try:
                content_str = content_bytes.decode(encoding)
                break
            except Exception:
                continue

        if not content_str:
            return templates.TemplateResponse(
                request=request,
                name="drug_import.html",
                context={
                    "error_msg": "Dosya okunamadı. Lütfen geçerli bir CSV veya Excel dosyası yükleyin.",
                    "depolar": depolar,
                    "user": request.state.user,
                },
            )

        lines = [line.strip() for line in content_str.splitlines() if line.strip()]
        if not lines or len(lines) < 2:
            return templates.TemplateResponse(
                request=request,
                name="drug_import.html",
                context={
                    "error_msg": "CSV dosyası boş veya yetersiz veri içeriyor.",
                    "depolar": depolar,
                    "user": request.state.user,
                },
            )

        delimiter = ';' if ';' in lines[0] else (',' if ',' in lines[0] else '\t')
        reader = csv.reader(lines, delimiter=delimiter)
        
        try:
            headers = [h.strip().upper() for h in next(reader)]
            for row in reader:
                if not row or not any(row):
                    continue
                rdict = {}
                for idx, cell in enumerate(row):
                    if idx < len(headers):
                        rdict[headers[idx]] = cell.strip()
                if rdict:
                    rows_data.append(rdict)
        except Exception as e:
            return templates.TemplateResponse(
                request=request,
                name="drug_import.html",
                context={
                    "error_msg": f"CSV dosyası ayrıştırılamadı: {str(e)}",
                    "depolar": depolar,
                    "user": request.state.user,
                },
            )

    if not rows_data:
        return templates.TemplateResponse(
            request=request,
            name="drug_import.html",
            context={
                "error_msg": "Dosyadan aktarılacak barkod ve ilaç verisi bulunamadı.",
                "depolar": depolar,
                "user": request.state.user,
            },
        )

    summary = {
        "total_read": 0,
        "added_master": 0,
        "already_exists": 0,
        "added_basic": 0,
        "stok_updated": 0,
        "stok_no_kalan": 0,
        "stok_depo_adi": stok_depo.ad if stok_depo else "",
        "details": []
    }

    processed_barcodes = set()

    for row_dict in rows_data:
        mapped = map_row_columns(row_dict)
        b = mapped.get("barkod")
        if not b or len(b) < 3 or b in processed_barcodes:
            continue

        processed_barcodes.add(b)
        summary["total_read"] += 1

        existing = db.query(models.Ilac).filter(models.Ilac.barkod == b).first()
        if existing:
            if not existing.nfc_kodu:
                m_info_ex = lookup_master_drug(b, master_db)
                auto_nfc = (m_info_ex.get("nfc_kodu") if m_info_ex else None) or mapped.get("nfc_kodu") or get_nfc_code_by_barcode(b)
                if auto_nfc:
                    existing.nfc_kodu = auto_nfc
            summary["already_exists"] += 1
            summary["details"].append({
                "barkod": b,
                "ad": existing.ad,
                "atc_kodu": existing.atc_kodu or "",
                "nfc_kodu": existing.nfc_kodu or "",
                "jenerik_adi": existing.jenerik_adi or "",
                "uretici": existing.uretici or "",
                "recete_turu": existing.recete_turu or "",
                "status": "exists"
            })
            continue

        # Master DB lookup
        m_info = lookup_master_drug(b, master_db)
        
        if m_info:
            nfc_k = m_info.get("nfc_kodu") or mapped.get("nfc_kodu") or get_nfc_code_by_barcode(b)
            yeni_ilac = models.Ilac(
                barkod=b,
                ad=m_info["ad"],
                uretici=m_info["uretici"],
                etken_madde=m_info["etken_madde"],
                ambalaj=m_info["ambalaj"],
                jenerik_kodu=m_info["jenerik_kodu"],
                jenerik_adi=m_info["jenerik_adi"],
                atc_kodu=m_info["atc_kodu"],
                nfc_kodu=nfc_k,
                recete_turu=m_info.get("recete_turu"),
                birim="Adet",
                koli_ici_adet=1,
                kritik_stok=0
            )
            db.add(yeni_ilac)
            summary["added_master"] += 1
            summary["details"].append({
                "barkod": b,
                "ad": m_info["ad"],
                "atc_kodu": m_info["atc_kodu"] or "",
                "nfc_kodu": nfc_k or "",
                "jenerik_adi": m_info["jenerik_adi"] or "",
                "uretici": m_info["uretici"] or "",
                "recete_turu": yeni_ilac.recete_turu or "",
                "status": "master"
            })
        else:
            ad_val = mapped.get("ad") or f"İlaç (Barkod: {b})"
            atc_val = mapped.get("atc_kodu") or ""
            jen_kodu_val = mapped.get("jenerik_kodu") or ""
            jen_adi_val = mapped.get("jenerik_adi") or ad_val
            uretici_val = mapped.get("uretici") or ""
            etken_val = mapped.get("etken_madde") or ""
            recete_val = ""
            nfc_val = mapped.get("nfc_kodu") or get_nfc_code_by_barcode(b)

            yeni_ilac = models.Ilac(
                barkod=b,
                ad=ad_val,
                uretici=uretici_val,
                etken_madde=etken_val,
                jenerik_kodu=jen_kodu_val,
                jenerik_adi=jen_adi_val,
                atc_kodu=atc_val,
                recete_turu=recete_val,
                nfc_kodu=nfc_val,
                birim="Adet",
                koli_ici_adet=1,
                kritik_stok=0
            )
            db.add(yeni_ilac)
            summary["added_basic"] += 1
            summary["details"].append({
                "barkod": b,
                "ad": ad_val,
                "atc_kodu": atc_val,
                "nfc_kodu": nfc_val or "",
                "jenerik_adi": jen_adi_val,
                "uretici": uretici_val,
                "recete_turu": recete_val,
                "status": "basic"
            })

    # --- İSTEĞE BAĞLI STOK AKTARIMI ---
    if do_stok and stok_depo:
        for row_dict in rows_data:
            mapped = map_row_columns(row_dict)
            b = mapped.get("barkod")
            if not b or len(b) < 3:
                continue

            # KALAN veya MIKTAR sütununu oku
            kalan_raw = None
            for col_key in ["KALAN", "MIKTAR", "ADET", "QTY", "QUANTITY", "TOPLAM"]:
                kalan_raw = row_dict.get(col_key)
                if kalan_raw is not None and str(kalan_raw).strip():
                    break

            if kalan_raw is None or str(kalan_raw).strip() == "":
                summary["stok_no_kalan"] += 1
                continue

            try:
                kalan_miktar = int(float(str(kalan_raw).replace(",", ".").strip()))
            except Exception:
                summary["stok_no_kalan"] += 1
                continue

            if kalan_miktar < 0:
                kalan_miktar = 0

            # İlaç kartını bul
            ilac = db.query(models.Ilac).filter(models.Ilac.barkod == b).first()
            if not ilac:
                continue  # Katalogta yoksa stok da yok

            # TOPLAM-STOK parti kaydını bul veya oluştur
            parti = db.query(models.Parti).filter(
                models.Parti.ilac_id == ilac.id,
                models.Parti.parti_no == "TOPLAM-STOK"
            ).first()

            if not parti:
                parti = models.Parti(
                    ilac_id=ilac.id,
                    parti_no="TOPLAM-STOK",
                    miad=None,
                    koli_ici_adet=ilac.koli_ici_adet or 1
                )
                db.add(parti)
                db.flush()

            # Stok kaydını bul veya oluştur; miktar ÜSTÜNE YAZILIR (toplam_depo mantığı)
            stok = db.query(models.Stok).filter(
                models.Stok.parti_id == parti.id,
                models.Stok.depo_id == stok_depo.id
            ).first()

            if not stok:
                stok = models.Stok(
                    depo_id=stok_depo.id,
                    parti_id=parti.id,
                    miktar=kalan_miktar,
                    raf_konumu=ilac.raf_konumu,
                    koli_ici_adet=ilac.koli_ici_adet or 1
                )
                db.add(stok)
            else:
                stok.miktar = kalan_miktar  # Üzerine yaz

            summary["stok_updated"] += 1

    db.commit()

    depolar = db.query(models.Depo).all()
    return templates.TemplateResponse(
        request=request,
        name="drug_import.html",
        context={
            "summary": summary,
            "depolar": depolar,
            "user": request.state.user,
        },
    )

def lookup_master_drug(barkod: str, master_db: Session):
    b = clean_gtin(barkod)
    if not b or not master_db:
        return None
    raw_clean = str(barkod).replace("'", "").replace('"', '').strip()
    try:
        master_query = text("""
            SELECT urun_adi, firma_adi, etkin_maddeler, ambalaj, jenerik_kodu, jenerik_adi, atc_kodu, recete_turu, nfc, nfc_kodu
            FROM master_ilaclar WHERE barkod = :b OR barkod = :raw_b LIMIT 1
        """)
        m_row = master_db.execute(master_query, {"b": b, "raw_b": raw_clean}).fetchone()
        if not m_row:
            return None
    except Exception:
        return None
    
    etken_maddeler = ""
    try:
        if m_row.etkin_maddeler:
            parsed = json.loads(m_row.etkin_maddeler)
            if isinstance(parsed, list):
                etken_maddeler = ", ".join(parsed)
            elif isinstance(parsed, dict):
                etken_maddeler = ", ".join([v for k,v in parsed.items()])
            else:
                etken_maddeler = str(parsed)
    except Exception:
        etken_maddeler = str(m_row.etkin_maddeler) if m_row.etkin_maddeler else ""
        
    nfc_val = getattr(m_row, 'nfc_kodu', None) or getattr(m_row, 'nfc', None)
    if nfc_val:
        nfc_val = str(nfc_val).strip().upper()
    if not nfc_val:
        nfc_val = get_nfc_code_by_barcode(b)

    return {
        "ad": m_row.urun_adi,
        "uretici": m_row.firma_adi or "",
        "etken_madde": etken_maddeler,
        "ambalaj": m_row.ambalaj or "",
        "kutu_ici_adet": parse_package_dose_count(m_row.ambalaj or "", m_row.urun_adi or ""),
        "jenerik_kodu": m_row.jenerik_kodu or "",
        "jenerik_adi": m_row.jenerik_adi or etken_maddeler or m_row.urun_adi,
        "atc_kodu": m_row.atc_kodu or "",
        "nfc_kodu": nfc_val or "",
        "recete_turu": normalize_recete_turu(m_row.recete_turu)
    }

@router.get("/bulk-entry", response_class=HTMLResponse)
async def bulk_entry_page(request: Request, db: DbSession):
    depolar = db.query(models.Depo).options(joinedload(models.Depo.lokasyonlar)).all()
    depo_lokasyonlar_map = {
        d.id: [
            l.code for l in sorted(
                [loc for loc in d.lokasyonlar if loc.is_active],
                key=lambda x: (x.pick_sequence or 0, x.code or "")
            )
        ]
        for d in depolar
    }
    ilaclar = db.query(models.Ilac).all()
    return templates.TemplateResponse(
        request=request,
        name="drug_bulk_entry.html",
        context={
            "depolar": depolar,
            "depo_lokasyonlar_map": depo_lokasyonlar_map,
            "ilaclar": ilaclar,
            "user": request.state.user,
        },
    )

def _build_pts_bulk_response_dict(parsed_data: dict, db: Session, master_db: Optional[Session]) -> dict:
    items_with_status = []
    for item in parsed_data.get("items", []):
        b = clean_gtin(item.get("barkod", ""))
        if not b:
            continue
            
        kutu_sayisi = int(item.get("kutu_sayisi") or item.get("miktar", 1) or 1)
        existing = db.query(models.Ilac).filter(models.Ilac.barkod == b).first()
        if existing:
            kutu_ici = existing.kutu_ici_adet if (existing.kutu_ici_adet and existing.kutu_ici_adet > 1) else parse_package_dose_count(existing.ambalaj, existing.ad)
            item_data = {
                "barkod": b,
                "gtin": item.get("gtin") or b.zfill(14),
                "ad": existing.ad,
                "ambalaj": existing.ambalaj or "",
                "parti_no": item.get("parti_no", "") or "VARSAYILAN",
                "skt": item.get("skt", ""),
                "koli_no": item.get("koli_no", ""),
                "paket_no": item.get("paket_no", ""),
                "carrier_path": item.get("carrier_path", ""),
                "kutu_sayisi": kutu_sayisi,
                "kutu_ici_adet": kutu_ici or 1,
                "miktar": kutu_sayisi * (kutu_ici or 1),
                "serials": item.get("serials", []),
                "serial_records": item.get("serial_records", []),
                "raf_konumu": existing.raf_konumu or "",
                "koli_ici_adet": existing.koli_ici_adet or 1,
                "status": "exists",
                "status_text": "Katalogta Var"
            }
        else:
            m_info = lookup_master_drug(b, master_db)
            kutu_ici = (m_info.get("kutu_ici_adet") if m_info else None) or 1
            item_data = {
                "barkod": b,
                "gtin": item.get("gtin") or b.zfill(14),
                "ad": m_info["ad"] if m_info else f"İlaç (Barkod: {b})",
                "ambalaj": m_info.get("ambalaj", "") if m_info else "",
                "parti_no": item.get("parti_no", "") or "VARSAYILAN",
                "skt": item.get("skt", ""),
                "koli_no": item.get("koli_no", ""),
                "paket_no": item.get("paket_no", ""),
                "carrier_path": item.get("carrier_path", ""),
                "kutu_sayisi": kutu_sayisi,
                "kutu_ici_adet": kutu_ici,
                "miktar": kutu_sayisi * kutu_ici,
                "serials": item.get("serials", []),
                "serial_records": item.get("serial_records", []),
                "raf_konumu": "",
                "koli_ici_adet": 1,
                "status": "pending",
                "status_text": "Kayıt Bekliyor (Katalogta Yok)",
                "master_info": m_info
            }
        items_with_status.append(item_data)

    return {
        "status": "success",
        "success": True,
        "doc_info": {
            "document_number": parsed_data.get("document_number", ""),
            "document_date": parsed_data.get("document_date", ""),
            "sender": parsed_data.get("sender", ""),
            "receiver": parsed_data.get("receiver", ""),
            "total_koli": parsed_data.get("total_koli", 0),
            "total_qrcodes": len(parsed_data.get("raw_qrcodes", []))
        },
        "items": items_with_status
    }


@router.post("/bulk-entry/parse-xml")
@router.post("/bulk-entry/parse-pts", include_in_schema=False)
async def parse_pts_xml_endpoint(
    request: Request,
    file: Annotated[UploadFile, File(...)],
    db: DbSession,
    master_db: MasterDbSession,
):
    if not file or not file.filename:
        return JSONResponse(status_code=400, content={"detail": "Geçerli bir XML dosyası yükleyiniz."})
        
    content_bytes = await file.read()
    try:
        parsed_data = parse_pts_xml(content_bytes)
    except Exception as e:
        return JSONResponse(status_code=400, content={"detail": f"XML Ayrıştırma Hatası: {str(e)}"})

    return JSONResponse(content=_build_pts_bulk_response_dict(parsed_data, db, master_db))


@router.post("/bulk-entry/pts-get-package")
async def get_pts_package_for_bulk_entry(
    request: Request,
    db: DbSession,
    master_db: MasterDbSession,
):
    from app.services.its_pts_service import ItsPtsService
    try:
        body = await request.json()
    except Exception:
        body = {}

    transfer_id = str(body.get("transferId") or "").strip()
    source_gln = str(body.get("sourceGln") or "").strip()
    transfer_date = str(body.get("transferDate") or "").strip()

    try:
        pkg = ItsPtsService.download_package(
            db=db,
            transfer_id=transfer_id,
            source_gln=source_gln,
            transfer_date=transfer_date
        )
        res_dict = _build_pts_bulk_response_dict(pkg["parsed_data"], db, master_db)
        res_dict["transfer_id"] = transfer_id
        res_dict["md5_verified"] = pkg["md5_verified"]
        res_dict["stream_md5"] = pkg["stream_md5"]
        return JSONResponse(content=res_dict)
    except Exception as e:
        return JSONResponse(
            status_code=400,
            content={"status": "error", "success": False, "detail": str(e), "message": str(e)}
        )

@router.post("/quick-register/{barkod}")
async def quick_register_drug(
    barkod: str,
    request: Request,
    db: DbSession,
    master_db: MasterDbSession,
):
    b = clean_gtin(barkod)
    if not b:
        return JSONResponse(status_code=400, content={"success": False, "msg": "Geçersiz barkod."})

    existing = db.query(models.Ilac).filter(models.Ilac.barkod == b).first()
    if existing:
        return JSONResponse(content={
            "success": True,
            "msg": f"'{existing.ad}' zaten kataloğunuzda kayıtlı.",
            "ilac": {"id": existing.id, "barkod": existing.barkod, "ad": existing.ad, "kutu_ici_adet": existing.kutu_ici_adet or 1}
        })

    m_info = lookup_master_drug(b, master_db)
    if m_info:
        yeni_ilac = models.Ilac(
            barkod=b,
            ad=m_info["ad"],
            uretici=m_info["uretici"],
            etken_madde=m_info["etken_madde"],
            ambalaj=m_info["ambalaj"],
            kutu_ici_adet=m_info.get("kutu_ici_adet") or parse_package_dose_count(m_info.get("ambalaj", ""), m_info.get("ad", "")),
            jenerik_kodu=m_info["jenerik_kodu"],
            jenerik_adi=m_info["jenerik_adi"],
            atc_kodu=m_info["atc_kodu"],
            nfc_kodu=m_info["nfc_kodu"],
            recete_turu=m_info.get("recete_turu"),
            birim="Adet",
            koli_ici_adet=1,
            kritik_stok=0
        )
    else:
        yeni_ilac = models.Ilac(
            barkod=b,
            ad=f"İlaç (Barkod: {b})",
            nfc_kodu=get_nfc_code_by_barcode(b),
            birim="Adet",
            kutu_ici_adet=1,
            koli_ici_adet=1,
            kritik_stok=0
        )

    db.add(yeni_ilac)
    db.commit()
    db.refresh(yeni_ilac)

    return JSONResponse(content={
        "success": True,
        "msg": f"'{yeni_ilac.ad}' ilaç kartı oluşturuldu ve kataloğa eklendi.",
        "ilac": {"id": yeni_ilac.id, "barkod": yeni_ilac.barkod, "ad": yeni_ilac.ad, "kutu_ici_adet": yeni_ilac.kutu_ici_adet or 1}
    })

@router.get("/detail-by-barcode/{barkod}")
async def get_drug_detail_by_barcode(
    barkod: str,
    db: DbSession,
    master_db: MasterDbSession,
):
    b = clean_gtin(barkod) or str(barkod).replace("'", "").strip()
    if not b:
        return JSONResponse(status_code=400, content={"error": "Geçersiz barkod"})

    m_info = lookup_master_drug(b, master_db) if master_db else None

    existing = db.query(models.Ilac).filter(models.Ilac.barkod == b).first()
    if existing:
        kutu_ici = existing.kutu_ici_adet if (existing.kutu_ici_adet and existing.kutu_ici_adet > 1) else (
            m_info.get("kutu_ici_adet") if m_info else parse_package_dose_count(existing.ambalaj, existing.ad)
        )
        return JSONResponse(content={
            "exists": True,
            "id": existing.id,
            "barkod": existing.barkod,
            "ad": existing.ad,
            "uretici": existing.uretici or (m_info.get("uretici") if m_info else ""),
            "etken_madde": existing.etken_madde or (m_info.get("etken_madde") if m_info else ""),
            "ambalaj": existing.ambalaj or (m_info.get("ambalaj") if m_info else ""),
            "jenerik_kodu": existing.jenerik_kodu or (m_info.get("jenerik_kodu") if m_info else ""),
            "jenerik_adi": existing.jenerik_adi or (m_info.get("jenerik_adi") if m_info else ""),
            "atc_kodu": existing.atc_kodu or (m_info.get("atc_kodu") if m_info else ""),
            "nfc_kodu": existing.nfc_kodu or (m_info.get("nfc_kodu") if m_info else "") or get_nfc_code_by_barcode(b),
            "recete_turu": existing.recete_turu or (m_info.get("recete_turu") if m_info else ""),
            "birim": existing.birim or "Adet",
            "kutu_ici_adet": kutu_ici or 1,
            "koli_ici_adet": existing.koli_ici_adet or 1,
            "raf_konumu": existing.raf_konumu or "",
            "kritik_stok": existing.kritik_stok or 0
        })

    if m_info:
        return JSONResponse(content={
            "exists": False,
            "barkod": b,
            "ad": m_info.get("ad", ""),
            "uretici": m_info.get("uretici", ""),
            "etken_madde": m_info.get("etken_madde", ""),
            "ambalaj": m_info.get("ambalaj", ""),
            "jenerik_kodu": m_info.get("jenerik_kodu", ""),
            "jenerik_adi": m_info.get("jenerik_adi", ""),
            "atc_kodu": m_info.get("atc_kodu", ""),
            "nfc_kodu": m_info.get("nfc_kodu", "") or get_nfc_code_by_barcode(b),
            "recete_turu": m_info.get("recete_turu", ""),
            "birim": "Adet",
            "kutu_ici_adet": m_info.get("kutu_ici_adet") or 1,
            "koli_ici_adet": 1,
            "raf_konumu": "",
            "kritik_stok": 0
        })

    return JSONResponse(content={
        "exists": False,
        "barkod": b,
        "ad": f"İlaç (Barkod: {b})",
        "uretici": "",
        "etken_madde": "",
        "ambalaj": "",
        "jenerik_kodu": "",
        "jenerik_adi": "",
        "atc_kodu": "",
        "nfc_kodu": get_nfc_code_by_barcode(b),
        "recete_turu": "",
        "birim": "Adet",
        "kutu_ici_adet": 1,
        "koli_ici_adet": 1,
        "raf_konumu": "",
        "kritik_stok": 0
    })

@router.post("/save-card")
async def save_drug_card(
    request: Request,
    db: DbSession,
    master_db: MasterDbSession,
):
    body = await request.json()
    raw_b = body.get("barkod", "")
    b = clean_gtin(raw_b) or str(raw_b).replace("'", "").strip()
    if not b:
        return JSONResponse(status_code=400, content={"success": False, "msg": "Geçersiz barkod."})

    m_info = lookup_master_drug(b, master_db) if master_db else None

    ilac = db.query(models.Ilac).filter(models.Ilac.barkod == b).first()

    ad = body.get("ad", "").strip() or (ilac.ad if ilac else "") or (m_info.get("ad") if m_info else f"İlaç (Barkod: {b})")
    uretici = body.get("uretici", "").strip() or (ilac.uretici if ilac else "") or (m_info.get("uretici") if m_info else "")
    etken_madde = body.get("etken_madde", "").strip() or (ilac.etken_madde if ilac else "") or (m_info.get("etken_madde") if m_info else "")
    ambalaj = body.get("ambalaj", "").strip() or (ilac.ambalaj if ilac else "") or (m_info.get("ambalaj") if m_info else "")
    jenerik_kodu = body.get("jenerik_kodu", "").strip() or (ilac.jenerik_kodu if ilac else "") or (m_info.get("jenerik_kodu") if m_info else "")
    jenerik_adi = body.get("jenerik_adi", "").strip() or (ilac.jenerik_adi if ilac else "") or (m_info.get("jenerik_adi") if m_info else "")
    atc_kodu = body.get("atc_kodu", "").strip().upper() or (ilac.atc_kodu if ilac else "") or (m_info.get("atc_kodu") if m_info else "")
    nfc_kodu = body.get("nfc_kodu", "").strip().upper() or (ilac.nfc_kodu if ilac else "") or (m_info.get("nfc_kodu") if m_info else "") or get_nfc_code_by_barcode(b)
    recete_turu = body.get("recete_turu", "").strip() or (ilac.recete_turu if ilac else None) or (m_info.get("recete_turu") if m_info else None)
    birim = body.get("birim", "").strip() or (ilac.birim if ilac else "Adet")
    kutu_ici_adet = int(
        body.get("kutu_ici_adet")
        or (ilac.kutu_ici_adet if (ilac and ilac.kutu_ici_adet and ilac.kutu_ici_adet > 1) else 0)
        or (m_info.get("kutu_ici_adet") if m_info else 0)
        or parse_package_dose_count(ambalaj, ad)
        or 1
    )
    koli_ici_adet = int(body.get("koli_ici_adet") or (ilac.koli_ici_adet if ilac else 1) or 1)
    raf_konumu = body.get("raf_konumu", "").strip() or (ilac.raf_konumu if ilac else "")
    kritik_stok = int(body.get("kritik_stok") or (ilac.kritik_stok if ilac else 0) or 0)

    if ilac:
        ilac.ad = ad
        ilac.uretici = uretici
        ilac.etken_madde = etken_madde
        ilac.ambalaj = ambalaj
        ilac.jenerik_kodu = jenerik_kodu
        ilac.jenerik_adi = jenerik_adi
        ilac.atc_kodu = atc_kodu
        ilac.nfc_kodu = nfc_kodu
        ilac.recete_turu = recete_turu
        ilac.birim = birim
        ilac.kutu_ici_adet = kutu_ici_adet
        ilac.koli_ici_adet = koli_ici_adet
        if raf_konumu:
            ilac.raf_konumu = raf_konumu
        ilac.kritik_stok = kritik_stok
        msg = f"'{ilac.ad}' ilaç kartı güncellendi."
    else:
        ilac = models.Ilac(
            barkod=b,
            ad=ad,
            uretici=uretici,
            etken_madde=etken_madde,
            ambalaj=ambalaj,
            jenerik_kodu=jenerik_kodu,
            jenerik_adi=jenerik_adi,
            atc_kodu=atc_kodu,
            nfc_kodu=nfc_kodu,
            recete_turu=recete_turu,
            birim=birim,
            kutu_ici_adet=kutu_ici_adet,
            koli_ici_adet=koli_ici_adet,
            raf_konumu=raf_konumu,
            kritik_stok=kritik_stok
        )
        db.add(ilac)
        msg = f"'{ilac.ad}' ilaç kartı oluşturuldu ve kataloğa eklendi."
    
    db.commit()
    db.refresh(ilac)

    return JSONResponse(content={
        "success": True,
        "msg": msg,
        "ilac": {
            "id": ilac.id,
            "barkod": ilac.barkod,
            "ad": ilac.ad,
            "uretici": ilac.uretici or "",
            "etken_madde": ilac.etken_madde or "",
            "ambalaj": ilac.ambalaj or "",
            "jenerik_kodu": ilac.jenerik_kodu or "",
            "jenerik_adi": ilac.jenerik_adi or "",
            "atc_kodu": ilac.atc_kodu or "",
            "nfc_kodu": ilac.nfc_kodu or "",
            "recete_turu": ilac.recete_turu or "",
            "birim": ilac.birim or "Adet",
            "kutu_ici_adet": ilac.kutu_ici_adet or 1,
            "koli_ici_adet": ilac.koli_ici_adet or 1,
            "raf_konumu": ilac.raf_konumu or ""
        }
    })

@router.post("/bulk-entry/confirm")
async def confirm_bulk_entry(
    request: Request,
    db: DbSession,
    master_db: MasterDbSession,
):
    body = await request.json()
    global_depo_id = body.get("depo_id")
    pts_no = body.get("pts_no") or body.get("evrak_no") or body.get("source_info") or ""
    items = body.get("items") or []

    if not items:
        return JSONResponse(status_code=400, content={"detail": "İşlenecek ilaç listesi boş."})

    toplu_islem_kodu = f"BATCH-IN-{datetime.datetime.now().strftime('%Y%m%d%H%M%S')}"
    processed_count = 0
    added_drugs_count = 0
    recorded_qrcodes_count = 0

    for item in items:
        b = clean_gtin(item.get("barkod", ""))
        if not b:
            continue
            
        miktar = int(item.get("miktar", 1))
        if miktar <= 0:
            continue

        item_depo_id = item.get("depo_id") or global_depo_id
        if not item_depo_id:
            continue

        depo = db.query(models.Depo).options(joinedload(models.Depo.ozellikler)).filter(models.Depo.id == int(item_depo_id)).first()
        if not depo:
            continue

        # 1. İlaç kartını kontrol et (Katalogta yoksa stoğa eklenmez, önce kart oluşturulmalı)
        ilac = db.query(models.Ilac).options(joinedload(models.Ilac.ozellikler)).filter(models.Ilac.barkod == b).first()
        if not ilac:
            m_info = lookup_master_drug(b, master_db) if master_db else None
            d_name = item.get("ad") or (m_info.get("ad") if m_info else f"Barkod: {b}")
            return JSONResponse(
                status_code=400,
                content={"detail": f"İlaç kartı oluşturulmadan stok girişi yapılamaz! Lütfen önce '{d_name}' ({b}) ilacı için İlaç Kartı oluşturun."}
            )

        is_compat, err_msg = check_depo_drug_compatibility(depo, ilac)
        if not is_compat:
            return JSONResponse(status_code=400, content={"detail": err_msg})

        # Kart seviyesinde sadece boşsa varsayılan değerleri doldur
        if item.get("raf_konumu") and item.get("raf_konumu").strip() and not ilac.raf_konumu:
            ilac.raf_konumu = item.get("raf_konumu").strip()
        if item.get("koli_ici_adet") and int(item.get("koli_ici_adet")) > 0 and (not ilac.koli_ici_adet or ilac.koli_ici_adet <= 1):
            ilac.koli_ici_adet = int(item.get("koli_ici_adet"))

        kutu_ici = int(
            item.get("kutu_ici_adet")
            or (ilac.kutu_ici_adet if (ilac.kutu_ici_adet and ilac.kutu_ici_adet > 1) else 0)
            or parse_package_dose_count(ilac.ambalaj, ilac.ad)
            or 1
        )
        if kutu_ici > 0 and item.get("kutu_ici_adet"):
            ilac.kutu_ici_adet = kutu_ici

        # 2. Parti (Lot / SKT) kaydını bul veya oluştur
        parti_no = (item.get("parti_no") or "VARSAYILAN").strip()
        skt_str = (item.get("skt") or "").strip()
        miad_date = None
        if skt_str:
            try:
                miad_date = datetime.datetime.strptime(parse_skt(skt_str), "%Y-%m-%d").date()
            except Exception:
                miad_date = None

        if not miad_date:
            return JSONResponse(
                status_code=400,
                content={"detail": f"Stok girişi yapılabilmesi için Son Kullanma Tarihi (SKT / Miad) girilmesi zorunludur. '{ilac.ad}' ilacının SKT tarihi eksik."}
            )

        # Farklı miadları ayrı partiler olarak kaydetmek için parti_no + miad birlikte sorgulanır
        parti = db.query(models.Parti).filter(
            models.Parti.ilac_id == ilac.id,
            models.Parti.parti_no == parti_no,
            models.Parti.miad == miad_date
        ).first()

        koli_adet = int(item.get("koli_ici_adet") or ilac.koli_ici_adet or 1)

        if not parti:
            parti = models.Parti(
                ilac_id=ilac.id,
                parti_no=parti_no,
                miad=miad_date,
                koli_ici_adet=koli_adet
            )
            db.add(parti)
            db.flush()
        # 3. Depo stok kaydını bul veya güncelle (Raf Konumu ve Koli İçi Adedi dikkate alınarak)
        raf_pos = (item.get("raf_konumu") or "").strip() or None

        stok_query = db.query(models.Stok).filter(
            models.Stok.parti_id == parti.id,
            models.Stok.depo_id == depo.id
        )

        if raf_pos:
            stok_query = stok_query.filter(models.Stok.raf_konumu == raf_pos)
        else:
            stok_query = stok_query.filter((models.Stok.raf_konumu == None) | (models.Stok.raf_konumu == ""))

        if koli_adet:
            stok_query = stok_query.filter((models.Stok.koli_ici_adet == koli_adet) | (models.Stok.koli_ici_adet == None))

        stok = stok_query.first()

        if not stok:
            stok = models.Stok(
                depo_id=depo.id,
                parti_id=parti.id,
                miktar=miktar,
                raf_konumu=raf_pos or ilac.raf_konumu,
                koli_ici_adet=koli_adet
            )
            db.add(stok)
        else:
            stok.miktar += miktar
            if not stok.koli_ici_adet:
                stok.koli_ici_adet = koli_adet

        # 4. Karekod listesini ve kutu sayısını hazırla
        serial_records = list(item.get("serial_records") or [])
        if not serial_records and item.get("serials"):
            for sn in item.get("serials", []):
                if sn:
                    serial_records.append({
                        "gtin": item.get("gtin") or b.zfill(14),
                        "serial": str(sn).strip(),
                        "batch": parti_no,
                        "expiry": miad_date.strftime("%Y-%m-%d"),
                        "koli_no": item.get("koli_no") or "",
                        "paket_no": item.get("paket_no") or "",
                        "carrier_path": item.get("carrier_path") or ""
                    })

        kutu_sayisi = int(
            item.get("kutu_sayisi")
            or (len(serial_records) if serial_records else 0)
            or max(1, miktar // max(1, kutu_ici))
        )

        # 5. Stok Hareketi logu oluştur
        koli_info = (item.get("koli_no") or "").strip()
        paket_info = (item.get("paket_no") or "").strip()
        koli_log = f" [Koli No: {koli_info}{(' / Paket: ' + paket_info) if (paket_info and paket_info != koli_info) else ''}]" if koli_info else ""
        kutu_log = f" [{kutu_sayisi} Kutu × {kutu_ici} = {miktar} Adet]" if kutu_ici > 1 else f" [{kutu_sayisi} Kutu / {miktar} Adet]"
        item_pts = (item.get("pts_no") or "").strip()
        clean_pts_no = item_pts or (pts_no if (pts_no and pts_no not in ("Toplu İlaç Girişi", "Manuel Giriş")) else None)
        desc_prefix = clean_pts_no or pts_no or "Toplu İlaç Girişi"

        hareket = models.StokHareketi(
            tarih=datetime.datetime.now(),
            hareket_tipi="Toplu Giriş",
            toplu_islem_kodu=toplu_islem_kodu,
            depo_id=depo.id,
            parti_id=parti.id,
            miktar=miktar,
            aciklama=f"{desc_prefix}{koli_log}{kutu_log} - Toplu Giriş ({depo.ad})",
            kullanici_id=request.state.user.id,
            pts_no=clean_pts_no,
            koli_no=koli_info or None,
            kutu_sayisi=kutu_sayisi,
            kutu_ici_adet=kutu_ici
        )
        db.add(hareket)
        db.flush()

        # 6. Varsa PTS / Karekod serilerini DepoKarekod ve ItsKarekod tablolarına kaydet
        if serial_records:
            recorded_qrcodes_count += QRBasketService.record_depo_qrcodes(
                db=db,
                depo_id=depo.id,
                parti_id=parti.id,
                ilac_id=ilac.id,
                kutu_ici_adet=kutu_ici,
                serial_records=serial_records,
                pts_no=clean_pts_no or "",
                giris_hareket_id=hareket.id,
                also_add_to_its=True
            )

        processed_count += 1

    db.commit()

    qr_msg = f" ({recorded_qrcodes_count} adet karekod depo ve İTS envanterine aktarıldı)" if recorded_qrcodes_count > 0 else ""
    return JSONResponse(content={
        "status": "success", "success": True,
        "msg": f"{processed_count} kalem ilaç stok girişi başarıyla tamamlandı{qr_msg}.",
        "added_drugs": added_drugs_count,
        "processed_count": processed_count,
        "recorded_qrcodes": recorded_qrcodes_count
    })

# ----------------------------------------------------
# TOPLU STOK ÇIKIŞI (BULK STOCK OUTPUT) ROUTES
# ----------------------------------------------------

@router.get("/bulk-exit", response_class=HTMLResponse)
async def bulk_exit_page(request: Request, db: DbSession):
    depolar = db.query(models.Depo).all()
    return templates.TemplateResponse(
        request=request,
        name="drug_bulk_exit.html",
        context={
            "depolar": depolar,
            "user": request.state.user,
        },
    )

def get_generic_group_filter(ilac_rec):
    if ilac_rec.jenerik_grubu and ilac_rec.jenerik_grubu.strip():
        return models.Ilac.jenerik_grubu == ilac_rec.jenerik_grubu.strip()
    elif ilac_rec.jenerik_kodu and ilac_rec.jenerik_kodu.strip():
        return models.Ilac.jenerik_kodu == ilac_rec.jenerik_kodu.strip()
    elif ilac_rec.jenerik_adi and ilac_rec.jenerik_adi.strip():
        return models.Ilac.jenerik_adi == ilac_rec.jenerik_adi.strip()
    elif ilac_rec.etken_madde and ilac_rec.etken_madde.strip():
        return models.Ilac.etken_madde == ilac_rec.etken_madde.strip()
    else:
        return models.Ilac.id == ilac_rec.id

def check_generic_fefo_warning(db: Session, ilac_rec: models.Ilac, current_depo_id: int = None, selected_parti_id: int = None):
    if not ilac_rec:
        return None

    group_filter = get_generic_group_filter(ilac_rec)
    group_name = (
        ilac_rec.jenerik_grubu or 
        ilac_rec.jenerik_adi or 
        ilac_rec.jenerik_kodu or 
        ilac_rec.etken_madde or 
        ilac_rec.ad
    )

    query = db.query(models.Stok, models.Parti, models.Ilac, models.Depo)\
        .join(models.Parti, models.Stok.parti_id == models.Parti.id)\
        .join(models.Ilac, models.Parti.ilac_id == models.Ilac.id)\
        .join(models.Depo, models.Stok.depo_id == models.Depo.id)\
        .filter(models.Stok.miktar > 0, group_filter)

    ref_miad = None
    if selected_parti_id:
        p = db.query(models.Parti).filter(models.Parti.id == int(selected_parti_id)).first()
        if p:
            ref_miad = p.miad

    if not ref_miad:
        own_query = db.query(models.Parti.miad)\
            .join(models.Stok, models.Stok.parti_id == models.Parti.id)\
            .filter(models.Parti.ilac_id == ilac_rec.id, models.Stok.miktar > 0)
        if current_depo_id:
            own_query = own_query.filter(models.Stok.depo_id == current_depo_id)
        own_earliest = own_query.order_by(models.Parti.miad.asc()).first()
        if own_earliest:
            ref_miad = own_earliest[0]

    global_earliest = query.order_by(models.Parti.miad.asc()).first()
    depot_earliest = query.filter(models.Stok.depo_id == current_depo_id).order_by(models.Parti.miad.asc()).first() if current_depo_id else global_earliest

    target_earliest = depot_earliest if depot_earliest else global_earliest

    warning = {
        "has_warning": False,
        "group_name": group_name,
        "is_different_drug": False,
        "has_earlier_in_same_depot": False,
        "earliest_drug_id": None,
        "earliest_drug_barkod": None,
        "earliest_drug_ad": None,
        "earliest_miad": None,
        "earliest_parti_no": None,
        "earliest_depo_id": None,
        "earliest_depo_ad": None,
        "earliest_miktar": 0,
        "current_drug_ad": ilac_rec.ad,
        "current_miad": ref_miad.strftime('%d.%m.%Y') if ref_miad else "-",
        "has_earlier_in_other_depot": False,
        "other_depo_name": None,
        "other_depo_miad": None
    }

    if target_earliest and ref_miad and target_earliest.Parti and target_earliest.Parti.miad and target_earliest.Parti.miad < ref_miad:
        warning["has_warning"] = True
        warning["has_earlier_in_same_depot"] = True
        warning["is_different_drug"] = (target_earliest.Ilac.id != ilac_rec.id)
        warning["earliest_drug_id"] = target_earliest.Ilac.id
        warning["earliest_drug_barkod"] = target_earliest.Ilac.barkod
        warning["earliest_drug_ad"] = target_earliest.Ilac.ad
        warning["earliest_miad"] = target_earliest.Parti.miad.strftime('%d.%m.%Y') if target_earliest.Parti.miad else "-"
        warning["earliest_parti_no"] = target_earliest.Parti.parti_no
        warning["earliest_depo_id"] = target_earliest.Depo.id
        warning["earliest_depo_ad"] = target_earliest.Depo.ad
        warning["earliest_miktar"] = target_earliest.Stok.miktar

    if global_earliest and current_depo_id and global_earliest.Stok.depo_id != current_depo_id:
        current_miad_check = (depot_earliest.Parti.miad if (depot_earliest and depot_earliest.Parti) else None) or ref_miad
        if global_earliest.Parti and global_earliest.Parti.miad and (not current_miad_check or global_earliest.Parti.miad < current_miad_check):
            warning["has_warning"] = True
            warning["has_earlier_in_other_depot"] = True
            warning["other_depo_name"] = global_earliest.Depo.ad
            warning["other_depo_miad"] = global_earliest.Parti.miad.strftime('%d.%m.%Y') if global_earliest.Parti.miad else "-"
            if not warning["earliest_drug_ad"]:
                warning["is_different_drug"] = (global_earliest.Ilac.id != ilac_rec.id)
                warning["earliest_drug_id"] = global_earliest.Ilac.id
                warning["earliest_drug_barkod"] = global_earliest.Ilac.barkod
                warning["earliest_drug_ad"] = global_earliest.Ilac.ad
                warning["earliest_miad"] = global_earliest.Parti.miad.strftime('%d.%m.%Y') if global_earliest.Parti.miad else "-"
                warning["earliest_depo_id"] = global_earliest.Depo.id
                warning["earliest_depo_ad"] = global_earliest.Depo.ad
                warning["earliest_miktar"] = global_earliest.Stok.miktar

    return warning if warning["has_warning"] else None

@router.get("/bulk-exit/stock-drugs")
async def get_stock_drugs_for_depot(
    db: DbSession,
    depo_id: Annotated[Optional[str], Query()] = None,
):
    """Seçilen depoda veya tüm depolarda stoğu bulunan ilaçları ve parti detaylarını döner."""
    clean_depo_id = int(depo_id) if (depo_id and str(depo_id).isdigit() and int(depo_id) > 0) else None

    query = db.query(models.Stok)\
        .join(models.Parti, models.Stok.parti_id == models.Parti.id)\
        .join(models.Ilac, models.Parti.ilac_id == models.Ilac.id)\
        .join(models.Depo, models.Stok.depo_id == models.Depo.id)\
        .filter(models.Stok.miktar > 0)

    if clean_depo_id:
        query = query.filter(models.Stok.depo_id == clean_depo_id)

    stoklar = query.order_by(models.Ilac.ad.asc(), models.Depo.ad.asc(), models.Parti.miad.asc()).all()

    drug_groups = {}
    for stok in stoklar:
        ilac = stok.parti.ilac
        depo = stok.depo
        parti = stok.parti

        if ilac.id not in drug_groups:
            drug_groups[ilac.id] = {
                "ilac": ilac,
                "depots": {}
            }
        if depo.id not in drug_groups[ilac.id]["depots"]:
            drug_groups[ilac.id]["depots"][depo.id] = {
                "depo_id": depo.id,
                "depo_ad": depo.ad,
                "mevcut_stok": 0,
                "partiler": []
            }
        drug_groups[ilac.id]["depots"][depo.id]["mevcut_stok"] += stok.miktar
        drug_groups[ilac.id]["depots"][depo.id]["partiler"].append({
            "stok_id": stok.id,
            "parti_id": parti.id,
            "parti_no": parti.parti_no,
            "miad": parti.miad.strftime('%d.%m.%Y') if parti.miad else "-",
            "miktar": stok.miktar,
            "raf_konumu": stok.raf_konumu or "-"
        })

    drugs_list = []
    for ilac_id, d_data in drug_groups.items():
        ilac = d_data["ilac"]
        depot_list = list(d_data["depots"].values())
        total_avail_all = sum(d["mevcut_stok"] for d in depot_list)
        default_depot = depot_list[0]

        fefo_w = check_generic_fefo_warning(db, ilac, clean_depo_id or default_depot["depo_id"])

        drugs_list.append({
            "id": ilac.id,
            "barkod": ilac.barkod,
            "ad": ilac.ad,
            "depo_id": default_depot["depo_id"],
            "depo_ad": default_depot["depo_ad"],
            "depot_options": depot_list,
            "toplam_miktar": default_depot["mevcut_stok"],
            "toplam_tum_depolar_stok": total_avail_all,
            "jenerik_grubu": ilac.jenerik_grubu or ilac.jenerik_adi or ilac.etken_madde or "",
            "jenerik_adi": ilac.jenerik_adi or "",
            "raf_konumu": ilac.raf_konumu or "-",
            "partiler": default_depot["partiler"],
            "fefo_warning": fefo_w,
            "display_label": f"{ilac.ad} (Toplam Stok: {total_avail_all} Adet, Barkod: {ilac.barkod})"
        })

    return JSONResponse({
        "success": True,
        "drugs": drugs_list
    })

@router.get("/bulk-exit/check-group-fefo")
async def check_group_fefo_route(
    ilac_id: Annotated[int, Query()],
    db: DbSession,
    depo_id: OptionalIntQuery = None,
    parti_id: OptionalIntQuery = None,
):
    """Aynı jenerik/özel grupta daha yakın miadlı ürün kontrolü yapar."""
    ilac = db.query(models.Ilac).filter(models.Ilac.id == ilac_id).first()
    if not ilac:
        return JSONResponse({"success": False, "fefo_warning": None})
    w = check_generic_fefo_warning(db, ilac, depo_id, parti_id)
    return JSONResponse({"success": True, "fefo_warning": w})

@router.get("/bulk-exit/generic-alternatives")
async def get_generic_alternatives(
    ilac_id: Annotated[int, Query()],
    db: DbSession,
):
    """Aynı jenerik gruptaki tüm stoğu bulunan muadil ilaçları (FEFO miat sırasıyla) döner."""
    ilac = db.query(models.Ilac).filter(models.Ilac.id == ilac_id).first()
    if not ilac:
        return JSONResponse({"success": False, "alternatives": []})

    group_filter = get_generic_group_filter(ilac)
    group_name = (
        ilac.jenerik_grubu or 
        ilac.jenerik_adi or 
        ilac.jenerik_kodu or 
        ilac.etken_madde or 
        ilac.ad
    )

    stoklar = db.query(models.Stok, models.Parti, models.Ilac, models.Depo)\
        .join(models.Parti, models.Stok.parti_id == models.Parti.id)\
        .join(models.Ilac, models.Parti.ilac_id == models.Ilac.id)\
        .join(models.Depo, models.Stok.depo_id == models.Depo.id)\
        .filter(models.Stok.miktar > 0, group_filter)\
        .order_by(models.Parti.miad.asc()).all()

    alt_map = {}
    for stok_rec, parti_rec, ilac_rec, depo_rec in stoklar:
        if ilac_rec.id not in alt_map:
            alt_map[ilac_rec.id] = {
                "id": ilac_rec.id,
                "barkod": ilac_rec.barkod,
                "ad": ilac_rec.ad,
                "is_current": (ilac_rec.id == ilac.id),
                "depo_id": depo_rec.id,
                "depo_ad": depo_rec.ad,
                "earliest_miad": parti_rec.miad.strftime('%d.%m.%Y') if parti_rec.miad else "-",
                "earliest_miad_raw": parti_rec.miad.isoformat() if parti_rec.miad else "9999-12-31",
                "toplam_stok": 0
            }
        alt_map[ilac_rec.id]["toplam_stok"] += stok_rec.miktar

    alternatives = list(alt_map.values())
    alternatives.sort(key=lambda x: (x["earliest_miad_raw"], x["ad"]))

    return JSONResponse({
        "success": True,
        "group_name": group_name,
        "current_drug_id": ilac.id,
        "alternatives": alternatives
    })


@router.get("/bulk-exit/expiring-items")
async def get_expiring_items_for_exit(
    db: DbSession,
    depo_id: Annotated[Optional[str], Query()] = None,
    days: Annotated[int, Query()] = 90,
):
    """Seçilen veya tüm depolarda miadı dolmuş veya dolmak üzere olan stokları döner."""
    clean_depo_id = int(depo_id) if (depo_id and str(depo_id).isdigit() and int(depo_id) > 0) else None
    target_date = datetime.date.today() + datetime.timedelta(days=days)

    query = db.query(models.Stok)\
        .join(models.Parti, models.Stok.parti_id == models.Parti.id)\
        .join(models.Ilac, models.Parti.ilac_id == models.Ilac.id)\
        .join(models.Depo, models.Stok.depo_id == models.Depo.id)\
        .filter(models.Stok.miktar > 0, models.Parti.miad <= target_date)

    if clean_depo_id:
        query = query.filter(models.Stok.depo_id == clean_depo_id)

    stoklar = query.order_by(models.Parti.miad.asc()).all()

    items = []
    bugun = datetime.date.today()

    for stok in stoklar:
        ilac = stok.parti.ilac
        parti = stok.parti
        depo = stok.depo
        kalan_gun = (parti.miad - bugun).days if parti.miad else 999

        durum_text = "Süresi Doldu" if kalan_gun < 0 else f"{kalan_gun} Gün Kaldı"
        renk = "danger" if kalan_gun <= 30 else ("warning" if kalan_gun <= 90 else "info")

        items.append({
            "stok_id": stok.id,
            "ilac_id": ilac.id,
            "barkod": ilac.barkod,
            "ad": ilac.ad,
            "depo_id": depo.id,
            "depo_ad": depo.ad,
            "parti_id": parti.id,
            "parti_no": parti.parti_no,
            "miad": parti.miad.strftime('%d.%m.%Y') if parti.miad else "-",
            "kalan_gun": kalan_gun,
            "durum_text": durum_text,
            "renk": renk,
            "mevcut_stok": stok.miktar,
            "cikis_miktari": stok.miktar,
            "raf_konumu": stok.raf_konumu or ilac.raf_konumu or "-"
        })

    return JSONResponse({
        "success": True,
        "items": items
    })

def extract_barcode_from_malzeme_kodu(val) -> str:
    """
    Excel'deki 'Malzeme Kodu' veya 'Barkod' sütunundan barkod numarasını ayıklar.
    Örnekler:
    - '150-03-01-8699788751642' -> '8699788751642'
    - '150-03-01-1111002233445' -> '1111002233445' (Yurt dışı barkodları)
    - '8699788751642' -> '8699788751642'
    - '11110022' -> '11110022'
    """
    if val is None:
        return ""
    s = str(val).strip()
    if s.endswith(".0"):
        s = s[:-2]
    s = s.replace("'", "").replace('"', '').strip()
    if not s:
        return ""

    if "-" in s:
        if s.startswith("150-03-01-"):
            s = s[len("150-03-01-"):].strip()
        else:
            parts = s.split("-")
            for part in reversed(parts):
                clean_p = re.sub(r"\D", "", part)
                if len(clean_p) >= 5:
                    s = clean_p
                    break

    digits = re.sub(r"\D", "", s)
    if len(digits) == 14 and digits.startswith("0"):
        return digits[1:]
    return digits

@router.post("/bulk-exit/parse-excel")
async def parse_excel_bulk_exit(
    request: Request,
    file: Annotated[UploadFile, File(...)],
    db: DbSession,
    depo_id: Annotated[Optional[str], Form()] = None,
):
    clean_depo_id = int(depo_id) if (depo_id and str(depo_id).isdigit() and int(depo_id) > 0) else None

    if not file or not file.filename:
        return JSONResponse(status_code=400, content={"detail": "Lütfen geçerli bir Excel veya CSV dosyası seçiniz."})

    filename = file.filename.lower()
    content_bytes = await file.read()

    rows_data = [] # list of (raw_malzeme_kodu, miktar_val)

    if filename.endswith(".xlsx") or filename.endswith(".xls"):
        try:
            import openpyxl
            wb = openpyxl.load_workbook(io.BytesIO(content_bytes), data_only=True)
            ws = wb.active
            excel_rows = list(ws.iter_rows(values_only=True))
            if not excel_rows or len(excel_rows) < 2:
                return JSONResponse(status_code=400, content={"detail": "Excel dosyası boş veya sadece başlık satırı içeriyor."})

            headers = [str(h).strip() if h is not None else "" for h in excel_rows[0]]

            malzeme_col_idx = None
            miktar_col_idx = None

            for idx, h in enumerate(headers):
                h_norm = h.upper().replace("İ", "I").replace("Ç", "C").replace("Ş", "S").replace("Ğ", "G").replace("Ü", "U").replace("Ö", "O")
                if ("MALZEME" in h_norm and "KOD" in h_norm) or h_norm == "MALZEME KODU" or "BARKOD" in h_norm or "GTIN" in h_norm:
                    if malzeme_col_idx is None:
                        malzeme_col_idx = idx
                elif "MIKTAR" in h_norm or "ADET" in h_norm or "QTY" in h_norm or "QUANTITY" in h_norm:
                    if miktar_col_idx is None:
                        miktar_col_idx = idx

            if malzeme_col_idx is None:
                malzeme_col_idx = 0
            if miktar_col_idx is None:
                miktar_col_idx = 1 if len(headers) > 1 else None

            for r in excel_rows[1:]:
                if not r or not any(r):
                    continue
                code_val = r[malzeme_col_idx] if malzeme_col_idx < len(r) else None
                qty_val = r[miktar_col_idx] if (miktar_col_idx is not None and miktar_col_idx < len(r)) else 1
                if code_val is not None:
                    rows_data.append((str(code_val), qty_val))
        except Exception as e:
            return JSONResponse(status_code=400, content={"detail": f"Excel dosyası okunamadı: {str(e)}"})
    else:
        content_str = None
        for enc in ["utf-8-sig", "utf-8", "iso-8859-9", "latin-1", "cp1254"]:
            try:
                content_str = content_bytes.decode(enc)
                break
            except Exception:
                continue

        if not content_str:
            return JSONResponse(status_code=400, content={"detail": "CSV dosyası okunamadı."})

        lines = [l.strip() for l in content_str.splitlines() if l.strip()]
        if not lines or len(lines) < 2:
            return JSONResponse(status_code=400, content={"detail": "CSV dosyası boş veya başlık içermiyor."})

        sample = lines[0]
        delim = ";" if ";" in sample else ("," if "," in sample else "\t")
        reader = csv.reader(lines, delimiter=delim)
        csv_rows = list(reader)

        headers = [str(h).strip() for h in csv_rows[0]]
        malzeme_col_idx = None
        miktar_col_idx = None

        for idx, h in enumerate(headers):
            h_norm = h.upper().replace("İ", "I").replace("Ç", "C").replace("Ş", "S").replace("Ğ", "G").replace("Ü", "U").replace("Ö", "O")
            if ("MALZEME" in h_norm and "KOD" in h_norm) or h_norm == "MALZEME KODU" or "BARKOD" in h_norm or "GTIN" in h_norm:
                if malzeme_col_idx is None:
                    malzeme_col_idx = idx
            elif "MIKTAR" in h_norm or "ADET" in h_norm or "QTY" in h_norm or "QUANTITY" in h_norm:
                if miktar_col_idx is None:
                    miktar_col_idx = idx

        if malzeme_col_idx is None:
            malzeme_col_idx = 0
        if miktar_col_idx is None:
            miktar_col_idx = 1 if len(headers) > 1 else None

        for r in csv_rows[1:]:
            if not r or not any(r):
                continue
            code_val = r[malzeme_col_idx] if malzeme_col_idx < len(r) else None
            qty_val = r[miktar_col_idx] if (miktar_col_idx is not None and miktar_col_idx < len(r)) else 1
            if code_val is not None:
                rows_data.append((str(code_val), qty_val))

    if not rows_data:
        return JSONResponse(status_code=400, content={"detail": "Excel dosyasından okunabilir malzeme verisi çıkarılamadı."})

    barcode_qty_map = {}
    unmatched_rows = []

    for raw_code, raw_qty in rows_data:
        extracted_b = extract_barcode_from_malzeme_kodu(raw_code)
        if not extracted_b:
            continue
        try:
            q_int = int(float(str(raw_qty).replace(",", ".")))
        except Exception:
            q_int = 1
        if q_int <= 0:
            q_int = 1

        if extracted_b not in barcode_qty_map:
            barcode_qty_map[extracted_b] = 0
        barcode_qty_map[extracted_b] += q_int

    if not barcode_qty_map:
        return JSONResponse(status_code=400, content={"detail": "Excel dosyasındaki Malzeme Kodu sütununda geçerli bir barkod numarası bulunamadı."})

    barcodes = list(barcode_qty_map.keys())
    db_drugs = db.query(models.Ilac).filter(models.Ilac.barkod.in_(barcodes)).all()
    drug_by_barcode = {d.barkod: d for d in db_drugs}

    drug_ids = [d.id for d in db_drugs]
    stock_query = db.query(models.Stok)\
        .join(models.Parti, models.Stok.parti_id == models.Parti.id)\
        .join(models.Depo, models.Stok.depo_id == models.Depo.id)\
        .filter(models.Parti.ilac_id.in_(drug_ids), models.Stok.miktar > 0)

    if clean_depo_id:
        stock_query = stock_query.filter(models.Stok.depo_id == clean_depo_id)

    stocks = stock_query.order_by(models.Parti.miad.asc()).all()

    stock_map = {}
    for s in stocks:
        d_id = s.parti.ilac_id
        if d_id not in stock_map:
            stock_map[d_id] = []
        stock_map[d_id].append(s)

    exit_items = []

    for b, req_qty in barcode_qty_map.items():
        ilac = drug_by_barcode.get(b)
        if not ilac:
            unmatched_rows.append({
                "barkod": b,
                "reason": "Sistemde tanımlı ilaç kartı bulunamadı"
            })
            continue

        ilac_stocks = stock_map.get(ilac.id, [])
        total_avail = sum(s.miktar for s in ilac_stocks)

        if not ilac_stocks:
            unmatched_rows.append({
                "barkod": b,
                "reason": f"'{ilac.ad}' ilacı için depolarda mevcut stok bulunamadı."
            })
            continue

        depot_stock_groups = {}
        for s in ilac_stocks:
            d_id = s.depo.id
            if d_id not in depot_stock_groups:
                depot_stock_groups[d_id] = {
                    "depo_id": d_id,
                    "depo_ad": s.depo.ad,
                    "mevcut_stok": 0,
                    "partiler": []
                }
            depot_stock_groups[d_id]["mevcut_stok"] += s.miktar
            depot_stock_groups[d_id]["partiler"].append({
                "stok_id": s.id,
                "parti_id": s.parti.id,
                "parti_no": s.parti.parti_no,
                "miad": s.parti.miad.strftime('%d.%m.%Y') if s.parti.miad else "-",
                "miktar": s.miktar,
                "raf_konumu": s.raf_konumu or "-"
            })

        depot_list = list(depot_stock_groups.values())
        default_depot = depot_list[0]

        fefo_w = check_generic_fefo_warning(db, ilac, default_depot["depo_id"])

        exit_items.append({
            "ilac_id": ilac.id,
            "barkod": ilac.barkod,
            "ad": ilac.ad,
            "depo_id": default_depot["depo_id"],
            "depo_ad": default_depot["depo_ad"],
            "depot_options": depot_list,
            "mevcut_stok": default_depot["mevcut_stok"],
            "toplam_tum_depolar_stok": total_avail,
            "parti_id": "",
            "partiler": default_depot["partiler"],
            "miktar": req_qty,
            "fefo_warning": fefo_w
        })

    return JSONResponse({
        "success": True,
        "msg": f"Excel dosyasından {len(exit_items)} kalem ilaç başarıyla çözümlendi.",
        "items": exit_items,
        "unmatched": unmatched_rows,
        "total_parsed": len(exit_items),
        "unmatched_count": len(unmatched_rows)
    })

@router.post("/bulk-exit/confirm")
async def confirm_bulk_exit(
    request: Request,
    db: DbSession,
):
    body = await request.json()
    global_depo_id = body.get("depo_id")
    if str(global_depo_id).lower() in ["all", "0", "", "none"]:
        global_depo_id = None
    else:
        global_depo_id = int(global_depo_id) if (global_depo_id and str(global_depo_id).isdigit()) else None

    cikis_nedeni = body.get("cikis_nedeni") or "Depo Çıkış"
    evrak_no = body.get("evrak_no") or body.get("source_info") or "Toplu Stok Çıkışı"
    items = body.get("items") or []

    if not items:
        return JSONResponse(status_code=400, content={"detail": "Çıkış yapılacak ilaç listesi boş."})

    toplu_islem_kodu = f"BATCH-OUT-{datetime.datetime.now().strftime('%Y%m%d%H%M%S')}"
    processed_count = 0
    total_deducted_qty = 0
    errors = []
    deduction_details = []

    for item in items:
        ilac_id = item.get("ilac_id")
        barkod = clean_gtin(item.get("barkod", ""))
        cikis_miktari = int(item.get("miktar", 0))
        parti_id = item.get("parti_id")
        item_depo_id = item.get("depo_id") or global_depo_id

        if str(item_depo_id).lower() in ["all", "0", "", "none"]:
            item_depo_id = None

        if cikis_miktari <= 0:
            continue

        if not ilac_id and barkod:
            ilac_obj = db.query(models.Ilac).filter(models.Ilac.barkod == barkod).first()
            if ilac_obj:
                ilac_id = ilac_obj.id

        if not ilac_id:
            errors.append(f"İlaç tanımlanamadı (Barkod: {barkod})")
            continue

        ilac_rec = db.query(models.Ilac).filter(models.Ilac.id == int(ilac_id)).first()
        if not ilac_rec:
            errors.append(f"İlaç bulunamadı (ID: {ilac_id})")
            continue

        # If user explicitly locked a specific parti_id, restrict candidates to that batch
        if parti_id:
            candidate_stocks = db.query(models.Stok).join(models.Parti).filter(
                models.Parti.ilac_id == ilac_rec.id,
                models.Stok.parti_id == int(parti_id),
                models.Stok.miktar > 0
            ).all()
        else:
            # Query candidate stocks across the ENTIRE generic group
            group_filter = get_generic_group_filter(ilac_rec)
            group_stocks = db.query(models.Stok)\
                .join(models.Parti, models.Stok.parti_id == models.Parti.id)\
                .join(models.Ilac, models.Parti.ilac_id == models.Ilac.id)\
                .filter(models.Stok.miktar > 0, group_filter)\
                .order_by(models.Parti.miad.asc()).all()

            # Prioritize candidate stocks:
            # 1. Target drug's own stocks first (same ilac_id), ordered by FEFO
            # 2. Other drugs in generic group (substitutes), ordered by FEFO
            # 3. If item_depo_id is specified, prefer matching depot within each priority
            def stock_sort_key(s):
                is_target_drug = (s.parti.ilac_id == ilac_rec.id)
                is_target_depo = (item_depo_id and s.depo_id == int(item_depo_id))
                miad_val = s.parti.miad if (s.parti and s.parti.miad) else datetime.date(9999, 12, 31)
                return (not is_target_drug, not is_target_depo, miad_val)

            candidate_stocks = sorted(group_stocks, key=stock_sort_key)

        total_avail = sum([s.miktar for s in candidate_stocks])
        if total_avail < cikis_miktari:
            group_title = ilac_rec.jenerik_grubu or ilac_rec.jenerik_adi or ilac_rec.ad
            errors.append(f"'{ilac_rec.ad}' ilacı ve '{group_title}' jenerik grubundaki tüm depolarda toplam yeterli stok bulunmuyor. (Grup Toplamı: {total_avail}, İstenen: {cikis_miktari})")
            continue

        remaining = cikis_miktari
        item_deducted = 0
        item_deductions = []

        for stok in candidate_stocks:
            if remaining <= 0:
                break
            if stok.miktar <= 0:
                continue

            deduct = min(stok.miktar, remaining)
            if deduct <= 0:
                continue

            stok.miktar -= deduct
            remaining -= deduct
            item_deducted += deduct
            total_deducted_qty += deduct

            item_deductions.append({
                "ilac_ad": stok.parti.ilac.ad,
                "depo_ad": stok.depo.ad,
                "parti_no": stok.parti.parti_no if stok.parti else "-",
                "miad": stok.parti.miad.strftime('%d.%m.%Y') if (stok.parti and stok.parti.miad) else "-",
                "miktar": deduct
            })

            is_cross_generic = (stok.parti.ilac_id != ilac_rec.id)
            is_cross_depot = bool(item_depo_id and stok.depo_id != int(item_depo_id))

            cikis_tag = ""
            if is_cross_generic and is_cross_depot:
                cikis_tag = " [Çapraz Depo & FEFO Muadil Çıkışı]"
            elif is_cross_generic:
                cikis_tag = " [Çapraz FEFO Muadil Çıkışı]"
            elif is_cross_depot:
                cikis_tag = " [Çapraz Depo Çıkışı]"

            koli_info = (item.get("koli_no") or "").strip()
            koli_tag = f" [Koli: {koli_info}]" if koli_info else ""
            kutu_ici_val = stok.parti.ilac.kutu_ici_adet if (stok.parti and stok.parti.ilac and stok.parti.ilac.kutu_ici_adet) else 1

            hareket = models.StokHareketi(
                tarih=datetime.datetime.now(),
                hareket_tipi="Toplu Çıkış",
                toplu_islem_kodu=toplu_islem_kodu,
                depo_id=stok.depo_id,
                parti_id=stok.parti_id,
                miktar=-deduct,
                aciklama=f"{evrak_no} - {cikis_nedeni}{koli_tag}{cikis_tag} ({stok.depo.ad} FEFO)",
                kullanici_id=request.state.user.id,
                koli_no=koli_info or None,
                kutu_ici_adet=kutu_ici_val
            )
            db.add(hareket)
            db.flush()

            # Fiziksel Depo Karekodlarından (DepoKarekod) doz düşümü yap
            specific_qr_ids = [int(x) for x in (item.get("qr_ids") or []) if str(x).isdigit()]
            rem_doses_for_qr = deduct
            finished_boxes_count = 0
            if specific_qr_ids:
                now_utc = datetime.datetime.now(datetime.timezone.utc).replace(tzinfo=None)
                spec_boxes = db.query(models.DepoKarekod).filter(
                    models.DepoKarekod.id.in_(specific_qr_ids),
                    models.DepoKarekod.depo_id == stok.depo_id,
                    models.DepoKarekod.parti_id == stok.parti_id,
                    models.DepoKarekod.durum == "depoda",
                    models.DepoKarekod.kalan_doz > 0
                ).all()
                for s_box in spec_boxes:
                    if rem_doses_for_qr <= 0:
                        break
                    c_doses = min(s_box.kalan_doz, rem_doses_for_qr)
                    s_box.kalan_doz -= c_doses
                    rem_doses_for_qr -= c_doses
                    if s_box.kalan_doz <= 0:
                        s_box.kalan_doz = 0
                        s_box.durum = "cikis_yapildi"
                        s_box.cikis_tarihi = now_utc
                        s_box.cikis_hareket_id = hareket.id
                        finished_boxes_count += 1
                        if s_box.koli_no and not hareket.koli_no:
                            hareket.koli_no = s_box.koli_no

            if rem_doses_for_qr > 0:
                finished_boxes_count += QRBasketService.deduct_depo_doses_fefo(
                    db=db,
                    depo_id=stok.depo_id,
                    parti_id=stok.parti_id,
                    dose_amount=rem_doses_for_qr,
                    cikis_hareket_id=hareket.id
                )

            if finished_boxes_count > 0:
                hareket.kutu_sayisi = finished_boxes_count

        processed_count += 1

        parts_str = ", ".join([f"{d['ilac_ad']}: {d['miktar']} Adet [{d['depo_ad']}]" for d in item_deductions])
        is_cross = len(item_deductions) > 1
        deduction_details.append({
            "ilac_ad": ilac_rec.ad,
            "barkod": ilac_rec.barkod,
            "toplam_cikis": item_deducted,
            "depo_dagilimi": parts_str,
            "is_cross_depot": is_cross,
            "deductions": item_deductions
        })

    if processed_count == 0 and errors:
        return JSONResponse(status_code=400, content={"detail": "<br>".join(errors)})

    db.commit()

    return JSONResponse(content={
        "status": "success", "success": True,
        "msg": f"{processed_count} kalem ilaç için toplam {total_deducted_qty} adet stok çıkışı başarıyla gerçekleştirildi.",
        "processed_count": processed_count,
        "total_deducted": total_deducted_qty,
        "details": deduction_details,
        "warnings": errors
    })






