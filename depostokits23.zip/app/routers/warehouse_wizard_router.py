from fastapi import APIRouter, Request, Depends, Form, Query, Body, status, HTTPException
from fastapi.responses import HTMLResponse, JSONResponse, Response, RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session, joinedload
from pydantic import BaseModel, Field, BeforeValidator
import datetime
import json
import hashlib
from typing import Annotated, Any, List, Optional

from .. import database, models

router = APIRouter(prefix="/warehouse-wizard", tags=["warehouse_wizard"], strict_content_type=False)
templates = Jinja2Templates(directory="app/templates")


def _parse_optional_int(v: Any) -> Optional[int]:
    if v is None or v == "" or str(v).lower() in ("none", "null", "undefined", "all"):
        return None
    if isinstance(v, int):
        return v
    s = str(v).strip()
    return int(s) if s.lstrip("-").isdigit() else None


DbSession = Annotated[Session, Depends(database.get_db)]
OptionalIntQuery = Annotated[Optional[int], BeforeValidator(_parse_optional_int), Query()]

# --- Helper Functions ---

def calculate_check_digit(code_str: str) -> str:
    """Calculates a 2-digit deterministic verification check digit (10..99) for paper-based safety."""
    val = 0
    for idx, ch in enumerate(code_str, 1):
        val += ord(ch) * (idx * 7)
    check_num = (val % 90) + 10
    return f"{check_num:02d}"

def generate_locations_from_blocks(warehouse_code: str, blocks: list) -> list:
    """
    Generator function that creates location records given warehouse code and block configurations.
    Applies topological serpentine pick_sequence (10, 20, 30...) and direction (ASC / DESC).
    """
    locations = []
    current_seq = 10
    wh_code_clean = (warehouse_code or "D1").strip().upper()

    def get_val(item, key, default):
        if isinstance(item, dict):
            return item.get(key, default)
        return getattr(item, key, default)

    # Sort blocks by sequence_order
    sorted_blocks = sorted(blocks, key=lambda b: get_val(b, 'sequence_order', 1))

    for b in sorted_blocks:
        b_code = str(get_val(b, 'block_code', 'A')).strip().upper()
        rack_count = int(get_val(b, 'rack_count', 1))
        levels = int(get_val(b, 'levels_per_rack', 1))
        direction = str(get_val(b, 'direction', 'ASC')).strip().upper()

        if direction == "DESC":
            rack_range = range(rack_count, 0, -1)
        else:
            rack_range = range(1, rack_count + 1)

        for r_no in rack_range:
            for l_no in range(1, levels + 1):
                code = f"{wh_code_clean}-{b_code}-R{r_no:02d}-K{l_no:02d}"
                chk = calculate_check_digit(code)
                locations.append({
                    "code": code,
                    "block_code": b_code,
                    "rack_no": r_no,
                    "level_no": l_no,
                    "pick_sequence": current_seq,
                    "check_digit": chk,
                    "is_active": True,
                    "direction": direction
                })
                current_seq += 10

    return locations

def generate_zpl_codes(locations: list, warehouse_code: str = "") -> str:
    """Generates ZPL II code string for thermal barcode printers (Code128 + Check Digit)."""
    zpl_lines = []
    for loc in locations:
        if not loc.get("is_active", True):
            continue
        code = loc.get("code", "")
        chk = loc.get("check_digit", "")
        seq = loc.get("pick_sequence", 0)
        
        zpl = (
            f"^XA\n"
            f"^FO40,25^A0N,28,28^FDDEPO: {warehouse_code}^FS\n"
            f"^FO40,55^A0N,32,32^FD{code}^FS\n"
            f"^FO40,95^BY2,3,60^BCN,60,Y,N,N^FD{code}^FS\n"
            f"^FO40,175^A0N,24,24^FDDOĞRULAMA (CHECK): {chk}   SIRA: #{seq}^FS\n"
            f"^XZ\n"
        )
        zpl_lines.append(zpl)
    return "".join(zpl_lines)


# --- Pydantic Schemas ---

class BlockInputSchema(BaseModel):
    sequence_order: int = 1
    block_code: str
    block_name: str
    rack_count: int = Field(gt=0, default=1)
    levels_per_rack: int = Field(gt=0, default=1)
    direction: str = "ASC"  # "ASC" or "DESC"

class PreviewRequestSchema(BaseModel):
    warehouse_code: str
    blocks: List[BlockInputSchema]

class LocationSaveItemSchema(BaseModel):
    code: str
    block_code: str = "GENEL"
    rack_no: int = 1
    level_no: int = 1
    pick_sequence: int = 10
    check_digit: Optional[str] = None
    is_active: bool = True

class SaveWizardSchema(BaseModel):
    depo_id: Optional[int] = None
    warehouse_code: str
    warehouse_name: str
    description: Optional[str] = ""
    blocks: List[BlockInputSchema] = Field(default_factory=list)
    locations: List[LocationSaveItemSchema] = Field(default_factory=list)


# --- API Routes ---

@router.get("", response_class=HTMLResponse)
async def get_wizard_page(
    request: Request,
    db: DbSession,
    depo_id: OptionalIntQuery = None,
):
    """Render Depo Etiket Tanımla UI Page."""
    depolar = db.query(models.Depo).options(
        joinedload(models.Depo.lokasyonlar)
    ).filter(models.Depo.is_toplam_depo == False).all()
    for d in depolar:
        d.aktif_etiket_sayisi = sum(1 for l in d.lokasyonlar if l.is_active)
    return templates.TemplateResponse(
        request=request,
        name="warehouse_wizard.html",
        context={
            "request": request,
            "depolar": depolar,
            "secili_depo_id": depo_id,
            "user": getattr(request.state, "user", None)
        }
    )

@router.get("/depo-config/{depo_id}")
async def get_depo_config(depo_id: int, db: DbSession):
    """Fetch existing blocks and locations for a warehouse."""
    depo = db.query(models.Depo).options(
        joinedload(models.Depo.bloklar),
        joinedload(models.Depo.lokasyonlar)
    ).filter(models.Depo.id == depo_id).first()
    if not depo:
        raise HTTPException(status_code=404, detail="Depo bulunamadı")

    blocks = sorted(depo.bloklar, key=lambda b: (b.sequence_order or 1, b.id))
    locations = sorted(depo.lokasyonlar, key=lambda l: (l.pick_sequence or 0, l.id))
    block_dir_map = {b.block_code: (b.direction or "ASC") for b in blocks}

    return JSONResponse({
        "status": "success",
        "depo": {
            "id": depo.id,
            "kod": depo.kod,
            "ad": depo.ad,
            "aciklama": depo.aciklama or ""
        },
        "blocks": [
            {
                "sequence_order": b.sequence_order or idx,
                "block_code": b.block_code,
                "block_name": b.block_name,
                "rack_count": b.rack_count,
                "levels_per_rack": b.levels_per_rack,
                "direction": b.direction or "ASC"
            }
            for idx, b in enumerate(blocks, 1)
        ],
        "locations": [
            {
                "id": l.id,
                "code": l.code,
                "block_code": l.block_code or "GENEL",
                "rack_no": l.rack_no or 1,
                "level_no": l.level_no or 1,
                "pick_sequence": l.pick_sequence or 10,
                "check_digit": l.check_digit or calculate_check_digit(l.code),
                "is_active": bool(l.is_active),
                "direction": block_dir_map.get(l.block_code, "ASC")
            }
            for l in locations
        ]
    })

@router.post("/generate-preview")
async def generate_preview(payload: PreviewRequestSchema):
    """Generate and return preview array of location records without saving to database."""
    try:
        locs = generate_locations_from_blocks(payload.warehouse_code, payload.blocks)
        return JSONResponse({
            "status": "success",
            "warehouse_code": payload.warehouse_code.upper(),
            "total_locations": len(locs),
            "locations": locs
        })
    except Exception as e:
        return JSONResponse({"status": "error", "message": str(e)}, status_code=400)

@router.post("/confirm-save")
async def confirm_save_wizard(payload: SaveWizardSchema, db: DbSession):
    """Bulk save Warehouse, Blocks, and Generated/Manual Locations to database."""
    try:
        wh_code_clean = payload.warehouse_code.strip().upper()
        
        # 1. Create or fetch Warehouse (Depo)
        depo = None
        if payload.depo_id:
            depo = db.query(models.Depo).filter(models.Depo.id == payload.depo_id).first()
            
        if not depo:
            depo = db.query(models.Depo).filter(models.Depo.kod == wh_code_clean).first()

        if not depo:
            depo = models.Depo(
                kod=wh_code_clean,
                ad=payload.warehouse_name.strip(),
                aciklama=payload.description or f"Depo Etiket Tanımla ile oluşturuldu ({datetime.date.today()})"
            )
            db.add(depo)
            db.flush()
        else:
            depo.ad = payload.warehouse_name.strip()
            if payload.description:
                depo.aciklama = payload.description

        # 2. Delete existing blocks & locations for this warehouse if re-configuring
        db.query(models.WarehouseLocation).filter(models.WarehouseLocation.depo_id == depo.id).delete()
        db.query(models.WarehouseBlock).filter(models.WarehouseBlock.depo_id == depo.id).delete()
        db.flush()

        # 3. Save Blocks
        block_model_map = {}
        for b_input in payload.blocks:
            b_obj = models.WarehouseBlock(
                depo_id=depo.id,
                sequence_order=b_input.sequence_order,
                block_code=b_input.block_code.strip().upper(),
                block_name=b_input.block_name.strip(),
                rack_count=b_input.rack_count,
                levels_per_rack=b_input.levels_per_rack,
                direction=b_input.direction.strip().upper()
            )
            db.add(b_obj)
            db.flush()
            block_model_map[b_input.block_code.strip().upper()] = b_obj.id

        # 4. Save Locations
        saved_loc_objs = []
        seen_codes = set()
        for l_input in payload.locations:
            clean_code = (l_input.code or "").strip().upper()
            if not clean_code or clean_code in seen_codes:
                continue
            seen_codes.add(clean_code)
            b_code = (l_input.block_code or "GENEL").strip().upper()
            chk_digit = (l_input.check_digit or "").strip() or calculate_check_digit(clean_code)
            loc_obj = models.WarehouseLocation(
                depo_id=depo.id,
                block_id=block_model_map.get(b_code),
                code=clean_code,
                block_code=b_code,
                rack_no=l_input.rack_no or 1,
                level_no=l_input.level_no or 1,
                pick_sequence=l_input.pick_sequence or 10,
                check_digit=chk_digit,
                is_active=l_input.is_active
            )
            db.add(loc_obj)
            saved_loc_objs.append(loc_obj)

        db.commit()

        active_saved_count = sum(1 for l in saved_loc_objs if l.is_active)
        return JSONResponse({
            "status": "success",
            "message": f"'{depo.ad}' ({depo.kod}) deposuna ait {active_saved_count} aktif etiket/konum kaydı başarıyla depoya atandı.",
            "depo_id": depo.id,
            "depo_kod": depo.kod,
            "total_saved": len(saved_loc_objs),
            "active_saved": active_saved_count
        })
    except Exception as e:
        db.rollback()
        return JSONResponse({"status": "error", "message": f"Kayıt esnasında hata oluştu: {str(e)}"}, status_code=500)

@router.get("/picking-route/{depo_id}")
async def get_picking_route(depo_id: int, db: DbSession):
    """Fetch locations ordered by topological pick_sequence ASC for paper picking route optimization."""
    depo = db.query(models.Depo).filter(models.Depo.id == depo_id).first()
    if not depo:
        raise HTTPException(status_code=404, detail="Depo bulunamadı")

    locations = db.query(models.WarehouseLocation).filter(
        models.WarehouseLocation.depo_id == depo_id,
        models.WarehouseLocation.is_active == True
    ).order_by(models.WarehouseLocation.pick_sequence.asc(), models.WarehouseLocation.code.asc()).all()

    return JSONResponse({
        "depo_id": depo.id,
        "depo_kod": depo.kod,
        "depo_ad": depo.ad,
        "total_active_locations": len(locations),
        "picking_route": [
            {
                "id": l.id,
                "code": l.code,
                "block_code": l.block_code,
                "rack_no": l.rack_no,
                "level_no": l.level_no,
                "pick_sequence": l.pick_sequence,
                "check_digit": l.check_digit
            }
            for l in locations
        ]
    })

@router.post("/export-labels-zpl")
async def export_labels_zpl(payload: Annotated[dict[str, Any], Body(default_factory=dict)]):
    """Generates ZPL II barcode output text for thermal printers."""
    locations = payload.get("locations", [])
    warehouse_code = payload.get("warehouse_code", "D1")
    zpl_content = generate_zpl_codes(locations, warehouse_code)
    
    headers = {
        "Content-Disposition": f"attachment; filename=raf_etiketleri_{warehouse_code}.zpl"
    }
    return Response(content=zpl_content, media_type="text/plain", headers=headers)

@router.post("/export-labels-pdf", response_class=HTMLResponse)
async def export_labels_pdf(request: Request, payload: Annotated[dict[str, Any], Body(default_factory=dict)]):
    """Renders printable Code128 barcode labels HTML view for printing A4 / Thermal labels."""
    locations = [loc for loc in payload.get("locations", []) if loc.get("is_active", True)]
    warehouse_code = payload.get("warehouse_code", "D1")
    
    return templates.TemplateResponse(
        request=request,
        name="warehouse_location_labels.html",
        context={
            "request": request,
            "warehouse_code": warehouse_code,
            "locations": locations,
            "print_date": datetime.datetime.now().strftime("%d.%m.%Y %H:%M")
        }
    )

