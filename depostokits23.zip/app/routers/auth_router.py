from typing import Annotated
from fastapi import APIRouter, Request, Depends, Form, status
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from .. import database, models, auth, crud

router = APIRouter(tags=["auth"])
templates = Jinja2Templates(directory="app/templates")

DbSession = Annotated[Session, Depends(database.get_db)]


@router.get("/login", response_class=HTMLResponse)
async def login_get(request: Request):
    return templates.TemplateResponse(
        request=request,
        name="login.html",
        context={"request": request}
    )


@router.post("/login")
async def login_post(
    request: Request,
    username: Annotated[str, Form(...)],
    password: Annotated[str, Form(...)],
    db: DbSession,
):
    user = crud.get_kullanici_by_username(db, username)
    if not user or not auth.verify_password(password, user.parola_hash):
        return templates.TemplateResponse(
            request=request,
            name="login.html",
            context={"request": request, "error": "Geçersiz kullanıcı adı veya parola."}
        )

    response = RedirectResponse(url="/", status_code=status.HTTP_302_FOUND)
    response.set_cookie(
        key="session_user_id",
        value=auth.create_session_token(user.id),
        httponly=True,
        samesite="lax",
        secure=request.url.scheme == "https"
    )
    return response


@router.get("/logout")
async def logout(request: Request):
    response = RedirectResponse(url="/login", status_code=status.HTTP_302_FOUND)
    response.delete_cookie("session_user_id")
    return response

