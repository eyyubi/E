from typing import Annotated, Optional
from fastapi import APIRouter, Request, Depends, Form, Query, status
from fastapi.responses import HTMLResponse, RedirectResponse, JSONResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session, joinedload
from sqlalchemy.exc import IntegrityError
from urllib.parse import quote
from .. import database, models

router = APIRouter(prefix="/warehouses", tags=["warehouses"], strict_content_type=False)
templates = Jinja2Templates(directory="app/templates")

DbSession = Annotated[Session, Depends(database.get_db)]

@router.get("", response_class=HTMLResponse)
async def list_warehouses(request: Request, db: DbSession):
    msg = request.query_params.get("msg")
    error = request.query_params.get("error")

    depolar = db.query(models.Depo).options(
        joinedload(models.Depo.ozellikler),
        joinedload(models.Depo.stoklar),
        joinedload(models.Depo.lokasyonlar)
    ).all()

    for depo in depolar:
        depo.toplam_stok = sum(s.miktar for s in depo.stoklar if s.miktar > 0)
        toplam_koli = sum(
            round(s.miktar / (s.koli_ici_adet or 1), 2) for s in depo.stoklar if s.miktar > 0
        )
        depo.toplam_koli = round(toplam_koli, 2)
        depo.ozellik_ids = [oz.id for oz in depo.ozellikler]
        depo.aktif_lokasyonlar = sorted(
            [l for l in depo.lokasyonlar if l.is_active],
            key=lambda x: (x.pick_sequence or 0, x.code or "")
        )

    tum_ozellikler = db.query(models.IlacOzellik).all()

    return templates.TemplateResponse(
        request=request,
        name="warehouses.html",
        context={
            "request": request,
            "depolar": depolar,
            "tum_ozellikler": tum_ozellikler,
            "msg": msg,
            "error": error,
            "user": getattr(request.state, "user", None)
        }
    )

@router.post("/add")
async def add_warehouse(
    request: Request,
    kod: Annotated[str, Form(...)],
    ad: Annotated[str, Form(...)],
    db: DbSession,
    aciklama: Annotated[str, Form()] = "",
    is_toplam_depo: Annotated[bool, Form()] = False,
):
    form_data = await request.form()
    ozellik_ids = [int(v) for k, v in form_data.multi_items() if k == "ozellik_ids"]

    kod = kod.strip().upper()
    ad = ad.strip()
    aciklama = aciklama.strip()

    if not kod or not ad:
        return RedirectResponse(url="/warehouses?error=Depo+kodu+ve+adı+zorunludur.", status_code=status.HTTP_302_FOUND)

    existing = db.query(models.Depo).filter(models.Depo.kod == kod).first()
    if existing:
        return RedirectResponse(url="/warehouses?error=Bu+kodlu+bir+depo+zaten+mevcut.", status_code=status.HTTP_302_FOUND)

    yeni_depo = models.Depo(
        kod=kod,
        ad=ad,
        aciklama=aciklama,
        is_toplam_depo=is_toplam_depo
    )
    # Toplam stok deposuna özellik atanamaz (anlamı yok)
    if not is_toplam_depo and ozellik_ids:
        yeni_depo.ozellikler = db.query(models.IlacOzellik).filter(models.IlacOzellik.id.in_(ozellik_ids)).all()

    db.add(yeni_depo)
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        return RedirectResponse(url="/warehouses?error=Veritabanı+kayıt+hatası.", status_code=status.HTTP_302_FOUND)

    depo_turu = "Toplam Stok Deposu" if is_toplam_depo else "Depo"
    return RedirectResponse(url=f"/warehouses?msg={depo_turu}+'{ad}'+başarıyla+tanımlandı.", status_code=status.HTTP_302_FOUND)

@router.post("/edit/{depo_id}")
async def edit_warehouse(
    depo_id: int,
    request: Request,
    kod: Annotated[str, Form(...)],
    ad: Annotated[str, Form(...)],
    db: DbSession,
    aciklama: Annotated[str, Form()] = "",
    is_toplam_depo: Annotated[Optional[bool], Form()] = None,
):
    form_data = await request.form()
    ozellik_ids = [int(v) for k, v in form_data.multi_items() if k == "ozellik_ids"]

    depo = db.query(models.Depo).options(joinedload(models.Depo.ozellikler)).filter(models.Depo.id == depo_id).first()
    if not depo:
        return RedirectResponse(url="/warehouses?error=Depo+bulunamadı.", status_code=status.HTTP_302_FOUND)

    kod = kod.strip().upper()
    ad = ad.strip()
    aciklama = aciklama.strip()

    if not kod or not ad:
        return RedirectResponse(url="/warehouses?error=Depo+kodu+ve+adı+boş+bırakılamaz.", status_code=status.HTTP_302_FOUND)

    # Check unique code if changed
    if kod != depo.kod:
        existing = db.query(models.Depo).filter(models.Depo.kod == kod).first()
        if existing:
            return RedirectResponse(url="/warehouses?error=Bu+kodlu+başka+bir+depo+zaten+mevcut.", status_code=status.HTTP_302_FOUND)

    depo.kod = kod
    depo.ad = ad
    depo.aciklama = aciklama

    # is_toplam_depo: zaten True ise değiştirilemez; False'tan True'ya geçilebilir
    if is_toplam_depo is not None:
        if depo.is_toplam_depo and not is_toplam_depo:
            # Toplam depo'yu geri almaya çalışıyorlar - stok varsa engelle
            toplam_stok = sum(s.miktar for s in depo.stoklar if s.miktar > 0)
            if toplam_stok > 0:
                return RedirectResponse(
                    url="/warehouses?error=Toplam+stok+deposunda+kayıtlı+stok+bulunduğundan+özellik+kaldırılamaz.",
                    status_code=status.HTTP_302_FOUND
                )
        depo.is_toplam_depo = is_toplam_depo

    if not depo.is_toplam_depo:
        if ozellik_ids:
            depo.ozellikler = db.query(models.IlacOzellik).filter(models.IlacOzellik.id.in_(ozellik_ids)).all()
        else:
            depo.ozellikler = []
    else:
        # Toplam depoya özellik atanmaz
        depo.ozellikler = []

    db.commit()
    return RedirectResponse(url="/warehouses?msg=Depo+bilgileri+ve+kabul+edilen+özellikler+güncellendi.", status_code=status.HTTP_302_FOUND)

@router.post("/delete/{depo_id}")
@router.get("/delete/{depo_id}", include_in_schema=False)
async def delete_warehouse(
    depo_id: int,
    request: Request,
    db: DbSession,
    force: Annotated[Optional[str], Query()] = None,
):
    try:
        depo = db.query(models.Depo).options(
            joinedload(models.Depo.stoklar),
            joinedload(models.Depo.ozellikler)
        ).filter(models.Depo.id == depo_id).first()
        if not depo:
            return RedirectResponse(url="/warehouses?error=Silinecek+depo+bulunamadı.", status_code=status.HTTP_302_FOUND)

        toplam_stok = sum(s.miktar for s in depo.stoklar if s.miktar > 0)
        depo_adi = depo.ad

        if depo.is_toplam_depo:
            # Toplam depo: stok olsa bile silinebilir — önce TOPLAM-STOK partilerini topla
            toplam_parti_ids = []
            for stok in depo.stoklar:
                if stok.parti and stok.parti.parti_no == "TOPLAM-STOK":
                    toplam_parti_ids.append(stok.parti_id)

            # İlişkili stokları ve geçmiş referansları güvenle temizle / null yap
            for s in list(depo.stoklar):
                db.delete(s)
            db.query(models.DepoKarekod).filter(models.DepoKarekod.depo_id == depo_id).update({"depo_id": None}, synchronize_session=False)
            db.query(models.StokHareketi).filter(models.StokHareketi.depo_id == depo_id).update(
                {"depo_id": None}, synchronize_session=False
            )
            db.query(models.StokHareketi).filter(models.StokHareketi.hedef_depo_id == depo_id).update(
                {"hedef_depo_id": None}, synchronize_session=False
            )
            db.query(models.WarehouseLocation).filter(models.WarehouseLocation.depo_id == depo_id).delete(synchronize_session=False)
            db.query(models.WarehouseBlock).filter(models.WarehouseBlock.depo_id == depo_id).delete(synchronize_session=False)
            depo.ozellikler = []

            db.delete(depo)
            db.flush()

            # Sahipsiz kalan TOPLAM-STOK parti kayıtlarını temizle
            for pid in toplam_parti_ids:
                stok_var = db.query(models.Stok).filter(models.Stok.parti_id == pid).count()
                if stok_var == 0:
                    db.query(models.Parti).filter(models.Parti.id == pid, models.Parti.parti_no == "TOPLAM-STOK").delete(synchronize_session=False)

            db.commit()
            return RedirectResponse(url=f"/warehouses?msg={quote(f'Toplam stok deposu ({depo_adi}) başarıyla silindi.')}", status_code=status.HTTP_302_FOUND)
        else:
            # Normal depo: aktif pozitif stok varsa silinemez
            if toplam_stok > 0:
                err_msg = f"UYARI: '{depo_adi}' deposunda {toplam_stok} Adet mevcut stok bulunduğundan depo silinemez. Lütfen önce stok çıkışı veya transfer yapınız."
                return RedirectResponse(url=f"/warehouses?error={quote(err_msg)}", status_code=status.HTTP_302_FOUND)

            # Sıfır stoklu depo: İlişkili 0-miktar stok kayıtlarını, konumları ve blokları temizle
            for s in list(depo.stoklar):
                db.delete(s)
            db.query(models.WarehouseLocation).filter(models.WarehouseLocation.depo_id == depo_id).delete(synchronize_session=False)
            db.query(models.WarehouseBlock).filter(models.WarehouseBlock.depo_id == depo_id).delete(synchronize_session=False)
            db.query(models.DepoKarekod).filter(models.DepoKarekod.depo_id == depo_id).update({"depo_id": None}, synchronize_session=False)

            # Geçmiş stok hareketlerindeki foreign key referanslarını null yap (geçmiş denetim izini korur ve FK hatasını önler)
            db.query(models.StokHareketi).filter(models.StokHareketi.depo_id == depo_id).update(
                {"depo_id": None}, synchronize_session=False
            )
            db.query(models.StokHareketi).filter(models.StokHareketi.hedef_depo_id == depo_id).update(
                {"hedef_depo_id": None}, synchronize_session=False
            )
            depo.ozellikler = []

            db.delete(depo)
            db.commit()

            return RedirectResponse(url=f"/warehouses?msg={quote(f'{depo_adi} deposu başarıyla silindi.')}", status_code=status.HTTP_302_FOUND)

    except Exception as e:
        db.rollback()
        err_str = f"Depo silinirken veritabanı hatası oluştu: {str(e)}"
        return RedirectResponse(url=f"/warehouses?error={quote(err_str)}", status_code=status.HTTP_302_FOUND)

@router.post("/{depo_id}/locations/add")
async def add_warehouse_location_quick(
    depo_id: int,
    code: Annotated[str, Form(...)],
    db: DbSession,
):
    depo = db.query(models.Depo).filter(models.Depo.id == depo_id).first()
    if not depo:
        return RedirectResponse(url="/warehouses?error=Depo+bulunamadı.", status_code=status.HTTP_302_FOUND)

    code = code.strip().upper()
    if not code:
        return RedirectResponse(url="/warehouses?error=Etiket+kodu+boş+olamaz.", status_code=status.HTTP_302_FOUND)

    existing = db.query(models.WarehouseLocation).filter(
        models.WarehouseLocation.depo_id == depo_id,
        models.WarehouseLocation.code == code
    ).first()
    if existing:
        existing.is_active = True
        db.commit()
        return RedirectResponse(url=f"/warehouses?msg='{code}'+etiketi+'{depo.ad}'+deposunda+aktif+edildi.", status_code=status.HTTP_302_FOUND)

    max_seq = db.query(models.WarehouseLocation).filter(models.WarehouseLocation.depo_id == depo_id).count()
    chk = str((sum(ord(c) * (i + 1) for i, c in enumerate(code)) % 89) + 10)
    block_guess = code.split("-")[0][:10] if "-" in code else (code[:1] or "GENEL")
    new_loc = models.WarehouseLocation(
        depo_id=depo_id,
        code=code,
        block_code=block_guess,
        rack_no=1,
        level_no=1,
        pick_sequence=max_seq + 1,
        check_digit=chk,
        is_active=True
    )
    db.add(new_loc)
    db.commit()
    return RedirectResponse(url=f"/warehouses?msg='{code}'+konum+etiketi+'{depo.ad}'+deposuna+atandı.", status_code=status.HTTP_302_FOUND)

@router.post("/locations/delete/{loc_id}")
@router.get("/locations/delete/{loc_id}", include_in_schema=False)
async def delete_warehouse_location_quick(
    loc_id: int,
    db: DbSession,
):
    loc = db.query(models.WarehouseLocation).filter(models.WarehouseLocation.id == loc_id).first()
    if not loc:
        return RedirectResponse(url="/warehouses?error=Silinecek+etiket+bulunamadı.", status_code=status.HTTP_302_FOUND)
    kod = loc.code
    db.delete(loc)
    db.commit()
    return RedirectResponse(url=f"/warehouses?msg='{kod}'+konum+etiketi+silindi.", status_code=status.HTTP_302_FOUND)


