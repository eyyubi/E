from typing import Annotated, Optional
from fastapi import APIRouter, Request, Depends, Form, Query, status, UploadFile, File
from fastapi.responses import HTMLResponse, RedirectResponse, JSONResponse, Response
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session, joinedload
from .. import database, models
from ..crud import check_depo_drug_compatibility
import datetime
import io
import json
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

router = APIRouter(prefix="/stock", tags=["stock"], strict_content_type=False)
templates = Jinja2Templates(directory="app/templates")

DbSession = Annotated[Session, Depends(database.get_db)]

def is_ajax_request(request: Request) -> bool:
    return (
        request.headers.get("x-requested-with") == "XMLHttpRequest" or
        "application/json" in request.headers.get("accept", "").lower() or
        "application/json" in request.headers.get("content-type", "").lower()
    )

@router.get("", response_class=HTMLResponse)
async def view_stock(
    request: Request,
    db: DbSession,
    depo_id: Annotated[Optional[str], Query()] = None,
    q: Annotated[Optional[str], Query()] = None,
    view_mode: Annotated[str, Query()] = "generic",
    sort_by: Annotated[str, Query()] = "name",
    page: Annotated[int, Query(ge=1)] = 1,
    per_page: Annotated[str, Query()] = "50",
):
    clean_depo_id = int(depo_id) if (depo_id and str(depo_id).isdigit()) else None
    msg = request.query_params.get("msg")
    error = request.query_params.get("error")

    query = db.query(models.Stok).options(
        joinedload(models.Stok.parti).joinedload(models.Parti.ilac),
        joinedload(models.Stok.depo)
    ).filter(
        models.Stok.miktar > 0,
        models.Stok.depo_id.in_(
            db.query(models.Depo.id).filter(models.Depo.is_toplam_depo == False)
        )
    )
    
    if clean_depo_id:
        query = query.filter(models.Stok.depo_id == clean_depo_id)
        
    stoklar = query.all()
    bugun = datetime.date.today()
    
    # Aktif Depo Karekod sayılarını (depo_id, parti_id) bazında çek
    from sqlalchemy import func
    qr_counts_raw = db.query(
        models.DepoKarekod.depo_id,
        models.DepoKarekod.parti_id,
        func.count(models.DepoKarekod.id).label("box_count"),
        func.sum(models.DepoKarekod.kalan_doz).label("dose_count")
    ).filter(
        models.DepoKarekod.durum == "depoda",
        models.DepoKarekod.kalan_doz > 0
    ).group_by(
        models.DepoKarekod.depo_id,
        models.DepoKarekod.parti_id
    ).all()
    qr_map = {
        (r.depo_id, r.parti_id): {"boxes": int(r.box_count or 0), "doses": int(r.dose_count or 0)}
        for r in qr_counts_raw
    }

    jenerik_limits = db.query(models.JenerikKritikStok).all()
    limits_map = {l.grup_kodu: l.kritik_stok for l in jenerik_limits}
    grouped_stock = {}

    for stok in stoklar:
        if not stok.parti or not stok.parti.ilac:
            continue
        ilac = stok.parti.ilac
        
        # Server-side search filter matching drug name, barcode, etken madde, generic name, generic code, generic group
        if q and q.strip():
            q_clean = q.strip().lower()
            match_search = (
                q_clean in (ilac.ad or "").lower() or
                q_clean in (ilac.barkod or "").lower() or
                q_clean in (ilac.etken_madde or "").lower() or
                q_clean in (ilac.jenerik_adi or "").lower() or
                q_clean in (ilac.jenerik_kodu or "").lower() or
                q_clean in (ilac.jenerik_grubu or "").lower()
            )
            if not match_search:
                continue

        if view_mode == "drug":
            group_key = f"ilac_{ilac.id}"
            grup_kodu = ilac.jenerik_grubu or ilac.jenerik_adi or ilac.jenerik_kodu or "-"
            grup_adi = ilac.ad
        else:
            group_key = ilac.jenerik_grubu.strip() if (ilac.jenerik_grubu and ilac.jenerik_grubu.strip()) else (ilac.jenerik_adi.strip() if (ilac.jenerik_adi and ilac.jenerik_adi.strip()) else (ilac.jenerik_kodu.strip() if (ilac.jenerik_kodu and ilac.jenerik_kodu.strip()) else (ilac.etken_madde.strip() if (ilac.etken_madde and ilac.etken_madde.strip()) else ilac.ad.strip())))
            grup_kodu = group_key
            grup_adi = group_key

        if group_key not in grouped_stock:
            grouped_stock[group_key] = {
                "group_key": group_key,
                "grup_kodu": grup_kodu,
                "grup_adi": grup_adi,
                "ilac": ilac,
                "toplam_adet": 0,
                "toplam_qr_kutu": 0,
                "ilaclar_map": {},
                "detaylar": [],
                "depolar_set": set()
            }
            
        if ilac.id not in grouped_stock[group_key]["ilaclar_map"]:
            grouped_stock[group_key]["ilaclar_map"][ilac.id] = ilac
            
        if stok.depo:
            grouped_stock[group_key]["depolar_set"].add(stok.depo.ad)

        durum = "Normal"
        kalan_gun = None
        renk = "success"
        
        if stok.parti.miad:
            kalan_gun = (stok.parti.miad - bugun).days
            if kalan_gun < 0:
                durum = "Miadı Geçmiş"
                renk = "danger"
            elif kalan_gun <= 30:
                durum = "Çok Acil (Son 30 Gün)"
                renk = "danger"
            elif kalan_gun <= 90:
                durum = "Yaklaşıyor (Son 90 Gün)"
                renk = "warning"
                
        grouped_stock[group_key]["toplam_adet"] += stok.miktar
        
        koli_ici = stok.koli_ici_adet or getattr(stok.parti, 'koli_ici_adet', None) or ilac.koli_ici_adet or 1
        koli_parca = round(stok.miktar / koli_ici, 2)
        qr_info = qr_map.get((stok.depo_id, stok.parti_id), {"boxes": 0, "doses": 0})
        grouped_stock[group_key]["toplam_qr_kutu"] += qr_info["boxes"]
        
        grouped_stock[group_key]["detaylar"].append({
            "stok": stok,
            "ilac": ilac,
            "durum": durum,
            "kalan_gun": kalan_gun,
            "renk": renk,
            "koli_parca": koli_parca,
            "raf_konumu": stok.raf_konumu or ilac.raf_konumu or "-",
            "qr_box_count": qr_info["boxes"],
            "qr_dose_count": qr_info["doses"],
            "kutu_ici_adet": getattr(ilac, "kutu_ici_adet", 1) or 1
        })
        
    grouped_list = list(grouped_stock.values())

    for group in grouped_list:
        if view_mode == "drug":
            ilac_obj = group["ilac"]
            kritik_sinir = ilac_obj.kritik_stok or 10
            group["grup_kodu_raw"] = ilac_obj.jenerik_grubu or ilac_obj.jenerik_adi or ilac_obj.jenerik_kodu or "-"
            group["jenerik_kodu"] = ilac_obj.jenerik_kodu or "-"
            group["jenerik_kodlari"] = [ilac_obj.jenerik_kodu] if (ilac_obj.jenerik_kodu and ilac_obj.jenerik_kodu.strip()) else []
            group["jenerik_grubu"] = ilac_obj.jenerik_grubu or ilac_obj.jenerik_adi or ilac_obj.etken_madde or "-"
            group["markalar_list"] = [ilac_obj.ad]
            group["markalar"] = ilac_obj.ad
        else:
            if group["grup_kodu"] in limits_map:
                kritik_sinir = limits_map[group["grup_kodu"]]
            else:
                kritik_sinir = sum([ilac.kritik_stok or 0 for ilac in group["ilaclar_map"].values()])

            group["markalar_list"] = sorted(list(set([ilac.ad for ilac in group["ilaclar_map"].values()])))
            group["markalar"] = ", ".join(group["markalar_list"])

            jenerik_kodlari = sorted(list(set([
                ilac.jenerik_kodu.strip()
                for ilac in group["ilaclar_map"].values()
                if ilac.jenerik_kodu and ilac.jenerik_kodu.strip()
            ])))
            group["jenerik_kodlari"] = jenerik_kodlari
            group["jenerik_kodu"] = ", ".join(jenerik_kodlari)
            
        group["depolar_list"] = sorted(list(group.get("depolar_set", set())))
        group["kritik_sinir"] = kritik_sinir
        group["is_kritik"] = group["toplam_adet"] <= kritik_sinir
        
        toplam_koli = sum([d["koli_parca"] for d in group["detaylar"]])
        group["toplam_koli"] = round(toplam_koli, 2)

        # FEFO sorting for sub-details inside a group by miad (expiration date)
        def miad_sort_key(d):
            p = getattr(d.get("stok"), "parti", None)
            m = getattr(p, "miad", None) if p else None
            if m is None:
                return (1, datetime.date.max)
            return (0, m)

        group["detaylar"].sort(key=miad_sort_key)

    # Sort main grouped_list according to sort_by
    def get_group_earliest_miad(group):
        miads = [
            d["stok"].parti.miad
            for d in group["detaylar"]
            if d.get("stok") and d["stok"].parti and d["stok"].parti.miad
        ]
        if miads:
            return (0, min(miads))
        return (1, datetime.date.max)

    if sort_by == "miad":
        grouped_list.sort(key=get_group_earliest_miad)
    elif sort_by == "quantity_desc":
        grouped_list.sort(key=lambda g: g["toplam_adet"], reverse=True)
    elif sort_by == "critical":
        grouped_list.sort(key=lambda g: (not g["is_kritik"], get_group_earliest_miad(g), g["grup_adi"].lower()))
    else:
        # Default: "name" (A-Z)
        grouped_list.sort(key=lambda g: g["grup_adi"].lower())

    depolar = db.query(models.Depo).options(joinedload(models.Depo.lokasyonlar)).all()
    depo_lokasyonlar_map = {
        d.id: [
            l.code for l in sorted(
                [loc for loc in d.lokasyonlar if loc.is_active],
                key=lambda x: (x.pick_sequence or 0, x.code or "")
            )
        ]
        for d in depolar
    }

    # Pagination calculation
    clean_page = max(1, page)
    if per_page in ["all", "0"]:
        clean_per_page = 0
    else:
        try:
            clean_per_page = int(per_page)
            if clean_per_page not in [25, 50, 100, 200]:
                clean_per_page = 50
        except (ValueError, TypeError):
            clean_per_page = 50

    total_items = len(grouped_list)
    if clean_per_page > 0:
        total_pages = max(1, (total_items + clean_per_page - 1) // clean_per_page)
        if clean_page > total_pages:
            clean_page = total_pages
        start_idx = (clean_page - 1) * clean_per_page
        end_idx = start_idx + clean_per_page
        paginated_list = grouped_list[start_idx:end_idx]
    else:
        total_pages = 1
        clean_page = 1
        paginated_list = grouped_list

    pagination_info = {
        "page": clean_page,
        "per_page": clean_per_page,
        "total_items": total_items,
        "total_pages": total_pages,
        "has_prev": clean_page > 1,
        "has_next": clean_page < total_pages,
        "prev_page": clean_page - 1,
        "next_page": clean_page + 1,
        "start_item": ((clean_page - 1) * clean_per_page + 1) if total_items > 0 and clean_per_page > 0 else (1 if total_items > 0 else 0),
        "end_item": min(clean_page * clean_per_page, total_items) if clean_per_page > 0 else total_items
    }
    
    return templates.TemplateResponse(
        request=request,
        name="stock.html",
        context={
            "request": request, 
            "grouped_list": paginated_list,
            "depolar": depolar,
            "depo_lokasyonlar_map": depo_lokasyonlar_map,
            "secili_depo": clean_depo_id,
            "q": q or "",
            "view_mode": view_mode if view_mode in ["generic", "drug"] else "generic",
            "sort_by": sort_by if sort_by in ["name", "miad", "quantity_desc", "critical"] else "name",
            "pagination": pagination_info,
            "per_page": str(per_page),
            "msg": msg,
            "error": error,
            "user": getattr(request.state, "user", None)
        }
    )

@router.post("/update")
async def update_stock_item(
    request: Request,
    stok_id: Annotated[int, Form(...)],
    depo_id: Annotated[int, Form(...)],
    db: DbSession,
    raf_konumu: Annotated[Optional[str], Form()] = None,
    miad: Annotated[Optional[str], Form()] = None,
    koli_ici_adet: Annotated[int, Form()] = 1,
    miktar: Annotated[int, Form()] = 0,
):
    is_ajax = is_ajax_request(request)


    stok = db.query(models.Stok).options(
        joinedload(models.Stok.parti).joinedload(models.Parti.ilac).joinedload(models.Ilac.ozellikler)
    ).filter(models.Stok.id == stok_id).first()
    
    if not stok:
        if is_ajax:
            return JSONResponse({"status": "error", "message": "Stok kaydı bulunamadı."}, status_code=400)
        return RedirectResponse(url="/stock?error=stok_bulunamadi", status_code=status.HTTP_302_FOUND)

    target_depo = db.query(models.Depo).options(joinedload(models.Depo.ozellikler)).filter(models.Depo.id == depo_id).first()
    if target_depo and target_depo.is_toplam_depo:
        if is_ajax:
            return JSONResponse({"status": "error", "message": "Toplam depoya stok kaydı veya düzenlemesi yapılamaz."}, status_code=400)
        return RedirectResponse(url="/stock?error=toplam_depo_yazma_engel", status_code=status.HTTP_302_FOUND)
    ilac = stok.parti.ilac if stok.parti else None
    if target_depo and ilac:
        is_compat, err_msg = check_depo_drug_compatibility(target_depo, ilac)
        if not is_compat:
            if is_ajax:
                return JSONResponse({"status": "error", "message": err_msg}, status_code=400)
            return RedirectResponse(url=f"/stock?error={err_msg}", status_code=status.HTTP_302_FOUND)

    eski_miktar = stok.miktar
    eski_depo_id = stok.depo_id
    eski_raf = stok.raf_konumu or "-"
    
    stok.depo_id = depo_id
    stok.raf_konumu = raf_konumu.strip() if raf_konumu else None
    stok.miktar = max(0, miktar)
    stok.koli_ici_adet = max(1, koli_ici_adet)

    dt_miad = None
    if stok.parti:
        stok.parti.koli_ici_adet = max(1, koli_ici_adet)
        if miad and miad.strip():
            try:
                dt_miad = datetime.datetime.strptime(miad.strip(), "%Y-%m-%d").date()
                stok.parti.miad = dt_miad
            except Exception:
                pass

    yeni_depo = target_depo or db.query(models.Depo).filter(models.Depo.id == depo_id).first()
    depo_ad = yeni_depo.ad if yeni_depo else f"Depo #{depo_id}"
    raf_str = stok.raf_konumu or "-"
    miad_str = dt_miad.strftime("%d.%m.%Y") if dt_miad else (stok.parti.miad.strftime("%d.%m.%Y") if (stok.parti and stok.parti.miad) else "-")

    diff_qty = miktar - eski_miktar
    user_id = getattr(request.state.user, "id", None) if hasattr(request.state, "user") and request.state.user else None

    # Record stock movement for audit/history (Düzeltme)
    hareket = models.StokHareketi(
        tarih=datetime.datetime.now(),
        hareket_tipi="Düzeltme",
        depo_id=depo_id,
        parti_id=stok.parti_id,
        miktar=diff_qty,
        aciklama=f"Stok Özellikleri Düzeltildi [Eski Miktar: {eski_miktar} -> Yeni Miktar: {miktar}, Depo: {depo_ad}, Raf: {raf_str}, SKT: {miad_str}, Koli İçi: {stok.koli_ici_adet}]",
        kullanici_id=user_id
    )
    db.add(hareket)
    db.flush()

    from ..services.qr_basket_service import QRBasketService
    if eski_depo_id != depo_id:
        db.query(models.DepoKarekod).filter(
            models.DepoKarekod.depo_id == eski_depo_id,
            models.DepoKarekod.parti_id == stok.parti_id,
            models.DepoKarekod.durum == "depoda"
        ).update({models.DepoKarekod.depo_id: depo_id}, synchronize_session=False)
    if diff_qty < 0:
        QRBasketService.deduct_depo_doses_fefo(
            db, depo_id=depo_id, parti_id=stok.parti_id,
            deduct_doses=abs(diff_qty), cikis_hareket_id=hareket.id
        )

    db.commit()

    if is_ajax:
        return JSONResponse({
            "status": "success",
            "message": "Stok özellikleri başarıyla güncellendi.",
            "stok": {
                "id": stok.id,
                "depo_id": stok.depo_id,
                "depo_ad": depo_ad,
                "raf_konumu": raf_str,
                "miad_str": miad_str,
                "miad_iso": dt_miad.strftime("%Y-%m-%d") if dt_miad else (stok.parti.miad.strftime("%Y-%m-%d") if (stok.parti and stok.parti.miad) else ""),
                "koli_ici_adet": stok.koli_ici_adet,
                "miktar": stok.miktar,
                "koli_parca": round(stok.miktar / max(1, stok.koli_ici_adet), 2)
            }
        })

    return RedirectResponse(url="/stock?msg=stok_guncellendi", status_code=status.HTTP_302_FOUND)

@router.post("/transfer")
async def transfer_single_stock(
    request: Request,
    stok_id: Annotated[int, Form(...)],
    hedef_depo_id: Annotated[int, Form(...)],
    transfer_miktari: Annotated[int, Form(...)],
    db: DbSession,
    hedef_raf_konumu: Annotated[Optional[str], Form()] = None,
):
    is_ajax = is_ajax_request(request)

    stok = db.query(models.Stok).options(
        joinedload(models.Stok.parti).joinedload(models.Parti.ilac).joinedload(models.Ilac.ozellikler),
        joinedload(models.Stok.depo)
    ).filter(models.Stok.id == stok_id).first()
    
    if not stok:
        if is_ajax:
            return JSONResponse({"status": "error", "message": "Stok kaydı bulunamadı."}, status_code=400)
        return RedirectResponse(url="/stock?error=stok_bulunamadi", status_code=status.HTTP_302_FOUND)

    if transfer_miktari <= 0:
        if is_ajax:
            return JSONResponse({"status": "error", "message": "Geçersiz transfer miktarı girdiniz."}, status_code=400)
        return RedirectResponse(url="/stock?error=gecersiz_miktar", status_code=status.HTTP_302_FOUND)

    if transfer_miktari > stok.miktar:
        if is_ajax:
            return JSONResponse({"status": "error", "message": "Transfer miktarı mevcut stoktan fazla olamaz."}, status_code=400)
        return RedirectResponse(url="/stock?error=yetersiz_stok", status_code=status.HTTP_302_FOUND)

    if hedef_depo_id == stok.depo_id:
        if is_ajax:
            return JSONResponse({"status": "error", "message": "Transfer için farklı bir hedef depo seçiniz."}, status_code=400)
        return RedirectResponse(url="/stock?error=ayni_depo", status_code=status.HTTP_302_FOUND)

    hedef_depo = db.query(models.Depo).options(joinedload(models.Depo.ozellikler)).filter(models.Depo.id == hedef_depo_id).first()
    if not hedef_depo:
        if is_ajax:
            return JSONResponse({"status": "error", "message": "Depo bulunamadı."}, status_code=400)
        return RedirectResponse(url="/stock?error=depo_bulunamadi", status_code=status.HTTP_302_FOUND)

    if hedef_depo.is_toplam_depo:
        if is_ajax:
            return JSONResponse({"status": "error", "message": "Toplam depoya transfer yapılamaz."}, status_code=400)
        return RedirectResponse(url="/stock?error=toplam_depo_transfer_engel", status_code=status.HTTP_302_FOUND)

    ilac = stok.parti.ilac if stok.parti else None
    if hedef_depo and ilac:
        is_compat, err_msg = check_depo_drug_compatibility(hedef_depo, ilac)
        if not is_compat:
            if is_ajax:
                return JSONResponse({"status": "error", "message": err_msg}, status_code=400)
            return RedirectResponse(url=f"/stock?error={err_msg}", status_code=status.HTTP_302_FOUND)

    kaynak_depo_id = stok.depo_id
    kaynak_depo_ad = stok.depo.ad if stok.depo else f"Depo #{kaynak_depo_id}"

    # Deduct from source stock
    stok.miktar -= transfer_miktari

    # Target stock entry
    clean_raf = hedef_raf_konumu.strip() if (hedef_raf_konumu and hedef_raf_konumu.strip()) else stok.raf_konumu
    target_stok = db.query(models.Stok).filter(
        models.Stok.depo_id == hedef_depo_id,
        models.Stok.parti_id == stok.parti_id
    ).first()

    if target_stok:
        target_stok.miktar += transfer_miktari
        if clean_raf:
            target_stok.raf_konumu = clean_raf
    else:
        target_stok = models.Stok(
            depo_id=hedef_depo_id,
            parti_id=stok.parti_id,
            miktar=transfer_miktari,
            raf_konumu=clean_raf,
            koli_ici_adet=stok.koli_ici_adet
        )
        db.add(target_stok)

    user_id = getattr(request.state.user, "id", None) if hasattr(request.state, "user") and request.state.user else None

    # Record stock transfer movement
    raf_log = f" (Hedef Raf: {clean_raf})" if clean_raf else ""
    hareket = models.StokHareketi(
        tarih=datetime.datetime.now(),
        hareket_tipi="Transfer",
        depo_id=kaynak_depo_id,
        hedef_depo_id=hedef_depo_id,
        parti_id=stok.parti_id,
        miktar=transfer_miktari,
        aciklama=f"Depo Transferi: {kaynak_depo_ad} -> {hedef_depo.ad}{raf_log}",
        kullanici_id=user_id
    )
    db.add(hareket)
    db.flush()

    from ..services.qr_basket_service import QRBasketService
    QRBasketService.transfer_depo_qrcodes(
        db, kaynak_depo_id=kaynak_depo_id, hedef_depo_id=hedef_depo_id,
        parti_id=stok.parti_id, transfer_doses=transfer_miktari
    )

    db.commit()

    if is_ajax:
        return JSONResponse({
            "status": "success",
            "message": "Stok transfer işlemi başarıyla tamamlandı.",
            "transfer": {
                "stok_id": stok.id,
                "kaynak_depo_id": kaynak_depo_id,
                "kaynak_depo_ad": kaynak_depo_ad,
                "kaynak_kalan_miktar": stok.miktar,
                "hedef_depo_id": hedef_depo_id,
                "hedef_depo_ad": hedef_depo.ad,
                "transfer_miktari": transfer_miktari,
                "target_stok_id": target_stok.id,
                "target_stok_miktar": target_stok.miktar,
                "target_raf_konumu": clean_raf or "-"
            }
        })

    return RedirectResponse(url="/stock?msg=stok_transfer_basarili", status_code=status.HTTP_302_FOUND)


@router.get("/export/excel")
async def export_stock_excel(
    db: DbSession,
    depo_id: Annotated[Optional[str], Query()] = None,
    q: Annotated[Optional[str], Query()] = None,
    view_mode: Annotated[str, Query()] = "generic",
    sort_by: Annotated[str, Query()] = "name",
):
    clean_depo_id = int(depo_id) if (depo_id and str(depo_id).isdigit()) else None

    query = db.query(models.Stok).options(
        joinedload(models.Stok.parti).joinedload(models.Parti.ilac),
        joinedload(models.Stok.depo)
    ).filter(models.Stok.miktar > 0)
    
    if clean_depo_id:
        query = query.filter(models.Stok.depo_id == clean_depo_id)
        
    stoklar = query.all()
    bugun = datetime.date.today()
    
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Müstahzar Stok Listesi" if view_mode == "drug" else "Jenerik Stok Listesi"
    ws.views.sheetView[0].showGridLines = True
    
    # Header styles
    header_fill = PatternFill(start_color="1F4E78", end_color="1F4E78", fill_type="solid")
    header_font = Font(name="Segoe UI", size=11, bold=True, color="FFFFFF")
    data_font = Font(name="Segoe UI", size=10)
    bold_font = Font(name="Segoe UI", size=10, bold=True)
    align_center = Alignment(horizontal="center", vertical="center")
    align_left = Alignment(horizontal="left", vertical="center")
    align_right = Alignment(horizontal="right", vertical="center")
    thin_border = Border(
        left=Side(style="thin", color="D9D9D9"),
        right=Side(style="thin", color="D9D9D9"),
        top=Side(style="thin", color="D9D9D9"),
        bottom=Side(style="thin", color="D9D9D9")
    )

    if view_mode == "drug":
        headers = [
            "#", "İlaç Markası / Müstahzar", "Barkod", "Jenerik Grubu / Etken Madde",
            "Jenerik Kodu", "Depo Adı", "Raf Konumu", "Parti (Lot) No", "Son Kullanma (SKT)",
            "Miktar (Adet)", "Koli İçi Adet", "Koli Karşılığı", "Durum"
        ]
    else:
        headers = [
            "#", "Jenerik Grubu / Etken Madde", "Jenerik Kodu", "İlaç Markası / Kartı",
            "Barkod", "Depo Adı", "Raf Konumu", "Parti (Lot) No", "Son Kullanma (SKT)",
            "Miktar (Adet)", "Koli İçi Adet", "Koli Karşılığı", "Durum"
        ]
    
    ws.append(headers)
    for col_num, h in enumerate(headers, 1):
        cell = ws.cell(row=1, column=col_num)
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = align_center
        cell.border = thin_border
    ws.row_dimensions[1].height = 28

    row_idx = 1
    for stok in stoklar:
        if not stok.parti or not stok.parti.ilac:
            continue
        ilac = stok.parti.ilac
        depo = stok.depo
        parti = stok.parti
        
        if q and q.strip():
            q_clean = q.strip().lower()
            match_search = (
                q_clean in (ilac.ad or "").lower() or
                q_clean in (ilac.barkod or "").lower() or
                q_clean in (ilac.etken_madde or "").lower() or
                q_clean in (ilac.jenerik_adi or "").lower() or
                q_clean in (ilac.jenerik_kodu or "").lower() or
                q_clean in (ilac.jenerik_grubu or "").lower()
            )
            if not match_search:
                continue

        grup_kodu = ilac.jenerik_grubu.strip() if (ilac.jenerik_grubu and ilac.jenerik_grubu.strip()) else (ilac.jenerik_adi.strip() if (ilac.jenerik_adi and ilac.jenerik_adi.strip()) else (ilac.jenerik_kodu.strip() if (ilac.jenerik_kodu and ilac.jenerik_kodu.strip()) else (ilac.etken_madde.strip() if (ilac.etken_madde and ilac.etken_madde.strip()) else ilac.ad.strip())))
        jenerik_kodu = ilac.jenerik_kodu or "-"
        koli_ici = stok.koli_ici_adet or (parti and parti.koli_ici_adet) or ilac.koli_ici_adet or 1
        koli_parca = round(stok.miktar / koli_ici, 2)
        
        durum = "Normal"
        if parti.miad:
            kalan_gun = (parti.miad - bugun).days
            if kalan_gun < 0:
                durum = "Miadı Geçmiş"
            elif kalan_gun <= 30:
                durum = "Çok Acil (Son 30 Gün)"
            elif kalan_gun <= 90:
                durum = "Yaklaşıyor (Son 90 Gün)"
                
        miad_str = parti.miad.strftime("%Y-%m-%d") if parti.miad else "-"
        raf_str = stok.raf_konumu or ilac.raf_konumu or "-"
        
        if view_mode == "drug":
            row_values = [
                row_idx,
                ilac.ad,
                ilac.barkod,
                grup_kodu,
                jenerik_kodu,
                depo.ad if depo else "-",
                raf_str,
                parti.parti_no or "-",
                miad_str,
                stok.miktar,
                koli_ici,
                koli_parca,
                durum
            ]
        else:
            row_values = [
                row_idx,
                grup_kodu,
                jenerik_kodu,
                ilac.ad,
                ilac.barkod,
                depo.ad if depo else "-",
                raf_str,
                parti.parti_no or "-",
                miad_str,
                stok.miktar,
                koli_ici,
                koli_parca,
                durum
            ]
        ws.append(row_values)
        current_row = row_idx + 1
        ws.row_dimensions[current_row].height = 20
        
        for col_num in range(1, len(row_values) + 1):
            c = ws.cell(row=current_row, column=col_num)
            c.font = data_font
            c.border = thin_border
            if col_num in [1, 3, 5, 7, 8, 9, 13]:
                c.alignment = align_center
            elif col_num in [10, 11, 12]:
                c.alignment = align_right
            else:
                c.alignment = align_left
                
            if col_num == 10:
                c.font = bold_font

        row_idx += 1

    # Auto-adjust column widths
    for col in ws.columns:
        max_len = max(len(str(cell.value or '')) for cell in col)
        col_letter = get_column_letter(col[0].column)
        ws.column_dimensions[col_letter].width = max(max_len + 3, 12)

    output = io.BytesIO()
    wb.save(output)
    output.seek(0)
    
    filename = f"stok_listesi_{datetime.date.today().strftime('%Y-%m-%d')}.xlsx"
    return Response(
        content=output.getvalue(),
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": f"attachment; filename={filename}"}
    )


@router.get("/backup/download")
async def download_stock_backup(db: DbSession):
    depolar = [
        {"id": d.id, "kod": d.kod, "ad": d.ad, "aciklama": d.aciklama}
        for d in db.query(models.Depo).all()
    ]
    ilaclar = [
        {
            "id": i.id, "barkod": i.barkod, "ad": i.ad, "etken_madde": i.etken_madde,
            "jenerik_kodu": i.jenerik_kodu, "jenerik_adi": i.jenerik_adi, "jenerik_grubu": i.jenerik_grubu,
            "atc_kodu": i.atc_kodu, "nfc_kodu": i.nfc_kodu, "recete_turu": i.recete_turu,
            "ambalaj": i.ambalaj, "birim": i.birim, "koli_ici_adet": i.koli_ici_adet,
            "raf_konumu": i.raf_konumu, "uretici": i.uretici, "kritik_stok": i.kritik_stok
        }
        for i in db.query(models.Ilac).all()
    ]
    partiler = [
        {
            "id": p.id, "ilac_id": p.ilac_id, "parti_no": p.parti_no,
            "miad": p.miad.strftime("%Y-%m-%d") if p.miad else None,
            "koli_ici_adet": p.koli_ici_adet
        }
        for p in db.query(models.Parti).all()
    ]
    stoklar = [
        {
            "id": s.id, "depo_id": s.depo_id, "parti_id": s.parti_id,
            "miktar": s.miktar, "raf_konumu": s.raf_konumu, "koli_ici_adet": s.koli_ici_adet
        }
        for s in db.query(models.Stok).all()
    ]
    jenerik_limits = [
        {"id": j.id, "grup_kodu": j.grup_kodu, "grup_adi": j.grup_adi, "kritik_stok": j.kritik_stok}
        for j in db.query(models.JenerikKritikStok).all()
    ]
    stok_hareketleri = [
        {
            "id": h.id, "tarih": h.tarih.strftime("%Y-%m-%d %H:%M:%S") if h.tarih else None,
            "hareket_tipi": h.hareket_tipi, "depo_id": h.depo_id, "hedef_depo_id": h.hedef_depo_id,
            "parti_id": h.parti_id, "miktar": h.miktar, "aciklama": h.aciklama,
            "kullanici_id": h.kullanici_id, "toplu_islem_kodu": h.toplu_islem_kodu
        }
        for h in db.query(models.StokHareketi).all()
    ]

    backup_data = {
        "version": "1.0",
        "created_at": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "depolar": depolar,
        "ilaclar": ilaclar,
        "partiler": partiler,
        "stoklar": stoklar,
        "jenerik_limits": jenerik_limits,
        "stok_hareketleri": stok_hareketleri
    }
    
    json_bytes = json.dumps(backup_data, ensure_ascii=False, indent=2).encode('utf-8')
    filename = f"stok_yedek_{datetime.datetime.now().strftime('%Y-%m-%d_%H%M')}.json"
    
    return Response(
        content=json_bytes,
        media_type="application/json",
        headers={"Content-Disposition": f"attachment; filename={filename}"}
    )


@router.post("/backup/restore")
async def restore_stock_backup(
    file: Annotated[UploadFile, File(...)],
    db: DbSession,
    restore_mode: Annotated[str, Form()] = "merge",
):
    if not file.filename.lower().endswith(".json"):
        return RedirectResponse(url="/stock?error=gecersiz_yedek_dosyasi", status_code=status.HTTP_302_FOUND)
        
    try:
        content = await file.read()
        backup_data = json.loads(content.decode('utf-8'))
    except Exception as e:
        return RedirectResponse(url="/stock?error=yedek_dosyasi_okunamadi", status_code=status.HTTP_302_FOUND)

    if "stoklar" not in backup_data or "ilaclar" not in backup_data:
        return RedirectResponse(url="/stock?error=gecersiz_yedek_formati", status_code=status.HTTP_302_FOUND)

    try:
        if restore_mode == "full":
            # Clear tables in reverse dependency order
            db.query(models.StokHareketi).delete(synchronize_session=False)
            db.query(models.Stok).delete(synchronize_session=False)
            db.query(models.Parti).delete(synchronize_session=False)
            db.query(models.JenerikKritikStok).delete(synchronize_session=False)
            db.query(models.Ilac).delete(synchronize_session=False)
            db.query(models.Depo).delete(synchronize_session=False)
            db.flush()

        # Restore Depolar
        depo_id_map = {}
        for d in backup_data.get("depolar", []):
            exist_depo = db.query(models.Depo).filter(models.Depo.kod == d.get("kod")).first()
            if exist_depo:
                exist_depo.ad = d.get("ad", exist_depo.ad)
                exist_depo.aciklama = d.get("aciklama", exist_depo.aciklama)
                depo_id_map[d.get("id")] = exist_depo.id
            else:
                new_depo = models.Depo(kod=d.get("kod"), ad=d.get("ad"), aciklama=d.get("aciklama"))
                db.add(new_depo)
                db.flush()
                depo_id_map[d.get("id")] = new_depo.id

        # Restore İlaçlar
        ilac_id_map = {}
        for i in backup_data.get("ilaclar", []):
            exist_ilac = db.query(models.Ilac).filter(models.Ilac.barkod == i.get("barkod")).first()
            if exist_ilac:
                exist_ilac.ad = i.get("ad", exist_ilac.ad)
                exist_ilac.etken_madde = i.get("etken_madde", exist_ilac.etken_madde)
                exist_ilac.jenerik_kodu = i.get("jenerik_kodu", exist_ilac.jenerik_kodu)
                exist_ilac.jenerik_adi = i.get("jenerik_adi", exist_ilac.jenerik_adi)
                exist_ilac.jenerik_grubu = i.get("jenerik_grubu", exist_ilac.jenerik_grubu)
                exist_ilac.atc_kodu = i.get("atc_kodu", exist_ilac.atc_kodu)
                exist_ilac.nfc_kodu = i.get("nfc_kodu", exist_ilac.nfc_kodu)
                exist_ilac.recete_turu = i.get("recete_turu", exist_ilac.recete_turu)
                exist_ilac.ambalaj = i.get("ambalaj", exist_ilac.ambalaj)
                exist_ilac.birim = i.get("birim", exist_ilac.birim)
                exist_ilac.koli_ici_adet = i.get("koli_ici_adet", exist_ilac.koli_ici_adet or 1)
                exist_ilac.raf_konumu = i.get("raf_konumu", exist_ilac.raf_konumu)
                exist_ilac.uretici = i.get("uretici", exist_ilac.uretici)
                exist_ilac.kritik_stok = i.get("kritik_stok", exist_ilac.kritik_stok or 10)
                ilac_id_map[i.get("id")] = exist_ilac.id
            else:
                new_ilac = models.Ilac(
                    barkod=i.get("barkod"), ad=i.get("ad"), etken_madde=i.get("etken_madde"),
                    jenerik_kodu=i.get("jenerik_kodu"), jenerik_adi=i.get("jenerik_adi"), jenerik_grubu=i.get("jenerik_grubu"),
                    atc_kodu=i.get("atc_kodu"), nfc_kodu=i.get("nfc_kodu"), recete_turu=i.get("recete_turu"),
                    ambalaj=i.get("ambalaj"), birim=i.get("birim", "Adet"), koli_ici_adet=i.get("koli_ici_adet", 1),
                    raf_konumu=i.get("raf_konumu"), uretici=i.get("uretici", "Tanımsız"), kritik_stok=i.get("kritik_stok", 10)
                )
                db.add(new_ilac)
                db.flush()
                ilac_id_map[i.get("id")] = new_ilac.id

        # Restore Partiler
        parti_id_map = {}
        for p in backup_data.get("partiler", []):
            target_ilac_id = ilac_id_map.get(p.get("ilac_id"))
            if not target_ilac_id:
                continue
            miad_dt = datetime.datetime.strptime(p.get("miad"), "%Y-%m-%d").date() if p.get("miad") else None
            exist_parti = db.query(models.Parti).filter(
                models.Parti.ilac_id == target_ilac_id,
                models.Parti.parti_no == p.get("parti_no"),
                models.Parti.miad == miad_dt
            ).first()
            if exist_parti:
                parti_id_map[p.get("id")] = exist_parti.id
            else:
                new_parti = models.Parti(
                    ilac_id=target_ilac_id,
                    parti_no=p.get("parti_no"),
                    miad=miad_dt,
                    koli_ici_adet=p.get("koli_ici_adet", 1)
                )
                db.add(new_parti)
                db.flush()
                parti_id_map[p.get("id")] = new_parti.id

        # Restore Stoklar
        for s in backup_data.get("stoklar", []):
            target_depo_id = depo_id_map.get(s.get("depo_id"))
            target_parti_id = parti_id_map.get(s.get("parti_id"))
            if not target_depo_id or not target_parti_id:
                continue
            exist_stok = db.query(models.Stok).filter(
                models.Stok.depo_id == target_depo_id,
                models.Stok.parti_id == target_parti_id
            ).first()
            if exist_stok:
                if restore_mode == "full":
                    exist_stok.miktar = s.get("miktar", 0)
                else:
                    exist_stok.miktar = max(exist_stok.miktar, s.get("miktar", 0))
                exist_stok.raf_konumu = s.get("raf_konumu", exist_stok.raf_konumu)
                exist_stok.koli_ici_adet = s.get("koli_ici_adet", exist_stok.koli_ici_adet)
            else:
                new_stok = models.Stok(
                    depo_id=target_depo_id,
                    parti_id=target_parti_id,
                    miktar=s.get("miktar", 0),
                    raf_konumu=s.get("raf_konumu"),
                    koli_ici_adet=s.get("koli_ici_adet")
                )
                db.add(new_stok)

        # Restore JenerikKritikStoklar
        for j in backup_data.get("jenerik_limits", []):
            exist_j = db.query(models.JenerikKritikStok).filter(models.JenerikKritikStok.grup_kodu == j.get("grup_kodu")).first()
            if exist_j:
                exist_j.kritik_stok = j.get("kritik_stok", exist_j.kritik_stok)
            else:
                new_j = models.JenerikKritikStok(
                    grup_kodu=j.get("grup_kodu"),
                    grup_adi=j.get("grup_adi"),
                    kritik_stok=j.get("kritik_stok", 10)
                )
                db.add(new_j)

        db.commit()
        return RedirectResponse(url="/stock?msg=stok_yedek_basariyla_yuklendi", status_code=status.HTTP_302_FOUND)
    except Exception as e:
        db.rollback()
        return RedirectResponse(url="/stock?error=yedek_yukleme_hatasi", status_code=status.HTTP_302_FOUND)

