from sqlalchemy.orm import Session
from . import models

def get_kullanici_by_username(db: Session, username: str):
    return db.query(models.Kullanici).filter(models.Kullanici.kullanici_adi == username).first()

def get_ilaclar(db: Session):
    return db.query(models.Ilac).all()

def get_ilac(db: Session, ilac_id: int):
    return db.query(models.Ilac).filter(models.Ilac.id == ilac_id).first()

def get_depolar(db: Session):
    return db.query(models.Depo).all()

def get_stoklar(db: Session):
    return db.query(models.Stok).all()

def get_partiler(db: Session):
    return db.query(models.Parti).all()

def get_stok_hareketleri(db: Session, limit: int = 50):
    return db.query(models.StokHareketi).order_by(models.StokHareketi.tarih.desc()).limit(limit).all()

def get_depo_by_kod(db: Session, kod: str):
    return db.query(models.Depo).filter(models.Depo.kod == kod).first()

def check_depo_drug_compatibility(depo: models.Depo, ilac: models.Ilac) -> tuple[bool, str]:
    if not depo or not ilac:
        return True, ""
    
    # If warehouse has no specific required features, any drug is allowed (Genel Depo)
    if not depo.ozellikler:
        return True, ""
        
    depo_feat_ids = {oz.id for oz in depo.ozellikler}
    ilac_feat_ids = {oz.id for oz in ilac.ozellikler} if ilac.ozellikler else set()
    
    # Intersection check: drug must have at least one of the accepted warehouse features
    if not (depo_feat_ids & ilac_feat_ids):
        depo_req_names = ", ".join([oz.ad for oz in depo.ozellikler])
        return False, f"UYARI: '{ilac.ad}' ilacında '{depo.ad}' deposunun kabul ettiği özellikte ({depo_req_names}) bilgi kartı bulunmadığı için bu depoya aktarılamaz!"
        
    return True, ""
