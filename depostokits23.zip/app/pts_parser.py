"""
PTS (Paket Transfer Sistemi) XML Ayrıştırıcısı
PTS XML transfer paketlerini okur, her bir (GTIN/Barkod, Parti/Lot No, SKT) kombinasyonundaki serialNumber sayılarını hesaba katarak miktar özetini çıkarır.
"""
import xml.etree.ElementTree as ET
import calendar
from datetime import datetime
import re

def clean_gtin(raw_gtin) -> str:
    if raw_gtin is None or raw_gtin == "":
        return ""
    s = str(raw_gtin).strip().replace("'", "").replace('"', '')
    if s.endswith(".0"):
        s = s[:-2]
    if "e+" in s.lower() or "e-" in s.lower():
        try:
            s = f"{float(s):.0f}"
        except Exception:
            pass
    digits = re.sub(r"\D", "", s)
    if len(digits) == 14 and digits.startswith("0"):
        return digits[1:]
    return digits

def _build_valid_iso_date(yyyy: int, mm: int, dd: int) -> str:
    if not (1900 <= yyyy <= 2100 and 1 <= mm <= 12):
        return ""
    max_day = calendar.monthrange(yyyy, mm)[1]
    if dd <= 0 or dd > max_day:
        dd = max_day
    return f"{yyyy:04d}-{mm:02d}-{dd:02d}"

def parse_skt(raw_skt: str) -> str:
    if not raw_skt:
        return ""
    skt_str = str(raw_skt).strip().strip('"').strip("'")
    if not skt_str:
        return ""

    # Timestamp (Örn: 2026-12-31 00:00:00 veya 2026-12-31T00:00:00) varsa tarih kısmını al
    if " " in skt_str:
        skt_str = skt_str.split(" ")[0].strip()
    if "T" in skt_str and len(skt_str) > 10:
        skt_str = skt_str.split("T")[0].strip()

    skt_str = skt_str.replace(".", "-").replace("/", "-")

    # YYYY-M-D veya YYYY-MM-DD formatı
    m_ymd = re.match(r"^(\d{4})-(\d{1,2})-(\d{1,2})$", skt_str)
    if m_ymd:
        iso = _build_valid_iso_date(int(m_ymd.group(1)), int(m_ymd.group(2)), int(m_ymd.group(3)))
        if iso:
            return iso

    # DD-MM-YYYY formatı (Örn: 31-12-2026)
    m_dmy = re.match(r"^(\d{1,2})-(\d{1,2})-(\d{4})$", skt_str)
    if m_dmy:
        iso = _build_valid_iso_date(int(m_dmy.group(3)), int(m_dmy.group(2)), int(m_dmy.group(1)))
        if iso:
            return iso

    # YYYY-MM formatı (Örn: 2026-12 -> ayın son günü)
    m_ym = re.match(r"^(\d{4})-(\d{1,2})$", skt_str)
    if m_ym:
        iso = _build_valid_iso_date(int(m_ym.group(1)), int(m_ym.group(2)), 0)
        if iso:
            return iso

    # YYMMDD (Örn: 261231 -> 2026-12-31 veya GS1 261200 -> 2026-12-31)
    if re.match(r"^\d{6}$", skt_str):
        yy = int(skt_str[:2])
        mm = int(skt_str[2:4])
        dd = int(skt_str[4:6])
        yyyy = 2000 + yy if yy < 70 else 1900 + yy
        iso = _build_valid_iso_date(yyyy, mm, dd)
        if iso:
            return iso

    # YYYYMMDD veya DDMMYYYY (8 haneli)
    if re.match(r"^\d{8}$", skt_str):
        p1 = int(skt_str[:4])
        m1 = int(skt_str[4:6])
        d1 = int(skt_str[6:8])
        if 1900 <= p1 <= 2100 and 1 <= m1 <= 12:
            iso = _build_valid_iso_date(p1, m1, d1)
            if iso:
                return iso
        d2 = int(skt_str[:2])
        m2 = int(skt_str[2:4])
        y2 = int(skt_str[4:8])
        if 1900 <= y2 <= 2100 and 1 <= m2 <= 12:
            iso = _build_valid_iso_date(y2, m2, d2)
            if iso:
                return iso

    return skt_str

def parse_package_dose_count(ambalaj: str, ad: str = "") -> int:
    """
    İlaç ambalaj metninden (veya adından) kutu içi doz/adet sayısını otomatik çıkarır.
    Örn:
      '10x1 ml ampul' -> 10
      '4x0,5 ml enjektör' -> 4
      '30 ml x 1 flakon' -> 1
      '20 tablet' -> 20
      '30x24 g poşet' -> 30
      '150 ml şişe' -> 1
      '500 ml torba - setli' -> 1
    """
    for source in (ambalaj, ad):
        if not source:
            continue
        text = str(source).strip().lower()
        if not text:
            continue

        # 1. '30 ml x 1 flakon' gibi önce hacim/ağırlık sonra adet gelen format
        m_vol_first = re.search(
            r"\d+(?:[.,]\d+)?\s*(?:ml|mg|g|gr|mcg|iu|ü|lt|l)\s*[xX*]\s*(\d+)\s*(?:flakon|ampul|şişe|sise|torba|enjektör|enjektor|poşet|poset|saşe|sase|tüp|tup)",
            text
        )
        if m_vol_first:
            val = int(m_vol_first.group(1))
            if 1 <= val <= 1000:
                return val

        # 2. '10x1 ml ampul', '4x0,5 ml enjektör', '30x24 g poşet', '1x100 ml flakon' formatı
        m_cnt_first = re.search(
            r"(\d+)\s*[xX*]\s*\d+(?:[.,]\d+)?\s*(?:ml|mg|g|gr|mcg|iu|ü|lt|l)\b",
            text
        )
        if m_cnt_first:
            val = int(m_cnt_first.group(1))
            if 1 <= val <= 1000:
                return val

        # 3. '1 flakon+1 ampul' (toz flakon + çözücü ampul)
        m_flk_amp = re.search(r"(\d+)\s*flakon\s*\+\s*\d+\s*ampul", text)
        if m_flk_amp:
            val = int(m_flk_amp.group(1))
            if 1 <= val <= 1000:
                return val

        # 4. '2x10 tablet' gibi çarpanlı birim formatı
        m_mult_unit = re.search(
            r"(\d+)\s*[xX*]\s*(\d+)\s*(?:tablet|kapsül|kapsul|draje|ampul|flakon|poşet|poset|saşe|sase|enjektör|enjektor|ovül|ovul|supozituvar|pastil)\b",
            text
        )
        if m_mult_unit:
            val = int(m_mult_unit.group(1)) * int(m_mult_unit.group(2))
            if 1 <= val <= 2000:
                return val

        # 5. '20 tablet', '10 ampul', '30 kapsül', '20 saşe', '1 flakon' formatı
        m_unit = re.search(
            r"(?<![.,\d]\s)(?<!ml\s)(?<!mg\s)(?<!gr\s)(?<!g\s)\b(\d+)\s*(?:film\s+|kaplı\s+|kapli\s+|efervesan\s+|çiğneme\s+|cigneme\s+|yumuşak\s+|yumusak\s+|enterik\s+|uzatılmış\s+|kontrollü\s+|salım\s+|tableti\s+)*(?:tablet|tableti|kapsül|kapsul|draje|ampul|flakon|poşet|poset|saşe|sase|enjektör|enjektor|ovül|ovul|supozituvar|pastil)\b",
            text
        )
        if m_unit:
            val = int(m_unit.group(1))
            if 1 <= val <= 1000:
                return val

    return 1


def _decode_xml_bytes(xml_bytes: bytes) -> str:
    for enc in ["utf-8-sig", "utf-8", "iso-8859-9", "latin-1", "cp1254", "windows-1254"]:
        try:
            return xml_bytes.decode(enc)
        except Exception:
            continue
    raise ValueError("Dosya karakter kodlaması okunamadı.")

def _parse_pts_single_xml_str(content: str) -> dict:
    content = content.strip()
    try:
        root = ET.fromstring(content)
    except Exception as parse_err:
        raise ValueError(f"XML sözdizimi geçersiz: {parse_err}")

    # Kök etiket isim boşluklarını (namespaces) temizle
    for elem in root.iter():
        if '}' in elem.tag:
            elem.tag = elem.tag.split('}', 1)[1]
            
    doc_number = (
        root.findtext("documentNumber") or 
        root.findtext("transferId") or 
        root.findtext("transferNoteId") or 
        root.findtext("belgeNo") or 
        root.findtext("faturaNo") or 
        root.findtext("irsaliyeNo") or ""
    )
    doc_date = (
        root.findtext("documentDate") or 
        root.findtext("transferDate") or 
        root.findtext("tarih") or ""
    )
    sender = (
        root.findtext("sender") or 
        root.findtext("gonderici") or 
        root.findtext("gonderen") or 
        root.findtext("gondericiDepo") or ""
    )
    receiver = (
        root.findtext("receiver") or 
        root.findtext("alici") or 
        root.findtext("musteri") or ""
    )
    
    # (GTIN, Lot, SKT, KoliNo) -> miktar sayacı ve karekod (serialNumber) listesi
    aggregated_items = {}
    koli_set = set()
    all_raw_qrcodes = []

    def process_product_node(node, carrier_chain=None):
        carrier_chain = list(carrier_chain or [])
        gtin_raw = (
            node.attrib.get("GTIN") or node.attrib.get("gtin") or 
            node.attrib.get("barcode") or node.attrib.get("barkod") or 
            node.findtext("GTIN") or node.findtext("gtin") or 
            node.findtext("barcode") or node.findtext("barkod") or ""
        )
        barkod = clean_gtin(gtin_raw)
        if not barkod:
            return

        lot = (
            node.attrib.get("lotNumber") or node.attrib.get("bn") or 
            node.attrib.get("lot") or node.attrib.get("partiNo") or 
            node.findtext("lotNumber") or node.findtext("bn") or 
            node.findtext("lot") or node.findtext("partiNo") or ""
        ).strip()

        skt_raw = (
            node.attrib.get("expirationDate") or node.attrib.get("exp") or 
            node.attrib.get("skt") or node.attrib.get("miad") or 
            node.findtext("expirationDate") or node.findtext("exp") or 
            node.findtext("skt") or node.findtext("miad") or ""
        )
        skt = parse_skt(skt_raw).strip()

        node_koli = (
            node.attrib.get("carrierLabel") or node.attrib.get("koliNo") or node.attrib.get("koli_no") or 
            node.findtext("carrierLabel") or node.findtext("koliNo") or ""
        ).strip()
        node_paket = (
            node.attrib.get("paketNo") or node.attrib.get("paket_no") or 
            node.findtext("paketNo") or ""
        ).strip()

        effective_chain = list(carrier_chain)
        if node_koli and node_koli not in effective_chain:
            effective_chain.append(node_koli)
        if node_paket and node_paket not in effective_chain:
            effective_chain.append(node_paket)

        koli = effective_chain[0] if effective_chain else ""
        paket = effective_chain[-1] if len(effective_chain) > 1 else node_paket
        carrier_path = ("|" + "|".join(effective_chain) + "|") if effective_chain else ""

        if koli:
            koli_set.add(koli)

        serial_elems = (
            node.findall("serialNumber") or 
            node.findall("sn") or 
            node.findall("karekod") or
            node.findall("serial")
        )
        extracted_serials = []
        if serial_elems:
            for s_el in serial_elems:
                sn_val = (s_el.text or s_el.attrib.get("sn") or s_el.attrib.get("serial") or "").strip()
                if sn_val:
                    extracted_serials.append(sn_val)
            count = len(extracted_serials) if extracted_serials else len(serial_elems)
        else:
            qty_attr = (
                node.attrib.get("quantity") or node.attrib.get("qty") or 
                node.attrib.get("amount") or node.attrib.get("adet") or 
                node.attrib.get("miktar") or 
                node.findtext("quantity") or node.findtext("qty") or 
                node.findtext("miktar") or "1"
            )
            try:
                count = int(qty_attr)
            except ValueError:
                count = 1

        key = (barkod, lot, skt, koli)
        if key not in aggregated_items:
            aggregated_items[key] = {
                "barkod": barkod,
                "parti_no": lot,
                "skt": skt,
                "koli_no": koli,
                "paket_no": paket,
                "carrier_path": carrier_path,
                "miktar": 0,
                "kutu_sayisi": 0,
                "serials": [],
                "serial_records": []
            }
        aggregated_items[key]["miktar"] += count
        aggregated_items[key]["kutu_sayisi"] += count
        if paket and not aggregated_items[key]["paket_no"]:
            aggregated_items[key]["paket_no"] = paket
        elif paket and paket not in aggregated_items[key]["paket_no"].split(", "):
            aggregated_items[key]["paket_no"] = f"{aggregated_items[key]['paket_no']}, {paket}"

        if carrier_path and not aggregated_items[key]["carrier_path"]:
            aggregated_items[key]["carrier_path"] = carrier_path
        elif carrier_path and carrier_path not in aggregated_items[key]["carrier_path"]:
            aggregated_items[key]["carrier_path"] += carrier_path.lstrip("|")

        for sn_val in extracted_serials:
            aggregated_items[key]["serials"].append(sn_val)
            rec = {
                "gtin": barkod.zfill(14),
                "barkod": barkod,
                "serial": sn_val,
                "batch": lot,
                "expiry": skt,
                "koli_no": koli,
                "paket_no": paket,
                "carrier_path": carrier_path
            }
            aggregated_items[key]["serial_records"].append(rec)
            all_raw_qrcodes.append(rec)

    product_tags = {"productList", "ProductList", "product", "item", "detay", "line"}

    def traverse(element, carrier_chain=None):
        carrier_chain = list(carrier_chain or [])
        tag = element.tag.split('}', 1)[1] if '}' in element.tag else element.tag

        if tag.lower() == "carrier":
            label = (element.attrib.get("carrierLabel") or element.attrib.get("label") or element.attrib.get("id") or "").strip()
            if label:
                carrier_chain.append(label)

        if tag in product_tags:
            process_product_node(element, carrier_chain)
        else:
            for child in element:
                traverse(child, carrier_chain)

    traverse(root, [])

    # Fallback if no product_tags matched
    if not aggregated_items:
        for item in root.iter("karekod"):
            gtin = clean_gtin(item.findtext("gtin") or item.attrib.get("gtin") or item.findtext("barcode") or item.attrib.get("barcode") or "")
            lot = (item.findtext("bn") or item.attrib.get("bn") or item.findtext("lot") or item.attrib.get("lot") or "").strip()
            skt = parse_skt(item.findtext("skt") or item.attrib.get("skt") or item.findtext("exp") or item.attrib.get("exp") or "").strip()
            koli = (item.findtext("carrierLabel") or item.attrib.get("carrierLabel") or "").strip()
            sn_val = (item.findtext("sn") or item.attrib.get("sn") or item.findtext("serial") or item.attrib.get("serial") or "").strip()
            if koli:
                koli_set.add(koli)
            if gtin:
                c_path = f"|{koli}|" if koli else ""
                key = (gtin, lot, skt, koli)
                if key not in aggregated_items:
                    aggregated_items[key] = {
                        "barkod": gtin, "parti_no": lot, "skt": skt,
                        "koli_no": koli, "paket_no": "", "carrier_path": c_path,
                        "miktar": 0, "kutu_sayisi": 0, "serials": [], "serial_records": []
                    }
                aggregated_items[key]["miktar"] += 1
                aggregated_items[key]["kutu_sayisi"] += 1
                if sn_val:
                    aggregated_items[key]["serials"].append(sn_val)
                    rec = {
                        "gtin": gtin.zfill(14), "barkod": gtin, "serial": sn_val,
                        "batch": lot, "expiry": skt, "koli_no": koli, "paket_no": "", "carrier_path": c_path
                    }
                    aggregated_items[key]["serial_records"].append(rec)
                    all_raw_qrcodes.append(rec)

    return {
        "document_number": doc_number,
        "document_date": doc_date,
        "sender": sender,
        "receiver": receiver,
        "total_koli": len(koli_set),
        "items": list(aggregated_items.values()),
        "raw_qrcodes": all_raw_qrcodes
    }


def parse_pts_xml(file_bytes: bytes) -> dict:
    """
    PTS transfer paketini (Ham XML veya ZIP arşivi) ayrıştırır.
    ZIP içerisinde .xml uzantılı, '_' isimli veya uzantısız tüm dosyaları inceleyerek PTS XML içeriğini çıkarır.
    """
    if not file_bytes:
        raise ValueError("Yüklenen dosya içeriği boş.")

    # 1. ZIP dosyası kontrolü
    import zipfile
    import io
    is_zip = False
    if file_bytes.startswith(b"PK\x03\x04") or zipfile.is_zipfile(io.BytesIO(file_bytes)):
        is_zip = True

    if is_zip:
        try:
            with zipfile.ZipFile(io.BytesIO(file_bytes)) as zf:
                infolist = zf.infolist()
                valid_entries = [
                    info for info in infolist 
                    if not info.is_dir() and not info.filename.startswith(".") and "__MACOSX" not in info.filename
                ]

                if not valid_entries:
                    raise ValueError("ZIP arşivi içerisinde okunabilir dosya bulunamadı.")

                # Öncelik 1: .xml veya .pts uzantılı dosyalar
                xml_entries = [info for info in valid_entries if info.filename.lower().endswith((".xml", ".pts"))]
                # Öncelik 2: Diğer dosyalar ('_' uzantılı/isimli, uzantısız vb.)
                other_entries = [info for info in valid_entries if info not in xml_entries]

                candidate_entries = xml_entries + other_entries
                last_error = None

                for info in candidate_entries:
                    try:
                        raw_entry = zf.read(info.filename)
                        content = _decode_xml_bytes(raw_entry)
                        # İçerik XML etiketi içeriyor mu?
                        if "<" in content and (
                            "<?xml" in content.lower() or 
                            "productlist" in content.lower() or 
                            "transfer" in content.lower() or
                            "documentnumber" in content.lower() or
                            "karekod" in content.lower()
                        ):
                            result = _parse_pts_single_xml_str(content)
                            if result.get("items") or result.get("document_number"):
                                return result
                    except Exception as ex:
                        last_error = ex
                        continue

                # Herhangi bir aday içerikten PTS verisi yakalamayı dene
                for info in candidate_entries:
                    try:
                        raw_entry = zf.read(info.filename)
                        content = _decode_xml_bytes(raw_entry)
                        result = _parse_pts_single_xml_str(content)
                        if result.get("items") or result.get("document_number"):
                            return result
                    except Exception as ex:
                        last_error = ex
                        continue

                raise ValueError(f"ZIP arşivi içerisinde geçerli bir PTS XML dosyası bulunamadı. (Hata: {last_error or 'Biçim tanınamadı'})")

        except zipfile.BadZipFile:
            pass

    # 2. Doğrudan XML olarak ayrıştır
    content = _decode_xml_bytes(file_bytes)
    return _parse_pts_single_xml_str(content)
