from sqlalchemy import create_engine, event
from sqlalchemy.orm import declarative_base, sessionmaker
import os

# Create data directory if not exists
os.makedirs("data", exist_ok=True)

SQLALCHEMY_DATABASE_URL = "sqlite:///./data/stock.db"
MASTER_DATABASE_URL = "sqlite:///./masterdrugs/medication_db.sqlite"

engine = create_engine(
    SQLALCHEMY_DATABASE_URL, connect_args={"check_same_thread": False, "timeout": 30.0}
)

@event.listens_for(engine, "connect")
def set_sqlite_pragma(dbapi_connection, connection_record):
    cursor = dbapi_connection.cursor()
    cursor.execute("PRAGMA journal_mode=WAL;")
    cursor.execute("PRAGMA synchronous=NORMAL;")
    cursor.execute("PRAGMA foreign_keys=ON;")
    cursor.close()

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# Master DB — sadece dosya mevcutsa engine oluşturulur
_master_db_path = "./masterdrugs/medication_db.sqlite"
_master_db_exists = os.path.exists(_master_db_path)

if _master_db_exists:
    master_engine = create_engine(
        MASTER_DATABASE_URL, connect_args={"check_same_thread": False, "timeout": 30.0}
    )

    @event.listens_for(master_engine, "connect")
    def set_master_sqlite_pragma(dbapi_connection, connection_record):
        cursor = dbapi_connection.cursor()
        cursor.execute("PRAGMA journal_mode=WAL;")
        cursor.execute("PRAGMA synchronous=NORMAL;")
        cursor.close()

    MasterSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=master_engine)
else:
    master_engine = None
    MasterSessionLocal = None

Base = declarative_base()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

def get_master_db():
    """Master DB bağlantısı döner. Dosya yoksa None döner (hata fırlatmaz)."""
    if MasterSessionLocal is None:
        yield None
        return
    db = MasterSessionLocal()
    try:
        yield db
    finally:
        db.close()
