from contextlib import asynccontextmanager
from fastapi import FastAPI, Request, Depends, HTTPException, status
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from fastapi.responses import RedirectResponse
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware
from sqlalchemy.orm import make_transient
import os
from . import models, database, auth
from .database import engine, SessionLocal, MasterSessionLocal
from .routers import auth_router, dashboard_router, drugs_router, warehouses_router, stock_router, movements_router, warehouse_wizard_router, qr_basket_router


def _run_startup(db):

    """Tek seferlik başlangıç görevlerini çalıştırır."""
    try:
        from sqlalchemy import text
        from .nfc_helper import get_nfc_code_by_barcode
        from .routers.drugs_router import seed_default_features

        # Seed default features once at startup
        seed_default_features(db)

        columns = [row[1] for row in db.execute(text("PRAGMA table_info(ilaclar)")).fetchall()]
        if "nfc_kodu" not in columns:
            db.execute(text("ALTER TABLE ilaclar ADD COLUMN nfc_kodu VARCHAR;"))
            db.commit()

        if "recete_turu" not in columns:
            db.execute(text("ALTER TABLE ilaclar ADD COLUMN recete_turu VARCHAR;"))
            db.commit()

        if "kutu_ici_adet" not in columns:
            db.execute(text("ALTER TABLE ilaclar ADD COLUMN kutu_ici_adet INTEGER DEFAULT 1;"))
            db.commit()

        stok_cols = [row[1] for row in db.execute(text("PRAGMA table_info(stoklar)")).fetchall()]
        if "koli_ici_adet" not in stok_cols:
            db.execute(text("ALTER TABLE stoklar ADD COLUMN koli_ici_adet INTEGER;"))
            db.commit()

        hareket_cols = [row[1] for row in db.execute(text("PRAGMA table_info(stok_hareketleri)")).fetchall()]
        if "toplu_islem_kodu" not in hareket_cols:
            db.execute(text("ALTER TABLE stok_hareketleri ADD COLUMN toplu_islem_kodu VARCHAR;"))
            db.commit()
        if "pts_no" not in hareket_cols:
            db.execute(text("ALTER TABLE stok_hareketleri ADD COLUMN pts_no VARCHAR;"))
            db.commit()
        if "koli_no" not in hareket_cols:
            db.execute(text("ALTER TABLE stok_hareketleri ADD COLUMN koli_no VARCHAR;"))
            db.commit()
        if "kutu_sayisi" not in hareket_cols:
            db.execute(text("ALTER TABLE stok_hareketleri ADD COLUMN kutu_sayisi INTEGER;"))
            db.commit()
        if "kutu_ici_adet" not in hareket_cols:
            db.execute(text("ALTER TABLE stok_hareketleri ADD COLUMN kutu_ici_adet INTEGER;"))
            db.commit()

        depo_cols = [row[1] for row in db.execute(text("PRAGMA table_info(depolar)")).fetchall()]
        if "aciklama" not in depo_cols:
            db.execute(text("ALTER TABLE depolar ADD COLUMN aciklama VARCHAR;"))
            db.commit()

        if "is_toplam_depo" not in depo_cols:
            db.execute(text("ALTER TABLE depolar ADD COLUMN is_toplam_depo BOOLEAN NOT NULL DEFAULT 0;"))
            db.commit()

        # Create missing indexes for query performance optimization
        db.execute(text("CREATE INDEX IF NOT EXISTS ix_partiler_ilac_id ON partiler (ilac_id);"))
        db.execute(text("CREATE INDEX IF NOT EXISTS ix_partiler_miad ON partiler (miad);"))
        db.execute(text("CREATE INDEX IF NOT EXISTS ix_stoklar_depo_id ON stoklar (depo_id);"))
        db.execute(text("CREATE INDEX IF NOT EXISTS ix_stoklar_parti_id ON stoklar (parti_id);"))
        db.execute(text("CREATE INDEX IF NOT EXISTS ix_stok_hareketleri_tarih ON stok_hareketleri (tarih);"))
        db.execute(text("CREATE INDEX IF NOT EXISTS ix_stok_hareketleri_depo_id ON stok_hareketleri (depo_id);"))
        db.execute(text("CREATE INDEX IF NOT EXISTS ix_stok_hareketleri_parti_id ON stok_hareketleri (parti_id);"))
        db.commit()

        # Auto fill missing kutu_ici_adet from ambalaj / ad
        from .pts_parser import parse_package_dose_count
        all_drugs_for_dose = db.query(models.Ilac).filter(
            (models.Ilac.kutu_ici_adet == None) | (models.Ilac.kutu_ici_adet <= 1)
        ).all()
        dose_updated = 0
        for d_item in all_drugs_for_dose:
            inferred_dose = parse_package_dose_count(d_item.ambalaj or "", d_item.ad or "")
            if inferred_dose and inferred_dose > 1:
                d_item.kutu_ici_adet = inferred_dose
                dose_updated += 1
            elif d_item.kutu_ici_adet is None:
                d_item.kutu_ici_adet = 1
                dose_updated += 1
        if dose_updated > 0:
            db.commit()

        # Auto fill missing nfc_kodu for existing drugs
        ilaclar = db.query(models.Ilac).filter(
            (models.Ilac.nfc_kodu == None) | (models.Ilac.nfc_kodu == "")
        ).all()

        if ilaclar:
            from .routers.drugs_router import lookup_master_drug
            # MasterSessionLocal None olabilir (dosya yoksa)
            master_db = None
            if MasterSessionLocal is not None:
                master_db = MasterSessionLocal()
            try:
                updated_count = 0
                for ilac in ilaclar:
                    m_info = lookup_master_drug(ilac.barkod, master_db) if master_db else None
                    auto_nfc = (m_info.get("nfc_kodu") if m_info else None) or get_nfc_code_by_barcode(ilac.barkod)
                    if auto_nfc:
                        ilac.nfc_kodu = auto_nfc
                        updated_count += 1
                if updated_count > 0:
                    db.commit()
            finally:
                if master_db is not None:
                    master_db.close()


    except Exception as e:
        print(f"Migration/startup error: {e}")

    # Create default user if none exists, or migrate legacy bcrypt hash to stdlib PBKDF2
    user = db.query(models.Kullanici).filter(models.Kullanici.kullanici_adi == "admin").first()
    if not user:
        hashed_pw = auth.get_password_hash("admin")
        new_user = models.Kullanici(kullanici_adi="admin", parola_hash=hashed_pw, rol="admin")
        db.add(new_user)
        db.commit()
    elif not user.parola_hash or not user.parola_hash.startswith("pbkdf2_sha256$"):
        user.parola_hash = auth.get_password_hash("admin")
        db.commit()

    # Create default warehouses if none exists
    if db.query(models.Depo).count() == 0:
        db.add(models.Depo(kod="ANA", ad="Ana Depo"))
        db.add(models.Depo(kod="ACIL", ad="Acil Servis Deposu"))
        db.commit()


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Uygulama başlatma ve kapatma işlemleri."""
    # Create DB tables
    models.Base.metadata.create_all(bind=engine)

    db = SessionLocal()
    try:
        _run_startup(db)
    finally:
        db.close()

    yield  # Uygulama burada çalışır

    # Kapatma sırasında yapılacak temizlik işlemleri buraya eklenebilir


app = FastAPI(
    title="İlaç Stok Yönetim Sistemi",
    lifespan=lifespan,
    strict_content_type=False,
)

# Starlette GZip sıkıştırma katmanı (büyük HTML/JSON yanıtlarını otomatik sıkıştırır)
app.add_middleware(GZipMiddleware, minimum_size=1000)

# Enable CORS for local network devices
# allow_credentials=True ile wildcard origin tarayıcılar tarafından engellenir;
# LAN erişimi için gerçek IP/hostname belirtilmeli veya credentials kaldırılmalı.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,  # Cookie session zaten middleware ile kontrol ediliyor
    allow_methods=["*"],
    allow_headers=["*"],
)

app.mount("/static", StaticFiles(directory="app/static"), name="static")

# Include routers
app.include_router(auth_router.router)
app.include_router(dashboard_router.router)
app.include_router(drugs_router.router)
app.include_router(warehouses_router.router)
app.include_router(stock_router.router)
app.include_router(movements_router.router)
app.include_router(warehouse_wizard_router.router)
app.include_router(qr_basket_router.router)


# Add a middleware to check auth on all routes except login, logout, static
@app.middleware("http")
async def check_auth_middleware(request: Request, call_next):
    if request.url.path.startswith("/login") or request.url.path.startswith("/static") or request.url.path.startswith("/logout"):
        return await call_next(request)

    raw_cookie = request.cookies.get("session_user_id")
    if not raw_cookie:
        return RedirectResponse(url="/login", status_code=status.HTTP_302_FOUND)

    user_id = auth.parse_session_user_id(raw_cookie)
    if not user_id:
        response = RedirectResponse(url="/login", status_code=status.HTTP_302_FOUND)
        response.delete_cookie("session_user_id")
        return response

    db = SessionLocal()
    try:
        user = db.query(models.Kullanici).filter(models.Kullanici.id == user_id).first()
        if user:
            db.expunge(user)
            make_transient(user)
    finally:
        db.close()

    if not user:
        return RedirectResponse(url="/login", status_code=status.HTTP_302_FOUND)

    request.state.user = user
    response = await call_next(request)
    return response
