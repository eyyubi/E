"""
Türkiye İlaç Takip Sistemi (İTS) ve GS1 DataMatrix Karekod Çözücü Modülü
Tekil ve merkezi karekod ayrıştırıcı kaynak kodudur.
"""
import re
from datetime import datetime
from typing import Optional, Dict, Any
from abc import ABC, abstractmethod


class BaseQRParser(ABC):
    @abstractmethod
    def parse(self, raw_data: str) -> Dict[str, Any]:
        """
        Karekod/Barkod verisini ayrıştırıp sözlük olarak döner.
        Örnek dönüş: {'gtin': '...', 'barkod': '...', 'skt': 'YYYY-MM-DD', 'sn': '...', 'lot': '...'}
        """
        pass


class GS1MedicationQRParser(BaseQRParser):
    """
    Türkiye İlaç Takip Sistemi (İTS) ve GS1 standart karekod ayrıştırıcısı.
    Yapı: 01[GTIN:14]21[SN:Değişken]17[EXP_DATE:YYAAGG]10[BN:Batch]
    Değişken uzunluktaki SN içerisinde yer alabilecek sahte '17'leri ayırt etmek için
    gerçek takvim tarihi (MM: 01-12, DD: 01-31) ve arkasından gelen '10' seperatörü doğrulanır.
    """

    @staticmethod
    def _is_valid_date(yy: str, mm: str, dd: str) -> bool:
        try:
            m_int = int(mm)
            d_int = int(dd)
            if not (1 <= m_int <= 12 and 0 <= d_int <= 31):
                return False
            # Gün 00 ise GS1 kuralı gereği ayın son günüdür veya geçerli aydır
            gun_test = "01" if d_int == 0 else dd
            datetime.strptime(f"20{yy}-{mm}-{gun_test}", "%Y-%m-%d")
            return True
        except ValueError:
            return False

    def parse(self, raw: str) -> Dict[str, Any]:
        if not raw:
            return self._finalize_result({
                "raw": "",
                "gtin": None,
                "barkod": None,
                "skt": None,
                "lot": None,
                "sn": None,
                "success": False
            })

        # 1. GS1 ASCII 29 (Group Separator) ve kontrol karakterlerini temizle
        clean = str(raw).strip().replace("\x1d", "").replace("\u001d", "").replace("\x1e", "").replace("\x04", "").replace("\r", "").replace("\n", "")

        # 2. (01), [01], (21), (17), (10) parantezli / köşeli parantezli AI etiketlerini normalize et
        clean = re.sub(r'[\(\[]\s*(01|21|17|10)\s*[\)\]]', r'\1', clean)

        res: Dict[str, Any] = {
            "raw": clean,
            "gtin": None,
            "barkod": None,
            "skt": None,
            "lot": None,
            "sn": None,
            "success": False
        }

        # 3. 01[GTIN:14] Eşleştirmesi
        gtin_match = re.search(r'01(\d{14})', clean)
        if gtin_match:
            gtin_14 = gtin_match.group(1)
            res["gtin"] = gtin_14
            res["barkod"] = gtin_14.lstrip("0")
            after_gtin = clean[gtin_match.end():]
        else:
            # Düz barkod girilmiş olabilir (EAN-13, EAN-8, GTIN-14)
            digits_only = re.sub(r'\D', '', clean)
            if len(digits_only) in (8, 12, 13, 14):
                res["gtin"] = digits_only.zfill(14)
                res["barkod"] = digits_only.lstrip("0")
                res["success"] = True
                return self._finalize_result(res)
            after_gtin = clean

        # 4. Kalıp 1: 21[SN]17[YYAAGG]10[BN] (Türkiye İTS En Yaygın Formatı)
        # after_21 içinde sahte '17'leri ayırt etmek için takvim doğrulaması ve arkasından gelen '10' kontrol edilir
        if after_gtin.startswith("21"):
            after_21 = after_gtin[2:]
            found = False
            for i in range(len(after_21) - 7):
                if after_21[i:i+2] == "17":
                    candidate = after_21[i:]
                    m = re.match(r'^17(\d{2})(\d{2})(\d{2})(?:10(.*))?$', candidate)
                    if m:
                        yy, mm, dd, bn = m.groups()
                        if self._is_valid_date(yy, mm, dd):
                            res["sn"] = after_21[:i]
                            gun_str = "01" if dd == "00" else dd
                            res["skt"] = f"20{yy}-{mm}-{gun_str}"
                            res["lot"] = bn if bn is not None else ""
                            res["success"] = True
                            found = True
                            break
            if found:
                return self._finalize_result(res)

        # 5. Kalıp 2: 17[YYAAGG] başta veya önce gelen format (örn: 01...17...10...21... veya 01...17...21...10...)
        if after_gtin.startswith("17") and len(after_gtin) >= 8:
            yy, mm, dd = after_gtin[2:4], after_gtin[4:6], after_gtin[6:8]
            if self._is_valid_date(yy, mm, dd):
                gun_str = "01" if dd == "00" else dd
                res["skt"] = f"20{yy}-{mm}-{gun_str}"
                rem = after_gtin[8:]
                if rem.startswith("10"):
                    rem_10 = rem[2:]
                    m_sn = re.search(r'21(.*)$', rem_10)
                    if m_sn:
                        res["lot"] = rem_10[:m_sn.start()]
                        res["sn"] = m_sn.group(1)
                    else:
                        res["lot"] = rem_10
                    res["success"] = True
                    return self._finalize_result(res)
                elif rem.startswith("21"):
                    rem_21 = rem[2:]
                    m_bn = re.search(r'10(.*)$', rem_21)
                    if m_bn:
                        res["sn"] = rem_21[:m_bn.start()]
                        res["lot"] = m_bn.group(1)
                    else:
                        res["sn"] = rem_21
                    res["success"] = True
                    return self._finalize_result(res)

        # 6. Fallback: Sıra farklıysa veya 10 sonda değilse en mantıklı 17[YYAAGG] kalıbını ara
        # SN içinde sahte 17 geçebileceği için arkasında 10 veya 21 olan geçerli tarihi önceliklendir
        candidates = []
        for m in re.finditer(r'17(\d{2})(\d{2})(\d{2})', clean):
            yy, mm, dd = m.groups()
            if self._is_valid_date(yy, mm, dd):
                pos = m.end()
                has_subsequent_ai = clean[pos:pos+2] in ("10", "21")
                candidates.append((has_subsequent_ai, m.start(), yy, mm, dd, pos))

        if candidates:
            candidates.sort(key=lambda c: (not c[0], c[1]))
            _, _, yy, mm, dd, pos = candidates[0]
            gun_str = "01" if dd == "00" else dd
            res["skt"] = f"20{yy}-{mm}-{gun_str}"

            if not res["lot"] and clean[pos:pos+2] == "10":
                res["lot"] = clean[pos+2:]

            if not res["sn"]:
                m_sn = re.search(r'21([^1]+)', clean)
                if m_sn:
                    res["sn"] = m_sn.group(1)

        res["success"] = bool(res["gtin"] and (res["sn"] or res["skt"] or res["lot"]))
        return self._finalize_result(res)

    def _finalize_result(self, res: Dict[str, Any]) -> Dict[str, Any]:
        """
        Standart İTS alanları (gtin, barkod, skt, lot, sn, success) ile
        tüm sistemle tam uyumluluk sağlayan eşanlamlı alias anahtarları (serial, batch, expiry, bn, xd, is_gs1, uid) ekler.
        """
        sn_val = (res.get("sn") or "").strip()
        lot_val = (res.get("lot") or "").strip()
        skt_val = (res.get("skt") or "").strip()
        gtin_val = (res.get("gtin") or "").strip()

        res["serial"] = sn_val
        res["batch"] = lot_val
        res["expiry"] = skt_val
        res["bn"] = lot_val
        res["xd"] = skt_val
        res["is_gs1"] = bool(gtin_val and sn_val)

        if res["is_gs1"]:
            res["success"] = True
            exp_digits = skt_val.replace("-", "")[2:] if skt_val else "000000"
            res["uid"] = f"01{gtin_val}21{sn_val}17{exp_digits}10{lot_val}"
        else:
            res["uid"] = ""

        return res


# Aktif tekil parser örneği
active_qr_parser: BaseQRParser = GS1MedicationQRParser()


def parse_qr_code(raw: str) -> Dict[str, Any]:
    """
    Karekod / Barkod / DataMatrix metnini ayrıştıran global fonksiyon.
    Tüm sistemde karekod çözümlemesi için bu fonksiyondan referans alınır.
    """
    return active_qr_parser.parse(raw)


__all__ = ["BaseQRParser", "GS1MedicationQRParser", "active_qr_parser", "parse_qr_code"]
