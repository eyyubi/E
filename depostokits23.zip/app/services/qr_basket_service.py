import os
import re
import io
import shutil
import zipfile
import tempfile
import platform
import subprocess
import datetime
from datetime import date
from pathlib import Path
from typing import List, Dict, Any, Optional, Tuple
import csv
import openpyxl

from sqlalchemy import or_, func, text
from sqlalchemy.orm import Session, joinedload
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

from app.database import MasterSessionLocal
from app.models import (
    Ilac, Parti, Stok, StokHareketi, Depo,
    ItsKarekod, ItsTransferKarekod, ItsKullanilanKarekod, ItsMiadiGecenKarekod,
    DepoKarekod
)
from app.pts_parser import parse_pts_xml, clean_gtin, parse_skt, parse_package_dose_count

from app.qr_parser import parse_qr_code, GS1MedicationQRParser, BaseQRParser, active_qr_parser


LABEL_SIZE = (60 * mm, 30 * mm)


class _MasterDrugRef:
    """Master veritabanından (master_ilaclar) çözümlenen ilaç referans nesnesi."""
    __slots__ = (
        "id", "in_catalog", "barkod", "ad", "ambalaj", "uretici",
        "etken_madde", "jenerik_kodu", "jenerik_adi", "atc_kodu",
        "nfc_kodu", "recete_turu", "kutu_ici_adet", "koli_ici_adet",
        "birim", "raf_konumu"
    )

    def __init__(
        self,
        barkod: str,
        ad: str,
        ambalaj: str = "",
        uretici: str = "",
        etken_madde: str = "",
        jenerik_kodu: str = "",
        jenerik_adi: str = "",
        atc_kodu: str = "",
        nfc_kodu: str = "",
        recete_turu: str = "",
        kutu_ici_adet: int = 1
    ):
        self.id = None
        self.in_catalog = False
        self.barkod = barkod
        self.ad = ad
        self.ambalaj = ambalaj
        self.uretici = uretici
        self.etken_madde = etken_madde
        self.jenerik_kodu = jenerik_kodu
        self.jenerik_adi = jenerik_adi
        self.atc_kodu = atc_kodu
        self.nfc_kodu = nfc_kodu
        self.recete_turu = recete_turu
        self.kutu_ici_adet = kutu_ici_adet or 1
        self.koli_ici_adet = 1
        self.birim = "Adet"
        self.raf_konumu = ""


class MedicineCodeService:
    @staticmethod
    def normalize_gtin(value: Any) -> str:
        if not value:
            return ""
        s = str(value).strip().replace("'", "").replace('"', '')
        if s.endswith(".0"):
            s = s[:-2]
        if "e+" in s.lower() or "e-" in s.lower():
            try:
                s = f"{float(s):.0f}"
            except Exception:
                pass
        digits = re.sub(r"\D", "", s)
        if len(digits) > 0:
            return digits.zfill(14)
        return ""

    @staticmethod
    def to_catalog_barcode(gtin: Any) -> str:
        norm = MedicineCodeService.normalize_gtin(gtin)
        if len(norm) == 14 and norm.startswith("0"):
            return norm[1:]
        return norm

    @staticmethod
    def format_expiry_yymmdd(expiry: Any) -> str:
        if not expiry:
            return "000000"
        if isinstance(expiry, (date, datetime.datetime)):
            return expiry.strftime("%y%m%d")

        parsed = MedicineCodeService.parse_expiry_date(expiry)
        if parsed:
            return parsed.strftime("%y%m%d")

        text_val = str(expiry).strip().replace(".", "-").replace("/", "-")
        digits = re.sub(r"\D", "", text_val)
        if len(digits) == 6:
            return digits
        if len(digits) == 8:
            return digits[2:8]
        return "000000"

    @staticmethod
    def parse_expiry_date(raw_expiry: Any) -> Optional[date]:
        if not raw_expiry:
            return None
        if isinstance(raw_expiry, datetime.datetime):
            return raw_expiry.date()
        if isinstance(raw_expiry, date):
            return raw_expiry
        s = str(raw_expiry).strip()
        if not s:
            return None
        iso_str = parse_skt(s)
        try:
            return datetime.datetime.strptime(iso_str, "%Y-%m-%d").date()
        except Exception:
            pass
        digits = re.sub(r"\D", "", s)
        if len(digits) == 6:
            iso6 = parse_skt(digits)
            try:
                return datetime.datetime.strptime(iso6, "%Y-%m-%d").date()
            except Exception:
                pass
        return None

    @staticmethod
    def make_uid(gtin: str, serial: str, batch: str = "", expiry: Optional[Any] = None) -> str:
        normalized_gtin = MedicineCodeService.normalize_gtin(gtin)
        expiry_part = MedicineCodeService.format_expiry_yymmdd(expiry)
        return f"01{normalized_gtin}21{str(serial or '').strip()}17{expiry_part}10{str(batch or '').strip()}"


class GS1DataMatrixParser:
    """
    Karekod ayrıştırıcı sınıfı (qr_parser.py referanslı tekil karekod çözücü).
    Türkiye İTS standartları ve GS1 DataMatrix desteği sağlar.
    Tüm karekod çözümleme işlemleri için qr_parser.parse_qr_code fonksiyonundan referans alır.
    """
    @staticmethod
    def parse(raw_text: str) -> Dict[str, Any]:
        text = str(raw_text or "").strip()
        if not text:
            return {
                "gtin": "", "serial": "", "expiry": "", "batch": "",
                "sn": "", "lot": "", "skt": "", "bn": "", "xd": "", "barkod": "",
                "uid": "", "raw": "", "is_gs1": False, "success": False
            }

        result = parse_qr_code(text)
        gtin = str(result.get("gtin") or "")
        serial = str(result.get("serial") or result.get("sn") or "")
        batch = str(result.get("batch") or result.get("lot") or result.get("bn") or "")
        expiry = str(result.get("expiry") or result.get("skt") or result.get("xd") or "")

        norm_gtin = MedicineCodeService.normalize_gtin(gtin) if gtin else ""
        is_gs1 = bool(result.get("is_gs1") or (norm_gtin and serial))

        uid = result.get("uid")
        if not uid and is_gs1:
            uid = MedicineCodeService.make_uid(norm_gtin, serial, batch, expiry)

        return {
            "gtin": norm_gtin,
            "serial": serial.strip(),
            "expiry": expiry.strip(),
            "batch": batch.strip(),
            "sn": serial.strip(),
            "lot": batch.strip(),
            "skt": expiry.strip(),
            "bn": batch.strip(),
            "xd": expiry.strip(),
            "barkod": result.get("barkod") or (norm_gtin.lstrip("0") if norm_gtin else ""),
            "uid": uid or "",
            "raw": text,
            "is_gs1": is_gs1,
            "success": bool(result.get("success", is_gs1))
        }

    @staticmethod
    def _format_expiry_iso(yymmdd: str) -> str:
        if len(yymmdd) == 6 and yymmdd.isdigit():
            yy = int(yymmdd[:2])
            mm = yymmdd[2:4]
            dd = yymmdd[4:6]
            yyyy = 2000 + yy if yy < 70 else 1900 + yy
            return f"{yyyy}-{mm}-{dd}"
        return yymmdd


class ZintQRService:
    """
    Zint tabanlı GS1 DataMatrix 2D Karekod Görseli, Tekli/Çoklu Etiket PDF ve ZPL Üretici.
    MedicineQR-sepet masaüstü uygulamasındaki ZintQRGenerator mimarisinin birebir karşılığıdır.
    """
    _fonts_registered = False

    @classmethod
    def get_zint_path(cls) -> Optional[str]:
        # 1. Ortam değişkeni kontrolü (ZINT_PATH)
        env_zint = os.environ.get("ZINT_PATH")
        if env_zint and os.path.exists(env_zint):
            return env_zint

        is_win = platform.system() == "Windows" or os.name == "nt"

        # 2. Windows desteği: MedicineQR-sepet ve app altındaki gömülü zint.exe
        base_dir = Path(__file__).parent.parent.parent
        app_dir = Path(__file__).parent.parent

        win_candidates = [
            base_dir / "MedicineQR-sepet" / "app" / "core" / "bin" / "win" / "zint.exe",
            app_dir / "core" / "bin" / "win" / "zint.exe",
            Path("MedicineQR-sepet/app/core/bin/win/zint.exe"),
            Path("app/core/bin/win/zint.exe"),
            Path("C:/Program Files/Zint/zint.exe"),
            Path("C:/Program Files (x86)/Zint/zint.exe"),
        ]

        if is_win:
            for p in win_candidates:
                if p.exists():
                    return str(p)
            found_win = shutil.which("zint.exe") or shutil.which("zint")
            if found_win:
                return found_win

        # 3. Linux / macOS ortamı
        found = shutil.which("zint")
        if found:
            return found
        if os.path.exists("/usr/bin/zint"):
            return "/usr/bin/zint"
        if os.path.exists("/usr/local/bin/zint"):
            return "/usr/local/bin/zint"
        if os.path.exists("/opt/homebrew/bin/zint"):
            return "/opt/homebrew/bin/zint"

        # 4. Fallback (Windows binary mevcutsa)
        for p in win_candidates:
            if p.exists():
                return str(p)

        return None

    @classmethod
    def ensure_fonts(cls):
        if cls._fonts_registered:
            return
        font_dirs = [
            Path("app/static/fonts"),
            Path("MedicineQR-sepet/app/fonts"),
        ]
        for fdir in font_dirs:
            reg = fdir / "Roboto-Regular.ttf"
            bold = fdir / "Roboto-Bold.ttf"
            try:
                if reg.exists():
                    pdfmetrics.registerFont(TTFont("Roboto", str(reg)))
                if bold.exists():
                    pdfmetrics.registerFont(TTFont("Roboto-Bold", str(bold)))
                if reg.exists() and bold.exists():
                    cls._fonts_registered = True
                    break
            except Exception:
                continue

    @classmethod
    def get_font(cls, bold: bool = False) -> str:
        cls.ensure_fonts()
        registered = pdfmetrics.getRegisteredFontNames()
        if bold:
            return "Roboto-Bold" if "Roboto-Bold" in registered else "Helvetica-Bold"
        return "Roboto" if "Roboto" in registered else "Helvetica"

    @classmethod
    def run_zint_png(cls, data_str: str, output_path: str, scale: float = 4.0) -> bool:
        zint_bin = cls.get_zint_path()
        if not zint_bin:
            return False
        cmd = [
            zint_bin, "-b", "71", "--gs1", "-d", data_str,
            "-o", str(output_path), "--scale", str(scale), "--square", "--notext"
        ]
        try:
            subprocess.run(
                cmd,
                check=True,
                capture_output=True,
                text=True,
                creationflags=0x08000000 if platform.system() == "Windows" else 0
            )
            return os.path.exists(output_path) and os.path.getsize(output_path) > 0
        except Exception:
            return False

    @classmethod
    def build_gs1_zint_input(cls, gtin: str, serial: str, batch: str, expiry: Any) -> str:
        norm_gtin = MedicineCodeService.normalize_gtin(gtin) or "00000000000000"
        yymmdd = MedicineCodeService.format_expiry_yymmdd(expiry)
        sn = str(serial or "0").strip() or "0"
        bn = str(batch or "0").strip() or "0"
        return f"[01]{norm_gtin}[21]{sn}[17]{yymmdd}[10]{bn}"

    @classmethod
    def generate_preview_png(cls, gtin: str, serial: str, batch: str, expiry: Any) -> Tuple[Optional[bytes], str]:
        data_str = cls.build_gs1_zint_input(gtin, serial, batch, expiry)
        fd, tmp_path = tempfile.mkstemp(suffix=".png")
        os.close(fd)
        try:
            if cls.run_zint_png(data_str, tmp_path, scale=4.0):
                with open(tmp_path, "rb") as f:
                    return f.read(), data_str
            return None, data_str
        finally:
            if os.path.exists(tmp_path):
                try:
                    os.remove(tmp_path)
                except OSError:
                    pass

    @classmethod
    def generate_datamatrix_png(cls, gtin: str, serial: str, batch: str = "", expiry: Any = "") -> bytes:
        png_bytes, _ = cls.generate_preview_png(gtin=gtin, serial=serial, batch=batch, expiry=expiry)
        return png_bytes or b""

    @classmethod
    def generate_pdf_labels(cls, items: List[Dict[str, Any]], multi: bool = False) -> bytes:
        if multi:
            return cls._generate_multi_label_pdf(items)
        return cls._generate_single_label_pdf(items)

    @classmethod
    def _generate_single_label_pdf(cls, items: List[Dict[str, Any]]) -> bytes:
        """60mm x 30mm Termal Etiket Boyutunda Tekli Karekod PDF Üretimi (Zint GS1 DataMatrix ile)"""
        buffer = io.BytesIO()
        c = canvas.Canvas(buffer, pagesize=LABEL_SIZE)
        font_bold = cls.get_font(bold=True)
        font_reg = cls.get_font(bold=False)

        for item in items:
            gtin = MedicineCodeService.normalize_gtin(item.get("gtin") or item.get("barkod"))
            serial = str(item.get("serial") or item.get("sn") or "").strip()
            batch = str(item.get("batch") or item.get("bn") or item.get("parti_no") or "").strip()
            expiry_val = str(item.get("expiry") or item.get("xd") or item.get("exp_date") or item.get("skt") or "").strip()
            product_name = str(item.get("product_name") or item.get("drug_name") or item.get("ad") or "Bilinmeyen İlaç").strip()
            data_str = cls.build_gs1_zint_input(gtin, serial, batch, expiry_val)

            fd, tmp_path = tempfile.mkstemp(suffix=".png")
            os.close(fd)
            try:
                if cls.run_zint_png(data_str, tmp_path, scale=2.0):
                    c.drawImage(tmp_path, 2 * mm, 6 * mm, width=18 * mm, height=18 * mm)
                else:
                    c.rect(2 * mm, 6 * mm, 18 * mm, 18 * mm)

                text_x = 22 * mm
                c.setFont(font_bold, 8)
                c.drawString(text_x, 22 * mm, product_name[:22])
                c.setFont(font_reg, 6.5)
                line_space = 3.5 * mm
                c.drawString(text_x, 22 * mm - line_space, f"GTIN: {gtin}")
                c.drawString(text_x, 22 * mm - 2 * line_space, f"SN  : {serial or '-'}")
                c.drawString(text_x, 22 * mm - 3 * line_space, f"BN  : {batch or '-'}")
                c.drawString(text_x, 22 * mm - 4 * line_space, f"SKT : {expiry_val or 'N/A'}")
                c.showPage()
            finally:
                if os.path.exists(tmp_path):
                    try:
                        os.remove(tmp_path)
                    except OSError:
                        pass

        c.save()
        buffer.seek(0)
        return buffer.getvalue()

    @classmethod
    def _generate_multi_label_pdf(cls, items: List[Dict[str, Any]]) -> bytes:
        """A4 Sayfasına Çoklu Karekod Etiket Dizilimi (Zint GS1 DataMatrix ile)"""
        buffer = io.BytesIO()
        c = canvas.Canvas(buffer, pagesize=A4)
        width, height = A4
        curr_x, curr_y = 10 * mm, height - 40 * mm
        font_bold = cls.get_font(bold=True)
        font_reg = cls.get_font(bold=False)

        for item in items:
            gtin = MedicineCodeService.normalize_gtin(item.get("gtin") or item.get("barkod"))
            serial = str(item.get("serial") or item.get("sn") or "").strip()
            batch = str(item.get("batch") or item.get("bn") or item.get("parti_no") or "").strip()
            expiry_val = str(item.get("expiry") or item.get("xd") or item.get("exp_date") or item.get("skt") or "").strip()
            product_name = str(item.get("product_name") or item.get("drug_name") or item.get("ad") or "Bilinmeyen İlaç").strip()
            data_str = cls.build_gs1_zint_input(gtin, serial, batch, expiry_val)

            fd, tmp_path = tempfile.mkstemp(suffix=".png")
            os.close(fd)
            try:
                c.setStrokeColorRGB(0.8, 0.8, 0.8)
                c.rect(curr_x, curr_y, 90 * mm, 35 * mm)
                if cls.run_zint_png(data_str, tmp_path, scale=2.5):
                    c.drawImage(tmp_path, curr_x + 2 * mm, curr_y + 5 * mm, width=25 * mm, height=25 * mm)
                c.setFillColorRGB(0, 0, 0)
                c.setFont(font_bold, 9)
                c.drawString(curr_x + 30 * mm, curr_y + 27 * mm, product_name[:30])
                c.setFont(font_reg, 7)
                c.drawString(curr_x + 30 * mm, curr_y + 20 * mm, f"GTIN: {gtin}")
                c.drawString(curr_x + 30 * mm, curr_y + 15 * mm, f"SN  : {serial or '-'}")
                c.drawString(curr_x + 30 * mm, curr_y + 10 * mm, f"BN  : {batch or '-'}")
                c.drawString(curr_x + 30 * mm, curr_y + 5 * mm, f"SKT : {expiry_val or 'N/A'}")
            finally:
                if os.path.exists(tmp_path):
                    try:
                        os.remove(tmp_path)
                    except OSError:
                        pass

            curr_x += 95 * mm
            if curr_x + 90 * mm > width:
                curr_x = 10 * mm
                curr_y -= 40 * mm
            if curr_y < 20 * mm:
                c.showPage()
                curr_x, curr_y = 10 * mm, height - 40 * mm

        c.save()
        buffer.seek(0)
        return buffer.getvalue()

    @classmethod
    def generate_zpl(cls, items: List[Dict[str, Any]]) -> str:
        zpl_lines = []
        for item in items:
            gtin = MedicineCodeService.normalize_gtin(item.get("gtin") or item.get("barkod"))
            serial = str(item.get("serial") or item.get("sn") or "").strip()
            batch = str(item.get("batch") or item.get("bn") or item.get("parti_no") or "").strip()
            expiry_raw = item.get("expiry") or item.get("xd") or item.get("exp_date") or item.get("skt") or ""
            yymmdd = MedicineCodeService.format_expiry_yymmdd(expiry_raw)
            name = str(item.get("product_name") or item.get("drug_name") or item.get("ad") or "Bilinmeyen İlaç")[:30]

            zpl_lines.append(
                "^XA\n"
                "^PW472\n"
                "^LL240\n"
                "^CI28\n"
                f"^FO25,90^BXN,5,200,,,,,1^FH_^FD_1D01{gtin}21{serial}_1D17{yymmdd}10{batch}^FS\n"
                f"^FO20,30^A0N,20,20^FD{name}^FS\n"
                f"^FO20,60^A0N,15,15^FD({gtin})^FS\n"
                f"^FO200,90^A0N,20,20^FD(01){gtin}^FS\n"
                f"^FO200,120^A0N,20,20^FD(21){serial}^FS\n"
                f"^FO200,150^A0N,20,20^FD(17){expiry_raw}^FS\n"
                f"^FO200,180^A0N,20,20^FD(10){batch}^FS\n"
                "^XZ"
            )
        return "\n".join(zpl_lines)

    @classmethod
    def list_printers(cls) -> List[str]:
        printers = []
        try:
            res = subprocess.run(["lpstat", "-a"], capture_output=True, text=True, timeout=3)
            if res.returncode == 0 and res.stdout:
                for line in res.stdout.splitlines():
                    parts = line.strip().split()
                    if parts:
                        printers.append(parts[0])
        except Exception:
            pass
        return printers

    @classmethod
    def send_zpl_to_printer(cls, zpl_string: str, printer_name: Optional[str] = None) -> Tuple[bool, str]:
        try:
            system = platform.system().lower()
            if system == "windows":
                import win32print
                p_name = printer_name or win32print.GetDefaultPrinter()
                hPrinter = win32print.OpenPrinter(p_name)
                try:
                    win32print.StartDocPrinter(hPrinter, 1, ("MedicineQR Labels", None, "RAW"))
                    try:
                        win32print.StartPagePrinter(hPrinter)
                        win32print.WritePrinter(hPrinter, zpl_string.encode("utf-8"))
                        win32print.EndPagePrinter(hPrinter)
                    finally:
                        win32print.EndDocPrinter(hPrinter)
                finally:
                    win32print.ClosePrinter(hPrinter)
                return True, f"ZPL etiketleri '{p_name}' yazıcısına gönderildi."
            else:
                cmd = ["lp", "-d", printer_name, "-s"] if printer_name else ["lp", "-s"]
                process = subprocess.Popen(
                    cmd,
                    stdin=subprocess.PIPE,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE
                )
                _, stderr = process.communicate(input=zpl_string.encode("utf-8"))
                if process.returncode != 0:
                    return False, f"Yazıcı hatası (lp): {stderr.decode('utf-8', errors='ignore').strip()}"
                return True, "ZPL etiketleri sistem yazıcısına gönderildi."
        except Exception as e:
            return False, f"Yazdırma hatası: {str(e)}"

    @classmethod
    def send_zpl_to_default_printer(cls, zpl_string: str) -> Tuple[bool, str]:
        return cls.send_zpl_to_printer(zpl_string, printer_name=None)


class QRBasketService:
    """
    Hem İTS Karekod Envanterini (Masaüstü Uygulaması Modülü) hem de
    Fiziksel Depo Karekod Stoğunu ve Çoklu Doz / Koli / FEFO süreçlerini yöneten ana servis.
    """
    CHUNK_SIZE = 900
    _master_drug_cache: Optional[Dict[str, _MasterDrugRef]] = None

    @classmethod
    def get_master_drug_map(cls) -> Dict[str, _MasterDrugRef]:
        if cls._master_drug_cache is not None:
            return cls._master_drug_cache

        cache: Dict[str, _MasterDrugRef] = {}
        if MasterSessionLocal is not None:
            mdb = MasterSessionLocal()
            try:
                rows = mdb.execute(text("""
                    SELECT barkod, urun_adi, ambalaj, firma_adi, etkin_maddeler,
                           jenerik_kodu, jenerik_adi, atc_kodu, nfc, nfc_kodu, recete_turu
                    FROM master_ilaclar
                """)).fetchall()
                for row in rows:
                    b_raw = str(row.barkod or "").replace("'", "").strip()
                    if not b_raw:
                        continue
                    norm = MedicineCodeService.normalize_gtin(b_raw)
                    short = MedicineCodeService.to_catalog_barcode(norm)
                    ad = str(row.urun_adi or "").strip() or f"İlaç ({short or b_raw})"
                    ambalaj = str(row.ambalaj or "").strip()
                    kutu_ici = parse_package_dose_count(ambalaj, ad) or 1
                    ref = _MasterDrugRef(
                        barkod=short or b_raw,
                        ad=ad,
                        ambalaj=ambalaj,
                        uretici=str(row.firma_adi or "").strip(),
                        etken_madde=str(row.etkin_maddeler or "").strip(),
                        jenerik_kodu=str(row.jenerik_kodu or "").strip(),
                        jenerik_adi=str(row.jenerik_adi or "").strip(),
                        atc_kodu=str(row.atc_kodu or "").strip(),
                        nfc_kodu=str(row.nfc_kodu or row.nfc or "").strip(),
                        recete_turu=str(row.recete_turu or "").strip(),
                        kutu_ici_adet=kutu_ici
                    )
                    cache[b_raw] = ref
                    if norm:
                        cache[norm] = ref
                    if short:
                        cache[short] = ref
            except Exception:
                pass
            finally:
                mdb.close()

        cls._master_drug_cache = cache
        return cache

    @staticmethod
    def build_gtin_to_drug_map(db: Session, gtins: List[str] = None) -> Dict[str, Any]:
        master_map = QRBasketService.get_master_drug_map()
        query = db.query(Ilac)
        if gtins:
            search_barcodes = set()
            for g in gtins:
                if not g:
                    continue
                norm = MedicineCodeService.normalize_gtin(g)
                short = MedicineCodeService.to_catalog_barcode(g)
                search_barcodes.add(norm)
                search_barcodes.add(short)
            search_list = list(search_barcodes)
            ilaclar = []
            for i in range(0, len(search_list), 900):
                chunk = search_list[i:i+900]
                ilaclar.extend(query.filter(Ilac.barkod.in_(chunk)).all())
            mapping: Dict[str, Any] = {}
            for code in search_barcodes:
                if code in master_map:
                    ref = master_map[code]
                    mapping[code] = ref
                    mapping[MedicineCodeService.normalize_gtin(code)] = ref
                    mapping[MedicineCodeService.to_catalog_barcode(code)] = ref
        else:
            ilaclar = query.all()
            mapping = dict(master_map)

        for ilac in ilaclar:
            if not ilac.barkod:
                continue
            norm = MedicineCodeService.normalize_gtin(ilac.barkod)
            short = MedicineCodeService.to_catalog_barcode(ilac.barkod)
            m_ref = master_map.get(norm) or master_map.get(short) or master_map.get(ilac.barkod)
            if m_ref and (
                not ilac.ad
                or ilac.ad.startswith("Tanımsız")
                or ilac.ad.startswith("Yeni İlaç")
                or ilac.ad.startswith("İlaç (")
            ):
                ilac.ad = m_ref.ad
            ilac.in_catalog = True
            mapping[ilac.barkod] = ilac
            mapping[norm] = ilac
            mapping[short] = ilac
        return mapping

    @staticmethod
    def resolve_drug_info(db_or_gtin: Any, gtin_or_map: Any = None) -> Dict[str, Any]:
        """
        Hem (db: Session, gtin: str) hem de (gtin: str, drug_map: Dict) çağrı biçimlerini destekler.
        """
        if hasattr(db_or_gtin, "query"):
            db: Optional[Session] = db_or_gtin
            raw_gtin = str(gtin_or_map or "")
            drug_map: Optional[Dict[str, Any]] = None
        else:
            db = None
            raw_gtin = str(db_or_gtin or "")
            drug_map = gtin_or_map if isinstance(gtin_or_map, dict) else {}

        norm_gtin = MedicineCodeService.normalize_gtin(raw_gtin)
        short_gtin = MedicineCodeService.to_catalog_barcode(raw_gtin)
        if not norm_gtin:
            return {
                "found": False, "in_catalog": False, "ilac_id": None, "ad": "Bilinmeyen İlaç",
                "drug_name": "Bilinmeyen İlaç", "product_name": "Bilinmeyen İlaç",
                "barkod": str(raw_gtin or ""), "gtin": "", "kutu_ici_adet": 1,
                "koli_ici_adet": 1, "ambalaj": "", "atc_kodu": "", "jenerik_kodu": ""
            }

        master_map = QRBasketService.get_master_drug_map()
        m_ref = master_map.get(norm_gtin) or master_map.get(short_gtin)

        ilac = None
        if drug_map is not None:
            candidate = drug_map.get(norm_gtin) or drug_map.get(short_gtin)
            if candidate is not None and isinstance(candidate, Ilac):
                ilac = candidate
            elif candidate is not None and not m_ref:
                m_ref = candidate
        elif db is not None:
            ilac = db.query(Ilac).filter(
                or_(Ilac.barkod == norm_gtin, Ilac.barkod == short_gtin)
            ).first()

        if ilac:
            resolved_ad = (
                m_ref.ad
                if (m_ref and (not ilac.ad or ilac.ad.startswith("Tanımsız") or ilac.ad.startswith("Yeni İlaç") or ilac.ad.startswith("İlaç (")))
                else ilac.ad
            )
            kutu_ici = ilac.kutu_ici_adet or (m_ref.kutu_ici_adet if m_ref else 0) or parse_package_dose_count(ilac.ambalaj or "", resolved_ad or "") or 1
            return {
                "found": True,
                "in_catalog": True,
                "ilac_id": ilac.id,
                "barkod": ilac.barkod or short_gtin,
                "gtin": norm_gtin,
                "ad": resolved_ad,
                "drug_name": resolved_ad,
                "product_name": resolved_ad,
                "ambalaj": ilac.ambalaj or (m_ref.ambalaj if m_ref else ""),
                "birim": ilac.birim or "Adet",
                "kutu_ici_adet": kutu_ici,
                "koli_ici_adet": ilac.koli_ici_adet or 1,
                "etken_madde": ilac.etken_madde or (m_ref.etken_madde if m_ref else ""),
                "jenerik_kodu": ilac.jenerik_kodu or (m_ref.jenerik_kodu if m_ref else ""),
                "jenerik_adi": ilac.jenerik_adi or (m_ref.jenerik_adi if m_ref else ""),
                "atc_kodu": ilac.atc_kodu or (m_ref.atc_kodu if m_ref else ""),
                "raf_konumu": ilac.raf_konumu or "",
                "recete_turu": ilac.recete_turu or (m_ref.recete_turu if m_ref else "")
            }

        if m_ref:
            return {
                "found": False,
                "in_catalog": False,
                "from_master_db": True,
                "ilac_id": None,
                "barkod": short_gtin,
                "gtin": norm_gtin,
                "ad": m_ref.ad,
                "drug_name": m_ref.ad,
                "product_name": m_ref.ad,
                "ambalaj": m_ref.ambalaj,
                "birim": "Adet",
                "kutu_ici_adet": m_ref.kutu_ici_adet or 1,
                "koli_ici_adet": 1,
                "etken_madde": m_ref.etken_madde,
                "jenerik_kodu": m_ref.jenerik_kodu,
                "jenerik_adi": m_ref.jenerik_adi,
                "atc_kodu": m_ref.atc_kodu,
                "raf_konumu": "",
                "recete_turu": m_ref.recete_turu
            }

        return {
            "found": False,
            "in_catalog": False,
            "ilac_id": None,
            "barkod": short_gtin,
            "gtin": norm_gtin,
            "ad": f"Tanımsız İlaç ({short_gtin})",
            "drug_name": f"Tanımsız İlaç ({short_gtin})",
            "product_name": f"Tanımsız İlaç ({short_gtin})",
            "ambalaj": "",
            "birim": "Adet",
            "kutu_ici_adet": 1,
            "koli_ici_adet": 1,
            "etken_madde": "",
            "jenerik_kodu": "",
            "jenerik_adi": "",
            "atc_kodu": "",
            "raf_konumu": "",
            "recete_turu": ""
        }

    @staticmethod
    def parse_input_string(db: Session, raw_text: str) -> Dict[str, Any]:
        parsed = GS1DataMatrixParser.parse(raw_text)
        gtin = parsed["gtin"]
        drug_info = QRBasketService.resolve_drug_info(db, gtin)
        return {**parsed, **drug_info}

    # =========================================================================
    # 1. İTS KAREKOD ENVANTERİ SERVİSLERİ (MASAÜSTÜ UYGULAMASI MODÜLÜ)
    # =========================================================================

    _ITS_COL_MAPPING = {
        "GTIN": "gtin", "BARKOD": "gtin", "BARCODE": "gtin", "URUN_BARKODU": "gtin",
        "URUN_GTIN": "gtin", "ILAC_BARKOD": "gtin", "ILAC_BARKODU": "gtin",
        "PRODUCT_CODE": "gtin", "GTIN_NO": "gtin", "BARKOD_NO": "gtin",
        "SN": "serial", "SERI_NO": "serial", "SERIAL": "serial", "SERINO": "serial",
        "SERI_NUMARASI": "serial", "SERIAL_NUMBER": "serial", "SERIAL_NO": "serial",
        "SERI": "serial", "SIRA_NO": "serial",
        "BN": "batch", "BATCH": "batch", "LOT": "batch", "PARTI_NO": "batch",
        "PARTINO": "batch", "PARTI": "batch", "LOT_NO": "batch", "LOTNO": "batch",
        "BATCH_NO": "batch", "BATCH_NUMBER": "batch",
        "EXP_DATE": "expiry", "SKT": "expiry", "EXPIRY": "expiry", "MIAD": "expiry",
        "MIAT": "expiry", "SON_KULLANMA_TARIHI": "expiry", "SON_KULLANIM_TARIHI": "expiry",
        "XD": "expiry", "EXP": "expiry", "EXPIRATION_DATE": "expiry", "SON_KULLANMA": "expiry",
        "KAREKOD": "raw_qr", "QR": "raw_qr", "DATAMATRIX": "raw_qr", "UID": "raw_qr",
        "RAW": "raw_qr", "KAREKOD_METNI": "raw_qr", "GS1": "raw_qr",
        "KOLI_NO": "koli_no", "KOLI": "koli_no", "CARRIER_LABEL": "koli_no", "PALET_NO": "koli_no",
        "PAKET_NO": "paket_no", "PAKET": "paket_no",
        "CARRIER_PATH": "carrier_path",
    }

    @staticmethod
    def _decode_text_bytes(raw: bytes) -> str:
        for enc in ("utf-8-sig", "utf-8", "cp1254", "iso-8859-9"):
            try:
                return raw.decode(enc)
            except UnicodeDecodeError:
                continue
        return raw.decode("utf-8-sig", errors="replace")

    @staticmethod
    def _norm_its_col(c: Any) -> str:
        t = str(c or "").replace("\ufeff", "").strip().strip('"').strip("'").strip().upper()
        t = t.translate(str.maketrans("İIÜÖŞĞÇıüöşğç", "IIUOSGCIIUOSGC"))
        t = re.sub(r"[-./()]+", " ", t)
        return "_".join(t.split())

    @staticmethod
    def _extract_records_from_mapped_rows(rows_list: List[Dict[str, str]], mapped_cols: set) -> List[Dict[str, Any]]:
        records: List[Dict[str, Any]] = []
        for row in rows_list:
            gtin_val = str(row.get("gtin") or "").strip().strip('"').strip("'")
            serial_val = str(row.get("serial") or "").strip().strip('"').strip("'")
            batch_val = str(row.get("batch") or "").strip().strip('"').strip("'")
            expiry_val = str(row.get("expiry") or "").strip().strip('"').strip("'")
            raw_qr_val = str(row.get("raw_qr") or "").strip().strip('"').strip("'")
            koli_val = str(row.get("koli_no") or "").strip()
            paket_val = str(row.get("paket_no") or "").strip()
            cpath_val = str(row.get("carrier_path") or "").strip()

            # gtin sütununda tam GS1 karekod metni varsa ayrıştır
            if gtin_val and not serial_val and len(gtin_val) > 16:
                p = GS1DataMatrixParser.parse(gtin_val)
                if p.get("gtin") and p.get("serial"):
                    gtin_val = p["gtin"]
                    serial_val = p["serial"]
                    batch_val = batch_val or p.get("batch", "")
                    expiry_val = expiry_val or p.get("expiry", "")

            # raw_qr / uid sütunu varsa eksik alanları tamamla
            if raw_qr_val and (not gtin_val or not serial_val or not expiry_val):
                p = GS1DataMatrixParser.parse(raw_qr_val)
                if p.get("gtin") and p.get("serial"):
                    gtin_val = gtin_val or p["gtin"]
                    serial_val = serial_val or p["serial"]
                    batch_val = batch_val or p.get("batch", "")
                    expiry_val = expiry_val or p.get("expiry", "")

            if gtin_val and serial_val:
                rec: Dict[str, Any] = {
                    "gtin": gtin_val,
                    "serial": serial_val,
                    "batch": batch_val,
                    "expiry": expiry_val,
                }
                if koli_val:
                    rec["koli_no"] = koli_val
                if paket_val:
                    rec["paket_no"] = paket_val
                if cpath_val:
                    rec["carrier_path"] = cpath_val
                records.append(rec)
        return records

    @staticmethod
    def _parse_its_csv_string(content: str) -> List[Dict[str, Any]]:
        if not content:
            return []
        content = content.lstrip("\ufeff").strip()
        if not content:
            return []

        records: List[Dict[str, Any]] = []
        lines = [ln for ln in content.splitlines() if ln.strip()]
        if not lines:
            return []

        first_line = lines[0]
        sep_candidates = [(";", first_line.count(";")), (",", first_line.count(",")), ("\t", first_line.count("\t")), ("|", first_line.count("|"))]
        sep_candidates.sort(key=lambda x: x[1], reverse=True)
        sep = sep_candidates[0][0] if sep_candidates[0][1] > 0 else ";"

        try:
            reader = csv.DictReader(io.StringIO(content), delimiter=sep)
            if reader.fieldnames:
                col_map = {
                    orig: QRBasketService._ITS_COL_MAPPING.get(QRBasketService._norm_its_col(orig), QRBasketService._norm_its_col(orig))
                    for orig in reader.fieldnames if orig is not None
                }
                mapped_cols = set(col_map.values())
                if "gtin" in mapped_cols or "raw_qr" in mapped_cols:
                    rows_list: List[Dict[str, str]] = []
                    for raw_row in reader:
                        mapped_row = {
                            col_map[k]: (v.strip() if isinstance(v, str) else "")
                            for k, v in raw_row.items() if k in col_map and v is not None
                        }
                        rows_list.append(mapped_row)
                    records = QRBasketService._extract_records_from_mapped_rows(rows_list, mapped_cols)
                    if records:
                        return records
        except Exception:
            pass

        # Başlıksız (headerless) CSV veya ham GS1 karekod satırları için fallback
        try:
            raw_reader = csv.reader(io.StringIO(content), delimiter=sep)
            for row_tokens in raw_reader:
                tokens = [str(t or "").strip().strip('"').strip("'") for t in row_tokens if str(t or "").strip()]
                if not tokens:
                    continue

                # Önce satırda ham GS1 karekod dizgesi var mı kontrol et
                gs1_matched = False
                for tok in tokens:
                    if len(tok) >= 18:
                        p = GS1DataMatrixParser.parse(tok)
                        if p.get("gtin") and p.get("serial"):
                            records.append({
                                "gtin": p["gtin"],
                                "serial": p["serial"],
                                "batch": p["batch"],
                                "expiry": p["expiry"]
                            })
                            gs1_matched = True
                            break
                if gs1_matched:
                    continue

                # Başlıksız çok sütunlu satır (Örn: GTIN;SERIAL;BATCH;EXPIRY)
                if len(tokens) >= 2:
                    c0_digits = re.sub(r"\D", "", tokens[0])
                    if len(c0_digits) in (13, 14) and tokens[1]:
                        gtin_c = MedicineCodeService.normalize_gtin(c0_digits)
                        serial_c = tokens[1]
                        batch_c = ""
                        expiry_c = ""
                        if len(tokens) >= 4:
                            # 3. ve 4. sütundan hangisi tarihse onu expiry yap
                            d2 = MedicineCodeService.parse_expiry_date(tokens[2])
                            d3 = MedicineCodeService.parse_expiry_date(tokens[3])
                            if d3 is not None or d2 is None:
                                batch_c = tokens[2]
                                expiry_c = tokens[3]
                            else:
                                expiry_c = tokens[2]
                                batch_c = tokens[3]
                        elif len(tokens) == 3:
                            if MedicineCodeService.parse_expiry_date(tokens[2]) is not None:
                                expiry_c = tokens[2]
                            else:
                                batch_c = tokens[2]
                        records.append({
                            "gtin": gtin_c,
                            "serial": serial_c,
                            "batch": batch_c,
                            "expiry": expiry_c
                        })
        except Exception:
            pass

        return records

    @staticmethod
    def _parse_its_excel_bytes(file_bytes: bytes) -> List[Dict[str, Any]]:
        records: List[Dict[str, Any]] = []
        try:
            wb = openpyxl.load_workbook(io.BytesIO(file_bytes), read_only=True, data_only=True)
            for ws in wb.worksheets:
                sheet_rows = list(ws.iter_rows(values_only=True))
                if not sheet_rows:
                    continue
                first_row = [str(c if c is not None else "").strip() for c in sheet_rows[0]]
                col_map = {
                    idx: QRBasketService._ITS_COL_MAPPING.get(QRBasketService._norm_its_col(h), QRBasketService._norm_its_col(h))
                    for idx, h in enumerate(first_row) if h
                }
                mapped_cols = set(col_map.values())
                if "gtin" in mapped_cols or "raw_qr" in mapped_cols:
                    rows_list: List[Dict[str, str]] = []
                    for r in sheet_rows[1:]:
                        mapped_row: Dict[str, str] = {}
                        for idx, target_key in col_map.items():
                            if idx < len(r) and r[idx] is not None:
                                val = r[idx]
                                if isinstance(val, (date, datetime.datetime)):
                                    mapped_row[target_key] = val.strftime("%Y-%m-%d")
                                else:
                                    mapped_row[target_key] = str(val).strip()
                        if mapped_row:
                            rows_list.append(mapped_row)
                    records.extend(QRBasketService._extract_records_from_mapped_rows(rows_list, mapped_cols))
                else:
                    # Başlıksız Excel sayfası
                    csv_lines = []
                    for r in sheet_rows:
                        line_vals = []
                        for c in r:
                            if c is None:
                                line_vals.append("")
                            elif isinstance(c, (date, datetime.datetime)):
                                line_vals.append(c.strftime("%Y-%m-%d"))
                            else:
                                line_vals.append(str(c).strip())
                        if any(line_vals):
                            csv_lines.append(";".join(line_vals))
                    if csv_lines:
                        records.extend(QRBasketService._parse_its_csv_string("\n".join(csv_lines)))
            wb.close()
        except Exception:
            pass
        return records

    @staticmethod
    def parse_its_csv_or_zip_bytes(file_bytes: bytes, filename: str) -> List[Dict[str, Any]]:
        results = []
        fname_low = (filename or "").lower()
        if fname_low.endswith((".xlsx", ".xlsm")):
            return QRBasketService._parse_its_excel_bytes(file_bytes)

        is_zip = file_bytes.startswith(b"PK\x03\x04") or zipfile.is_zipfile(io.BytesIO(file_bytes))
        if is_zip:
            with zipfile.ZipFile(io.BytesIO(file_bytes), "r") as z:
                names = z.namelist()
                # Eğer doğrudan bir .xlsx dosyasıysa (ZIP imzalı)
                if any(n.startswith("xl/") for n in names):
                    return QRBasketService._parse_its_excel_bytes(file_bytes)
                for name in names:
                    if name.endswith("/") or name.startswith("__MACOSX") or name.startswith("."):
                        continue
                    n_low = name.lower()
                    if n_low.endswith((".csv", ".txt")):
                        raw = z.read(name)
                        text_content = QRBasketService._decode_text_bytes(raw)
                        results.extend(QRBasketService._parse_its_csv_string(text_content))
                    elif n_low.endswith((".xlsx", ".xlsm")):
                        results.extend(QRBasketService._parse_its_excel_bytes(z.read(name)))
                    elif n_low.endswith((".xml", ".pts")):
                        pts_data = parse_pts_xml(z.read(name))
                        results.extend(pts_data.get("raw_qrcodes", []))
        elif fname_low.endswith((".xml", ".pts")):
            pts_data = parse_pts_xml(file_bytes)
            results.extend(pts_data.get("raw_qrcodes", []))
        else:
            text_content = QRBasketService._decode_text_bytes(file_bytes)
            results.extend(QRBasketService._parse_its_csv_string(text_content))
        return results

    @staticmethod
    def _consolidate_expired_into_its_inventory(db: Session) -> int:
        """
        Eski sürümden kalan ItsMiadiGecenKarekod (its_expired_medicines) tablosundaki
        kayıtları tekil ve bire bir envanter tablosu olan ItsKarekod'a (its_inventory) taşır.
        Böylece tüm miad filtreleri, ID seçimleri ve dosya senkronizasyonu %100 tutarlı çalışır.
        """
        try:
            exp_cnt = db.query(func.count(ItsMiadiGecenKarekod.id)).scalar() or 0
            if exp_cnt > 0:
                db.execute(text("""
                    INSERT OR IGNORE INTO its_inventory (uid, gtin, serial, batch, expiry, created_at)
                    SELECT uid, gtin, serial, batch, expiry, CURRENT_TIMESTAMP
                    FROM its_expired_medicines
                """))
                db.execute(text("DELETE FROM its_expired_medicines"))
                db.commit()
                return exp_cnt
        except Exception:
            db.rollback()
        return 0

    @staticmethod
    def sync_its_inventory_from_file(
        db: Session,
        file_bytes: bytes,
        filename: str,
        move_missing_to_used: bool = True
    ) -> Dict[str, Any]:
        """
        İTS CSV/ZIP/Excel dosyası ile Ana İTS Envanterini bire bir (1-to-1) eşitler:
        - Önce varsa eski its_expired_medicines kayıtlarını its_inventory tablosunda birleştirir.
        - Dosyadaki tüm geçerli karekodları (hem miadı geçmemiş hem miadı geçmiş) ItsKarekod tablosunda tutar.
        - Önceden envanterde olup yeni yüklenen dosyada OLMAYAN karekodları (UID ve GTIN+SN bazında)
          'Kullanılan Karekodlar (its_used_medicines)' tablosuna aktarır ve ana envanterden siler.
        - Yeni yüklenen dosyada bulunan karekodlar önceden Kullanılan Karekodlar'da ise oradan çıkarır.
        """
        QRBasketService._consolidate_expired_into_its_inventory(db)

        raw_rows = QRBasketService.parse_its_csv_or_zip_bytes(file_bytes, filename)
        if not raw_rows:
            return {"status": "error", "success": False, "message": "Dosyada geçerli karekod verisi bulunamadı."}

        today = date.today()
        incoming_by_gs: Dict[Tuple[str, str], Dict[str, Any]] = {}

        for r in raw_rows:
            gtin = MedicineCodeService.normalize_gtin(r.get("gtin", ""))
            serial = str(r.get("serial", "")).strip()
            batch = str(r.get("batch", "")).strip() or "VARSAYILAN"
            exp_date = MedicineCodeService.parse_expiry_date(r.get("expiry"))
            if not gtin or not serial:
                continue
            gs_key = (gtin, serial)
            incoming_by_gs[gs_key] = {
                "gtin": gtin,
                "serial": serial,
                "batch": batch,
                "expiry": exp_date,
                "koli_no": r.get("koli_no") or None,
                "paket_no": r.get("paket_no") or None,
                "carrier_path": r.get("carrier_path") or None
            }

        if not incoming_by_gs:
            return {"status": "error", "success": False, "message": "Dosyadaki karekodların GTIN/Seri bilgileri ayrıştırılamadı."}

        # Mevcut tüm İTS envanter kayıtlarını hızlı tuple sorgusu ile çek
        existing_rows = db.query(
            ItsKarekod.id,
            ItsKarekod.uid,
            ItsKarekod.gtin,
            ItsKarekod.serial,
            ItsKarekod.batch,
            ItsKarekod.expiry
        ).all()

        matched_gs_keys = set()
        missing_rows = []
        rows_to_update = []
        skipped_count = 0

        for row_id, old_uid, old_gtin, old_serial, old_batch, old_expiry in existing_rows:
            norm_old_gtin = MedicineCodeService.normalize_gtin(old_gtin)
            gs_key = (norm_old_gtin, str(old_serial or "").strip())

            if gs_key in incoming_by_gs:
                inc = incoming_by_gs[gs_key]
                # Eğer dosyada SKT boşsa mevcut kaydın SKT'sini koru, yoksa varsayılan ata
                eff_expiry = inc["expiry"] or old_expiry or date(2099, 12, 31)
                inc["expiry"] = eff_expiry
                eff_batch = inc["batch"] if inc["batch"] != "VARSAYILAN" or not old_batch else old_batch
                inc["batch"] = eff_batch
                new_uid = MedicineCodeService.make_uid(inc["gtin"], inc["serial"], eff_batch, eff_expiry)
                inc["uid"] = new_uid

                if gs_key in matched_gs_keys:
                    # Veritabanında aynı (gtin, serial) için mükerrer kayıt varsa fazlalığı temizle
                    missing_rows.append((row_id, old_uid, norm_old_gtin, old_serial, old_batch, old_expiry, False))
                    continue

                matched_gs_keys.add(gs_key)
                skipped_count += 1

                if old_uid != new_uid or old_batch != eff_batch or old_expiry != eff_expiry or old_gtin != inc["gtin"]:
                    rows_to_update.append({
                        "b_id": row_id,
                        "b_uid": new_uid,
                        "b_gtin": inc["gtin"],
                        "b_batch": eff_batch,
                        "b_expiry": eff_expiry
                    })
            else:
                missing_rows.append((row_id, old_uid, norm_old_gtin, old_serial, old_batch, old_expiry, True))

        moved_to_used_count = 0

        # 1. Önceden envanterde olup yeni yüklenen dosyada OLMAYAN karekodları Kullanılan Karekodlar'a aktar ve envanterden sil
        if missing_rows:
            if move_missing_to_used:
                real_missing = [m for m in missing_rows if m[6]]
                if real_missing:
                    used_params = [
                        {
                            "uid": m[1],
                            "gtin": m[2],
                            "serial": m[3],
                            "batch": m[4] or "VARSAYILAN",
                            "expiry": m[5].strftime("%Y-%m-%d") if isinstance(m[5], (date, datetime.datetime)) else str(m[5] or today.strftime("%Y-%m-%d")),
                            "detection_date": today.strftime("%Y-%m-%d")
                        }
                        for m in real_missing
                    ]
                    for i in range(0, len(used_params), 2000):
                        batch_params = used_params[i:i + 2000]
                        old_uids = [p["uid"] for p in batch_params]
                        for j in range(0, len(old_uids), QRBasketService.CHUNK_SIZE):
                            db.query(ItsKullanilanKarekod).filter(
                                ItsKullanilanKarekod.uid.in_(old_uids[j:j + QRBasketService.CHUNK_SIZE])
                            ).delete(synchronize_session=False)
                        db.execute(
                            text("""
                                INSERT OR REPLACE INTO its_used_medicines (uid, gtin, serial, batch, expiry, detection_date)
                                VALUES (:uid, :gtin, :serial, :batch, :expiry, :detection_date)
                            """),
                            batch_params
                        )
                    moved_to_used_count = len(real_missing)

            # Envanterin yüklenen dosya ile bire bir (1-to-1) aynı olması için dosyada olmayanları ItsKarekod'dan sil
            missing_ids = [m[0] for m in missing_rows]
            for i in range(0, len(missing_ids), QRBasketService.CHUNK_SIZE):
                chunk_ids = missing_ids[i:i + QRBasketService.CHUNK_SIZE]
                db.query(ItsKarekod).filter(ItsKarekod.id.in_(chunk_ids)).delete(synchronize_session=False)

        # 2. Güncellenen mevcut kayıtları uygula
        if rows_to_update:
            for u in rows_to_update:
                db.execute(
                    text("""
                        UPDATE its_inventory
                        SET uid = :b_uid, gtin = :b_gtin, batch = :b_batch, expiry = :b_expiry
                        WHERE id = :b_id
                    """),
                    u
                )

        # 3. Dosyada yeni gelen karekodları ItsKarekod tablosuna ekle
        new_items_params = []
        now_str = datetime.datetime.now(datetime.timezone.utc).replace(tzinfo=None).strftime("%Y-%m-%d %H:%M:%S")
        for gs_key, data in incoming_by_gs.items():
            if gs_key in matched_gs_keys:
                continue
            eff_exp = data["expiry"] or date(2099, 12, 31)
            data["expiry"] = eff_exp
            uid = MedicineCodeService.make_uid(data["gtin"], data["serial"], data["batch"], eff_exp)
            data["uid"] = uid
            new_items_params.append({
                "uid": uid,
                "gtin": data["gtin"],
                "serial": data["serial"],
                "batch": data["batch"],
                "expiry": eff_exp.strftime("%Y-%m-%d") if isinstance(eff_exp, (date, datetime.datetime)) else str(eff_exp),
                "koli_no": data.get("koli_no"),
                "paket_no": data.get("paket_no"),
                "carrier_path": data.get("carrier_path"),
                "created_at": now_str
            })

        added_count = len(new_items_params)
        if new_items_params:
            for i in range(0, len(new_items_params), 2000):
                batch_params = new_items_params[i:i + 2000]
                db.execute(
                    text("""
                        INSERT OR IGNORE INTO its_inventory
                            (uid, gtin, serial, batch, expiry, koli_no, paket_no, carrier_path, created_at)
                        VALUES
                            (:uid, :gtin, :serial, :batch, :expiry, :koli_no, :paket_no, :carrier_path, :created_at)
                    """),
                    batch_params
                )

        # 4. Yeni yüklenen stok dosyasında mevcut olan karekodlar önceden Kullanılan Karekodlar'da ise oradan temizle
        used_count_in_db = db.query(func.count(ItsKullanilanKarekod.id)).scalar() or 0
        if used_count_in_db > 0:
            used_rows = db.query(ItsKullanilanKarekod.id, ItsKullanilanKarekod.gtin, ItsKullanilanKarekod.serial).all()
            returned_used_ids = [
                u_id for u_id, u_gtin, u_serial in used_rows
                if (MedicineCodeService.normalize_gtin(u_gtin), str(u_serial or "").strip()) in incoming_by_gs
            ]
            for i in range(0, len(returned_used_ids), QRBasketService.CHUNK_SIZE):
                chunk_u_ids = returned_used_ids[i:i + QRBasketService.CHUNK_SIZE]
                db.query(ItsKullanilanKarekod).filter(ItsKullanilanKarekod.id.in_(chunk_u_ids)).delete(synchronize_session=False)

        db.commit()
        total_now = db.query(func.count(ItsKarekod.id)).scalar() or 0
        return {
            "status": "success",
            "success": True,
            "added": added_count,
            "skipped": skipped_count,
            "moved_to_used": moved_to_used_count,
            "added_count": added_count,
            "skipped_count": skipped_count,
            "moved_to_used_count": moved_to_used_count,
            "total_inventory": total_now,
            "file_unique_count": len(incoming_by_gs),
            "message": (
                f"İTS Eşitleme Tamamlandı (Toplam Envanter: {total_now} karekod): "
                f"{added_count} yeni karekod eklendi, {skipped_count} mevcut karekod korundu, "
                f"yeni dosyada olmayan {moved_to_used_count} karekod Kullanılan Karekodlara aktarıldı."
            )
        }

    @staticmethod
    def sync_its_from_file(
        db: Session,
        file_bytes: bytes,
        filename: str,
        move_missing_to_used: bool = True
    ) -> Dict[str, Any]:
        return QRBasketService.sync_its_inventory_from_file(
            db=db,
            file_bytes=file_bytes,
            filename=filename,
            move_missing_to_used=move_missing_to_used
        )

    @staticmethod
    def add_qrcodes_to_its(db: Session, qr_records: List[Dict[str, Any]], pts_no: str = "") -> int:
        if not qr_records:
            return 0
        QRBasketService._consolidate_expired_into_its_inventory(db)
        prepared = {}
        for r in qr_records:
            gtin = MedicineCodeService.normalize_gtin(r.get("gtin") or r.get("barkod"))
            serial = str(r.get("serial") or r.get("sn") or "").strip()
            batch = str(r.get("batch") or r.get("bn") or r.get("parti_no") or "VARSAYILAN").strip()
            exp_date = MedicineCodeService.parse_expiry_date(r.get("expiry") or r.get("xd") or r.get("skt"))
            if not gtin or not serial or not exp_date:
                continue
            uid = MedicineCodeService.make_uid(gtin, serial, batch, exp_date)
            prepared[uid] = {
                "uid": uid,
                "gtin": gtin,
                "serial": serial,
                "batch": batch,
                "expiry": exp_date,
                "koli_no": r.get("koli_no") or None,
                "paket_no": r.get("paket_no") or None,
                "carrier_path": r.get("carrier_path") or None,
                "pts_no": pts_no or r.get("pts_no") or None
            }

        if not prepared:
            return 0

        uids = list(prepared.keys())
        existing_uids = set()
        for i in range(0, len(uids), QRBasketService.CHUNK_SIZE):
            chunk = uids[i:i+QRBasketService.CHUNK_SIZE]
            existing_uids.update(
                row[0] for row in db.query(ItsKarekod.uid).filter(ItsKarekod.uid.in_(chunk)).all()
            )

        to_add = [ItsKarekod(**d) for uid, d in prepared.items() if uid not in existing_uids]
        if to_add:
            db.bulk_save_objects(to_add)
        return len(to_add)

    @staticmethod
    def get_its_inventory_paginated(
        db: Session,
        page: int = 1,
        limit: int = 50,
        search: str = "",
        expiry_filter: str = "",
        sort: str = "expiry ASC"
    ) -> Dict[str, Any]:
        QRBasketService._consolidate_expired_into_its_inventory(db)
        today = date.today()
        offset = max(0, (page - 1) * limit)

        model = ItsKarekod
        query = db.query(model)

        if expiry_filter in ("Geçen", "expired"):
            query = query.filter(model.expiry < today)
        elif expiry_filter in ("Geçmeyen", "valid", "all_valid"):
            query = query.filter(model.expiry >= today)
        elif expiry_filter == "1m":
            query = query.filter(model.expiry >= today, model.expiry <= today + datetime.timedelta(days=30))
        elif expiry_filter == "3m":
            query = query.filter(model.expiry >= today, model.expiry <= today + datetime.timedelta(days=90))
        elif expiry_filter == "6m":
            query = query.filter(model.expiry >= today, model.expiry <= today + datetime.timedelta(days=180))
        # expiry_filter in ("", "all", "Tümü") ise tüm İTS envanterini (dosya ile bire bir) getirir

        if search and search.strip():
            s_clean = search.strip()
            s_like = f"%{s_clean}%"
            matching_gtins = [
                MedicineCodeService.normalize_gtin(b[0])
                for b in db.query(Ilac.barkod).filter(
                    or_(Ilac.ad.ilike(s_like), Ilac.barkod.ilike(s_like))
                ).limit(850).all()
                if b[0]
            ]
            conds = [
                model.gtin.ilike(s_like),
                model.serial.ilike(s_like),
                model.batch.ilike(s_like),
                model.uid.ilike(s_like),
                model.koli_no.ilike(s_like)
            ]
            if matching_gtins:
                conds.append(model.gtin.in_(matching_gtins))
            query = query.filter(or_(*conds))

        total = query.count()
        total_all = db.query(func.count(ItsKarekod.id)).scalar() or 0

        sort_map = {
            "id DESC": model.id.desc(),
            "id_desc": model.id.desc(),
            "id ASC": model.id.asc(),
            "id_asc": model.id.asc(),
            "expiry ASC": model.expiry.asc(),
            "xd_asc": model.expiry.asc(),
            "expiry DESC": model.expiry.desc(),
            "xd_desc": model.expiry.desc(),
            "name_asc": model.gtin.asc(),
            "name_desc": model.gtin.desc(),
        }
        rows = query.order_by(sort_map.get(sort, model.expiry.asc())).offset(offset).limit(limit).all()
        drug_map = QRBasketService.build_gtin_to_drug_map(db, [r.gtin for r in rows])

        items = []
        for r in rows:
            short_b = MedicineCodeService.to_catalog_barcode(r.gtin)
            ilac = drug_map.get(r.gtin) or drug_map.get(short_b)
            drug_name = ilac.ad if ilac else f"Tanımsız İlaç ({r.gtin})"
            in_catalog = bool(getattr(ilac, "id", None))
            exp_str = r.expiry.strftime("%Y-%m-%d") if r.expiry else ""
            added_str = r.created_at.strftime("%Y-%m-%d %H:%M") if getattr(r, "created_at", None) else "-"
            items.append({
                "id": r.id,
                "uid": r.uid,
                "gtin": r.gtin,
                "barkod": short_b,
                "in_catalog": in_catalog,
                "ilac_id": getattr(ilac, "id", None),
                "drug_name": drug_name,
                "product_name": drug_name,
                "ad": drug_name,
                "sn": r.serial,
                "serial": r.serial,
                "bn": r.batch,
                "batch": r.batch,
                "xd": exp_str,
                "expiry": exp_str,
                "added_at": added_str,
                "koli_no": getattr(r, "koli_no", "") or "",
                "paket_no": getattr(r, "paket_no", "") or "",
                "pts_no": getattr(r, "pts_no", "") or "",
                "kutu_ici_adet": (ilac.kutu_ici_adet or 1) if ilac else 1
            })

        return {
            "status": "success",
            "items": items,
            "total": total,
            "total_all": total_all,
            "page": page,
            "limit": limit,
            "per_page": limit,
            "total_pages": max(1, (total + limit - 1) // limit)
        }

    @staticmethod
    def transfer_its_to_pool(
        db: Session,
        uids: Optional[List[str]] = None,
        ids: Optional[List[int]] = None,
        gtin: Optional[str] = None,
        batch: Optional[str] = None,
        expiry: Optional[str] = None,
        count: Optional[int] = None
    ) -> Tuple[bool, str, int]:
        QRBasketService._consolidate_expired_into_its_inventory(db)
        moved = 0
        items_to_move: List[ItsKarekod] = []

        if ids:
            clean_ids = [int(x) for x in ids if str(x).isdigit()]
            for i in range(0, len(clean_ids), QRBasketService.CHUNK_SIZE):
                chunk = clean_ids[i:i+QRBasketService.CHUNK_SIZE]
                items_to_move.extend(db.query(ItsKarekod).filter(ItsKarekod.id.in_(chunk)).all())
        elif uids:
            for i in range(0, len(uids), QRBasketService.CHUNK_SIZE):
                chunk = uids[i:i+QRBasketService.CHUNK_SIZE]
                items_to_move.extend(db.query(ItsKarekod).filter(ItsKarekod.uid.in_(chunk)).all())
        elif gtin:
            norm_gtin = MedicineCodeService.normalize_gtin(gtin)
            q = db.query(ItsKarekod).filter(ItsKarekod.gtin == norm_gtin)
            if batch:
                q = q.filter(ItsKarekod.batch == batch)
            if expiry:
                exp_d = MedicineCodeService.parse_expiry_date(expiry)
                if exp_d:
                    q = q.filter(ItsKarekod.expiry == exp_d)
            q = q.order_by(ItsKarekod.expiry.asc(), ItsKarekod.id.asc())
            if count and int(count) > 0:
                q = q.limit(int(count))
            items_to_move = q.all()

        if not items_to_move:
            return False, "Seçili kriterlere uygun aktif İTS karekodu bulunamadı.", 0

        target_uids = [it.uid for it in items_to_move]
        existing_pool_uids = set()
        for i in range(0, len(target_uids), QRBasketService.CHUNK_SIZE):
            chunk = target_uids[i:i+QRBasketService.CHUNK_SIZE]
            existing_pool_uids.update(
                r[0] for r in db.query(ItsTransferKarekod.uid).filter(ItsTransferKarekod.uid.in_(chunk)).all()
            )

        new_pool_objs = [
            ItsTransferKarekod(
                uid=it.uid, gtin=it.gtin, serial=it.serial,
                batch=it.batch, expiry=it.expiry,
                transfer_date=date.today(), is_exported=False
            )
            for it in items_to_move if it.uid not in existing_pool_uids
        ]
        if new_pool_objs:
            db.bulk_save_objects(new_pool_objs)

        for i in range(0, len(target_uids), QRBasketService.CHUNK_SIZE):
            chunk = target_uids[i:i+QRBasketService.CHUNK_SIZE]
            db.query(ItsKarekod).filter(ItsKarekod.uid.in_(chunk)).delete(synchronize_session=False)

        moved = len(items_to_move)
        db.commit()
        return True, f"{moved} adet karekod Transfer Havuzuna aktarıldı.", moved

    @staticmethod
    def transfer_its_by_gtin_and_batch(db: Session, gtin: str, batch: str) -> Tuple[bool, str]:
        ok, msg, _ = QRBasketService.transfer_its_to_pool(db, gtin=gtin, batch=batch)
        return ok, msg

    @staticmethod
    def get_its_transfer_pool(
        db: Session,
        show_exported: bool = False,
        search: str = "",
        page: int = 1,
        limit: int = 100
    ) -> Dict[str, Any]:
        query = db.query(ItsTransferKarekod)
        if not show_exported:
            query = query.filter(ItsTransferKarekod.is_exported == False)
        if search and search.strip():
            s_clean = search.strip()
            s = f"%{s_clean}%"
            matching_gtins = [
                MedicineCodeService.normalize_gtin(b[0])
                for b in db.query(Ilac.barkod).filter(
                    or_(Ilac.ad.ilike(s), Ilac.barkod.ilike(s))
                ).limit(850).all()
                if b[0]
            ]
            conds = [
                ItsTransferKarekod.gtin.ilike(s),
                ItsTransferKarekod.serial.ilike(s),
                ItsTransferKarekod.batch.ilike(s)
            ]
            if matching_gtins:
                conds.append(ItsTransferKarekod.gtin.in_(matching_gtins))
            query = query.filter(or_(*conds))

        total = query.count()
        q_ordered = query.order_by(ItsTransferKarekod.id.desc())
        if limit and limit > 0:
            offset = max(0, (page - 1) * limit)
            rows = q_ordered.offset(offset).limit(limit).all()
        else:
            rows = q_ordered.all()

        drug_map = QRBasketService.build_gtin_to_drug_map(db, [r.gtin for r in rows])
        result = []
        for r in rows:
            short_b = MedicineCodeService.to_catalog_barcode(r.gtin)
            ilac = drug_map.get(r.gtin) or drug_map.get(short_b)
            drug_name = ilac.ad if ilac else f"Tanımsız İlaç ({r.gtin})"
            in_catalog = bool(getattr(ilac, "id", None))
            exp_str = r.expiry.strftime("%Y-%m-%d") if r.expiry else ""
            t_date = r.transfer_date.strftime("%Y-%m-%d") if r.transfer_date else ""
            result.append({
                "id": r.id,
                "uid": r.uid,
                "gtin": r.gtin,
                "barkod": short_b,
                "in_catalog": in_catalog,
                "ilac_id": getattr(ilac, "id", None),
                "drug_name": drug_name,
                "product_name": drug_name,
                "ad": drug_name,
                "sn": r.serial,
                "serial": r.serial,
                "bn": r.batch,
                "batch": r.batch,
                "xd": exp_str,
                "expiry": exp_str,
                "added_at": t_date,
                "transfer_date": t_date,
                "is_exported": r.is_exported,
                "kutu_ici_adet": (ilac.kutu_ici_adet or 1) if ilac else 1
            })
        eff_limit = limit if (limit and limit > 0) else max(1, total)
        return {
            "status": "success",
            "items": result,
            "total": total,
            "count": len(result),
            "page": page,
            "limit": eff_limit,
            "per_page": eff_limit,
            "total_pages": max(1, (total + eff_limit - 1) // eff_limit)
        }

    @staticmethod
    def rollback_transfer_pool_to_its(
        db: Session,
        uids: Optional[List[str]] = None,
        ids: Optional[List[int]] = None
    ) -> Tuple[bool, str, int]:
        items: List[ItsTransferKarekod] = []
        if ids:
            clean_ids = [int(x) for x in ids if str(x).isdigit()]
            for i in range(0, len(clean_ids), QRBasketService.CHUNK_SIZE):
                chunk = clean_ids[i:i+QRBasketService.CHUNK_SIZE]
                items.extend(db.query(ItsTransferKarekod).filter(ItsTransferKarekod.id.in_(chunk)).all())
        elif uids:
            for i in range(0, len(uids), QRBasketService.CHUNK_SIZE):
                chunk = uids[i:i+QRBasketService.CHUNK_SIZE]
                items.extend(db.query(ItsTransferKarekod).filter(ItsTransferKarekod.uid.in_(chunk)).all())

        if not items:
            return False, "Seçili karekod yok.", 0

        target_uids = [it.uid for it in items]
        existing_its = set()
        for i in range(0, len(target_uids), QRBasketService.CHUNK_SIZE):
            chunk = target_uids[i:i+QRBasketService.CHUNK_SIZE]
            existing_its.update(
                r[0] for r in db.query(ItsKarekod.uid).filter(ItsKarekod.uid.in_(chunk)).all()
            )

        to_restore = [
            ItsKarekod(uid=it.uid, gtin=it.gtin, serial=it.serial, batch=it.batch, expiry=it.expiry)
            for it in items if it.uid not in existing_its
        ]
        if to_restore:
            db.bulk_save_objects(to_restore)

        for i in range(0, len(target_uids), QRBasketService.CHUNK_SIZE):
            chunk = target_uids[i:i+QRBasketService.CHUNK_SIZE]
            db.query(ItsTransferKarekod).filter(ItsTransferKarekod.uid.in_(chunk)).delete(synchronize_session=False)

        restored = len(items)
        db.commit()
        return True, f"{restored} adet karekod Ana İTS Envanterine geri taşındı.", restored

    @staticmethod
    def clear_exported_transfer_pool(db: Session) -> Tuple[bool, str]:
        count = db.query(ItsTransferKarekod).filter(ItsTransferKarekod.is_exported == True).delete()
        db.commit()
        return True, f"{count} adet dışa aktarılmış kayıt Transfer Havuzundan temizlendi."

    @staticmethod
    def get_its_used_list(
        db: Session,
        search: str = "",
        page: int = 1,
        limit: int = 100
    ) -> Dict[str, Any]:
        query = db.query(ItsKullanilanKarekod)
        if search and search.strip():
            s_clean = search.strip()
            s = f"%{s_clean}%"
            matching_gtins = [
                MedicineCodeService.normalize_gtin(b[0])
                for b in db.query(Ilac.barkod).filter(
                    or_(Ilac.ad.ilike(s), Ilac.barkod.ilike(s))
                ).limit(850).all()
                if b[0]
            ]
            conds = [
                ItsKullanilanKarekod.gtin.ilike(s),
                ItsKullanilanKarekod.serial.ilike(s),
                ItsKullanilanKarekod.batch.ilike(s),
                ItsKullanilanKarekod.uid.ilike(s)
            ]
            if matching_gtins:
                conds.append(ItsKullanilanKarekod.gtin.in_(matching_gtins))
            query = query.filter(or_(*conds))

        total = query.count()
        q_ordered = query.order_by(ItsKullanilanKarekod.detection_date.desc(), ItsKullanilanKarekod.id.desc())
        if limit and limit > 0:
            offset = max(0, (page - 1) * limit)
            rows = q_ordered.offset(offset).limit(limit).all()
        else:
            rows = q_ordered.all()

        drug_map = QRBasketService.build_gtin_to_drug_map(db, [r.gtin for r in rows])
        result = []
        for r in rows:
            short_b = MedicineCodeService.to_catalog_barcode(r.gtin)
            ilac = drug_map.get(r.gtin) or drug_map.get(short_b)
            drug_name = ilac.ad if ilac else f"Tanımsız İlaç ({r.gtin})"
            in_catalog = bool(getattr(ilac, "id", None))
            exp_str = r.expiry.strftime("%Y-%m-%d") if r.expiry else ""
            det_str = r.detection_date.strftime("%Y-%m-%d") if r.detection_date else ""
            result.append({
                "id": r.id,
                "uid": r.uid,
                "gtin": r.gtin,
                "barkod": short_b,
                "in_catalog": in_catalog,
                "ilac_id": getattr(ilac, "id", None),
                "drug_name": drug_name,
                "product_name": drug_name,
                "ad": drug_name,
                "sn": r.serial,
                "serial": r.serial,
                "bn": r.batch,
                "batch": r.batch,
                "xd": exp_str,
                "expiry": exp_str,
                "used_at": det_str,
                "detection_date": det_str,
                "kutu_ici_adet": (ilac.kutu_ici_adet or 1) if ilac else 1
            })
        eff_limit = limit if (limit and limit > 0) else max(1, total)
        return {
            "status": "success",
            "items": result,
            "total": total,
            "count": len(result),
            "page": page,
            "limit": eff_limit,
            "per_page": eff_limit,
            "total_pages": max(1, (total + eff_limit - 1) // eff_limit)
        }

    @staticmethod
    def rollback_used_to_its(
        db: Session,
        uids: Optional[List[str]] = None,
        ids: Optional[List[int]] = None
    ) -> Tuple[bool, str, int]:
        items: List[ItsKullanilanKarekod] = []
        if ids:
            clean_ids = [int(x) for x in ids if str(x).isdigit()]
            for i in range(0, len(clean_ids), QRBasketService.CHUNK_SIZE):
                chunk = clean_ids[i:i+QRBasketService.CHUNK_SIZE]
                items.extend(db.query(ItsKullanilanKarekod).filter(ItsKullanilanKarekod.id.in_(chunk)).all())
        elif uids:
            for i in range(0, len(uids), QRBasketService.CHUNK_SIZE):
                chunk = uids[i:i+QRBasketService.CHUNK_SIZE]
                items.extend(db.query(ItsKullanilanKarekod).filter(ItsKullanilanKarekod.uid.in_(chunk)).all())

        if not items:
            return False, "Seçili karekod yok.", 0

        target_uids = [it.uid for it in items]
        existing_its = set()
        for i in range(0, len(target_uids), QRBasketService.CHUNK_SIZE):
            chunk = target_uids[i:i+QRBasketService.CHUNK_SIZE]
            existing_its.update(
                r[0] for r in db.query(ItsKarekod.uid).filter(ItsKarekod.uid.in_(chunk)).all()
            )

        to_restore = [
            ItsKarekod(uid=it.uid, gtin=it.gtin, serial=it.serial, batch=it.batch, expiry=it.expiry)
            for it in items if it.uid not in existing_its
        ]
        if to_restore:
            db.bulk_save_objects(to_restore)

        for i in range(0, len(target_uids), QRBasketService.CHUNK_SIZE):
            chunk = target_uids[i:i+QRBasketService.CHUNK_SIZE]
            db.query(ItsKullanilanKarekod).filter(ItsKullanilanKarekod.uid.in_(chunk)).delete(synchronize_session=False)

        restored = len(items)
        db.commit()
        return True, f"{restored} adet kullanılan karekod Ana İTS Envanterine geri alındı.", restored

    @staticmethod
    def delete_its_used_items(
        db: Session,
        uids: Optional[List[str]] = None,
        ids: Optional[List[int]] = None
    ) -> Tuple[bool, str, int]:
        deleted = 0
        if ids:
            clean_ids = [int(x) for x in ids if str(x).isdigit()]
            for i in range(0, len(clean_ids), QRBasketService.CHUNK_SIZE):
                chunk = clean_ids[i:i+QRBasketService.CHUNK_SIZE]
                deleted += db.query(ItsKullanilanKarekod).filter(ItsKullanilanKarekod.id.in_(chunk)).delete(synchronize_session=False)
        elif uids:
            for i in range(0, len(uids), QRBasketService.CHUNK_SIZE):
                chunk = uids[i:i+QRBasketService.CHUNK_SIZE]
                deleted += db.query(ItsKullanilanKarekod).filter(ItsKullanilanKarekod.uid.in_(chunk)).delete(synchronize_session=False)
        else:
            return False, "Seçili karekod yok.", 0

        db.commit()
        return True, f"{deleted} adet kayıt Kullanılan Karekodlar listesinden silindi.", deleted

    @staticmethod
    def clear_all_its_used(db: Session) -> Tuple[bool, str]:
        c = db.query(ItsKullanilanKarekod).delete()
        db.commit()
        return True, f"Kullanılan Karekodlar listesi temizlendi ({c} kayıt silindi)."

    @staticmethod
    def delete_its_items(
        db: Session,
        uids: Optional[List[str]] = None,
        ids: Optional[List[int]] = None
    ) -> Tuple[bool, str, int]:
        QRBasketService._consolidate_expired_into_its_inventory(db)
        deleted = 0
        if ids:
            clean_ids = [int(x) for x in ids if str(x).isdigit()]
            for i in range(0, len(clean_ids), QRBasketService.CHUNK_SIZE):
                chunk = clean_ids[i:i+QRBasketService.CHUNK_SIZE]
                deleted += db.query(ItsKarekod).filter(ItsKarekod.id.in_(chunk)).delete(synchronize_session=False)
        elif uids:
            for i in range(0, len(uids), QRBasketService.CHUNK_SIZE):
                chunk = uids[i:i+QRBasketService.CHUNK_SIZE]
                deleted += db.query(ItsKarekod).filter(ItsKarekod.uid.in_(chunk)).delete(synchronize_session=False)
        else:
            return False, "Seçili karekod yok.", 0

        db.commit()
        return True, f"{deleted} adet karekod İTS envanterinden silindi.", deleted

    @staticmethod
    def reset_its_inventory(db: Session) -> Tuple[bool, str]:
        c1 = db.query(ItsKarekod).delete()
        c2 = db.query(ItsMiadiGecenKarekod).delete()
        db.commit()
        return True, f"İTS Envanteri sıfırlandı ({c1 + c2} kayıt temizlendi)."

    @staticmethod
    def get_its_dashboard(db: Session, filter_key: str = "all_valid", search: str = "", sort: str = "name ASC") -> Dict[str, Any]:
        QRBasketService._consolidate_expired_into_its_inventory(db)
        today = date.today()
        one_m = today + datetime.timedelta(days=30)
        three_m = today + datetime.timedelta(days=90)
        six_m = today + datetime.timedelta(days=180)

        total_all_cnt = db.query(func.count(ItsKarekod.id)).scalar() or 0
        all_valid_cnt = db.query(func.count(ItsKarekod.id)).filter(ItsKarekod.expiry >= today).scalar() or 0
        exp_cnt = db.query(func.count(ItsKarekod.id)).filter(ItsKarekod.expiry < today).scalar() or 0
        m1_cnt = db.query(func.count(ItsKarekod.id)).filter(ItsKarekod.expiry >= today, ItsKarekod.expiry <= one_m).scalar() or 0
        m3_cnt = db.query(func.count(ItsKarekod.id)).filter(ItsKarekod.expiry >= today, ItsKarekod.expiry <= three_m).scalar() or 0
        m6_cnt = db.query(func.count(ItsKarekod.id)).filter(ItsKarekod.expiry >= today, ItsKarekod.expiry <= six_m).scalar() or 0

        stats = {
            "total_all": total_all_cnt,
            "total": all_valid_cnt,
            "all_valid": all_valid_cnt,
            "expired": exp_cnt,
            "1m": m1_cnt,
            "3m": m3_cnt,
            "6m": m6_cnt
        }

        drug_map = QRBasketService.build_gtin_to_drug_map(db)

        q = db.query(
            ItsKarekod.gtin,
            ItsKarekod.batch,
            ItsKarekod.expiry,
            func.count(ItsKarekod.id).label("cnt")
        )
        if filter_key == "expired":
            q = q.filter(ItsKarekod.expiry < today)
        elif filter_key == "1m":
            q = q.filter(ItsKarekod.expiry >= today, ItsKarekod.expiry <= one_m)
        elif filter_key == "3m":
            q = q.filter(ItsKarekod.expiry >= today, ItsKarekod.expiry <= three_m)
        elif filter_key == "6m":
            q = q.filter(ItsKarekod.expiry >= today, ItsKarekod.expiry <= six_m)
        elif filter_key != "all":
            q = q.filter(ItsKarekod.expiry >= today)

        grouped_rows = q.group_by(ItsKarekod.gtin, ItsKarekod.batch, ItsKarekod.expiry).order_by(ItsKarekod.expiry.asc()).all()

        merged: Dict[str, Dict[str, Any]] = {}
        for r in grouped_rows:
            gtin = r.gtin
            exp_s = r.expiry.strftime("%Y-%m-%d") if r.expiry else ""
            days_left = (r.expiry - today).days if r.expiry else 9999
            bn_s = r.batch or "-"
            cnt = int(r.cnt or 0)

            if gtin not in merged:
                short_b = MedicineCodeService.to_catalog_barcode(gtin)
                ilac = drug_map.get(gtin) or drug_map.get(short_b)
                d_name = ilac.ad if ilac else f"Tanımsız İlaç ({gtin})"
                in_catalog = bool(getattr(ilac, "id", None))
                merged[gtin] = {
                    "gtin": gtin,
                    "barkod": short_b,
                    "in_catalog": in_catalog,
                    "ilac_id": getattr(ilac, "id", None),
                    "kutu_ici_adet": (ilac.kutu_ici_adet or 1) if ilac else 1,
                    "drug_name": d_name,
                    "product_name": d_name,
                    "total_boxes": 0,
                    "total_stock": 0,
                    "min_xd": exp_s,
                    "nearest_expiry": exp_s,
                    "_batch_map": {}
                }

            entry = merged[gtin]
            entry["total_boxes"] += cnt
            entry["total_stock"] += cnt
            if exp_s and (not entry["min_xd"] or exp_s < entry["min_xd"]):
                entry["min_xd"] = exp_s
                entry["nearest_expiry"] = exp_s

            b_key = (bn_s, exp_s)
            if b_key not in entry["_batch_map"]:
                entry["_batch_map"][b_key] = {
                    "bn": bn_s,
                    "batch": bn_s,
                    "xd": exp_s,
                    "expiry": exp_s,
                    "count": 0,
                    "total_quantity": 0,
                    "days_left": days_left
                }
            entry["_batch_map"][b_key]["count"] += cnt
            entry["_batch_map"][b_key]["total_quantity"] += cnt

        summary_list = []
        for gtin, entry in merged.items():
            b_list = sorted(entry.pop("_batch_map").values(), key=lambda x: (x["xd"] or "9999-12-31", x["bn"]))
            entry["batches"] = b_list
            entry["batch_count"] = len(b_list)
            summary_list.append(entry)

        if search and search.strip():
            s_low = search.strip().lower()
            summary_list = [
                item for item in summary_list
                if (
                    s_low in item["gtin"].lower()
                    or s_low in item["product_name"].lower()
                    or any(s_low in (b["bn"] or "").lower() for b in item.get("batches", []))
                )
            ]

        reverse = "DESC" in sort
        if "stock" in sort:
            summary_list.sort(key=lambda x: x["total_stock"], reverse=reverse)
        elif "expiry" in sort:
            summary_list.sort(key=lambda x: x["nearest_expiry"] or "9999-12-31", reverse=reverse)
        else:
            summary_list.sort(key=lambda x: x["product_name"].lower(), reverse=reverse)

        return {"status": "success", "stats": stats, "cards": stats, "summary": summary_list}

    @staticmethod
    def get_its_gtin_batch_detail(db: Session, gtin: str, filter_key: str = "all_valid") -> List[Dict[str, Any]]:
        QRBasketService._consolidate_expired_into_its_inventory(db)
        norm_gtin = MedicineCodeService.normalize_gtin(gtin)
        today = date.today()
        one_m = today + datetime.timedelta(days=30)
        three_m = today + datetime.timedelta(days=90)
        six_m = today + datetime.timedelta(days=180)

        q = db.query(
            ItsKarekod.batch,
            ItsKarekod.expiry,
            func.count(ItsKarekod.id).label("total_quantity")
        ).filter(ItsKarekod.gtin == norm_gtin)

        if filter_key == "expired":
            q = q.filter(ItsKarekod.expiry < today)
        elif filter_key == "1m":
            q = q.filter(ItsKarekod.expiry >= today, ItsKarekod.expiry <= one_m)
        elif filter_key == "3m":
            q = q.filter(ItsKarekod.expiry >= today, ItsKarekod.expiry <= three_m)
        elif filter_key == "6m":
            q = q.filter(ItsKarekod.expiry >= today, ItsKarekod.expiry <= six_m)
        elif filter_key in ("all_valid", "valid"):
            q = q.filter(ItsKarekod.expiry >= today)
        # filter_key in ("all", "") ise tarih filtresi uygulanmaz

        rows = q.group_by(ItsKarekod.batch, ItsKarekod.expiry).order_by(ItsKarekod.expiry.asc()).all()
        return [
            {
                "bn": r.batch,
                "batch": r.batch,
                "xd": r.expiry.strftime("%Y-%m-%d") if r.expiry else "",
                "expiry": r.expiry.strftime("%Y-%m-%d") if r.expiry else "",
                "count": r.total_quantity,
                "total_quantity": r.total_quantity,
                "days_left": (r.expiry - today).days if r.expiry else 9999
            }
            for r in rows
        ]

    # =========================================================================
    # 2. FİZİKSEL DEPO KAREKOD STOĞU & ÇOKLU DOZ & KOLİ / FEFO SERVİSLERİ
    # =========================================================================

    @staticmethod
    def record_depo_qrcodes(
        db: Session,
        depo_id: int,
        parti_id: int,
        ilac_id: int,
        kutu_ici_adet: int,
        serial_records: List[Dict[str, Any]],
        pts_no: str = "",
        giris_hareket_id: Optional[int] = None,
        also_add_to_its: bool = True
    ) -> int:
        """
        PTS veya Karekod girişinde her bir kutu karekodunu DepoKarekod tablosuna
        (ve istenirse İTS Envanterine) kaydeder.
        """
        if not serial_records:
            return 0

        kutu_doz = max(1, int(kutu_ici_adet or 1))
        now = datetime.datetime.now(datetime.timezone.utc).replace(tzinfo=None)
        to_insert_depo = []

        for rec in serial_records:
            gtin = MedicineCodeService.normalize_gtin(rec.get("gtin") or rec.get("barkod"))
            serial = str(rec.get("serial") or "").strip()
            batch = str(rec.get("batch") or rec.get("parti_no") or "VARSAYILAN").strip()
            exp_date = MedicineCodeService.parse_expiry_date(rec.get("expiry") or rec.get("skt"))
            if not gtin or not serial or not exp_date:
                continue

            uid = MedicineCodeService.make_uid(gtin, serial, batch, exp_date)
            koli_no = (rec.get("koli_no") or "").strip() or None
            paket_no = (rec.get("paket_no") or "").strip() or None
            carrier_path = (rec.get("carrier_path") or "").strip()
            if not carrier_path and (koli_no or paket_no):
                chain = [c for c in (koli_no, paket_no) if c]
                carrier_path = "|" + "|".join(chain) + "|"

            to_insert_depo.append(DepoKarekod(
                uid=uid,
                gtin=gtin,
                ilac_id=ilac_id,
                parti_id=parti_id,
                depo_id=depo_id,
                serial=serial,
                batch=batch,
                expiry=exp_date,
                koli_no=koli_no,
                paket_no=paket_no,
                carrier_path=carrier_path or None,
                pts_no=(pts_no or rec.get("pts_no") or "").strip() or None,
                kutu_ici_adet=kutu_doz,
                kalan_doz=kutu_doz,
                durum="depoda",
                giris_tarihi=now,
                giris_hareket_id=giris_hareket_id
            ))

        if to_insert_depo:
            db.bulk_save_objects(to_insert_depo)

        if also_add_to_its and serial_records:
            QRBasketService.add_qrcodes_to_its(db, serial_records, pts_no=pts_no)

        return len(to_insert_depo)

    @staticmethod
    def deduct_depo_doses_fefo(
        db: Session,
        depo_id: int,
        parti_id: int,
        dose_amount: int = 0,
        cikis_hareket_id: Optional[int] = None,
        deduct_doses: int = 0
    ) -> int:
        """
        Fiziksel depodan adet (doz) bazlı stok çıkışı yapıldığında:
        - Kutu tamamen bittiğinde (kalan_doz == 0 olduğunda) karekod 'cikis_yapildi' durumuna düşer!
        - Önce açık kutular (kalan_doz < kutu_ici_adet) bitirilir, sonra tam kutulardan düşülür.
        """
        amount = int(dose_amount or deduct_doses or 0)
        if amount <= 0:
            return 0

        active_boxes = db.query(DepoKarekod).filter(
            DepoKarekod.depo_id == depo_id,
            DepoKarekod.parti_id == parti_id,
            DepoKarekod.durum == "depoda",
            DepoKarekod.kalan_doz > 0
        ).order_by(
            DepoKarekod.kalan_doz.asc(),
            DepoKarekod.expiry.asc(),
            DepoKarekod.id.asc()
        ).all()

        remaining = amount
        finished_box_count = 0
        now = datetime.datetime.now(datetime.timezone.utc).replace(tzinfo=None)

        for box in active_boxes:
            if remaining <= 0:
                break
            consume = min(box.kalan_doz, remaining)
            box.kalan_doz -= consume
            remaining -= consume
            if box.kalan_doz <= 0:
                box.kalan_doz = 0
                box.durum = "cikis_yapildi"
                box.cikis_tarihi = now
                box.cikis_hareket_id = cikis_hareket_id
                finished_box_count += 1

        if cikis_hareket_id and finished_box_count > 0:
            hareket = db.query(StokHareketi).filter(StokHareketi.id == cikis_hareket_id).first()
            if hareket and not hareket.kutu_sayisi:
                hareket.kutu_sayisi = finished_box_count

        return finished_box_count

    @staticmethod
    def transfer_depo_qrcodes(
        db: Session,
        source_depo_id: Optional[int] = None,
        target_depo_id: Optional[int] = None,
        parti_id: int = 0,
        dose_amount: int = 0,
        kaynak_depo_id: Optional[int] = None,
        hedef_depo_id: Optional[int] = None,
        transfer_doses: int = 0
    ) -> int:
        """Depolar arası stok transferinde ilgili karekodları hedef depoya taşır."""
        src_id = source_depo_id or kaynak_depo_id
        dst_id = target_depo_id or hedef_depo_id
        amount = int(dose_amount or transfer_doses or 0)
        if not src_id or not dst_id or amount <= 0:
            return 0
        boxes = db.query(DepoKarekod).filter(
            DepoKarekod.depo_id == src_id,
            DepoKarekod.parti_id == parti_id,
            DepoKarekod.durum == "depoda",
            DepoKarekod.kalan_doz > 0
        ).order_by(DepoKarekod.kalan_doz.desc(), DepoKarekod.id.asc()).all()

        transferred_doses = 0
        moved_boxes = 0
        for box in boxes:
            if transferred_doses >= amount:
                break
            box.depo_id = dst_id
            transferred_doses += box.kalan_doz
            moved_boxes += 1
        return moved_boxes

    @staticmethod
    def check_fefo_for_depo_batch(db: Session, ilac_id: int, depo_id: int, target_miad: Optional[date]) -> Optional[Dict[str, Any]]:
        """
        Seçilen karekodun/kolinin miadını depodaki (ve tüm depolardaki) en yakın miadlı parti ile karşılaştırır.
        Daha yakın miadlı stok varsa FEFO uyarısı döner.
        """
        if not ilac_id or not target_miad:
            return None

        ilac = db.query(Ilac).filter(Ilac.id == ilac_id).first()
        if not ilac:
            return None

        q = db.query(Stok, Parti, Ilac, Depo).join(
            Parti, Stok.parti_id == Parti.id
        ).join(
            Ilac, Parti.ilac_id == Ilac.id
        ).join(
            Depo, Stok.depo_id == Depo.id
        ).filter(
            Stok.miktar > 0,
            Parti.miad.isnot(None),
            Parti.miad < target_miad,
            or_(Depo.is_toplam_depo == False, Depo.is_toplam_depo.is_(None))
        )

        if ilac.jenerik_grubu and ilac.jenerik_grubu.strip():
            q = q.filter(Ilac.jenerik_grubu == ilac.jenerik_grubu)
        elif ilac.jenerik_kodu and ilac.jenerik_kodu.strip():
            q = q.filter(Ilac.jenerik_kodu == ilac.jenerik_kodu)
        elif ilac.jenerik_adi and ilac.jenerik_adi.strip():
            q = q.filter(Ilac.jenerik_adi == ilac.jenerik_adi)
        elif ilac.etken_madde and ilac.etken_madde.strip():
            q = q.filter(Ilac.etken_madde == ilac.etken_madde)
        else:
            q = q.filter(Ilac.id == ilac_id)

        # Önce aynı depoda daha yakın miadlı var mı kontrol et
        same_depo_earlier = q.filter(Stok.depo_id == depo_id).order_by(Parti.miad.asc()).first() if depo_id else None
        earliest = same_depo_earlier or q.order_by(Parti.miad.asc()).first()

        if not earliest:
            return None

        return {
            "has_fefo_warning": True,
            "earlier_ilac_ad": earliest.Ilac.ad,
            "earlier_parti_no": earliest.Parti.parti_no,
            "earlier_miad": earliest.Parti.miad.strftime("%Y-%m-%d"),
            "earlier_depo_ad": earliest.Depo.ad,
            "earlier_depo_id": earliest.Depo.id,
            "earlier_miktar": earliest.Stok.miktar,
            "message": (
                f"FEFO UYARISI: Seçilen ürünün miadı ({target_miad.strftime('%d.%m.%Y')}) yerine "
                f"'{earliest.Depo.ad}' deposunda daha yakın miadlı ({earliest.Parti.miad.strftime('%d.%m.%Y')} - "
                f"Parti: {earliest.Parti.parti_no}, Stok: {earliest.Stok.miktar} Adet) '{earliest.Ilac.ad}' bulunmaktadır!"
            )
        }

    @staticmethod
    def lookup_depo_qr_or_koli(
        db: Session,
        scan_text: str,
        depo_id: Optional[int] = None
    ) -> Dict[str, Any]:
        """
        Karekod (GS1 DataMatrix) veya Koli/Paket No (carrierLabel) okutulduğunda
        DepoKarekod tablosundan ilgili tüm aktif karekodları (iç içe paketler dahil) bulur
        ve FEFO kontrolü yapar.
        """
        raw = str(scan_text or "").strip()
        if not raw:
            return {"status": "error", "success": False, "message": "Okutulan veri boş."}

        parsed = GS1DataMatrixParser.parse(raw)
        query = db.query(DepoKarekod).options(
            joinedload(DepoKarekod.ilac),
            joinedload(DepoKarekod.depo),
            joinedload(DepoKarekod.parti)
        ).filter(DepoKarekod.durum == "depoda", DepoKarekod.kalan_doz > 0)

        if depo_id:
            query = query.filter(DepoKarekod.depo_id == int(depo_id))

        matched_boxes: List[DepoKarekod] = []
        match_type = "qr"

        # 1. Eğer GS1 DataMatrix ise (GTIN + Serial)
        if parsed.get("is_gs1") and parsed.get("gtin") and parsed.get("serial"):
            matched_boxes = query.filter(
                DepoKarekod.gtin == parsed["gtin"],
                DepoKarekod.serial == parsed["serial"]
            ).all()
            match_type = "qr"

        # 2. Eşleşme yoksa Koli No / Paket No / Carrier Path (İç içe koliler dahil!) olarak ara
        if not matched_boxes:
            path_token = f"|{raw}|"
            matched_boxes = query.filter(
                or_(
                    DepoKarekod.koli_no == raw,
                    DepoKarekod.paket_no == raw,
                    DepoKarekod.carrier_path.contains(path_token),
                    DepoKarekod.uid == raw,
                    DepoKarekod.serial == raw
                )
            ).order_by(DepoKarekod.expiry.asc(), DepoKarekod.id.asc()).all()
            if matched_boxes and any(
                b.koli_no == raw or b.paket_no == raw or (b.carrier_path and path_token in b.carrier_path)
                for b in matched_boxes
            ):
                match_type = "koli"

        if not matched_boxes:
            return {
                "status": "error",
                "success": False,
                "message": f"'{raw}' ile eşleşen aktif depo karekodu veya kolisi bulunamadı."
            }

        items = []
        fefo_warnings = []
        checked_keys = set()

        for b in matched_boxes:
            check_key = (b.ilac_id, b.depo_id, b.expiry)
            if check_key not in checked_keys:
                checked_keys.add(check_key)
                warn = QRBasketService.check_fefo_for_depo_batch(db, b.ilac_id, b.depo_id, b.expiry)
                if warn:
                    fefo_warnings.append(warn)

            d_name = b.ilac.ad if b.ilac else f"İlaç ({b.gtin})"
            exp_s = b.expiry.strftime("%Y-%m-%d") if b.expiry else ""
            items.append({
                "id": b.id,
                "uid": b.uid,
                "gtin": b.gtin,
                "barkod": b.ilac.barkod if b.ilac else MedicineCodeService.to_catalog_barcode(b.gtin),
                "ilac_id": b.ilac_id,
                "parti_id": b.parti_id,
                "depo_id": b.depo_id,
                "depo_ad": b.depo.ad if b.depo else "",
                "drug_name": d_name,
                "product_name": d_name,
                "ad": d_name,
                "sn": b.serial,
                "serial": b.serial,
                "bn": b.batch,
                "batch": b.batch,
                "xd": exp_s,
                "expiry": exp_s,
                "koli_no": b.koli_no or "",
                "paket_no": b.paket_no or "",
                "carrier_path": b.carrier_path or "",
                "pts_no": b.pts_no or "",
                "kutu_ici_adet": b.kutu_ici_adet,
                "kalan_doz": b.kalan_doz,
                "durum": b.durum
            })

        return {
            "status": "success",
            "success": True,
            "match_type": match_type,
            "scanned_code": raw,
            "box_count": len(items),
            "total_doses": sum(it["kalan_doz"] for it in items),
            "fefo_warnings": fefo_warnings,
            "has_fefo_warning": len(fefo_warnings) > 0,
            "items": items
        }

    @staticmethod
    def execute_depo_qr_exit(
        db: Session,
        user_id: int,
        qr_ids: List[int],
        aciklama: str = "",
        also_send_to_its_transfer: bool = False
    ) -> Dict[str, Any]:
        """
        Seçilen DepoKarekod kayıtlarının (tekil karekod veya koli içindeki tüm karekodlar)
        fiziksel depo stoğundan çıkışını yapar, kutuları 'cikis_yapildi' olarak işaretler
        ve detaylı StokHareketi oluşturur.
        """
        if not qr_ids:
            return {"status": "error", "success": False, "message": "Çıkışı yapılacak karekod seçilmedi."}

        boxes = db.query(DepoKarekod).filter(
            DepoKarekod.id.in_(qr_ids),
            DepoKarekod.durum == "depoda",
            DepoKarekod.kalan_doz > 0
        ).all()

        if not boxes:
            return {"status": "error", "success": False, "message": "Seçilen karekodlar zaten çıkış yapılmış veya depoda aktif değil."}

        now = datetime.datetime.now(datetime.timezone.utc).replace(tzinfo=None)
        toplu_islem_kodu = f"QR-OUT-{datetime.datetime.now().strftime('%Y%m%d%H%M%S')}"

        grouped: Dict[Tuple[int, int], List[DepoKarekod]] = {}
        for b in boxes:
            key = (b.depo_id, b.parti_id)
            grouped.setdefault(key, []).append(b)

        total_boxes = 0
        total_doses = 0
        all_uids = []

        for (depo_id, parti_id), group_boxes in grouped.items():
            group_doses = sum(b.kalan_doz for b in group_boxes)
            koli_set = sorted(list({b.koli_no for b in group_boxes if b.koli_no}))
            pts_set = sorted(list({b.pts_no for b in group_boxes if b.pts_no}))
            koli_str = ", ".join(koli_set) if koli_set else None
            pts_str = ", ".join(pts_set) if pts_set else None
            kutu_ici = group_boxes[0].kutu_ici_adet or 1

            # Deduct from physical Stok
            stok_rows = db.query(Stok).filter(
                Stok.depo_id == depo_id,
                Stok.parti_id == parti_id,
                Stok.miktar > 0
            ).all()

            rem = group_doses
            for s_row in stok_rows:
                if rem <= 0:
                    break
                ded = min(s_row.miktar, rem)
                s_row.miktar -= ded
                rem -= ded

            koli_note = f" [Koli: {koli_str}]" if koli_str else ""
            note_prefix = aciklama.strip() if aciklama and aciklama.strip() else "Karekod/Koli ile Stok Çıkışı"
            full_note = f"{note_prefix}{koli_note} ({len(group_boxes)} Kutu / {group_doses} Adet)"

            hareket = StokHareketi(
                tarih=now,
                hareket_tipi="Toplu Çıkış" if len(boxes) > 1 else "Çıkış",
                toplu_islem_kodu=toplu_islem_kodu if len(grouped) > 1 or len(boxes) > 1 else None,
                depo_id=depo_id,
                parti_id=parti_id,
                miktar=-group_doses,
                aciklama=full_note,
                kullanici_id=user_id,
                pts_no=pts_str,
                koli_no=koli_str,
                kutu_sayisi=len(group_boxes),
                kutu_ici_adet=kutu_ici
            )
            db.add(hareket)
            db.flush()

            for b in group_boxes:
                b.kalan_doz = 0
                b.durum = "cikis_yapildi"
                b.cikis_tarihi = now
                b.cikis_hareket_id = hareket.id
                total_boxes += 1
                all_uids.append(b.uid)

            total_doses += group_doses

        if also_send_to_its_transfer and all_uids:
            QRBasketService.transfer_its_to_pool(db, uids=all_uids)

        db.commit()
        return {
            "status": "success",
            "success": True,
            "exited_count": total_boxes,
            "box_count": total_boxes,
            "total_doses": total_doses,
            "message": f"{total_boxes} kutu karekod ({total_doses} adet/doz) fiziksel depo stoğundan düşüldü ve Çıkışı Yapılan Karekodlar listesine aktarıldı."
        }

    @staticmethod
    def get_depo_qrcodes_paginated(
        db: Session,
        durum: str = "depoda",
        depo_id: Optional[int] = None,
        parti_id: Optional[int] = None,
        ilac_id: Optional[int] = None,
        koli_no: Optional[str] = None,
        pts_no: Optional[str] = None,
        box_state: Optional[str] = None,  # "all", "full", "partial", "open"
        search: str = "",
        page: int = 1,
        limit: int = 50
    ) -> Dict[str, Any]:
        # Compute stats for the depot filter
        stat_base = db.query(DepoKarekod)
        if depo_id:
            stat_base = stat_base.filter(DepoKarekod.depo_id == int(depo_id))

        active_boxes = stat_base.filter(DepoKarekod.durum == "depoda", DepoKarekod.kalan_doz > 0).count()
        active_doses = stat_base.with_entities(func.sum(DepoKarekod.kalan_doz)).filter(
            DepoKarekod.durum == "depoda", DepoKarekod.kalan_doz > 0
        ).scalar() or 0
        open_boxes = stat_base.filter(
            DepoKarekod.durum == "depoda",
            DepoKarekod.kalan_doz > 0,
            DepoKarekod.kalan_doz < DepoKarekod.kutu_ici_adet
        ).count()
        exited_boxes = stat_base.filter(DepoKarekod.durum == "cikis_yapildi").count()

        stats = {
            "active_boxes": active_boxes,
            "active_doses": int(active_doses),
            "open_boxes": open_boxes,
            "exited_boxes": exited_boxes
        }

        query = db.query(DepoKarekod).options(
            joinedload(DepoKarekod.ilac),
            joinedload(DepoKarekod.depo),
            joinedload(DepoKarekod.parti)
        )
        if durum and durum not in ("all", ""):
            query = query.filter(DepoKarekod.durum == durum)

        if depo_id:
            query = query.filter(DepoKarekod.depo_id == int(depo_id))
        if parti_id:
            query = query.filter(DepoKarekod.parti_id == int(parti_id))
        if ilac_id:
            query = query.filter(DepoKarekod.ilac_id == int(ilac_id))
        if pts_no and pts_no.strip():
            query = query.filter(DepoKarekod.pts_no == pts_no.strip())
        if koli_no and koli_no.strip():
            k_clean = koli_no.strip()
            query = query.filter(or_(
                DepoKarekod.koli_no == k_clean,
                DepoKarekod.paket_no == k_clean,
                DepoKarekod.carrier_path.contains(f"|{k_clean}|")
            ))

        if durum == "depoda" or box_state in ("full", "partial", "open"):
            if box_state == "full":
                query = query.filter(DepoKarekod.kalan_doz >= DepoKarekod.kutu_ici_adet)
            elif box_state in ("partial", "open"):
                query = query.filter(DepoKarekod.kalan_doz > 0, DepoKarekod.kalan_doz < DepoKarekod.kutu_ici_adet)

        if search and search.strip():
            s_clean = search.strip()
            s_like = f"%{s_clean}%"
            matching_ilac_ids = [
                r[0] for r in db.query(Ilac.id).filter(
                    or_(Ilac.ad.ilike(s_like), Ilac.barkod.ilike(s_like))
                ).all()
            ]
            conds = [
                DepoKarekod.gtin.ilike(s_like),
                DepoKarekod.serial.ilike(s_like),
                DepoKarekod.batch.ilike(s_like),
                DepoKarekod.koli_no.ilike(s_like),
                DepoKarekod.paket_no.ilike(s_like),
                DepoKarekod.pts_no.ilike(s_like),
                DepoKarekod.carrier_path.ilike(s_like)
            ]
            if matching_ilac_ids:
                conds.append(DepoKarekod.ilac_id.in_(matching_ilac_ids))
            query = query.filter(or_(*conds))

        total = query.count()
        offset = max(0, (page - 1) * limit)

        if durum == "cikis_yapildi":
            query = query.order_by(DepoKarekod.cikis_tarihi.desc(), DepoKarekod.id.desc())
        else:
            query = query.order_by(DepoKarekod.expiry.asc(), DepoKarekod.id.desc())

        rows = query.offset(offset).limit(limit).all()

        items = []
        for b in rows:
            d_name = b.ilac.ad if b.ilac else f"Tanımsız İlaç ({b.gtin})"
            exp_s = b.expiry.strftime("%Y-%m-%d") if b.expiry else ""
            items.append({
                "id": b.id,
                "uid": b.uid,
                "gtin": b.gtin,
                "ilac_id": b.ilac_id,
                "parti_id": b.parti_id,
                "depo_id": b.depo_id,
                "depo_ad": b.depo.ad if b.depo else "-",
                "drug_name": d_name,
                "product_name": d_name,
                "ad": d_name,
                "sn": b.serial,
                "serial": b.serial,
                "bn": b.batch,
                "batch": b.batch,
                "xd": exp_s,
                "expiry": exp_s,
                "koli_no": b.koli_no or "",
                "paket_no": b.paket_no or "",
                "carrier_path": b.carrier_path or "",
                "pts_no": b.pts_no or "",
                "kutu_ici_adet": b.kutu_ici_adet,
                "kalan_doz": b.kalan_doz,
                "durum": b.durum,
                "is_partial": 0 < b.kalan_doz < b.kutu_ici_adet,
                "giris_tarihi": b.giris_tarihi.strftime("%d.%m.%Y %H:%M") if b.giris_tarihi else "-",
                "cikis_tarihi": b.cikis_tarihi.strftime("%d.%m.%Y %H:%M") if b.cikis_tarihi else "-"
            })

        # Distinct PTS numbers and Koli numbers in depot for quick filtering & printing
        pts_list = [
            r[0] for r in db.query(DepoKarekod.pts_no).filter(
                DepoKarekod.pts_no.isnot(None), DepoKarekod.pts_no != ""
            ).distinct().all()
        ]
        koli_list = [
            r[0] for r in db.query(DepoKarekod.koli_no).filter(
                DepoKarekod.koli_no.isnot(None), DepoKarekod.koli_no != ""
            ).distinct().all()
        ]

        return {
            "status": "success",
            "stats": stats,
            "items": items,
            "total": total,
            "page": page,
            "limit": limit,
            "per_page": limit,
            "total_pages": max(1, (total + limit - 1) // limit),
            "pts_list": sorted(pts_list),
            "koli_list": sorted(koli_list)
        }

    @staticmethod
    def get_qrcodes_for_movement(
        db: Session,
        hareket_id: Optional[int] = None,
        toplu_islem_kodu: Optional[str] = None
    ) -> Dict[str, Any]:
        movement_ids = []
        if toplu_islem_kodu and toplu_islem_kodu.strip():
            movement_ids = [
                r[0] for r in db.query(StokHareketi.id).filter(
                    StokHareketi.toplu_islem_kodu == toplu_islem_kodu.strip()
                ).all()
            ]
        elif hareket_id:
            movement_ids = [int(hareket_id)]

        if not movement_ids:
            return {"items": [], "count": 0}

        rows = db.query(DepoKarekod).options(
            joinedload(DepoKarekod.ilac),
            joinedload(DepoKarekod.depo),
            joinedload(DepoKarekod.parti)
        ).filter(
            or_(
                DepoKarekod.giris_hareket_id.in_(movement_ids),
                DepoKarekod.cikis_hareket_id.in_(movement_ids)
            )
        ).order_by(DepoKarekod.id.asc()).all()

        items = []
        for b in rows:
            d_name = b.ilac.ad if b.ilac else f"Tanımsız İlaç ({b.gtin})"
            exp_s = b.expiry.strftime("%Y-%m-%d") if b.expiry else ""
            items.append({
                "id": b.id,
                "uid": b.uid,
                "gtin": b.gtin,
                "ilac_id": b.ilac_id,
                "parti_id": b.parti_id,
                "depo_id": b.depo_id,
                "depo_ad": b.depo.ad if b.depo else "-",
                "drug_name": d_name,
                "product_name": d_name,
                "ad": d_name,
                "sn": b.serial,
                "serial": b.serial,
                "bn": b.batch,
                "batch": b.batch,
                "xd": exp_s,
                "expiry": exp_s,
                "koli_no": b.koli_no or "",
                "paket_no": b.paket_no or "",
                "carrier_path": b.carrier_path or "",
                "pts_no": b.pts_no or "",
                "kutu_ici_adet": b.kutu_ici_adet,
                "kalan_doz": b.kalan_doz,
                "durum": b.durum,
                "giris_tarihi": b.giris_tarihi.strftime("%d.%m.%Y %H:%M") if b.giris_tarihi else "-",
                "cikis_tarihi": b.cikis_tarihi.strftime("%d.%m.%Y %H:%M") if b.cikis_tarihi else "-"
            })

        return {
            "status": "success",
            "items": items,
            "count": len(items),
            "pts_list": sorted(list({it["pts_no"] for it in items if it["pts_no"]})),
            "koli_list": sorted(list({it["koli_no"] for it in items if it["koli_no"]}))
        }

    # =========================================================================
    # 3. GENEL DOSYA AYRIŞTIRMA, ТОPLU GİRİŞ/ÇIKIŞ VE ETİKET METOTLARI
    # =========================================================================

    @staticmethod
    def parse_file(db: Session, file_bytes: bytes, filename: str) -> List[Dict[str, Any]]:
        fname = filename.lower()
        items = []

        if fname.endswith(".zip") or fname.endswith(".xml") or fname.endswith(".pts"):
            pts_res = parse_pts_xml(file_bytes)
            pts_items = pts_res.get("items", [])
            doc_no = pts_res.get("document_number", "")
            for item in pts_items:
                gtin = MedicineCodeService.normalize_gtin(item.get("barkod") or item.get("gtin"))
                drug_info = QRBasketService.resolve_drug_info(db, gtin)
                kutu_sayisi = item.get("kutu_sayisi") or item.get("miktar", 1)
                kutu_ici = drug_info.get("kutu_ici_adet") or 1
                items.append({
                    "gtin": gtin,
                    "serial": item["serials"][0] if item.get("serials") and len(item["serials"]) == 1 else "",
                    "serials": item.get("serials", []),
                    "serial_records": item.get("serial_records", []),
                    "batch": item.get("parti_no") or "",
                    "expiry": item.get("skt") or "",
                    "kutu_sayisi": kutu_sayisi,
                    "kutu_ici_adet": kutu_ici,
                    "miktar": kutu_sayisi * kutu_ici,
                    "koli_no": item.get("koli_no") or "",
                    "paket_no": item.get("paket_no") or "",
                    "carrier_path": item.get("carrier_path") or "",
                    "pts_no": doc_no,
                    **drug_info
                })
        elif fname.endswith(".csv") or fname.endswith(".xlsx") or fname.endswith(".xls"):
            rows_iter: List[Dict[str, str]] = []
            if fname.endswith(".csv"):
                content = file_bytes.decode("utf-8-sig", errors="ignore")
                sep = ";" if content[:2048].count(";") > content[:2048].count(",") else ","
                reader = csv.DictReader(io.StringIO(content), delimiter=sep)
                for r in reader:
                    rows_iter.append({(k or "").strip().upper(): str(v or "").strip() for k, v in r.items()})
            else:
                wb = openpyxl.load_workbook(io.BytesIO(file_bytes), read_only=True, data_only=True)
                ws = wb.active
                sheet_rows = list(ws.iter_rows(values_only=True))
                wb.close()
                if sheet_rows:
                    headers = [str(h or "").strip().upper() for h in sheet_rows[0]]
                    for r in sheet_rows[1:]:
                        rows_iter.append({
                            headers[i]: ("" if i >= len(r) or r[i] is None else str(r[i]).strip())
                            for i in range(len(headers))
                        })

            for row in rows_iter:
                gtin_raw = row.get("GTIN") or row.get("BARKOD") or row.get("BARCODE") or ""
                gtin = MedicineCodeService.normalize_gtin(gtin_raw)
                if not gtin:
                    continue
                sn = str(row.get("SERIAL") or row.get("SN") or row.get("SERI_NO") or "").strip()
                bn = str(row.get("BATCH") or row.get("BN") or row.get("LOT") or row.get("PARTI_NO") or "").strip()
                exp = str(row.get("EXPIRY") or row.get("SKT") or row.get("EXP") or row.get("EXP_DATE") or "").strip()
                qty = 1
                try:
                    qty = int(row.get("MIKTAR") or row.get("QTY") or 1)
                except ValueError:
                    qty = 1
                drug_info = QRBasketService.resolve_drug_info(db, gtin)
                kutu_ici = drug_info.get("kutu_ici_adet") or 1
                items.append({
                    "gtin": gtin,
                    "serial": sn,
                    "serials": [sn] if sn else [],
                    "serial_records": [{"gtin": gtin, "serial": sn, "batch": bn, "expiry": exp}] if sn else [],
                    "batch": bn,
                    "expiry": parse_skt(exp) if exp else "",
                    "kutu_sayisi": qty,
                    "kutu_ici_adet": kutu_ici,
                    "miktar": qty * kutu_ici,
                    **drug_info
                })

        return items

    @staticmethod
    def parse_pts_for_printing(db: Session, file_bytes: bytes, filename: str) -> Dict[str, Any]:
        """PTS XML/ZIP dosyasındaki tüm tekil karekodları etiket basımı için çıkarır."""
        pts_res = parse_pts_xml(file_bytes)
        raw_qrs = pts_res.get("raw_qrcodes", [])
        drug_map = QRBasketService.build_gtin_to_drug_map(db, [r.get("gtin", "") for r in raw_qrs])

        items = []
        for idx, r in enumerate(raw_qrs, 1):
            gtin = MedicineCodeService.normalize_gtin(r.get("gtin") or r.get("barkod"))
            ilac = drug_map.get(gtin) or drug_map.get(MedicineCodeService.to_catalog_barcode(gtin))
            d_name = ilac.ad if ilac else f"Tanımsız İlaç ({gtin})"
            sn_s = r.get("serial", "")
            bn_s = r.get("batch", "")
            exp_s = r.get("expiry", "")
            uid = MedicineCodeService.make_uid(gtin, sn_s, bn_s, exp_s)
            items.append({
                "id": idx,
                "uid": uid,
                "gtin": gtin,
                "sn": sn_s,
                "serial": sn_s,
                "bn": bn_s,
                "batch": bn_s,
                "xd": exp_s,
                "expiry": exp_s,
                "koli_no": r.get("koli_no", ""),
                "paket_no": r.get("paket_no", ""),
                "carrier_path": r.get("carrier_path", ""),
                "drug_name": d_name,
                "product_name": d_name,
                "ad": d_name
            })

        return {
            "status": "success",
            "success": True,
            "filename": filename,
            "pts_no": pts_res.get("document_number", ""),
            "document_number": pts_res.get("document_number", ""),
            "total_koli": pts_res.get("total_koli", 0),
            "count": len(items),
            "items": items
        }

    @staticmethod
    def execute_bulk_stock_in(
        db: Session,
        user_id: int,
        depo_id: int,
        items: List[Dict[str, Any]],
        aciklama: str = "",
        pts_no: str = "",
        also_add_to_its: bool = True,
        raf_konumu: str = ""
    ) -> Dict[str, Any]:
        depo = db.query(Depo).filter(Depo.id == depo_id).first()
        if not depo:
            return {"status": "error", "success": False, "message": "Seçilen depo bulunamadı."}

        if not items:
            return {"status": "error", "success": False, "message": "Stok girişi yapılacak kalem bulunamadı."}

        # Ön kontrol: Tüm kalemlerin yerel veritabanında (Ilac tablosunda) ilaç kartı olmalı.
        # İlaç kartı oluşturulmadan İTS üzerinden stok girişi yapılamaz.
        missing_cards_map: Dict[str, Dict[str, Any]] = {}
        resolved_ilac_by_gtin: Dict[str, Ilac] = {}

        for item in items:
            norm_gtin = MedicineCodeService.normalize_gtin(item.get("gtin") or item.get("barkod"))
            short_barkod = MedicineCodeService.to_catalog_barcode(norm_gtin)
            if not norm_gtin:
                continue

            if norm_gtin in resolved_ilac_by_gtin:
                continue

            ilac_id = item.get("ilac_id")
            ilac = None
            if ilac_id:
                ilac = db.query(Ilac).filter(Ilac.id == ilac_id).first()
            if not ilac:
                ilac = db.query(Ilac).filter(
                    or_(Ilac.barkod == short_barkod, Ilac.barkod == norm_gtin)
                ).first()

            if ilac:
                resolved_ilac_by_gtin[norm_gtin] = ilac
            else:
                if short_barkod not in missing_cards_map:
                    info = QRBasketService.resolve_drug_info(norm_gtin, {})
                    missing_cards_map[short_barkod] = {
                        "gtin": norm_gtin,
                        "barkod": short_barkod,
                        "drug_name": item.get("ad") or item.get("drug_name") or info["drug_name"],
                    }

        if missing_cards_map:
            missing_list = list(missing_cards_map.values())
            missing_names = ", ".join(
                f"{m['drug_name']} ({m['barkod']})" for m in missing_list[:5]
            )
            if len(missing_list) > 5:
                missing_names += f" ve {len(missing_list) - 5} ilaç daha"
            return {
                "status": "error",
                "success": False,
                "requires_drug_card": True,
                "missing_cards": missing_list,
                "message": f"İlaç kartı oluşturulmadan stok girişi yapılamaz! Lütfen önce şu ilaç(lar) için İlaç Kartı oluşturun: {missing_names}"
            }

        processed_count = 0
        total_qty = 0
        total_qr_recorded = 0
        toplu_islem_kodu = f"QR-IN-{datetime.datetime.now().strftime('%Y%m%d%H%M%S')}"
        now = datetime.datetime.now(datetime.timezone.utc).replace(tzinfo=None)

        for item in items:
            norm_gtin = MedicineCodeService.normalize_gtin(item.get("gtin") or item.get("barkod"))
            if not norm_gtin:
                continue

            ilac = resolved_ilac_by_gtin.get(norm_gtin)
            if not ilac:
                continue
            ilac_id = ilac.id

            kutu_ici = int(item.get("kutu_ici_adet") or ilac.kutu_ici_adet or 1)
            if kutu_ici > 1 and (not ilac.kutu_ici_adet or ilac.kutu_ici_adet <= 1):
                ilac.kutu_ici_adet = kutu_ici

            parti_no = (item.get("batch") or item.get("bn") or item.get("parti_no") or "VARSAYILAN").strip()
            raw_expiry = item.get("expiry") or item.get("xd") or item.get("skt")
            miad_date = MedicineCodeService.parse_expiry_date(raw_expiry) or date(2030, 12, 31)

            parti = db.query(Parti).filter(
                Parti.ilac_id == ilac_id,
                Parti.parti_no == parti_no,
                Parti.miad == miad_date
            ).first()

            if not parti:
                parti = Parti(ilac_id=ilac_id, parti_no=parti_no, miad=miad_date)
                db.add(parti)
                db.flush()

            stok = db.query(Stok).filter(
                Stok.depo_id == depo_id,
                Stok.parti_id == parti.id
            ).first()

            # Kutu sayısı ve çarpan hesabı
            serial_records = list(item.get("serial_records") or [])
            raw_serial = item.get("serial") or item.get("sn")
            if not serial_records and raw_serial:
                serial_records = [{
                    "gtin": norm_gtin,
                    "serial": str(raw_serial).strip(),
                    "batch": parti_no,
                    "expiry": miad_date.strftime("%Y-%m-%d"),
                    "koli_no": item.get("koli_no") or "",
                    "paket_no": item.get("paket_no") or "",
                    "carrier_path": item.get("carrier_path") or ""
                }]

            kutu_sayisi = int(item.get("kutu_sayisi") or (len(serial_records) if serial_records else 0) or 1)
            if "miktar" in item and item.get("miktar") is not None and not item.get("kutu_sayisi"):
                if serial_records:
                    kutu_sayisi = len(serial_records)
                    miktar = kutu_sayisi * kutu_ici
                else:
                    miktar = int(item.get("miktar") or 1)
            else:
                miktar = int(item.get("miktar") or (kutu_sayisi * kutu_ici))

            item_raf = (item.get("raf_konumu") or raf_konumu or "").strip()

            if stok:
                stok.miktar += miktar
                if item_raf:
                    stok.raf_konumu = item_raf
            else:
                stok = Stok(
                    depo_id=depo_id,
                    parti_id=parti.id,
                    miktar=miktar,
                    raf_konumu=item_raf or None
                )
                db.add(stok)
            db.flush()

            item_pts_no = pts_no or item.get("pts_no") or ""
            item_koli_no = item.get("koli_no") or ""
            hareket = StokHareketi(
                tarih=now,
                hareket_tipi="Toplu Giriş",
                toplu_islem_kodu=toplu_islem_kodu,
                depo_id=depo_id,
                parti_id=parti.id,
                miktar=miktar,
                aciklama=aciklama or f"{item_pts_no or 'İTS Karekod'} Stok Girişi ({kutu_sayisi} Kutu × {kutu_ici} = {miktar} Adet)",
                kullanici_id=user_id,
                pts_no=item_pts_no or None,
                koli_no=item_koli_no or None,
                kutu_sayisi=kutu_sayisi,
                kutu_ici_adet=kutu_ici
            )
            db.add(hareket)
            db.flush()

            if serial_records:
                total_qr_recorded += QRBasketService.record_depo_qrcodes(
                    db=db,
                    depo_id=depo_id,
                    parti_id=parti.id,
                    ilac_id=ilac_id,
                    kutu_ici_adet=kutu_ici,
                    serial_records=serial_records,
                    pts_no=item_pts_no,
                    giris_hareket_id=hareket.id,
                    also_add_to_its=also_add_to_its
                )

            processed_count += 1
            total_qty += miktar

        db.commit()
        return {
            "status": "success",
            "success": True,
            "processed_count": processed_count,
            "total_qty": total_qty,
            "total_qr_recorded": total_qr_recorded,
            "message": f"{processed_count} kalem ({total_qty} adet, {total_qr_recorded} karekod) stok girişi '{depo.ad}' deposuna yapıldı."
        }

    @staticmethod
    def execute_bulk_stock_out(
        db: Session,
        user_id: int,
        depo_id: int,
        items: List[Dict[str, Any]],
        aciklama: str = ""
    ) -> Dict[str, Any]:
        depo = db.query(Depo).filter(Depo.id == depo_id).first()
        if not depo:
            return {"success": False, "message": "Seçilen depo bulunamadı."}

        processed_count = 0
        total_qty = 0
        finished_qr_boxes = 0
        toplu_islem_kodu = f"QR-OUT-{datetime.datetime.now().strftime('%Y%m%d%H%M%S')}"
        now = datetime.datetime.now(datetime.timezone.utc).replace(tzinfo=None)

        for item in items:
            norm_gtin = MedicineCodeService.normalize_gtin(item.get("gtin") or item.get("barkod"))
            short_barkod = MedicineCodeService.to_catalog_barcode(norm_gtin)
            if not norm_gtin:
                continue

            ilac = db.query(Ilac).filter(
                or_(Ilac.barkod == short_barkod, Ilac.barkod == norm_gtin)
            ).first()
            if not ilac:
                continue

            miktar = int(item.get("miktar") or 1)
            parti_no = item.get("batch") or item.get("parti_no")

            query = db.query(Stok).join(Parti).filter(
                Stok.depo_id == depo_id,
                Parti.ilac_id == ilac.id,
                Stok.miktar > 0
            )
            if parti_no:
                stok = query.filter(Parti.parti_no == parti_no).order_by(Parti.miad.asc()).first()
            else:
                stok = query.order_by(Parti.miad.asc()).first()

            if not stok:
                continue

            cikis_miktari = min(stok.miktar, miktar)
            stok.miktar -= cikis_miktari

            hareket = StokHareketi(
                tarih=now,
                hareket_tipi="Toplu Çıkış",
                toplu_islem_kodu=toplu_islem_kodu,
                depo_id=depo_id,
                parti_id=stok.parti_id,
                miktar=-cikis_miktari,
                aciklama=aciklama or "Karekod Sepeti Toplu Stok Çıkışı",
                kullanici_id=user_id,
                kutu_ici_adet=ilac.kutu_ici_adet or 1
            )
            db.add(hareket)
            db.flush()

            finished_qr_boxes += QRBasketService.deduct_depo_doses_fefo(
                db=db,
                depo_id=depo_id,
                parti_id=stok.parti_id,
                dose_amount=cikis_miktari,
                cikis_hareket_id=hareket.id
            )

            processed_count += 1
            total_qty += cikis_miktari

        db.commit()
        return {
            "success": True,
            "processed_count": processed_count,
            "total_qty": total_qty,
            "finished_qr_boxes": finished_qr_boxes,
            "message": f"{processed_count} kalem ({total_qty} adet, {finished_qr_boxes} biten karekod kutusu) stok çıkışı '{depo.ad}' deposundan yapıldı."
        }

    @staticmethod
    def generate_zpl(items: List[Dict[str, Any]]) -> str:
        return ZintQRService.generate_zpl(items)

    @staticmethod
    def generate_pdf_labels(items: List[Dict[str, Any]], multi: bool = False) -> bytes:
        return ZintQRService.generate_pdf_labels(items, multi=multi)
