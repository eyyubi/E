import hashlib
import hmac
import os
import secrets
from typing import Annotated, Optional
from fastapi import Request, Depends
from sqlalchemy.orm import Session
from . import models, database

_PBKDF2_ITERATIONS = 260_000
_SESSION_SECRET = os.environ.get(
    "ILAC_STOK_SECRET_KEY",
    "ilac-stok-local-hmac-secret-key-2026"
).encode("utf-8")


def get_password_hash(password: str) -> str:
    """Hiçbir ek paket gerektirmeden (Python stdlib hashlib + secrets) parola hashler."""
    if not isinstance(password, str):
        password = str(password)
    salt = secrets.token_hex(16)
    dk = hashlib.pbkdf2_hmac(
        "sha256",
        password.encode("utf-8"),
        salt.encode("utf-8"),
        _PBKDF2_ITERATIONS,
    )
    return f"pbkdf2_sha256${_PBKDF2_ITERATIONS}${salt}${dk.hex()}"


def verify_password(plain_password: str, hashed_password: str) -> bool:
    """Zamanlama saldırılarına korumalı (hmac.compare_digest) parola doğrulaması."""
    if not plain_password or not hashed_password:
        return False
    if hashed_password.startswith("pbkdf2_sha256$"):
        try:
            _, iter_str, salt, digest_hex = hashed_password.split("$", 3)
            iterations = int(iter_str)
            dk = hashlib.pbkdf2_hmac(
                "sha256",
                plain_password.encode("utf-8"),
                salt.encode("utf-8"),
                iterations,
            )
            return hmac.compare_digest(dk.hex(), digest_hex)
        except (ValueError, TypeError):
            return False
    return False


def create_session_token(user_id: int) -> str:
    """Kullanıcı ID'sini standart kütüphane HMAC-SHA256 ile imzalar."""
    payload = str(user_id)
    sig = hmac.new(_SESSION_SECRET, payload.encode("utf-8"), hashlib.sha256).hexdigest()
    return f"{payload}.{sig}"


def parse_session_user_id(cookie_value: Optional[str]) -> Optional[int]:
    """İmzalı (veya geriye dönük tam sayı) oturum çerezinden kullanıcı ID'sini çözümler."""
    if not cookie_value:
        return None
    val = str(cookie_value).strip()
    if "." in val:
        uid_part, sig_part = val.split(".", 1)
        expected_sig = hmac.new(_SESSION_SECRET, uid_part.encode("utf-8"), hashlib.sha256).hexdigest()
        if not hmac.compare_digest(sig_part, expected_sig):
            return None
        val = uid_part
    try:
        return int(val)
    except (TypeError, ValueError):
        return None


def get_current_user_from_cookie(
    request: Request,
    db: Annotated[Session, Depends(database.get_db)],
) -> Optional[models.Kullanici]:
    user_id = parse_session_user_id(request.cookies.get("session_user_id"))
    if not user_id:
        return None
    return db.query(models.Kullanici).filter(models.Kullanici.id == user_id).first()

