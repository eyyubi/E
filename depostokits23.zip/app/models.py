from sqlalchemy import Column, Integer, String, Float, ForeignKey, DateTime, Date, Table, Boolean
from sqlalchemy.orm import relationship
import datetime
from .database import Base

ilac_ozellik_association = Table(
    "ilac_ozellik_map",
    Base.metadata,
    Column("ilac_id", Integer, ForeignKey("ilaclar.id", ondelete="CASCADE"), primary_key=True),
    Column("ozellik_id", Integer, ForeignKey("ilac_ozellikleri.id", ondelete="CASCADE"), primary_key=True)
)

class IlacOzellik(Base):
    __tablename__ = "ilac_ozellikleri"
    id = Column(Integer, primary_key=True, index=True)
    kod = Column(String, unique=True, index=True)
    ad = Column(String)
    renk = Column(String, default="info") # info, danger, warning, dark, secondary, primary, success
    ikon = Column(String, default="fa-shield-halved")
    aciklama = Column(String, nullable=True)
    resim_url = Column(String, nullable=True)

    ilaclar = relationship("Ilac", secondary=ilac_ozellik_association, back_populates="ozellikler")

class Kullanici(Base):
    __tablename__ = "kullanicilar"
    id = Column(Integer, primary_key=True, index=True)
    kullanici_adi = Column(String, unique=True, index=True)
    parola_hash = Column(String)
    rol = Column(String, default="user")
    
    hareketler = relationship("StokHareketi", back_populates="kullanici")

class Ilac(Base):
    __tablename__ = "ilaclar"
    id = Column(Integer, primary_key=True, index=True)
    barkod = Column(String, unique=True, index=True)
    ad = Column(String, index=True)
    etken_madde = Column(String)
    jenerik_kodu = Column(String, nullable=True, index=True)
    jenerik_adi = Column(String, nullable=True)
    jenerik_grubu = Column(String, nullable=True, index=True)
    atc_kodu = Column(String, nullable=True, index=True)
    nfc_kodu = Column(String, nullable=True, index=True)
    recete_turu = Column(String, nullable=True)
    ambalaj = Column(String, nullable=True)
    birim = Column(String)
    koli_ici_adet = Column(Integer, default=1)
    kutu_ici_adet = Column(Integer, default=1)
    raf_konumu = Column(String, nullable=True)
    uretici = Column(String)
    kritik_stok = Column(Integer, default=10)
    
    partiler = relationship("Parti", back_populates="ilac", cascade="all, delete-orphan")
    ozellikler = relationship("IlacOzellik", secondary=ilac_ozellik_association, back_populates="ilaclar")
    depo_karekodlar = relationship("DepoKarekod", back_populates="ilac", cascade="all, delete-orphan")

class JenerikKritikStok(Base):
    __tablename__ = "jenerik_kritik_stoklar"
    id = Column(Integer, primary_key=True, index=True)
    grup_kodu = Column(String, unique=True, index=True)
    grup_adi = Column(String, nullable=True)
    kritik_stok = Column(Integer, default=10)

depo_ozellik_association = Table(
    "depo_ozellik_map",
    Base.metadata,
    Column("depo_id", Integer, ForeignKey("depolar.id", ondelete="CASCADE"), primary_key=True),
    Column("ozellik_id", Integer, ForeignKey("ilac_ozellikleri.id", ondelete="CASCADE"), primary_key=True)
)

class Depo(Base):
    __tablename__ = "depolar"
    id = Column(Integer, primary_key=True, index=True)
    kod = Column(String, unique=True, index=True)
    ad = Column(String)
    aciklama = Column(String, nullable=True)
    is_toplam_depo = Column(Boolean, default=False, nullable=False)
    
    stoklar = relationship("Stok", back_populates="depo", cascade="all, delete-orphan")
    ozellikler = relationship("IlacOzellik", secondary=depo_ozellik_association)
    bloklar = relationship("WarehouseBlock", back_populates="depo", cascade="all, delete-orphan")
    lokasyonlar = relationship("WarehouseLocation", back_populates="depo", cascade="all, delete-orphan")
    karekodlar = relationship("DepoKarekod", back_populates="depo", cascade="all, delete-orphan")

class WarehouseBlock(Base):
    __tablename__ = "depo_bloklari"
    id = Column(Integer, primary_key=True, index=True)
    depo_id = Column(Integer, ForeignKey("depolar.id", ondelete="CASCADE"), index=True)
    sequence_order = Column(Integer, default=1)
    block_code = Column(String, index=True)
    block_name = Column(String)
    rack_count = Column(Integer, default=1)
    levels_per_rack = Column(Integer, default=1)
    direction = Column(String, default="ASC") # "ASC" (1->N) or "DESC" (N->1)

    depo = relationship("Depo", back_populates="bloklar")
    lokasyonlar = relationship("WarehouseLocation", back_populates="blok", cascade="all, delete-orphan")

class WarehouseLocation(Base):
    __tablename__ = "depo_lokasyonlari"
    id = Column(Integer, primary_key=True, index=True)
    depo_id = Column(Integer, ForeignKey("depolar.id", ondelete="CASCADE"), index=True)
    block_id = Column(Integer, ForeignKey("depo_bloklari.id", ondelete="CASCADE"), nullable=True, index=True)
    code = Column(String, index=True) # e.g. D2-A-R01-K01
    block_code = Column(String, index=True)
    rack_no = Column(Integer)
    level_no = Column(Integer)
    pick_sequence = Column(Integer, index=True) # Topological walking sequence: 10, 20, 30...
    check_digit = Column(String) # 2-digit verification check digit: 00..99
    is_active = Column(Boolean, default=True, nullable=False)

    depo = relationship("Depo", back_populates="lokasyonlar")
    blok = relationship("WarehouseBlock", back_populates="lokasyonlar")

class Parti(Base):
    __tablename__ = "partiler"
    id = Column(Integer, primary_key=True, index=True)
    ilac_id = Column(Integer, ForeignKey("ilaclar.id"), index=True)
    parti_no = Column(String, index=True)
    miad = Column(Date, index=True)
    koli_ici_adet = Column(Integer, default=1)
    
    ilac = relationship("Ilac", back_populates="partiler")
    stoklar = relationship("Stok", back_populates="parti", cascade="all, delete-orphan")
    hareketler = relationship("StokHareketi", back_populates="parti")
    karekodlar = relationship("DepoKarekod", back_populates="parti", cascade="all, delete-orphan")

class Stok(Base):
    __tablename__ = "stoklar"
    id = Column(Integer, primary_key=True, index=True)
    depo_id = Column(Integer, ForeignKey("depolar.id"), index=True)
    parti_id = Column(Integer, ForeignKey("partiler.id"), index=True)
    miktar = Column(Integer, default=0)
    raf_konumu = Column(String, nullable=True)
    koli_ici_adet = Column(Integer, nullable=True)
    
    depo = relationship("Depo", back_populates="stoklar")
    parti = relationship("Parti", back_populates="stoklar")

class StokHareketi(Base):
    __tablename__ = "stok_hareketleri"
    id = Column(Integer, primary_key=True, index=True)
    tarih = Column(DateTime, default=lambda: datetime.datetime.now(datetime.timezone.utc).replace(tzinfo=None), index=True)
    hareket_tipi = Column(String, index=True) # "giris", "cikis", "transfer", "sayim", "iade"
    depo_id = Column(Integer, ForeignKey("depolar.id"), index=True)
    hedef_depo_id = Column(Integer, ForeignKey("depolar.id"), nullable=True, index=True) # Sadece transferlerde
    parti_id = Column(Integer, ForeignKey("partiler.id"), index=True)
    miktar = Column(Integer)
    aciklama = Column(String, nullable=True)
    kullanici_id = Column(Integer, ForeignKey("kullanicilar.id"), index=True)
    toplu_islem_kodu = Column(String, nullable=True, index=True)
    pts_no = Column(String, nullable=True, index=True)
    koli_no = Column(String, nullable=True, index=True)
    kutu_sayisi = Column(Integer, nullable=True)
    kutu_ici_adet = Column(Integer, nullable=True)
    
    depo = relationship("Depo", foreign_keys=[depo_id])
    hedef_depo = relationship("Depo", foreign_keys=[hedef_depo_id])
    parti = relationship("Parti", back_populates="hareketler")
    kullanici = relationship("Kullanici", back_populates="hareketler")
    giris_karekodlar = relationship("DepoKarekod", foreign_keys="DepoKarekod.giris_hareket_id", back_populates="giris_hareket")
    cikis_karekodlar = relationship("DepoKarekod", foreign_keys="DepoKarekod.cikis_hareket_id", back_populates="cikis_hareket")


class ItsKarekod(Base):
    """İTS Üzerindeki Aktif Karekod Envanteri (Masaüstü Uygulaması Ana Envanteri)"""
    __tablename__ = "its_inventory"
    id = Column(Integer, primary_key=True, autoincrement=True, index=True)
    uid = Column(String, unique=True, index=True, nullable=False)
    gtin = Column(String, index=True, nullable=False)
    serial = Column(String, index=True, nullable=False)
    batch = Column(String, index=True, nullable=False)
    expiry = Column(Date, index=True, nullable=False)
    koli_no = Column(String, nullable=True, index=True)
    paket_no = Column(String, nullable=True, index=True)
    carrier_path = Column(String, nullable=True, index=True)
    pts_no = Column(String, nullable=True, index=True)
    created_at = Column(DateTime, default=lambda: datetime.datetime.now(datetime.timezone.utc).replace(tzinfo=None))


class ItsTransferKarekod(Base):
    """Kullanıcının İTS Envanterinden Seçerek CSV/Excel'e Aktarmak İçin Ayırdığı Transfer Havuzu"""
    __tablename__ = "its_transfer_pool"
    id = Column(Integer, primary_key=True, autoincrement=True, index=True)
    uid = Column(String, index=True, nullable=False)
    gtin = Column(String, index=True, nullable=False)
    serial = Column(String, index=True, nullable=False)
    batch = Column(String, nullable=False)
    expiry = Column(Date, nullable=False)
    transfer_date = Column(Date, default=datetime.date.today, index=True)
    is_exported = Column(Boolean, default=False, index=True)


class ItsKullanilanKarekod(Base):
    """Önceki İTS Dosyasında Olup Yeni Yüklenen İTS Dosyasında Olmayan (İTS'den Düşülmüş/Kullanılmış) Karekodlar"""
    __tablename__ = "its_used_medicines"
    id = Column(Integer, primary_key=True, autoincrement=True, index=True)
    uid = Column(String, index=True, nullable=False)
    gtin = Column(String, index=True, nullable=False)
    serial = Column(String, index=True, nullable=False)
    batch = Column(String, nullable=False)
    expiry = Column(Date, nullable=False)
    detection_date = Column(Date, default=datetime.date.today, index=True)


class ItsMiadiGecenKarekod(Base):
    """Miadı Geçmiş İTS Karekodları"""
    __tablename__ = "its_expired_medicines"
    id = Column(Integer, primary_key=True, autoincrement=True, index=True)
    uid = Column(String, unique=True, index=True, nullable=False)
    gtin = Column(String, index=True, nullable=False)
    serial = Column(String, index=True, nullable=False)
    batch = Column(String, nullable=False)
    expiry = Column(Date, nullable=False, index=True)
    detection_date = Column(Date, default=datetime.date.today)


class DepoKarekod(Base):
    """Fiziksel Depo Stoğundaki Karekodlar ve Çıkışı Yapılan Depo Karekodları"""
    __tablename__ = "depo_karekodlar"
    id = Column(Integer, primary_key=True, autoincrement=True, index=True)
    uid = Column(String, index=True, nullable=False)
    gtin = Column(String, index=True, nullable=False)
    ilac_id = Column(Integer, ForeignKey("ilaclar.id", ondelete="CASCADE"), nullable=True, index=True)
    parti_id = Column(Integer, ForeignKey("partiler.id", ondelete="CASCADE"), nullable=True, index=True)
    depo_id = Column(Integer, ForeignKey("depolar.id", ondelete="CASCADE"), nullable=True, index=True)
    serial = Column(String, index=True, nullable=False)
    batch = Column(String, index=True, nullable=False)
    expiry = Column(Date, index=True, nullable=False)
    koli_no = Column(String, nullable=True, index=True)
    paket_no = Column(String, nullable=True, index=True)
    carrier_path = Column(String, nullable=True, index=True)
    pts_no = Column(String, nullable=True, index=True)
    kutu_ici_adet = Column(Integer, default=1, nullable=False)
    kalan_doz = Column(Integer, default=1, nullable=False)
    durum = Column(String, default="depoda", index=True) # "depoda", "cikis_yapildi"
    giris_tarihi = Column(DateTime, default=lambda: datetime.datetime.now(datetime.timezone.utc).replace(tzinfo=None), index=True)
    cikis_tarihi = Column(DateTime, nullable=True, index=True)
    giris_hareket_id = Column(Integer, ForeignKey("stok_hareketleri.id", ondelete="SET NULL"), nullable=True, index=True)
    cikis_hareket_id = Column(Integer, ForeignKey("stok_hareketleri.id", ondelete="SET NULL"), nullable=True, index=True)

    ilac = relationship("Ilac", back_populates="depo_karekodlar")
    parti = relationship("Parti", back_populates="karekodlar")
    depo = relationship("Depo", back_populates="karekodlar")
    giris_hareket = relationship("StokHareketi", foreign_keys=[giris_hareket_id], back_populates="giris_karekodlar")
    cikis_hareket = relationship("StokHareketi", foreign_keys=[cikis_hareket_id], back_populates="cikis_karekodlar")


class ItsApiAyarlari(Base):
    """İTS ve PTS REST API Bağlantı Ayarları"""
    __tablename__ = "its_api_settings"
    id = Column(Integer, primary_key=True, autoincrement=True, index=True)
    ortam = Column(String, default="test")  # "test", "prod", "custom"
    base_url = Column(String, default="https://itstest2.saglik.gov.tr")
    username = Column(String, nullable=True)
    password = Column(String, nullable=True)
    gln_no = Column(String, nullable=True)
    updated_at = Column(DateTime, default=lambda: datetime.datetime.now(datetime.timezone.utc).replace(tzinfo=None))
