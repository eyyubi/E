console.log("İlaç Stok Yönetim Sistemi Başlatıldı.");

/**
 * A4 Yazdırma Yardımcısı
 * Ekranda görüntülenen mevcut filtreli liste veya evrağı A4 formatında yazdırmak üzere hazırlar.
 */
function printA4View(docTitle) {
    const title = docTitle || "Rapor ve Liste Çıktısı";
    const printDate = new Date().toLocaleString('tr-TR');

    let userEl = document.querySelector('#navbarDropdown');
    let userName = userEl ? userEl.innerText.trim() : 'Sistem';

    let countEl = document.getElementById('visibleDrugCount') || document.querySelector('.visible-count');
    let countText = countEl ? countEl.innerText.trim() : '';

    let printHeader = document.getElementById('a4PrintHeader');
    if (!printHeader) {
        printHeader = document.createElement('div');
        printHeader.id = 'a4PrintHeader';
        printHeader.className = 'd-none d-print-block mb-3 border-bottom pb-2';
        document.body.prepend(printHeader);
    }

    printHeader.innerHTML = `
        <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 2.5px solid #176b87; padding-bottom: 8px; margin-bottom: 12px;">
            <div>
                <h3 style="margin: 0; font-size: 16pt; font-weight: 700; color: #176b87; font-family: sans-serif;">İlaçStok <span style="font-size: 11pt; font-weight: 400; color: #444;">| ${title}</span></h3>
                <small style="color: #555; font-size: 8.5pt;">Yazdırma Tarihi: ${printDate} | İşlemi Yapan: ${userName} ${countText ? '| Toplam Kayıt: ' + countText : ''}</small>
            </div>
            <div style="text-align: right;">
                <span style="font-size: 8.5pt; font-weight: 700; background: #e7f3f4; color: #176b87; padding: 4px 10px; border-radius: 4px; border: 1px solid #176b87; font-family: sans-serif;">A4 RESMİ EVRAK / ÇIKTI</span>
            </div>
        </div>
    `;

    window.print();
}

// <main class="fade-in"> içindeki transform kaynaklı stacking context nedeniyle
// .modal-backdrop'un modalların önüne geçmesini önlemek için tüm modalları body'ye taşı
document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('main .modal').forEach(modalEl => {
        document.body.appendChild(modalEl);
    });
});

document.addEventListener('show.bs.modal', (event) => {
    const modalEl = event.target;
    if (modalEl && modalEl.parentElement !== document.body) {
        document.body.appendChild(modalEl);
    }
});
