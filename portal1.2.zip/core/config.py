import os
import socket
from pathlib import Path
from typing import List
from pydantic import BaseModel, Field

# Base directories
BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
DATA_DIR.mkdir(parents=True, exist_ok=True)

# Database Paths (Unified single source of truth in data/)
MASTER_DB_PATH = Path(os.getenv("MASTER_DB_PATH", str(DATA_DIR / "medication_db.sqlite")))
STOK_DB_PATH = Path(os.getenv("STOK_DB_PATH", str(DATA_DIR / "stok.db")))
SERUM_DB_PATH = Path(os.getenv("SERUM_DB_PATH", str(DATA_DIR / "serumfiltre.db")))
RECETE_DB_PATH = Path(os.getenv("MEDRECETE_DB", str(DATA_DIR / "recete.db")))
ETIKET_DB_PATH = Path(os.getenv("ETIKET_DB_PATH", str(DATA_DIR / "etiket.db")))
SETTINGS_FILE = Path(os.getenv("FILTER_SETTINGS_PATH", str(DATA_DIR / "filter_settings.json")))

# Database URLs
MASTER_DATABASE_URL = f"sqlite:///{MASTER_DB_PATH}"
STOK_DATABASE_URL = f"sqlite:///{STOK_DB_PATH}"
SERUM_DATABASE_URL = f"sqlite:///{SERUM_DB_PATH}"
RECETE_DATABASE_URL = f"sqlite:///{RECETE_DB_PATH}"
ETIKET_DATABASE_URL = f"sqlite:///{ETIKET_DB_PATH}"

# Network and Host configuration
HOST = os.getenv("HOST", os.getenv("APP_HOST", "0.0.0.0"))
PORT = int(os.getenv("PORT", os.getenv("APP_PORT", 8000)))

def get_lan_ip() -> str:
    """Yerel ağ IP adresini tespit eder (örn: 192.168.1.xxx)"""
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(('10.255.255.255', 1))
        ip = s.getsockname()[0]
    except Exception:
        ip = '127.0.0.1'
    finally:
        s.close()
    return ip

class FilterConfig(BaseModel):
    """Serum Filtre kategori kuralları yapılandırma modeli"""
    group1_name: str = "Tablet Grubu"
    group1_nfc_prefixes: List[str] = ["A", "B"]
    
    group2_name: str = "Serum & Mama Grubu"
    group2_generic_codes: List[str] = Field(default_factory=list)
    group2_barcodes: List[str] = Field(default_factory=list)
    
    group3_name: str = "Diğer İlaçlar"

class Settings:
    PROJECT_NAME: str = "Klinik Eczane & İlaç Yönetim Platformu"
    VERSION: str = "2.5.0"
    HOST: str = HOST
    PORT: int = PORT
    DATABASE_URL: str = MASTER_DATABASE_URL
    MASTER_DB_PATH: Path = MASTER_DB_PATH
    STOK_DB_PATH: Path = STOK_DB_PATH
    RECETE_DB_PATH: Path = RECETE_DB_PATH
    ETIKET_DB_PATH: Path = ETIKET_DB_PATH
    SETTINGS_FILE: Path = SETTINGS_FILE

settings = Settings()
