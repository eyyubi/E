"""Core package for shared configurations and database management."""
from core.config import settings, HOST, PORT, MASTER_DB_PATH, STOK_DB_PATH, RECETE_DB_PATH, ETIKET_DB_PATH
from core.database import (
    master_engine, MasterSessionLocal, MasterBase, get_master_db,
    stok_engine, StokSessionLocal, StokBase, get_stok_db,
    etiket_engine, EtiketSessionLocal, EtiketBase, get_etiket_db,
    get_recete_db_conn, recete_db_session, init_all_databases
)

__all__ = [
    "settings", "HOST", "PORT", "MASTER_DB_PATH", "STOK_DB_PATH", "RECETE_DB_PATH", "ETIKET_DB_PATH",
    "master_engine", "MasterSessionLocal", "MasterBase", "get_master_db",
    "stok_engine", "StokSessionLocal", "StokBase", "get_stok_db",
    "etiket_engine", "EtiketSessionLocal", "EtiketBase", "get_etiket_db",
    "get_recete_db_conn", "recete_db_session", "init_all_databases"
]
