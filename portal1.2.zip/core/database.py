import sqlite3
import unicodedata
from contextlib import contextmanager
from typing import Iterator
from sqlalchemy import create_engine
from sqlalchemy.orm import declarative_base, sessionmaker

from core.config import (
    MASTER_DATABASE_URL,
    MASTER_DB_PATH,
    STOK_DATABASE_URL,
    STOK_DB_PATH,
    SERUM_DATABASE_URL,
    SERUM_DB_PATH,
    RECETE_DATABASE_URL,
    RECETE_DB_PATH,
    ETIKET_DATABASE_URL,
    ETIKET_DB_PATH,
)

# ── 1. Master Veritabanı (medication_db.sqlite - Ortak Master Referans) ───────
# Master veritabanı SADECE ilaç referans verilerini içerir (products, generics,
# teb_active_ingredients, atc_codes, nfc_codes, master_ilaclar, substances_bilingual).
# Numune, serum filtre ve medreçeteden hiçbir kullanıcı verisi buraya kaydedilmez.
master_engine = create_engine(
    MASTER_DATABASE_URL,
    connect_args={"check_same_thread": False}
)
MasterSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=master_engine)
MasterBase = declarative_base()

def get_master_db():
    """FastAPI bağımlılığı: Master DB oturumu (Salt-Okunur İlaç Kataloğu)"""
    db = MasterSessionLocal()
    try:
        yield db
    finally:
        db.close()


# ── 2. Serum Filtre Veritabanı (serumfiltre.db - Servisler, Raporlar, Aliaslar) ───
serum_engine = create_engine(
    SERUM_DATABASE_URL,
    connect_args={"check_same_thread": False}
)
SerumSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=serum_engine)
SerumBase = declarative_base()

# Geriye dönük uyumluluk takma adları (serumfiltre modelleri için)
Base = SerumBase
engine = serum_engine
SessionLocal = SerumSessionLocal

def _ensure_serum_columns():
    try:
        with sqlite3.connect(str(SERUM_DB_PATH)) as s_conn:
            svc_cols = [row[1] for row in s_conn.execute("PRAGMA table_info(hospital_services)").fetchall()]
            if svc_cols and "extension" not in svc_cols:
                s_conn.execute("ALTER TABLE hospital_services ADD COLUMN extension VARCHAR(30) DEFAULT ''")
            rep_cols = [row[1] for row in s_conn.execute("PRAGMA table_info(report_history)").fetchall()]
            if rep_cols and "service_extension" not in rep_cols:
                s_conn.execute("ALTER TABLE report_history ADD COLUMN service_extension VARCHAR(30) DEFAULT ''")
            s_conn.commit()
    except Exception:
        pass

_ensure_serum_columns()

def get_serum_db():
    """FastAPI bağımlılığı: Serum Filtre DB oturumu"""
    db = SerumSessionLocal()
    try:
        yield db
    finally:
        db.close()

get_db = get_serum_db


# ── 3. Stok Veritabanı (stok.db - Numune İlaç ve Miad Takibi) ─────────────────
stok_engine = create_engine(
    STOK_DATABASE_URL,
    connect_args={"check_same_thread": False}
)
StokSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=stok_engine)
StokBase = declarative_base()

def get_stok_db():
    """FastAPI bağımlılığı: Stok DB oturumu"""
    db = StokSessionLocal()
    try:
        yield db
    finally:
        db.close()


# ── 4. Reçete Veritabanı (recete.db - Medikal Reçete & Kalemleri) ──────────────
_TR_TRANS = str.maketrans("İIÜÖŞĞÇ", "IIUOSGC")

def normalize_text(s) -> str:
    """Türkçe karakterleri ve aksanları sadeleştirip BÜYÜK harfe çevirir."""
    if s is None:
        return ""
    s = str(s).strip().upper().translate(_TR_TRANS)
    s = unicodedata.normalize("NFKD", s)
    return "".join(ch for ch in s if not unicodedata.combining(ch))

def configure_sqlite_connection(conn: sqlite3.Connection) -> sqlite3.Connection:
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute("PRAGMA busy_timeout = 30000")
    conn.execute("PRAGMA synchronous = NORMAL")
    conn.execute("PRAGMA temp_store = MEMORY")
    conn.create_function("NORMALIZE", 1, normalize_text, deterministic=True)
    return conn

def _init_recete_schema(conn: sqlite3.Connection):
    """Reçete veritabanının şemasını oluşturur."""
    conn.executescript("""
    CREATE TABLE IF NOT EXISTS prescriptions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        patient_name TEXT,
        doctor_name TEXT NOT NULL,
        prescription_date TEXT NOT NULL,
        created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%S', 'now', 'localtime')),
        updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%S', 'now', 'localtime'))
    );
    CREATE TABLE IF NOT EXISTS prescription_items (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        prescription_id INTEGER NOT NULL,
        product_barcode TEXT,
        product_name TEXT NOT NULL,
        quantity INTEGER NOT NULL CHECK (quantity > 0),
        notes TEXT,
        FOREIGN KEY (prescription_id) REFERENCES prescriptions (id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS app_settings (
        key TEXT PRIMARY KEY,
        value TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_prescriptions_date ON prescriptions (prescription_date);
    CREATE INDEX IF NOT EXISTS idx_prescription_items_pid ON prescription_items (prescription_id);
    """)

def get_recete_db_conn() -> sqlite3.Connection:
    """Reçete veritabanına yeni bir SQLite bağlantısı döndürür."""
    conn = configure_sqlite_connection(sqlite3.connect(str(RECETE_DB_PATH), timeout=30))
    _init_recete_schema(conn)
    return conn

@contextmanager
def recete_db_session() -> Iterator[sqlite3.Connection]:
    """Başarıda commit, hatada rollback yapan bağlam yöneticisi."""
    conn = get_recete_db_conn()
    try:
        yield conn
        conn.commit()
    except BaseException:
        conn.rollback()
        raise
    finally:
        conn.close()


# ── 5. Etiket Veritabanı (etiket.db - Dinamik Tablet & Blister Şablonları) ─────
etiket_engine = create_engine(
    ETIKET_DATABASE_URL,
    connect_args={"check_same_thread": False}
)
EtiketSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=etiket_engine)
EtiketBase = declarative_base()

def get_etiket_db():
    """FastAPI bağımlılığı: Etiket DB oturumu (SQLAlchemy Ortak Şablonlar)"""
    db = EtiketSessionLocal()
    try:
        yield db
    finally:
        db.close()


# ── 6. Merkezi Başlatma ve Tablo Doğrulama ────────────────────────────────────
def init_all_databases():
    """Tüm sistem veritabanlarını başlatır ve gerekli şemaları hazırlar."""
    # 1. Master DB temizliği ve iki dilli etken madde görünümü
    # Master DB'de sadece ilaç verisi olacak; numune, serum filtre veya medreçete tabloları olmayacak.
    try:
        with sqlite3.connect(str(MASTER_DB_PATH)) as m_conn:
            # Serumfiltre'den master'a sızmış tablolar varsa kaldır
            m_conn.execute("DROP TABLE IF EXISTS hospital_services")
            m_conn.execute("DROP TABLE IF EXISTS report_history")
            m_conn.execute("DROP TABLE IF EXISTS drug_aliases")
            m_conn.execute("DROP TABLE IF EXISTS prescriptions")
            m_conn.execute("DROP TABLE IF EXISTS prescription_items")
            
            # İki dilli etken madde görünümü (Türkçe <-> İngilizce kod eşleşmesi)
            m_conn.execute("""
            CREATE VIEW IF NOT EXISTS substances_bilingual AS
            SELECT 
                etkin_madde_id,
                MAX(CASE WHEN dil = 'tr' THEN etkin_madde END) as tr_name,
                MAX(CASE WHEN dil = 'en' THEN etkin_madde END) as en_name
            FROM teb_active_ingredients
            GROUP BY etkin_madde_id;
            """)
            
            # Arama performans indeksleri
            m_conn.execute("CREATE INDEX IF NOT EXISTS idx_products_urun_adi ON products (urun_adi);")
            m_conn.execute("CREATE INDEX IF NOT EXISTS idx_products_barkod ON products (barkod);")
            m_conn.execute("CREATE INDEX IF NOT EXISTS idx_products_jenerik ON products (jenerik_kodu);")
            m_conn.commit()
    except Exception as e:
        print(f"[Master DB Init] Uyarı: {e}")

    # 2. Serum filtre tabloları (hospital_services, report_history, drug_aliases -> serumfiltre.db)
    try:
        import serumfiltre.app.models.service
        import serumfiltre.app.models.report
        import serumfiltre.app.models.drug_alias
    except Exception as e:
        print(f"[Serumfiltre Models Import] Uyarı: {e}")
    SerumBase.metadata.create_all(bind=serum_engine)
    try:
        with sqlite3.connect(str(SERUM_DB_PATH)) as s_conn:
            svc_cols = [row[1] for row in s_conn.execute("PRAGMA table_info(hospital_services)").fetchall()]
            if "extension" not in svc_cols:
                s_conn.execute("ALTER TABLE hospital_services ADD COLUMN extension VARCHAR(30) DEFAULT ''")
            rep_cols = [row[1] for row in s_conn.execute("PRAGMA table_info(report_history)").fetchall()]
            if "service_extension" not in rep_cols:
                s_conn.execute("ALTER TABLE report_history ADD COLUMN service_extension VARCHAR(30) DEFAULT ''")
            cnt = s_conn.execute("SELECT COUNT(*) FROM hospital_services").fetchone()[0]
            if cnt == 0:
                default_services = [
                    ("Acil Servis", "Zemin Kat", "ACIL"),
                    ("Dahiliye", "1. Kat", "DAH"),
                    ("Genel Cerrahi", "2. Kat", "CER"),
                    ("Yoğun Bakım", "3. Kat", "YB"),
                    ("Göğüs Hastalıkları", "4. Kat", "GOG"),
                    ("Gastroenteroloji", "5. Kat", "GAS"),
                ]
                s_conn.executemany("INSERT INTO hospital_services (name, floor, code) VALUES (?, ?, ?)", default_services)
            s_conn.commit()
    except Exception as e:
        print(f"[Serumfiltre Services Init] Uyarı: {e}")

    # 3. Stok tabloları (stok, miad_gecmis, receteler -> stok.db)
    try:
        import numuneilaclar.app.infrastructure.orm_models
    except Exception as e:
        print(f"[Stok Models Import] Uyarı: {e}")
    StokBase.metadata.create_all(bind=stok_engine)

    # 4. Reçete tabloları (prescriptions, prescription_items, app_settings -> recete.db)
    with get_recete_db_conn() as r_conn:
        pass

    # 5. Etiket tabloları (blister_templates -> etiket.db)
    try:
        import etiket.models  # Modelleri EtiketBase'e bağlar
    except Exception as e:
        print(f"[Etiket Models Import] Uyarı: {e}")
    EtiketBase.metadata.create_all(bind=etiket_engine)
    try:
        with sqlite3.connect(str(ETIKET_DB_PATH)) as e_conn:
            cols = [row[1] for row in e_conn.execute("PRAGMA table_info(blister_templates)").fetchall()]
            if "font_size" not in cols:
                e_conn.execute("ALTER TABLE blister_templates ADD COLUMN font_size REAL")
                e_conn.commit()
    except Exception as e:
        print(f"[Etiket DB Migration] Uyarı: {e}")

    # 6. WAL modu ayarları (eşzamanlı yüksek okuma/yazma performansı için)
    for db_file in [str(MASTER_DB_PATH), str(SERUM_DB_PATH), str(STOK_DB_PATH), str(RECETE_DB_PATH), str(ETIKET_DB_PATH)]:
        try:
            with sqlite3.connect(db_file) as conn:
                conn.execute("PRAGMA journal_mode = WAL")
        except Exception:
            pass

