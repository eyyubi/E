/**
 * Kusursuz A4 ve Etiket Baskı Yöneticisi (Print Manager)
 * 
 * - A4 tek sütun, 40 kaleme kadar okunaklı ve izlenebilir satırlar.
 * - Sütun sıralaması: İsim %72, Miktar %10, Raf %13, Tik %5.
 * - Çıktı başlıklarında Servis ve Bulunduğu Kat bilgisi gösterilir.
 * - Etiket için: İlaç İsmi, Miktar ve Raf belirgin olarak görüntülenir.
 * - İzole iframe üzerinden yazdırılır (asla bozulma olmaz).
 */
class PrintManager {
  /**
   * Tarih formatlayıcı
   */
  static getFormattedDate() {
    const now = new Date();
    const d = String(now.getDate()).padStart(2, '0');
    const m = String(now.getMonth() + 1).padStart(2, '0');
    const y = now.getFullYear();
    const h = String(now.getHours()).padStart(2, '0');
    const min = String(now.getMinutes()).padStart(2, '0');
    return `${d}.${m}.${y} ${h}:${min}`;
  }

  /**
   * İzole iframe ile yazdırma (Sıfır bozulma garantisi)
   */
  static printHtmlViaIframe(htmlContent, pageCss) {
    let iframe = document.getElementById("hiddenPrintIframe");
    if (!iframe) {
      iframe = document.createElement("iframe");
      iframe.id = "hiddenPrintIframe";
      iframe.style.position = "fixed";
      iframe.style.right = "0";
      iframe.style.bottom = "0";
      iframe.style.width = "0";
      iframe.style.height = "0";
      iframe.style.border = "none";
      document.body.appendChild(iframe);
    }

    const doc = iframe.contentWindow.document;
    doc.open();
    doc.write(`
      <!DOCTYPE html>
      <html lang="tr">
      <head>
        <meta charset="UTF-8">
        <title>İlaç Raporu Baskı</title>
        <style>
          ${pageCss}
        </style>
      </head>
      <body>
        ${htmlContent}
      </body>
      </html>
    `);
    doc.close();

    setTimeout(() => {
      iframe.contentWindow.focus();
      iframe.contentWindow.print();
    }, 250);
  }

  /**
   * A4 Baskı CSS Stilleri
   */
  static getA4PrintStyles() {
    return `
      * {
        box-sizing: border-box;
        margin: 0;
        padding: 0;
      }
      @page {
        size: A4 portrait;
        margin: 5mm 7mm;
      }
      body {
        font-family: Arial, "Helvetica Neue", Helvetica, sans-serif;
        color: #000000;
        background: #ffffff;
        font-size: 9pt;
        line-height: 1.15;
        -webkit-print-color-adjust: exact !important;
        print-color-adjust: exact !important;
      }
      .a4-container {
        width: 100%;
      }

      /* Rapor başlığı */
      .header-compact {
        border-bottom: 1.2pt solid #334155;
        padding-bottom: 1.5mm;
        margin-bottom: 2mm;
        display: flex;
        justify-content: space-between;
        align-items: center;
      }
      .header-title-main {
        font-size: 12pt;
        font-weight: 900;
        letter-spacing: -0.01em;
        text-transform: uppercase;
      }
      .header-title-sub {
        font-size: 8pt;
        color: #444444;
        font-weight: 600;
        margin-top: 0.3mm;
      }
      .header-meta {
        text-align: right;
        font-size: 8pt;
        font-family: monospace;
      }
      .header-meta strong {
        font-size: 9pt;
        color: #000000;
      }

      /* Tek Sütun Tablo */
      .med-table {
        width: 100% !important;
        border-collapse: collapse !important;
        table-layout: fixed !important;
        margin-bottom: 2mm;
      }
      .med-table thead {
        display: table-header-group;
      }
      .med-table th {
        background: #e8eef5 !important;
        border: 0.6pt solid #64748b;
        padding: 1mm 1.2mm;
        font-size: 8pt;
        font-weight: 800;
        text-align: left;
        letter-spacing: 0.02em;
      }
      .med-table th:not(:first-child) {
        text-align: center;
      }
      .med-table td {
        border: 0.45pt solid #aeb9c6;
        padding: 0.7mm 1.2mm;
        font-size: 8.5pt;
        vertical-align: middle;
        white-space: normal;
        overflow: visible;
        overflow-wrap: anywhere;
      }
      .med-table tbody tr.item-row:nth-child(even) {
        background: #f5f8fb !important;
      }
      .med-table .item-row {
        break-inside: avoid;
        page-break-inside: avoid;
      }

      /* Grup Başlık Satırı */
      .group-row {
        background-color: #e2e8f0 !important;
        font-weight: 900;
        font-size: 9pt;
        text-transform: uppercase;
        padding: 1.2mm 1.5mm !important;
        border: 0.8pt solid #64748b !important;
        break-after: avoid;
        page-break-after: avoid;
      }
      .group-row-serum  { background-color: #cffafe !important; }
      .group-row-tablet { background-color: #fef3c7 !important; }
      .group-row-diger  { background-color: #e2e8f0 !important; }

      /* Sütun Oranları: İsim %72, Miktar %10, Raf %13, Tik %5 */
      .col-drug {
        width: 72% !important;
        padding: 0.7mm 1.2mm !important;
        white-space: normal !important;
        overflow: visible !important;
        overflow-wrap: anywhere !important;
      }
      .drug-cell {
        display: flex;
        align-items: baseline;
        flex-wrap: wrap;
        column-gap: 1mm;
        width: 100%;
      }
      .drug-kisa {
        display: inline;
        font-weight: 900;
        font-size: 9pt;
        white-space: normal;
        overflow-wrap: anywhere;
      }
      .drug-tam-isim {
        display: inline;
        font-size: 7.5pt;
        color: #555555;
        font-weight: 400;
        white-space: normal;
        overflow-wrap: anywhere;
      }
      .drug-text-full {
        display: inline;
        width: 100%;
        font-weight: 700;
        font-size: 8.5pt;
        white-space: normal;
        overflow-wrap: anywhere;
      }
      .col-qty {
        width: 10% !important;
        text-align: center !important;
        font-weight: 900;
        font-family: monospace;
        white-space: nowrap;
        font-size: 9pt !important;
      }
      .col-raf {
        width: 13% !important;
        text-align: center !important;
        font-family: monospace;
        font-weight: 800;
        white-space: nowrap;
        font-size: 8pt !important;
      }
      .col-chk {
        width: 5% !important;
        text-align: center !important;
        white-space: nowrap;
      }
      .chk-box {
        display: inline-block;
        width: 11px;
        height: 11px;
        border: 1pt solid #334155;
        background-color: #ffffff !important;
        vertical-align: middle;
      }

      /* Alt Bilgi */
      .a4-footer {
        border-top: 0.8pt solid #64748b;
        padding-top: 1.5mm;
        margin-top: 2mm;
        display: flex;
        justify-content: space-between;
        align-items: center;
        font-size: 7.5pt;
        color: #333333;
      }
      .sig-block {
        display: flex;
        gap: 8mm;
      }
      .sig-cell {
        border-top: 0.8pt dashed #000000;
        width: 28mm;
        text-align: center;
        padding-top: 0.8mm;
        font-size: 7pt;
      }
    `;
  }

  /**
   * Grup başlığını olabildiğince kısaltır
   */
  static getShortGroupTitle(groupOrName) {
    const key = typeof groupOrName === "object" && groupOrName ? (groupOrName.key || "") : "";
    const rawName = typeof groupOrName === "object" && groupOrName ? (groupOrName.name || "") : String(groupOrName || "");
    if (key === "tablet" || /tablet/i.test(rawName)) return "TABLET";
    if (key === "serum" || /serum/i.test(rawName)) return "SERUM/MAMA";
    if (key === "diger" || /diğer|diger/i.test(rawName)) return "DİĞER";
    return rawName
      .replace(/\s*Grubu\s*/gi, "")
      .replace(/\s*İlaçlar\s*/gi, "")
      .trim()
      .toUpperCase() || "GRUP";
  }

  /**
   * 3 Grubu Bir Arada İçeren A4 HTML Üretici (Servis, Kat ve Dahili No Bilgili)
   */
  static buildCombinedA4Html(categorizeData, service = null) {
    if (!categorizeData) return "";

    const islemNo = categorizeData.islem_no || "-";
    const dateStr = PrintManager.getFormattedDate();
    const totalKalem = categorizeData.toplam_kalem || 0;
    const totalAdet = categorizeData.toplam_adet || 0;

    let serviceMainTitle = "SERVİS: GENEL";
    if (service && service.name) {
      const floorPart = service.floor ? ` (${service.floor.toUpperCase()})` : "";
      const extPart = service.extension ? ` — DAHİLİ: ${service.extension}` : "";
      serviceMainTitle = `SERVİS: ${service.name.toUpperCase()}${floorPart}${extPart}`;
    }

    const groupOrder = [
      { key: "tablet", name: "1. TABLET", class: "group-row-tablet" },
      { key: "diger", name: "2. DİĞER", class: "group-row-diger" },
      { key: "serum", name: "3. SERUM/MAMA", class: "group-row-serum" }
    ];

    let rowsHtml = "";

    groupOrder.forEach(gDef => {
      const g = categorizeData.gruplar[gDef.key];
      const items = g ? g.items : [];
      const count = g ? g.item_count : 0;
      const qty = g ? g.total_quantity : 0;

      rowsHtml += `
        <tr>
          <td colspan="4" class="group-row ${gDef.class}">
            ${gDef.name} &nbsp;—&nbsp; ${count} KALEM / ${qty} ADET
          </td>
        </tr>
      `;

      if (items.length === 0) {
        rowsHtml += `
          <tr class="item-row">
            <td colspan="4" style="text-align: center; color: #777; font-size: 10pt; padding: 2px;">
              - Bu grupta ilaç kaydı bulunmamaktadır -
            </td>
          </tr>
        `;
      } else {
        items.forEach(item => {
          const raf = item.raf_konumu && item.raf_konumu !== "-" ? item.raf_konumu : "RAF YOK";
          const urunAdi = item.urun_adi || "Tanımsız İlaç";
          const miktar = item.toplam_miktar || 1;

          // A4 raporunda yalnızca tam ilaç ismi gösterilir (kısa isim gösterilmez)
          const drugDisplay = `<span class="drug-text-full">${urunAdi}</span>`;

          rowsHtml += `
            <tr class="item-row">
              <!-- 1. İlaç (%80 - Tam Görünüm) -->
              <td class="col-drug">
                <div class="drug-cell" title="${urunAdi}">${drugDisplay}</div>
              </td>
              <!-- 2. Miktar (%7) -->
              <td class="col-qty">${miktar}</td>
              <!-- 3. Raf (%9) -->
              <td class="col-raf" title="${raf}">${raf}</td>
              <!-- 4. Tik (%4) -->
              <td class="col-chk"><span class="chk-box"></span></td>
            </tr>
          `;
        });
      }
    });

    return `
      <div class="a4-container">
        <!-- Minimal üst başlık (Servis İsmi, Kat, Dahili No & İşlem No Odaklı) -->
        <div class="header-compact">
          <div>
            <div class="header-title-main">${serviceMainTitle}</div>
            <div class="header-title-sub">İLAÇ TOPLAMA VE DAĞITIM LİSTESİ</div>
          </div>
          <div class="header-meta">
            <div>İŞLEM NO: <strong>${islemNo}</strong></div>
            <div>${dateStr} &nbsp;|&nbsp; <strong>${totalKalem} Kalem (${totalAdet} Adet)</strong></div>
          </div>
        </div>

        <!-- Tek Sütun Tablo -->
        <table class="med-table">
          <colgroup>
            <col style="width: 72%;">
            <col style="width: 10%;">
            <col style="width: 13%;">
            <col style="width: 5%;">
          </colgroup>
          <thead>
            <tr>
              <th>İLAÇ ADI</th>
              <th>MİKTAR</th>
              <th>RAF</th>
              <th>✓</th>
            </tr>
          </thead>
          <tbody>
            ${rowsHtml}
          </tbody>
        </table>

        <!-- Alt Bilgi & İmzalar -->
        <div class="a4-footer">
          <div>* Raftan toplanan ilaçların sağındaki <strong>[ ]</strong> kutusunu işaretleyiniz.</div>
          <div class="sig-block">
            <div class="sig-cell">Hazırlayan (Teknisyen)</div>
            <div class="sig-cell">Kontrol Eden (Eczacı)</div>
          </div>
        </div>
      </div>
    `;
  }

  /**
   * 8x10 Termal Etiket Stilleri (Kompakt Başlık & Tam İlaç İsmi + Miktar)
   */
  static getLabelPrintStyles() {
    return `
      * {
        box-sizing: border-box;
        margin: 0;
        padding: 0;
      }
      @page {
        size: 80mm 100mm;
        margin: 1.5mm;
      }
      body {
        font-family: Arial, "Helvetica Neue", Helvetica, sans-serif;
        color: #000000;
        background: #ffffff;
        font-size: 7pt;
        -webkit-print-color-adjust: exact !important;
        print-color-adjust: exact !important;
      }
      .label-card {
        width: 77mm;
        height: 97mm;
        border: 1.4pt solid #000000;
        padding: 1.5mm 1.8mm;
        display: flex;
        flex-direction: column;
        justify-content: flex-start;
        page-break-after: always;
      }
      .label-card:last-child {
        page-break-after: auto;
      }
      /* Çok Kısıtlı / Kompakt Üst Başlık */
      .lbl-top {
        border-bottom: 1pt solid #000000;
        padding-bottom: 0.8mm;
        margin-bottom: 0.8mm;
      }
      .lbl-hdr-row1 {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 1.5mm;
      }
      .lbl-service-title {
        font-size: 7.8pt;
        font-weight: 900;
        text-transform: uppercase;
        color: #000000;
        line-height: 1.1;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }
      .lbl-grp-name {
        font-size: 7.5pt;
        font-weight: 900;
        background-color: #000000 !important;
        color: #ffffff !important;
        padding: 0.4mm 1.5mm;
        border-radius: 2px;
        letter-spacing: 0.3px;
        text-transform: uppercase;
        white-space: nowrap;
        flex-shrink: 0;
      }
      .lbl-meta {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-top: 0.5mm;
        font-size: 6.4pt;
        font-family: monospace;
        line-height: 1.1;
      }
      .lbl-meta strong {
        font-size: 6.8pt;
      }
      .lbl-body {
        flex: 1;
        min-height: 0;
        overflow: hidden;
      }
      /* İlaç İsmi ve Miktar Tablosu — Tam İsim Görünür (Sarma / Wrap Aktif) */
      .lbl-tbl {
        width: 100% !important;
        table-layout: fixed !important;
        border-collapse: collapse !important;
      }
      .lbl-tbl th {
        border-bottom: 0.9pt solid #000000;
        padding: 0.5px 2px;
        text-align: left;
        font-size: 6.4pt;
        font-weight: 900;
        background-color: #f1f5f9 !important;
        white-space: nowrap !important;
      }
      .lbl-tbl td {
        padding: 1px 2px;
        border-bottom: 0.4pt dotted #777777;
        vertical-align: top;
      }
      .lbl-tbl-drug {
        width: 87% !important;
        white-space: normal !important;
        overflow: visible !important;
        word-break: break-word !important;
        overflow-wrap: anywhere !important;
      }
      .lbl-drug-full {
        display: block !important;
        width: 100% !important;
        white-space: normal !important;
        overflow: visible !important;
        word-break: break-word !important;
        overflow-wrap: anywhere !important;
        font-weight: 800 !important;
        line-height: 1.12;
      }
      .lbl-tbl-qty {
        width: 13% !important;
        text-align: center !important;
        font-weight: 900;
        font-family: monospace;
        white-space: nowrap !important;
        vertical-align: middle !important;
      }

      /* Tekil Kalem Etiketi (Tam İlaç İsmi ve Miktar Odaklı) */
      .single-item-card {
        width: 77mm;
        height: 97mm;
        border: 2pt solid #000000;
        padding: 2.5mm;
        display: flex;
        flex-direction: column;
        justify-content: space-between;
        page-break-after: always;
        text-align: center;
      }
      .single-item-card:last-child {
        page-break-after: auto;
      }
      .single-lbl-header {
        border-bottom: 1.2pt solid #000000;
        padding-bottom: 1mm;
        font-size: 7pt;
        font-weight: bold;
        display: flex;
        justify-content: space-between;
        gap: 2mm;
      }
      .single-lbl-drug {
        font-size: 10.5pt;
        font-weight: 900;
        line-height: 1.2;
        white-space: normal;
        word-break: break-word;
        overflow-wrap: anywhere;
        margin: 1.5mm 0;
        padding: 2mm;
        border: 1pt solid #000000;
        background-color: #fafafa !important;
      }
      .single-lbl-qty {
        font-size: 16pt;
        font-weight: 900;
        font-family: monospace;
        border: 1.8pt solid #000000;
        padding: 2mm;
        margin: 1mm 0;
      }
    `;
  }

  /**
   * 8x10 Grup Dağıtım Etiketi: Kısıtlanmış Kompakt Başlık + Tam İlaç İsmi ve Miktar
   */
  static buildSingleGroupLabelHtml(group, islemNo, service = null) {
    if (!group || !group.items || group.items.length === 0) return "";
    const dateStr = PrintManager.getFormattedDate();
    const items = group.items;

    let serviceTitle = "GENEL";
    if (service && service.name) {
      const floorPart = service.floor ? ` (${service.floor.toUpperCase()})` : "";
      const extPart = service.extension ? ` · Dhl:${service.extension}` : "";
      serviceTitle = `${service.name.toUpperCase()}${floorPart}${extPart}`;
    }

    const shortGrp = PrintManager.getShortGroupTitle(group);

    // Kalem sayısına ve isim uzunluğuna göre dinamik yazı boyutu (kısa isim varsa kısa isim, yoksa tam isim)
    const getLabelDrugName = (it) => {
      if (it && it.kisa_isim && String(it.kisa_isim).trim()) {
        return String(it.kisa_isim).trim();
      }
      return (it && it.urun_adi) ? it.urun_adi : "Tanımsız İlaç";
    };

    const maxItemsPerPage = 18;
    const pages = [];
    for (let i = 0; i < items.length; i += maxItemsPerPage) {
      pages.push(items.slice(i, i + maxItemsPerPage));
    }

    return pages.map((pageItems, pageIdx) => {
      const totalChars = pageItems.reduce((acc, it) => acc + String(getLabelDrugName(it)).length, 0);
      let tableFontPt = 7.2;
      if (pageItems.length > 14 || totalChars > 520) {
        tableFontPt = 6.0;
      } else if (pageItems.length > 10 || totalChars > 360) {
        tableFontPt = 6.6;
      }

      const pageBadge = pages.length > 1 ? ` (${pageIdx + 1}/${pages.length})` : "";

      const rows = pageItems.map(it => `
        <tr>
          <!-- 1. İlaç İsmi (Kısa İsim Varsa Kısa İsim, Yoksa Tam İsim Görünür) -->
          <td class="lbl-tbl-drug">
            <div class="lbl-drug-full">${getLabelDrugName(it)}</div>
          </td>
          <!-- 2. Miktar -->
          <td class="lbl-tbl-qty">${it.toplam_miktar}</td>
        </tr>
      `).join("");

      return `
        <div class="label-card">
          <!-- Kısıtlanmış Minimal Başlık -->
          <div class="lbl-top">
            <div class="lbl-hdr-row1">
              <div class="lbl-service-title">${serviceTitle}</div>
              <div class="lbl-grp-name">${shortGrp}${pageBadge}</div>
            </div>
            <div class="lbl-meta">
              <span>No:<strong>${islemNo}</strong></span>
              <span><strong>${group.item_count}</strong> Klm / <strong>${group.total_quantity}</strong> Ad</span>
              <span>${dateStr}</span>
            </div>
          </div>

          <!-- Sadece İlaç İsmi (Kısa İsim Varsa Kısa İsim, Yoksa Tam İsim) ve Miktar Tablosu -->
          <div class="lbl-body">
            <table class="lbl-tbl" style="font-size: ${tableFontPt}pt;">
              <colgroup>
                <col style="width: 87%;">
                <col style="width: 13%;">
              </colgroup>
              <thead>
                <tr>
                  <th style="width: 87%;">İLAÇ</th>
                  <th style="width: 13%; text-align: center;">ADET</th>
                </tr>
              </thead>
              <tbody>
                ${rows}
              </tbody>
            </table>
          </div>
        </div>
      `;
    }).join("");
  }

  /**
   * 8x10 Tekil Kalem Etiketleri: Kısa İsim (Varsa) veya Tam İlaç İsmi ve Miktar Vurgulu
   */
  static buildSingleItemLabelsHtml(items, islemNo, service = null) {
    if (!items || items.length === 0) return "";
    let svcText = "GENEL";
    if (service && service.name) {
      const floorPart = service.floor ? ` (${service.floor.toUpperCase()})` : "";
      const extPart = service.extension ? ` · Dhl:${service.extension}` : "";
      svcText = `${service.name.toUpperCase()}${floorPart}${extPart}`;
    }

    return items.map(item => {
      const displayName = (item && item.kisa_isim && String(item.kisa_isim).trim())
        ? String(item.kisa_isim).trim()
        : (item.urun_adi || "Tanımsız İlaç");
      return `
      <div class="single-item-card">
        <div class="single-lbl-header">
          <span>No:${islemNo}</span>
          <span style="font-weight: 900;">${svcText}</span>
        </div>

        <!-- 1. İlaç İsmi (Kısa İsim Varsa Kısa İsim, Yoksa Tam İsim Görünür) -->
        <div class="single-lbl-drug">
          ${displayName}
        </div>

        <!-- 2. Miktar -->
        <div class="single-lbl-qty">
          ADET: ${item.toplam_miktar}
        </div>

        <div style="font-size: 7pt; font-family: monospace; border-top: 1pt solid #000; padding-top: 1mm; display: flex; justify-content: space-between;">
          <span>Barkod: ${item.barkod}</span>
          <span>${PrintManager.getShortGroupTitle(item.kategori_adi || "")}</span>
        </div>
      </div>
    `;
    }).join("");
  }

  /**
   * A4 Raporunu Yazdırır (Servis ve Kat Bilgisi Dahil)
   */
  static printA4(categorizeData, service = null) {
    if (!categorizeData) {
      alert("Yazdırılacak veri bulunamadı. Lütfen önce XML yükleyin.");
      return;
    }
    const html = PrintManager.buildCombinedA4Html(categorizeData, service);
    const css = PrintManager.getA4PrintStyles();
    PrintManager.printHtmlViaIframe(html, css);
  }

  /**
   * Belirli bir grubun 8x10 Etiketini Yazdırır (İlaç İsmi, Miktar ve Raf)
   */
  static printGroupLabel(group, islemNo, service = null) {
    if (!group || !group.items || group.items.length === 0) {
      alert("Bu grupta yazdırılacak ilaç kaydı bulunamadı.");
      return;
    }
    const html = PrintManager.buildSingleGroupLabelHtml(group, islemNo, service);
    const css = PrintManager.getLabelPrintStyles();
    PrintManager.printHtmlViaIframe(html, css);
  }

  /**
   * Ekranda Canlı Önizleme Modalı Açar
   */
  static showPreview(contentHtml, title) {
    const modal = document.getElementById("previewModal");
    const titleEl = document.getElementById("previewModalTitle");
    const bodyEl = document.getElementById("previewModalBody");
    if (!modal || !bodyEl) return;

    titleEl.textContent = title;
    const previewFrame = document.createElement("iframe");
    previewFrame.className = "a4-preview-frame";
    previewFrame.title = title;
    previewFrame.setAttribute("sandbox", "");
    previewFrame.srcdoc = `
      <!doctype html>
      <html lang="tr">
        <head>
          <meta charset="UTF-8">
          <style>
            ${PrintManager.getA4PrintStyles()}
            html, body { min-width: 0; min-height: 100%; }
            body {
              display: flex;
              justify-content: center;
              padding: 12px !important;
              background: #64748b !important;
            }
            .preview-a4-page {
              background: #ffffff;
              width: 210mm;
              max-width: 100%;
              min-height: 297mm;
              padding: 6mm 8mm;
              box-shadow: 0 4px 15px rgba(0,0,0,0.3);
              margin: 0 auto;
              font-family: Arial, sans-serif;
            }
          </style>
        </head>
        <body><main class="preview-a4-page">${contentHtml}</main></body>
      </html>
    `;
    bodyEl.replaceChildren(previewFrame);
    modal.classList.add("open");
  }
}

window.PrintManager = PrintManager;
