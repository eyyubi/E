/**
 * Ana Uygulama Mantığı (İlaç Filtreleme Sistemi)
 */
(function() {
  // Uygulama Durumu
  const state = {
    currentData: null,
    currentFileName: "reçete.xml",
    activeCategory: "all",
    searchTerm: "",
    selectedBarcodes: new Set(),
    rawRecords: null,
    servicesList: [],
    selectedService: null,
    reportHistoryList: [],
    aliasMap: null
  };

  // DOM Elemanları
  const dropZone = document.getElementById("dropZone");
  const fileInput = document.getElementById("fileInput");
  const fileDeck = document.getElementById("fileDeck");
  const fileNameDisplay = document.getElementById("fileNameDisplay");
  const islemNoDisplay = document.getElementById("islemNoDisplay");
  const parseTimeDisplay = document.getElementById("parseTimeDisplay");
  const totalItemsMeta = document.getElementById("totalItemsMeta");
  const fileSizeMeta = document.getElementById("fileSizeMeta");

  // Servis & Kat Elemanları
  const serviceSelector = document.getElementById("serviceSelector");
  const btnOpenServiceModal = document.getElementById("btnOpenServiceModal");
  const serviceModal = document.getElementById("serviceModal");
  const btnCloseServiceModal = document.getElementById("btnCloseServiceModal");
  const btnCloseServiceModalFooter = document.getElementById("btnCloseServiceModalFooter");
  const servicesTableBody = document.querySelector("#servicesTable tbody");
  const serviceFormTitle = document.getElementById("serviceFormTitle");
  const editServiceIdInput = document.getElementById("editServiceId");
  const svcNameInput = document.getElementById("svcNameInput");
  const svcFloorInput = document.getElementById("svcFloorInput");
  const svcExtensionInput = document.getElementById("svcExtensionInput");
  const svcCodeInput = document.getElementById("svcCodeInput");
  const btnSaveService = document.getElementById("btnSaveService");

  // Raporlama Geçmişi Elemanları
  const btnOpenHistory = document.getElementById("btnOpenHistory");
  const historyModal = document.getElementById("historyModal");
  const btnCloseHistory = document.getElementById("btnCloseHistory");
  const btnCloseHistoryFooter = document.getElementById("btnCloseHistoryFooter");
  const historyCountBadge = document.getElementById("historyCountBadge");
  const historyTotalCount = document.getElementById("historyTotalCount");
  const historyTableBody = document.getElementById("historyTableBody");
  const historySearchInput = document.getElementById("historySearchInput");
  const btnClearAllHistory = document.getElementById("btnClearAllHistory");
  const quickHistoryContainer = document.getElementById("quickHistoryContainer");
  const quickHistoryChips = document.getElementById("quickHistoryChips");
  const btnSaveToHistory = document.getElementById("btnSaveToHistory");

  // KPI Elemanları
  const kpiGrid = document.getElementById("kpiGrid");
  const kpiSerumCount = document.getElementById("kpiSerumCount");
  const kpiSerumQty = document.getElementById("kpiSerumQty");
  const kpiSerumShare = document.getElementById("kpiSerumShare");

  const kpiTabletCount = document.getElementById("kpiTabletCount");
  const kpiTabletQty = document.getElementById("kpiTabletQty");
  const kpiTabletShare = document.getElementById("kpiTabletShare");

  const kpiDigerCount = document.getElementById("kpiDigerCount");
  const kpiDigerQty = document.getElementById("kpiDigerQty");
  const kpiDigerShare = document.getElementById("kpiDigerShare");

  // Tablo & Filtreler
  const mainWorkplace = document.getElementById("mainWorkplace");
  const categoryTabs = document.getElementById("categoryTabs");
  const searchInput = document.getElementById("searchInput");
  const medsTableBody = document.querySelector("#medsTable tbody");
  const checkAll = document.getElementById("checkAll");
  const selectedCountDisplay = document.getElementById("selectedCount");
  const totalListedDisplay = document.getElementById("totalListed");

  // Sekme Sayaçları
  const countAll = document.getElementById("countAll");
  const countSerum = document.getElementById("countSerum");
  const countTablet = document.getElementById("countTablet");
  const countDiger = document.getElementById("countDiger");

  // Gruba Özel 8x10 Etiket Butonları
  const btnPrintLabelTabletBox = document.getElementById("btnPrintLabelTabletBox");
  const btnPrintLabelSerumBox = document.getElementById("btnPrintLabelSerumBox");
  const btnPrintLabelDigerBox = document.getElementById("btnPrintLabelDigerBox");

  // Genel Yazdırma Butonları
  const btnPrintA4 = document.getElementById("btnPrintA4");
  const btnPreviewA4 = document.getElementById("btnPreviewA4");
  const btnOpenSettings = document.getElementById("btnOpenSettings");
  const btnResetData = document.getElementById("btnResetData");

  // Ayarlar Modalı
  const settingsModal = document.getElementById("settingsModal");
  const btnCloseSettings = document.getElementById("btnCloseSettings");
  const btnSaveSettings = document.getElementById("btnSaveSettings");
  const group1NfcInput = document.getElementById("group1NfcInput");
  const serumGenericLookup = document.getElementById("serumGenericLookup");
  const serumGenericSearch = document.getElementById("serumGenericSearch");
  const serumGenericResults = document.getElementById("serumGenericResults");
  const serumGenericSelected = document.getElementById("serumGenericSelected");
  const serumBarcodeInput = document.getElementById("serumBarcodeInput");
  const btnAddSerumBarcode = document.getElementById("btnAddSerumBarcode");
  const serumBarcodeSelected = document.getElementById("serumBarcodeSelected");
  let selectedSerumGenericCodes = [];
  let selectedSerumBarcodes = [];
  let serumGenericSearchTimer = null;
  let serumGenericRequestId = 0;

  // Önizleme Modalı
  const previewModal = document.getElementById("previewModal");
  const btnClosePreview = document.getElementById("btnClosePreview");
  const btnTriggerPrintFromPreview = document.getElementById("btnTriggerPrintFromPreview");

  // Toast Bildirim
  const toastMsg = document.getElementById("toastMsg");

  function showToast(text) {
    if (!toastMsg) return;
    toastMsg.textContent = text;
    toastMsg.style.display = "block";
    setTimeout(() => {
      toastMsg.style.display = "none";
    }, 3000);
  }

  // -------------------------------------------------------------
  // 1. Servis ve Kat Yönetimi
  // -------------------------------------------------------------
  async function loadServices() {
    try {
      const services = await ApiClient.getServices();
      state.servicesList = services;

      // Dropdown'ı doldur
      serviceSelector.innerHTML = '<option value="">- Servis Seçiniz -</option>';
      services.forEach(svc => {
        const opt = document.createElement("option");
        opt.value = svc.id;
        opt.textContent = `${svc.name} (${svc.floor})${svc.extension ? ' · Dahili: ' + svc.extension : ''}${svc.code ? ' [' + svc.code + ']' : ''}`;
        serviceSelector.appendChild(opt);
      });

      // Kayıtlı seçimi hatırla
      const savedId = localStorage.getItem("selectedServiceId");
      if (savedId) {
        serviceSelector.value = savedId;
        state.selectedService = services.find(s => String(s.id) === String(savedId)) || null;
      } else if (services.length > 0) {
        serviceSelector.value = services[0].id;
        state.selectedService = services[0];
      }

      renderServicesModalTable();
    } catch (err) {
      console.warn("Servisler yüklenemedi:", err);
    }
  }

  serviceSelector.addEventListener("change", (e) => {
    const val = e.target.value;
    if (val) {
      localStorage.setItem("selectedServiceId", val);
      state.selectedService = state.servicesList.find(s => String(s.id) === String(val)) || null;
    } else {
      localStorage.removeItem("selectedServiceId");
      state.selectedService = null;
    }
  });

  function renderServicesModalTable() {
    if (!servicesTableBody) return;
    servicesTableBody.innerHTML = "";

    if (state.servicesList.length === 0) {
      servicesTableBody.innerHTML = `<tr><td colspan="5" style="text-align:center; color:#888; padding:1rem;">Kayıtlı servis bulunamadı.</td></tr>`;
      return;
    }

    state.servicesList.forEach(svc => {
      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td style="font-weight:600;">${svc.name}</td>
        <td>${svc.floor}</td>
        <td><span style="font-family:var(--font-mono); font-size:0.8rem; font-weight:600; color:var(--primary);">${svc.extension || '-'}</span></td>
        <td><span style="font-family:var(--font-mono); font-size:0.75rem;">${svc.code || '-'}</span></td>
        <td style="text-align:right;">
          <button class="btn btn-secondary btn-sm btn-edit-svc" data-id="${svc.id}" style="padding:0.15rem 0.4rem; font-size:0.75rem;">Düzenle</button>
          <button class="btn btn-secondary btn-sm btn-del-svc" data-id="${svc.id}" style="padding:0.15rem 0.4rem; font-size:0.75rem; color:var(--status-error);">Sil</button>
        </td>
      `;
      servicesTableBody.appendChild(tr);
    });

    // Düzenle Butonları
    servicesTableBody.querySelectorAll(".btn-edit-svc").forEach(btn => {
      btn.addEventListener("click", () => {
        const id = parseInt(btn.getAttribute("data-id"), 10);
        const svc = state.servicesList.find(s => s.id === id);
        if (svc) {
          editServiceIdInput.value = svc.id;
          svcNameInput.value = svc.name;
          svcFloorInput.value = svc.floor;
          if (svcExtensionInput) svcExtensionInput.value = svc.extension || "";
          svcCodeInput.value = svc.code || "";
          serviceFormTitle.textContent = `✎ Servis Düzenle: ${svc.name}`;
          btnSaveService.textContent = "Güncelle";
        }
      });
    });

    // Sil Butonları
    servicesTableBody.querySelectorAll(".btn-del-svc").forEach(btn => {
      btn.addEventListener("click", async () => {
        const id = parseInt(btn.getAttribute("data-id"), 10);
        const svc = state.servicesList.find(s => s.id === id);
        if (svc && confirm(`"${svc.name}" servisini silmek istediğinizden emin misiniz?`)) {
          try {
            await ApiClient.deleteService(id);
            showToast("Servis silindi.");
            await loadServices();
          } catch (e) {
            alert("Hata: " + e.message);
          }
        }
      });
    });
  }

  function resetServiceForm() {
    editServiceIdInput.value = "";
    svcNameInput.value = "";
    svcFloorInput.value = "";
    if (svcExtensionInput) svcExtensionInput.value = "";
    svcCodeInput.value = "";
    serviceFormTitle.textContent = "✚ Yeni Servis, Kat ve Dahili No Ekle";
    btnSaveService.textContent = "Kaydet";
  }

  if (btnOpenServiceModal) {
    btnOpenServiceModal.addEventListener("click", () => {
      resetServiceForm();
      renderServicesModalTable();
      serviceModal.classList.add("open");
    });
  }

  if (btnCloseServiceModal) {
    btnCloseServiceModal.addEventListener("click", () => serviceModal.classList.remove("open"));
  }
  if (btnCloseServiceModalFooter) {
    btnCloseServiceModalFooter.addEventListener("click", () => serviceModal.classList.remove("open"));
  }

  if (btnSaveService) {
    btnSaveService.addEventListener("click", async () => {
      const name = svcNameInput.value.trim();
      const floor = svcFloorInput.value.trim();
      const extension = svcExtensionInput ? svcExtensionInput.value.trim() : "";
      const code = svcCodeInput.value.trim();
      const editId = editServiceIdInput.value;

      if (!name || !floor) {
        alert("Lütfen Servis Adı ve Bulunduğu Kat alanlarını doldurunuz.");
        return;
      }

      try {
        if (editId) {
          await ApiClient.updateService(editId, { name, floor, code, extension });
          showToast("Servis güncellendi.");
        } else {
          await ApiClient.createService({ name, floor, code, extension });
          showToast("Yeni servis eklendi.");
        }
        resetServiceForm();
        await loadServices();
      } catch (err) {
        alert("Hata: " + err.message);
      }
    });
  }

  // -------------------------------------------------------------
  // 2. Dosya Yükleme & XML Ayrıştırma
  // -------------------------------------------------------------
  if (dropZone && fileInput) {
    dropZone.addEventListener("click", () => fileInput.click());

    dropZone.addEventListener("dragover", (e) => {
      e.preventDefault();
      dropZone.classList.add("dragover");
    });

    dropZone.addEventListener("dragleave", () => {
      dropZone.classList.remove("dragover");
    });

    dropZone.addEventListener("drop", (e) => {
      e.preventDefault();
      dropZone.classList.remove("dragover");
      if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
        handleFile(e.dataTransfer.files[0]);
      }
    });

    fileInput.addEventListener("change", (e) => {
      if (e.target.files && e.target.files.length > 0) {
        handleFile(e.target.files[0]);
      }
    });
  }

  async function handleFile(file) {
    if (!file.name.toLowerCase().endsWith(".xml")) {
      alert("Lütfen geçerli bir .xml dosyası seçiniz.");
      return;
    }

    try {
      const startTime = performance.now();
      state.currentFileName = file.name;
      fileNameDisplay.textContent = file.name;
      fileSizeMeta.textContent = (file.size / 1024).toFixed(1) + " KB";

      const parsedRecords = await XmlDrugParser.parseFile(file);
      state.rawRecords = parsedRecords;

      const result = await ApiClient.categorize(parsedRecords);
      const elapsed = Math.round(performance.now() - startTime);

      parseTimeDisplay.textContent = `${elapsed} ms`;
      totalItemsMeta.textContent = `${result.toplam_kalem} Kalem (${result.toplam_adet} Adet)`;
      
      applyCategorizeResult(result);
      showToast("XML başarıyla işlendi ve 3 gruba ayrıldı.");

      // Rapor geçmişine otomatik kaydet
      await saveCurrentToHistory(false);
    } catch (err) {
      console.error(err);
      alert("Hata: " + err.message);
    }
  }

  function syncAliasesToData(data) {
    if (!data || !state.aliasMap) return;
    const updateList = (arr) => {
      if (!Array.isArray(arr)) return;
      arr.forEach(item => {
        if (item && item.jenerik_kodu) {
          item.kisa_isim = state.aliasMap[item.jenerik_kodu] || null;
        }
      });
    };
    updateList(data.tum_liste);
    if (data.gruplar) {
      if (data.gruplar.tablet) updateList(data.gruplar.tablet.items);
      if (data.gruplar.serum) updateList(data.gruplar.serum.items);
      if (data.gruplar.diger) updateList(data.gruplar.diger.items);
    }
  }

  function applyCategorizeResult(data) {
    syncAliasesToData(data);
    state.currentData = data;
    state.selectedBarcodes.clear();

    const islemNo = data.islem_no || "-";
    islemNoDisplay.textContent = islemNo;

    // KPI Güncelleme
    const serumGroup = data.gruplar.serum || { item_count: 0, total_quantity: 0, percentage: 0 };
    const tabletGroup = data.gruplar.tablet || { item_count: 0, total_quantity: 0, percentage: 0 };
    const digerGroup = data.gruplar.diger || { item_count: 0, total_quantity: 0, percentage: 0 };

    kpiSerumCount.textContent = serumGroup.item_count;
    kpiSerumQty.textContent = `${serumGroup.total_quantity} adet`;
    kpiSerumShare.textContent = `%${serumGroup.percentage} Pay`;

    kpiTabletCount.textContent = tabletGroup.item_count;
    kpiTabletQty.textContent = `${tabletGroup.total_quantity} adet`;
    kpiTabletShare.textContent = `%${tabletGroup.percentage} Pay`;

    kpiDigerCount.textContent = digerGroup.item_count;
    kpiDigerQty.textContent = `${digerGroup.total_quantity} adet`;
    kpiDigerShare.textContent = `%${digerGroup.percentage} Pay`;

    // Sekme Sayaçları
    countAll.textContent = data.toplam_kalem;
    countSerum.textContent = serumGroup.item_count;
    countTablet.textContent = tabletGroup.item_count;
    countDiger.textContent = digerGroup.item_count;

    // Çalışma alanını aç
    kpiGrid.style.display = "grid";
    mainWorkplace.style.display = "block";
    fileDeck.style.display = "block";

    renderTable();
  }

  // -------------------------------------------------------------
  // 3. Tablo Render & Arama & Filtreleme
  // -------------------------------------------------------------
  function getFilteredItems() {
    if (!state.currentData) return [];

    let items = [];
    if (state.activeCategory === "all") {
      items = state.currentData.tum_liste;
    } else {
      const group = state.currentData.gruplar[state.activeCategory];
      items = group ? group.items : [];
    }

    if (!state.searchTerm) return items;

    const term = state.searchTerm.toLowerCase();
    return items.filter(item => {
      const matchName = (item.urun_adi || "").toLowerCase().includes(term);
      const matchShortName = (item.kisa_isim || "").toLowerCase().includes(term);
      const matchBarcode = (item.barkod || "").toLowerCase().includes(term);
      const matchShelf = (item.raf_konumu || "").toLowerCase().includes(term);
      const matchGeneric = (item.jenerik_kodu || "").toLowerCase().includes(term);
      const matchAtc = (item.atc_kodu || "").toLowerCase().includes(term);
      const matchNfc = (item.nfc_kodu || "").toLowerCase().includes(term);
      return matchName || matchShortName || matchBarcode || matchShelf || matchGeneric || matchAtc || matchNfc;
    });
  }

  function renderTable() {
    if (!medsTableBody) return;
    medsTableBody.innerHTML = "";

    const items = getFilteredItems();
    totalListedDisplay.textContent = items.length;

    if (items.length === 0) {
      medsTableBody.innerHTML = `
        <tr>
          <td colspan="8" style="text-align: center; padding: 2rem; color: var(--text-muted);">
            Kriterlere uygun ilaç kaydı bulunamadı.
          </td>
        </tr>
      `;
      updateSelectedCountDisplay();
      return;
    }

    items.forEach(item => {
      const tr = document.createElement("tr");
      const isChecked = state.selectedBarcodes.has(item.barkod);

      const rafBadge = item.raf_konumu && item.raf_konumu !== "-" 
        ? `<span class="shelf-badge">${item.raf_konumu}</span>` 
        : `<span class="shelf-badge shelf-empty">Raf Yok</span>`;

      let catBadgeClass = "badge-diger";
      if (item.kategori_key === "tablet") catBadgeClass = "badge-tablet";
      if (item.kategori_key === "serum") catBadgeClass = "badge-serum";

      const kisaIsimBadge = item.kisa_isim
        ? `<span style="display:inline-block; margin-left:6px; padding:1px 6px; border-radius:4px; background:rgba(99,102,241,0.12); color:#4f46e5; font-size:0.72rem; font-weight:700;" title="Etiket Kısa İsmi">🏷 ${item.kisa_isim}</span>`
        : "";

      tr.innerHTML = `
        <td style="width: 38px; text-align: center;">
          <input type="checkbox" class="row-chk" data-barcode="${item.barkod}" ${isChecked ? "checked" : ""}>
        </td>
        <td style="width: 120px;">
          ${rafBadge}
        </td>
        <td style="width: 150px;">
          <span class="barcode-text">${item.barkod}</span>
        </td>
        <td>
          <div style="font-weight: 600; color: var(--text-primary); max-width: 380px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;" title="${item.urun_adi}">${item.urun_adi}${kisaIsimBadge}</div>
          <div style="font-size: 0.75rem; color: var(--text-muted); max-width: 380px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">${item.ambalaj || item.firma_adi || ""}</div>
        </td>
        <td style="width: 90px; text-align: center;">
          <span class="quantity-badge">${item.toplam_miktar}</span>
        </td>
        <td style="width: 140px;">
          <span class="kpi-badge ${catBadgeClass}">${item.kategori_adi}</span>
        </td>
        <td style="width: 165px; font-family: var(--font-mono); font-size: 0.75rem; color: var(--text-secondary);">
          <div>Jenerik: <strong>${item.jenerik_kodu || "-"}</strong></div>
          <div>NFC: <strong>${item.nfc_kodu || "-"}</strong></div>
          <div>ATC: <strong>${item.atc_kodu || "-"}</strong></div>
        </td>
        <td style="width: 110px;">
          ${item.bulundu 
            ? `<span style="color: var(--status-success); font-size: 0.75rem; font-weight: 600;">✓ Eşleşti</span>` 
            : `<span style="color: var(--status-warning); font-size: 0.75rem; font-weight: 600;">! Kayıtsız</span>`}
        </td>
      `;

      medsTableBody.appendChild(tr);
    });

    medsTableBody.querySelectorAll(".row-chk").forEach(chk => {
      chk.addEventListener("change", (e) => {
        const bc = e.target.getAttribute("data-barcode");
        if (e.target.checked) {
          state.selectedBarcodes.add(bc);
        } else {
          state.selectedBarcodes.delete(bc);
        }
        updateSelectedCountDisplay();
      });
    });

    updateSelectedCountDisplay();
  }

  function updateSelectedCountDisplay() {
    if (selectedCountDisplay) {
      selectedCountDisplay.textContent = state.selectedBarcodes.size;
    }
    if (checkAll) {
      const items = getFilteredItems();
      const allSelected = items.length > 0 && items.every(i => state.selectedBarcodes.has(i.barkod));
      checkAll.checked = allSelected;
    }
  }

  // -------------------------------------------------------------
  // 4. Sekmeler & Arama Olayları
  // -------------------------------------------------------------
  if (categoryTabs) {
    categoryTabs.querySelectorAll(".cat-pill").forEach(pill => {
      pill.addEventListener("click", () => {
        categoryTabs.querySelectorAll(".cat-pill").forEach(p => p.classList.remove("active"));
        pill.classList.add("active");
        state.activeCategory = pill.getAttribute("data-filter") || "all";
        renderTable();
      });
    });
  }

  if (searchInput) {
    searchInput.addEventListener("input", (e) => {
      state.searchTerm = e.target.value.trim();
      renderTable();
    });

    window.addEventListener("keydown", (e) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        searchInput.focus();
      }
    });
  }

  if (checkAll) {
    checkAll.addEventListener("change", (e) => {
      const isChecked = e.target.checked;
      const items = getFilteredItems();
      items.forEach(i => {
        if (isChecked) {
          state.selectedBarcodes.add(i.barkod);
        } else {
          state.selectedBarcodes.delete(i.barkod);
        }
      });
      renderTable();
    });
  }

  // -------------------------------------------------------------
  // 5. Gruba Özel 8x10 Etiket Butonları (İlaç, Miktar, Raf)
  // -------------------------------------------------------------
  if (btnPrintLabelTabletBox) {
    btnPrintLabelTabletBox.addEventListener("click", async () => {
      if (!state.currentData) {
        alert("Lütfen önce bir XML yükleyin.");
        return;
      }
      PrintManager.printGroupLabel(state.currentData.gruplar.tablet, state.currentData.islem_no, state.selectedService);
      await saveCurrentToHistory();
    });
  }

  if (btnPrintLabelSerumBox) {
    btnPrintLabelSerumBox.addEventListener("click", async () => {
      if (!state.currentData) {
        alert("Lütfen önce bir XML yükleyin.");
        return;
      }
      PrintManager.printGroupLabel(state.currentData.gruplar.serum, state.currentData.islem_no, state.selectedService);
      await saveCurrentToHistory();
    });
  }

  if (btnPrintLabelDigerBox) {
    btnPrintLabelDigerBox.addEventListener("click", async () => {
      if (!state.currentData) {
        alert("Lütfen önce bir XML yükleyin.");
        return;
      }
      PrintManager.printGroupLabel(state.currentData.gruplar.diger, state.currentData.islem_no, state.selectedService);
      await saveCurrentToHistory();
    });
  }

  // -------------------------------------------------------------
  // 6. A4 Yazdırma & Önizleme Butonları (Servis ve Kat Bilgili)
  // -------------------------------------------------------------
  if (btnPrintA4) {
    btnPrintA4.addEventListener("click", async () => {
      if (!state.currentData) {
        alert("Lütfen önce bir XML dosyası yükleyin.");
        return;
      }
      PrintManager.printA4(state.currentData, state.selectedService);
      await saveCurrentToHistory();
    });
  }

  if (btnPreviewA4) {
    btnPreviewA4.addEventListener("click", () => {
      if (!state.currentData) {
        alert("Lütfen önce bir XML dosyası yükleyin.");
        return;
      }
      const html = PrintManager.buildCombinedA4Html(state.currentData, state.selectedService);
      PrintManager.showPreview(html, "A4 Baskı Canlı Önizleme (3 Grup Bir Arada)");
    });
  }

  // Önizleme Modalı Butonları
  if (btnClosePreview) {
    btnClosePreview.addEventListener("click", () => {
      previewModal.classList.remove("open");
    });
  }

  if (btnTriggerPrintFromPreview) {
    btnTriggerPrintFromPreview.addEventListener("click", async () => {
      previewModal.classList.remove("open");
      if (!state.currentData) return;
      PrintManager.printA4(state.currentData, state.selectedService);
      await saveCurrentToHistory();
    });
  }

  // -------------------------------------------------------------
  // 7. Kategori Ayarları Modalı (NFC ve jenerik kodları)
  // -------------------------------------------------------------
  function renderSerumGenericCodes() {
    if (!serumGenericSelected) return;
    serumGenericSelected.replaceChildren();

    if (selectedSerumGenericCodes.length === 0) {
      const empty = document.createElement("div");
      empty.className = "serum-generic-empty";
      empty.textContent = "Henüz serum/mama grubuna atanmış jenerik kod yok.";
      serumGenericSelected.appendChild(empty);
      return;
    }

    selectedSerumGenericCodes.forEach(code => {
      const chip = document.createElement("div");
      chip.className = "serum-generic-chip";

      const codeText = document.createElement("code");
      codeText.textContent = code;
      chip.appendChild(codeText);

      const removeButton = document.createElement("button");
      removeButton.type = "button";
      removeButton.className = "serum-generic-remove";
      removeButton.textContent = "Kaldır";
      removeButton.setAttribute("aria-label", `${code} kodunu serum/mama grubundan kaldır`);
      removeButton.addEventListener("click", () => {
        selectedSerumGenericCodes = selectedSerumGenericCodes.filter(item => item !== code);
        renderSerumGenericCodes();
      });
      chip.appendChild(removeButton);
      serumGenericSelected.appendChild(chip);
    });
  }

  function renderSerumGenericResults(results) {
    if (!serumGenericResults) return;
    serumGenericResults.replaceChildren();

    const alreadySelected = new Set(selectedSerumGenericCodes);
    const uniqueResults = [...new Map(
      (results || [])
        .filter(result => result.jenerik_kodu && !alreadySelected.has(String(result.jenerik_kodu).trim().toUpperCase()))
        .map(result => [String(result.jenerik_kodu).trim().toUpperCase(), result])
    ).values()];

    if (uniqueResults.length === 0) {
      const empty = document.createElement("div");
      empty.className = "serum-generic-result-empty";
      empty.textContent = "Yeni kod bulunamadı.";
      serumGenericResults.appendChild(empty);
      serumGenericResults.hidden = false;
      return;
    }

    uniqueResults.forEach(result => {
      const code = String(result.jenerik_kodu).trim().toUpperCase();
      const option = document.createElement("button");
      option.type = "button";
      option.className = "serum-generic-option";
      option.setAttribute("role", "option");

      const codeText = document.createElement("strong");
      codeText.textContent = code;
      const nameText = document.createElement("span");
      nameText.textContent = result.jenerik_adi || "Jenerik adı yok";
      const countText = document.createElement("small");
      countText.textContent = `${result.ilac_sayisi} ilaç`;
      option.append(codeText, nameText, countText);

      option.addEventListener("mousedown", event => event.preventDefault());
      option.addEventListener("click", () => {
        if (!selectedSerumGenericCodes.includes(code)) {
          selectedSerumGenericCodes.push(code);
          selectedSerumGenericCodes.sort((a, b) => a.localeCompare(b, "tr"));
          renderSerumGenericCodes();
        }
        serumGenericSearch.value = "";
        serumGenericResults.hidden = true;
        serumGenericSearch.focus();
      });
      serumGenericResults.appendChild(option);
    });
    serumGenericResults.hidden = false;
  }

  function normalizeSerumBarcode(value) {
    return String(value || "").trim().replace(/'/g, "").toUpperCase();
  }

  function renderSerumBarcodes() {
    if (!serumBarcodeSelected) return;
    serumBarcodeSelected.replaceChildren();

    if (selectedSerumBarcodes.length === 0) {
      const empty = document.createElement("div");
      empty.className = "serum-generic-empty";
      empty.textContent = "Henüz barkodla atanmış ilaç yok.";
      serumBarcodeSelected.appendChild(empty);
      return;
    }

    selectedSerumBarcodes.forEach(barcode => {
      const chip = document.createElement("div");
      chip.className = "serum-generic-chip";

      const barcodeText = document.createElement("code");
      barcodeText.textContent = barcode;
      chip.appendChild(barcodeText);

      const removeButton = document.createElement("button");
      removeButton.type = "button";
      removeButton.className = "serum-generic-remove";
      removeButton.textContent = "Kaldır";
      removeButton.setAttribute("aria-label", `${barcode} barkodunu serum/mama grubundan kaldır`);
      removeButton.addEventListener("click", () => {
        selectedSerumBarcodes = selectedSerumBarcodes.filter(item => item !== barcode);
        renderSerumBarcodes();
      });
      chip.appendChild(removeButton);
      serumBarcodeSelected.appendChild(chip);
    });
  }

  function addSerumBarcode() {
    const barcode = normalizeSerumBarcode(serumBarcodeInput?.value);
    if (!barcode) {
      serumBarcodeInput?.focus();
      return;
    }
    if (barcode.length > 70) {
      showToast("Barkod en fazla 70 karakter olabilir.");
      return;
    }
    if (selectedSerumBarcodes.includes(barcode)) {
      showToast("Bu barkod serum/mama listesinde zaten var.");
      return;
    }

    selectedSerumBarcodes.push(barcode);
    selectedSerumBarcodes.sort((a, b) => a.localeCompare(b, "tr"));
    serumBarcodeInput.value = "";
    renderSerumBarcodes();
    serumBarcodeInput.focus();
  }

  if (btnAddSerumBarcode) {
    btnAddSerumBarcode.addEventListener("click", addSerumBarcode);
  }
  if (serumBarcodeInput) {
    serumBarcodeInput.addEventListener("keydown", event => {
      if (event.key === "Enter") {
        event.preventDefault();
        addSerumBarcode();
      }
    });
  }

  if (serumGenericSearch) {
    serumGenericSearch.addEventListener("input", () => {
      clearTimeout(serumGenericSearchTimer);
      const query = serumGenericSearch.value.trim();
      const requestId = ++serumGenericRequestId;

      if (query.length < 2) {
        serumGenericResults.hidden = true;
        return;
      }

      serumGenericSearchTimer = setTimeout(async () => {
        try {
          const results = await ApiClient.searchJenerik(query);
          if (requestId === serumGenericRequestId && query === serumGenericSearch.value.trim()) {
            renderSerumGenericResults(results);
          }
        } catch (error) {
          if (requestId !== serumGenericRequestId) return;
          const message = document.createElement("div");
          message.className = "serum-generic-result-empty";
          message.textContent = "Jenerik kodları aranamadı. Tekrar deneyin.";
          serumGenericResults.replaceChildren(message);
          serumGenericResults.hidden = false;
          console.warn("Serum jenerik kodları aranamadı:", error);
        }
      }, 250);
    });
  }

  if (serumGenericLookup) {
    document.addEventListener("click", event => {
      if (!serumGenericLookup.contains(event.target)) serumGenericResults.hidden = true;
    });
  }

  async function loadSettings() {
    try {
      const cfg = await ApiClient.getSettings();
      if (group1NfcInput) group1NfcInput.value = cfg.group1_nfc_prefixes.join(", ");
      selectedSerumGenericCodes = [...new Set(
        (cfg.group2_generic_codes || [])
          .map(code => String(code).trim().toUpperCase())
          .filter(Boolean)
      )].sort((a, b) => a.localeCompare(b, "tr"));
      selectedSerumBarcodes = [...new Set(
        (cfg.group2_barcodes || [])
          .map(normalizeSerumBarcode)
          .filter(Boolean)
      )].sort((a, b) => a.localeCompare(b, "tr"));
      if (serumGenericSearch) serumGenericSearch.value = "";
      if (serumGenericResults) serumGenericResults.hidden = true;
      if (serumBarcodeInput) serumBarcodeInput.value = "";
      renderSerumGenericCodes();
      renderSerumBarcodes();
    } catch (e) {
      console.warn("Ayarlar yüklenemedi:", e);
    }
  }

  if (btnOpenSettings) {
    btnOpenSettings.addEventListener("click", () => {
      loadSettings();
      settingsModal.classList.add("open");
    });
  }

  if (btnCloseSettings) {
    btnCloseSettings.addEventListener("click", () => {
      settingsModal.classList.remove("open");
    });
  }

  if (btnSaveSettings) {
    btnSaveSettings.addEventListener("click", async () => {
      const nfcVals = group1NfcInput.value.split(",").map(s => s.trim().toUpperCase()).filter(Boolean);

      try {
        await ApiClient.updateSettings({
          group1_name: "Tablet Grubu",
          group1_nfc_prefixes: nfcVals,
          group2_name: "Serum & Mama Grubu",
          group2_generic_codes: selectedSerumGenericCodes,
          group2_barcodes: selectedSerumBarcodes,
          group3_name: "Diğer İlaçlar"
        });

        settingsModal.classList.remove("open");
        showToast("Filtre kuralları güncellendi.");

        if (state.rawRecords) {
          const result = await ApiClient.categorize(state.rawRecords);
          applyCategorizeResult(result);
        }
      } catch (err) {
        alert("Ayar kaydetme hatası: " + err.message);
      }
    });
  }

  if (btnResetData) {
    btnResetData.addEventListener("click", () => {
      if (confirm("Mevcut XML dökümünü temizlemek istiyor musunuz?")) {
        state.currentData = null;
        state.rawRecords = null;
        state.selectedBarcodes.clear();
        fileDeck.style.display = "none";
        kpiGrid.style.display = "none";
        mainWorkplace.style.display = "none";
        if (fileInput) fileInput.value = "";
      }
    });
  }

  // -------------------------------------------------------------
  // 8. Raporlama Geçmişi Yönetimi (Arşiv, Arama, Geri Yükleme)
  // -------------------------------------------------------------
  async function saveCurrentToHistory(isManual = false) {
    if (!state.currentData) {
      if (isManual) alert("Kaydedilecek aktif bir rapor bulunmamaktadır. Lütfen önce XML yükleyin.");
      return;
    }

    try {
      const payload = {
        islem_no: state.currentData.islem_no || "-",
        dosya_adi: state.currentFileName || "reçete.xml",
        service_id: state.selectedService ? state.selectedService.id : null,
        service_name: state.selectedService ? state.selectedService.name : null,
        service_floor: state.selectedService ? state.selectedService.floor : null,
        service_extension: state.selectedService ? (state.selectedService.extension || "") : null,
        data: state.currentData
      };

      await ApiClient.saveReport(payload);
      await loadReportHistory();
      if (isManual) {
        showToast("Rapor başarıyla geçmişe kaydedildi.");
      }
    } catch (err) {
      console.warn("Rapor geçmişe kaydedilemedi:", err);
      if (isManual) alert("Hata: " + err.message);
    }
  }

  async function loadReportHistory() {
    try {
      const reports = await ApiClient.getReports(50);
      state.reportHistoryList = reports;
      if (historyCountBadge) historyCountBadge.textContent = reports.length;
      if (historyTotalCount) historyTotalCount.textContent = reports.length;
      renderQuickHistoryChips();
      renderHistoryTable();
    } catch (err) {
      console.warn("Rapor geçmişi yüklenemedi:", err);
    }
  }

  function renderQuickHistoryChips() {
    if (!quickHistoryContainer || !quickHistoryChips) return;
    if (state.reportHistoryList.length === 0) {
      quickHistoryContainer.style.display = "none";
      return;
    }

    quickHistoryContainer.style.display = "flex";
    quickHistoryChips.innerHTML = "";

    // Son 3 raporu göster
    const recent = state.reportHistoryList.slice(0, 3);
    recent.forEach(r => {
      const chip = document.createElement("button");
      chip.type = "button";
      chip.className = "quick-chip";
      const timePart = (r.created_at_formatted || "").split(" ")[1] || "";
      chip.innerHTML = `<strong>${r.islem_no || 'İŞL'}</strong> <span style="opacity:0.75;">| ${timePart}</span>`;
      chip.title = `${r.dosya_adi || 'Rapor'} - ${r.service_name || 'Genel Servis'} (${r.toplam_kalem} Kalem / ${r.toplam_adet} Adet)`;
      chip.addEventListener("click", () => loadReportIntoWorkplace(r.id));
      quickHistoryChips.appendChild(chip);
    });
  }

  function renderHistoryTable() {
    if (!historyTableBody) return;
    historyTableBody.innerHTML = "";

    const query = (historySearchInput ? historySearchInput.value : "").trim().toLowerCase();
    const filtered = state.reportHistoryList.filter(r => {
      if (!query) return true;
      const str = `${r.islem_no} ${r.dosya_adi} ${r.service_name} ${r.service_floor} ${r.service_extension || ''} ${r.created_at_formatted}`.toLowerCase();
      return str.includes(query);
    });

    if (filtered.length === 0) {
      historyTableBody.innerHTML = `
        <tr>
          <td colspan="7" style="text-align: center; color: var(--text-muted); padding: 2.5rem;">
            ${query ? 'Arama kriterine uygun geçmiş rapor bulunamadı.' : 'Henüz kayıtlı rapor geçmişi bulunmamaktadır.'}
          </td>
        </tr>
      `;
      return;
    }

    filtered.forEach(r => {
      const tr = document.createElement("tr");

      const extInfo = r.service_extension ? ` · Dahili: ${r.service_extension}` : "";
      const svcDisplay = r.service_name 
        ? `<strong style="color:var(--text-primary); font-size:0.8125rem;">${r.service_name}</strong> <span style="font-size:0.75rem; color:var(--text-muted);">(${r.service_floor || '-'}${extInfo})</span>`
        : `<span style="color:var(--text-muted); font-size:0.8125rem;">Genel Dağıtım</span>`;

      // Dağılım yüzdeleri
      const tPct = r.toplam_kalem > 0 ? Math.round((r.tablet_kalem / r.toplam_kalem) * 100) : 0;
      const sPct = r.toplam_kalem > 0 ? Math.round((r.serum_kalem / r.toplam_kalem) * 100) : 0;
      const dPct = r.toplam_kalem > 0 ? Math.round((r.diger_kalem / r.toplam_kalem) * 100) : 0;

      tr.innerHTML = `
        <td style="font-size:0.75rem; font-family:var(--font-mono); color:var(--text-secondary); white-space:nowrap;">
          ${r.created_at_formatted}
        </td>
        <td>
          <span class="islem-no-pill" style="font-size:0.75rem; padding:0.15rem 0.5rem;">${r.islem_no || '-'}</span>
        </td>
        <td>
          <div style="font-weight:600; font-size:0.8125rem; max-width:180px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;" title="${r.dosya_adi || '-'}">
            ${r.dosya_adi || '-'}
          </div>
        </td>
        <td>
          <div>${svcDisplay}</div>
        </td>
        <td style="text-align:center; font-family:var(--font-mono); font-size:0.8125rem; white-space:nowrap;">
          <strong>${r.toplam_kalem}</strong> <span style="font-size:0.7rem; color:var(--text-muted);">kalem</span><br>
          <span style="font-size:0.75rem; color:var(--primary); font-weight:700;">${r.toplam_adet} adet</span>
        </td>
        <td>
          <div style="display:flex; gap:0.25rem; font-size:0.7rem; font-weight:700; flex-wrap:wrap;">
            <span class="kpi-badge badge-tablet" style="padding:0.1rem 0.35rem;" title="Tablet: ${r.tablet_kalem} Kalem / ${r.tablet_adet} Adet">%${tPct} Tab</span>
            <span class="kpi-badge badge-serum" style="padding:0.1rem 0.35rem;" title="Serum & Mama: ${r.serum_kalem} Kalem / ${r.serum_adet} Adet">%${sPct} Ser</span>
            <span class="kpi-badge badge-diger" style="padding:0.1rem 0.35rem;" title="Diğer: ${r.diger_kalem} Kalem / ${r.diger_adet} Adet">%${dPct} Diğ</span>
          </div>
        </td>
        <td style="text-align:right; white-space:nowrap;">
          <div style="display:inline-flex; gap:0.3rem;">
            <button class="btn btn-primary btn-sm btn-load-report" data-id="${r.id}" style="padding:0.2rem 0.45rem; font-size:0.75rem;" title="Bu raporu ana çalışma masasına yükler">
              👁 Yükle
            </button>
            <button class="btn btn-secondary btn-sm btn-print-a4-report" data-id="${r.id}" style="padding:0.2rem 0.45rem; font-size:0.75rem;" title="A4 Raporu Yazdır">
              🖨 A4
            </button>
            <button class="btn btn-secondary btn-sm btn-del-report" data-id="${r.id}" style="padding:0.2rem 0.4rem; font-size:0.75rem; color:var(--status-error);" title="Raporu Geçmişten Sil">
              🗑
            </button>
          </div>
        </td>
      `;

      historyTableBody.appendChild(tr);
    });

    // Masaya Yükle
    historyTableBody.querySelectorAll(".btn-load-report").forEach(btn => {
      btn.addEventListener("click", () => {
        const id = parseInt(btn.getAttribute("data-id"), 10);
        loadReportIntoWorkplace(id);
      });
    });

    // A4 Yazdır
    historyTableBody.querySelectorAll(".btn-print-a4-report").forEach(btn => {
      btn.addEventListener("click", async () => {
        const id = parseInt(btn.getAttribute("data-id"), 10);
        try {
          const detail = await ApiClient.getReportDetail(id);
          const matchedSvc = detail.service_id ? state.servicesList.find(s => s.id === detail.service_id) : null;
          const svc = detail.service_name ? {
            name: detail.service_name,
            floor: detail.service_floor,
            extension: detail.service_extension || (matchedSvc ? matchedSvc.extension : "")
          } : null;
          PrintManager.printA4(detail.data, svc);
        } catch (e) {
          alert("Yazdırma hatası: " + e.message);
        }
      });
    });

    // Sil
    historyTableBody.querySelectorAll(".btn-del-report").forEach(btn => {
      btn.addEventListener("click", async () => {
        const id = parseInt(btn.getAttribute("data-id"), 10);
        if (confirm("Bu raporu geçmişten silmek istediğinize emin misiniz?")) {
          try {
            await ApiClient.deleteReport(id);
            showToast("Rapor geçmişten silindi.");
            await loadReportHistory();
          } catch (e) {
            alert("Silme hatası: " + e.message);
          }
        }
      });
    });
  }

  async function loadReportIntoWorkplace(reportId) {
    try {
      const detail = await ApiClient.getReportDetail(reportId);
      if (!detail || !detail.data) {
        alert("Rapor verisi bulunamadı.");
        return;
      }

      state.currentFileName = detail.dosya_adi || "geçmiş_rapor.xml";
      fileNameDisplay.textContent = state.currentFileName;
      fileSizeMeta.textContent = "Arşiv Kaydı";
      parseTimeDisplay.textContent = "Geçmişten Yüklendi";
      totalItemsMeta.textContent = `${detail.toplam_kalem} Kalem (${detail.toplam_adet} Adet)`;

      // Servis eşleme
      if (detail.service_id && serviceSelector) {
        serviceSelector.value = detail.service_id;
        state.selectedService = state.servicesList.find(s => s.id === detail.service_id) || {
          name: detail.service_name,
          floor: detail.service_floor,
          extension: detail.service_extension || ""
        };
      } else if (detail.service_name) {
        state.selectedService = {
          name: detail.service_name,
          floor: detail.service_floor,
          extension: detail.service_extension || ""
        };
      }

      applyCategorizeResult(detail.data);

      if (historyModal) historyModal.classList.remove("open");
      showToast(`İşlem ${detail.islem_no || ''} masaya başarıyla yüklendi.`);
    } catch (err) {
      alert("Rapor yüklenirken hata oluştu: " + err.message);
    }
  }

  // Rapor Geçmişi Modalı Butonları
  if (btnOpenHistory) {
    btnOpenHistory.addEventListener("click", () => {
      loadReportHistory();
      if (historyModal) historyModal.classList.add("open");
    });
  }

  if (btnCloseHistory) {
    btnCloseHistory.addEventListener("click", () => {
      if (historyModal) historyModal.classList.remove("open");
    });
  }

  if (btnCloseHistoryFooter) {
    btnCloseHistoryFooter.addEventListener("click", () => {
      if (historyModal) historyModal.classList.remove("open");
    });
  }

  if (historySearchInput) {
    historySearchInput.addEventListener("input", () => {
      renderHistoryTable();
    });
  }

  if (btnClearAllHistory) {
    btnClearAllHistory.addEventListener("click", async () => {
      if (confirm("DİKKAT: Tüm raporlama geçmişi kalıcı olarak silinecektir. Emin misiniz?")) {
        try {
          await ApiClient.clearAllReports();
          showToast("Tüm rapor geçmişi temizlendi.");
          await loadReportHistory();
        } catch (e) {
          alert("Temizleme hatası: " + e.message);
        }
      }
    });
  }

  if (btnSaveToHistory) {
    btnSaveToHistory.addEventListener("click", () => {
      saveCurrentToHistory(true);
    });
  }


  // -------------------------------------------------------------
  // 9. Kısa İsim (Alias) Yönetimi
  // -------------------------------------------------------------
  const aliasModal          = document.getElementById("aliasModal");
  const btnOpenAlias        = document.getElementById("btnOpenAlias");
  const btnCloseAlias       = document.getElementById("btnCloseAlias");
  const btnCloseAliasFooter = document.getElementById("btnCloseAliasFooter");
  const btnSaveAlias        = document.getElementById("btnSaveAlias");
  const aliasJenerikSearch      = document.getElementById("aliasJenerikSearch");
  const aliasJenerikDropdown    = document.getElementById("aliasJenerikDropdown");
  const aliasJenerikKoduDisplay = document.getElementById("aliasJenerikKoduDisplay");
  const aliasKisaIsimInput  = document.getElementById("aliasKisaIsimInput");
  const aliasNotlarInput    = document.getElementById("aliasNotlarInput");
  const aliasFormMsg        = document.getElementById("aliasFormMsg");
  const aliasTableBody      = document.getElementById("aliasTableBody");
  const aliasEmptyMsg       = document.getElementById("aliasEmptyMsg");
  const aliasTotalCount     = document.getElementById("aliasTotalCount");

  let selectedJenerik = null;
  let aliasDebounceTimer = null;

  function showAliasFormMsg(msg, isError = true) {
    if (!aliasFormMsg) return;
    aliasFormMsg.textContent = msg;
    aliasFormMsg.style.color = isError ? "var(--status-error)" : "var(--status-success)";
    aliasFormMsg.style.display = msg ? "block" : "none";
  }

  async function loadAliases() {
    try {
      const list = await ApiClient.getAliases();
      const map = {};
      if (Array.isArray(list)) {
        list.forEach(a => {
          if (a && a.jenerik_kodu && a.kisa_isim) {
            map[a.jenerik_kodu] = a.kisa_isim;
          }
        });
      }
      state.aliasMap = map;
      if (state.currentData) {
        syncAliasesToData(state.currentData);
        renderTable();
      }
      renderAliasTable(list);
    } catch (e) { console.warn("Alias yuklenemedi:", e); }
  }

  function renderAliasTable(list) {
    if (!aliasTableBody) return;
    aliasTableBody.innerHTML = "";
    if (aliasTotalCount) aliasTotalCount.textContent = list.length;
    if (list.length === 0) {
      if (aliasEmptyMsg) aliasEmptyMsg.style.display = "block";
      return;
    }
    if (aliasEmptyMsg) aliasEmptyMsg.style.display = "none";

    list.forEach(alias => {
      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td><code style="font-size:0.8rem;">${alias.jenerik_kodu}</code></td>
        <td style="font-size:0.85rem;color:var(--text-secondary);">${alias.jenerik_adi || "-"}</td>
        <td><input type="text" value="${alias.kisa_isim}" data-alias-id="${alias.id}"
          class="form-input alias-inline-edit" style="padding:3px 6px;font-size:0.85rem;font-weight:700;" maxlength="100"></td>
        <td style="font-size:0.8rem;color:var(--text-muted);">${alias.notlar || ""}</td>
        <td style="text-align:center;">
          <button class="btn btn-primary btn-sm alias-save-btn" data-alias-id="${alias.id}"
            style="font-size:0.75rem;padding:2px 8px;margin-right:4px;" title="Kaydet">💾</button>
          <button class="btn btn-secondary btn-sm alias-del-btn" data-alias-id="${alias.id}"
            style="font-size:0.75rem;padding:2px 8px;color:var(--status-error);" title="Sil">🗑</button>
        </td>`;
      aliasTableBody.appendChild(tr);
    });

    aliasTableBody.querySelectorAll(".alias-save-btn").forEach(btn => {
      btn.addEventListener("click", async () => {
        const id = parseInt(btn.dataset.aliasId);
        const inp = aliasTableBody.querySelector(`.alias-inline-edit[data-alias-id="${id}"]`);
        const val = inp ? inp.value.trim() : "";
        if (!val) { alert("Kisa isim bos olamaz."); return; }
        try {
          await ApiClient.updateAlias(id, { kisa_isim: val });
          showToast("Kisa isim guncellendi.");
          await loadAliases();
        } catch (e) { alert("Guncelleme hatasi: " + e.message); }
      });
    });

    aliasTableBody.querySelectorAll(".alias-del-btn").forEach(btn => {
      btn.addEventListener("click", async () => {
        const id = parseInt(btn.dataset.aliasId);
        if (!confirm("Bu kisa isim silinecek. Emin misiniz?")) return;
        try {
          await ApiClient.deleteAlias(id);
          showToast("Kisa isim silindi.");
          await loadAliases();
        } catch (e) { alert("Silme hatasi: " + e.message); }
      });
    });
  }

  if (aliasJenerikSearch) {
    aliasJenerikSearch.addEventListener("input", () => {
      clearTimeout(aliasDebounceTimer);
      const q = aliasJenerikSearch.value.trim();
      if (q.length < 2) { aliasJenerikDropdown.style.display = "none"; return; }
      aliasDebounceTimer = setTimeout(async () => {
        try {
          const results = await ApiClient.searchJenerik(q);
          renderJenerikDropdown(results);
        } catch (e) { console.warn(e); }
      }, 300);
    });
    aliasJenerikSearch.addEventListener("blur", () => {
      setTimeout(() => { aliasJenerikDropdown.style.display = "none"; }, 200);
    });
  }

  function renderJenerikDropdown(results) {
    if (!aliasJenerikDropdown) return;
    if (!results || results.length === 0) {
      aliasJenerikDropdown.innerHTML = `<div style="padding:10px 14px;font-size:0.82rem;color:var(--text-muted);">Sonuç bulunamadı</div>`;
      aliasJenerikDropdown.style.display = "block";
      return;
    }
    aliasJenerikDropdown.innerHTML = results.map(r => `
      <div class="jenerik-item" data-kodu="${r.jenerik_kodu}" data-adi="${r.jenerik_adi || ""}">
        <span class="ji-kodu">${r.jenerik_kodu}</span>
        <span class="ji-adi">${r.jenerik_adi || "-"}</span>
        <span class="ji-sayi">${r.ilac_sayisi} ilaç</span>
      </div>`).join("");
    aliasJenerikDropdown.style.display = "block";

    aliasJenerikDropdown.querySelectorAll(".jenerik-item").forEach(item => {
      item.addEventListener("mousedown", () => {
        selectedJenerik = { jenerik_kodu: item.dataset.kodu, jenerik_adi: item.dataset.adi };
        aliasJenerikSearch.value = `${item.dataset.kodu} — ${item.dataset.adi}`;
        aliasJenerikKoduDisplay.value = item.dataset.kodu;
        aliasJenerikDropdown.style.display = "none";
      });
    });
  }

  if (btnSaveAlias) {
    btnSaveAlias.addEventListener("click", async () => {
      showAliasFormMsg("");
      if (!selectedJenerik || !selectedJenerik.jenerik_kodu) {
        showAliasFormMsg("Lutfen once jenerik grup arayip secin.");
        return;
      }
      const kisaIsim = aliasKisaIsimInput ? aliasKisaIsimInput.value.trim() : "";
      if (!kisaIsim) { showAliasFormMsg("Kisa isim bos olamaz."); return; }
      try {
        await ApiClient.createAlias({
          jenerik_kodu: selectedJenerik.jenerik_kodu,
          jenerik_adi:  selectedJenerik.jenerik_adi,
          kisa_isim:    kisaIsim,
          notlar: aliasNotlarInput ? aliasNotlarInput.value.trim() : null
        });
        showAliasFormMsg(`"${kisaIsim}" basariyla eklendi.`, false);
        aliasJenerikSearch.value = "";
        aliasJenerikKoduDisplay.value = "";
        aliasKisaIsimInput.value = "";
        aliasNotlarInput.value = "";
        selectedJenerik = null;
        await loadAliases();
      } catch (e) { showAliasFormMsg("Hata: " + e.message); }
    });
  }

  if (btnOpenAlias) {
    btnOpenAlias.addEventListener("click", async () => {
      if (aliasModal) aliasModal.classList.add("open");
      await loadAliases();
    });
  }
  [btnCloseAlias, btnCloseAliasFooter].forEach(btn => {
    if (btn) btn.addEventListener("click", () => {
      if (aliasModal) aliasModal.classList.remove("open");
    });
  });

  // Başlangıçta ayarları, servisleri, kısa isimleri ve rapor geçmişini yükle
  loadSettings();
  loadServices();
  loadAliases();
  loadReportHistory();
})();
