/**
 * API İletişim İstemcisi
 */
class ApiClient {
  static baseUrl = "";

  /**
   * Parse edilen kayıtları backend'e gönderip gruplandırma sonucunu alır
   * @param {Array} records 
   */
  static async categorize(records) {
    const response = await fetch(`${this.baseUrl}/api/categorize`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ records })
    });

    if (!response.ok) {
      const err = await response.json().catch(() => ({}));
      throw new Error(err.detail || "Sunucu ayrıştırma isteğini işleyemedi.");
    }

    return await response.json();
  }

  /**
   * Güncel filtre/kategori ayarlarını çeker
   */
  static async getSettings() {
    const response = await fetch(`${this.baseUrl}/api/settings`);
    if (!response.ok) {
      throw new Error("Ayarlar yüklenemedi.");
    }
    return await response.json();
  }

  /**
   * Filtre ayarlarını günceller
   * @param {Object} settingsData 
   */
  static async updateSettings(settingsData) {
    const response = await fetch(`${this.baseUrl}/api/settings`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(settingsData)
    });

    if (!response.ok) {
      throw new Error("Ayarlar kaydedilemedi.");
    }
    return await response.json();
  }

  /**
   * Servis ve Kat listesini çeker
   */
  static async getServices() {
    const response = await fetch(`${this.baseUrl}/api/services`);
    if (!response.ok) {
      throw new Error("Servisler yüklenemedi.");
    }
    return await response.json();
  }

  /**
   * Yeni servis ve kat ekler
   */
  static async createService(serviceData) {
    const response = await fetch(`${this.baseUrl}/api/services`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(serviceData)
    });
    if (!response.ok) {
      const err = await response.json().catch(() => ({}));
      throw new Error(err.detail || "Servis eklenemedi.");
    }
    return await response.json();
  }

  /**
   * Servis ve kat bilgisini günceller
   */
  static async updateService(id, serviceData) {
    const response = await fetch(`${this.baseUrl}/api/services/${id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(serviceData)
    });
    if (!response.ok) {
      const err = await response.json().catch(() => ({}));
      throw new Error(err.detail || "Servis güncellenemedi.");
    }
    return await response.json();
  }

  /**
   * Servisi siler
   */
  static async deleteService(id) {
    const response = await fetch(`${this.baseUrl}/api/services/${id}`, {
      method: "DELETE"
    });
    if (!response.ok) {
      throw new Error("Servis silinemedi.");
    }
    return await response.json();
  }

  /**
   * Raporlama geçmişi listesini çeker
   */
  static async getReports(limit = 50) {
    const response = await fetch(`${this.baseUrl}/api/reports?limit=${limit}`);
    if (!response.ok) {
      throw new Error("Rapor geçmişi yüklenemedi.");
    }
    return await response.json();
  }

  /**
   * Belirli bir geçmiş raporun tam verisini çeker
   */
  static async getReportDetail(id) {
    const response = await fetch(`${this.baseUrl}/api/reports/${id}`);
    if (!response.ok) {
      throw new Error("Rapor detayı yüklenemedi.");
    }
    return await response.json();
  }

  /**
   * Raporu geçmişe kaydeder
   */
  static async saveReport(reportData) {
    const response = await fetch(`${this.baseUrl}/api/reports`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(reportData)
    });
    if (!response.ok) {
      const err = await response.json().catch(() => ({}));
      throw new Error(err.detail || "Rapor geçmişe kaydedilemedi.");
    }
    return await response.json();
  }

  /**
   * Geçmişten belirli bir raporu siler
   */
  static async deleteReport(id) {
    const response = await fetch(`${this.baseUrl}/api/reports/${id}`, {
      method: "DELETE"
    });
    if (!response.ok) {
      throw new Error("Rapor silinemedi.");
    }
    return await response.json();
  }

  /**
   * Tüm raporlama geçmişini temizler
   */
  static async clearAllReports() {
    const response = await fetch(`${this.baseUrl}/api/reports`, {
      method: "DELETE"
    });
    if (!response.ok) {
      throw new Error("Rapor geçmişi temizlenemedi.");
    }
    return await response.json();
  }

  // ----------------------------------------------------------
  // İlaç Kısa İsimleri (Alias) API Metodları
  // ----------------------------------------------------------

  /** Tüm kısa isim tanımlarını listeler */
  static async getAliases() {
    const response = await fetch(`${this.baseUrl}/api/aliases`);
    if (!response.ok) throw new Error("Kısa isimler yüklenemedi.");
    return await response.json();
  }

  /** Yeni kısa isim ekler (jenerik_kodu, kisa_isim, [jenerik_adi, notlar]) */
  static async createAlias(data) {
    const response = await fetch(`${this.baseUrl}/api/aliases`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data)
    });
    if (!response.ok) {
      const err = await response.json().catch(() => ({}));
      throw new Error(err.detail || "Kısa isim eklenemedi.");
    }
    return await response.json();
  }

  /** Kısa isim günceller (kisa_isim, [notlar]) */
  static async updateAlias(id, data) {
    const response = await fetch(`${this.baseUrl}/api/aliases/${id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data)
    });
    if (!response.ok) throw new Error("Kısa isim güncellenemedi.");
    return await response.json();
  }

  /** Kısa isim siler */
  static async deleteAlias(id) {
    const response = await fetch(`${this.baseUrl}/api/aliases/${id}`, {
      method: "DELETE"
    });
    if (!response.ok) throw new Error("Kısa isim silinemedi.");
    return await response.json();
  }

  /** Master DB'de jenerik kodu/adı arar */
  static async searchJenerik(q) {
    const response = await fetch(
      `${this.baseUrl}/api/aliases/search-jenerik?q=${encodeURIComponent(q)}`
    );
    if (!response.ok) throw new Error("Jenerik arama başarısız.");
    return await response.json();
  }
}

window.ApiClient = ApiClient;

