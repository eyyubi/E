import unittest
from serumfiltre.app.core.database import SessionLocal, Base, engine
import serumfiltre.app.models # Register models
from serumfiltre.app.services.report_service import ReportService
from serumfiltre.app.services.hospital_service import HospitalServiceService
from serumfiltre.app.schemas.report import ReportHistoryCreate
from serumfiltre.app.schemas.service import ServiceCreate, ServiceUpdate

class TestReportService(unittest.TestCase):
    def setUp(self):
        Base.metadata.create_all(bind=engine)
        self.db = SessionLocal()

    def tearDown(self):
        self.db.close()

    def test_save_and_retrieve_report(self):
        test_data = {
            "islem_no": "TEST-9988",
            "toplam_kalem": 3,
            "toplam_adet": 15,
            "gruplar": {
                "tablet": {"key": "tablet", "name": "Tablet Grubu", "item_count": 1, "total_quantity": 5, "percentage": 33.3, "items": []},
                "serum": {"key": "serum", "name": "Serum & Mama Grubu", "item_count": 1, "total_quantity": 8, "percentage": 53.3, "items": []},
                "diger": {"key": "diger", "name": "Diğer İlaçlar", "item_count": 1, "total_quantity": 2, "percentage": 13.4, "items": []}
            },
            "tum_liste": []
        }

        req = ReportHistoryCreate(
            islem_no="TEST-9988",
            dosya_adi="test_recete.xml",
            service_id=1,
            service_name="Test Dahiliye",
            service_floor="Kat 3",
            service_extension="2145",
            data=test_data
        )

        saved = ReportService.save_report(self.db, req)
        self.assertIsNotNone(saved.id)
        self.assertEqual(saved.islem_no, "TEST-9988")
        self.assertEqual(saved.service_name, "Test Dahiliye")
        self.assertEqual(saved.service_extension, "2145")
        self.assertEqual(saved.toplam_kalem, 3)
        self.assertEqual(saved.toplam_adet, 15)

        # Retrieve detail
        detail = ReportService.get_by_id(self.db, saved.id)
        self.assertIsNotNone(detail)
        self.assertEqual(detail.islem_no, "TEST-9988")
        self.assertEqual(detail.service_extension, "2145")
        self.assertEqual(detail.data.toplam_kalem, 3)
        self.assertIn("tablet", detail.data.gruplar)

        # List all
        all_reports = ReportService.get_all(self.db)
        self.assertTrue(len(all_reports) >= 1)
        self.assertTrue(any(r.id == saved.id for r in all_reports))

        # Delete
        del_success = ReportService.delete(self.db, saved.id)
        self.assertTrue(del_success)

        # Verify deletion
        detail_after = ReportService.get_by_id(self.db, saved.id)
        self.assertIsNone(detail_after)

    def test_hospital_service_extension_crud(self):
        created = HospitalServiceService.create(
            self.db,
            ServiceCreate(name="Test Kardiyoloji", floor="Kat 4", code="KRD", extension="4410")
        )
        self.assertIsNotNone(created.id)
        self.assertEqual(created.extension, "4410")

        updated = HospitalServiceService.update(
            self.db,
            created.id,
            ServiceUpdate(name="Test Kardiyoloji", floor="Kat 4", code="KRD", extension="4412")
        )
        self.assertEqual(updated.extension, "4412")

        deleted = HospitalServiceService.delete(self.db, created.id)
        self.assertTrue(deleted)

if __name__ == "__main__":
    unittest.main()
