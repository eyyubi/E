from pydantic import BaseModel, ConfigDict, Field
from typing import Optional
from datetime import datetime


class DrugAliasCreate(BaseModel):
    """Yeni jenerik grup kısa ismi oluşturma"""
    jenerik_kodu: str = Field(description="Jenerik kodu (master_ilaclar.jenerik_kodu)")
    jenerik_adi: Optional[str] = Field(default=None, description="Jenerik grup adı (otomatik)")
    kisa_isim: str = Field(description="Kullanıcı tanımlı kısa isim (çıktıda gösterilir)")
    notlar: Optional[str] = Field(default=None)


class DrugAliasUpdate(BaseModel):
    """Kısa isim güncelleme"""
    kisa_isim: Optional[str] = None
    notlar: Optional[str] = None


class DrugAliasResponse(BaseModel):
    """API yanıtı"""
    model_config = ConfigDict(from_attributes=True)

    id: int
    jenerik_kodu: str
    jenerik_adi: Optional[str] = None
    kisa_isim: str
    notlar: Optional[str] = None
    created_at: datetime
    updated_at: datetime


class JenerikSearchResult(BaseModel):
    """Master DB'den jenerik kodu arama sonucu"""
    jenerik_kodu: str
    jenerik_adi: Optional[str] = None
    ilac_sayisi: int = 0  # Bu jenerikteki ilaç barkod sayısı
