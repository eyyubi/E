from pydantic import BaseModel, ConfigDict, Field
from typing import Optional

class ServiceBase(BaseModel):
    name: str = Field(..., description="Servis / Klinik Adı (Örn: Dahiliye)")
    floor: str = Field(..., description="Bulunduğu Kat (Örn: Kat 2)")
    code: Optional[str] = Field(default="", description="Servis Kodu (Örn: DH)")
    extension: Optional[str] = Field(default="", description="Dahili Telefon No (Örn: 2145)")

class ServiceCreate(ServiceBase):
    pass

class ServiceUpdate(ServiceBase):
    pass

class ServiceResponse(ServiceBase):
    model_config = ConfigDict(from_attributes=True)

    id: int
