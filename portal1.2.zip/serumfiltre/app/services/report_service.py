import json
from sqlalchemy.orm import Session
from typing import List, Optional
from datetime import datetime

from serumfiltre.app.models.report import ReportHistory
from serumfiltre.app.schemas.report import ReportHistoryCreate, ReportHistoryListItem, ReportHistoryDetail

class ReportService:
    """Raporlama Geçmişi Servis Mantığı"""

    @staticmethod
    def save_report(db: Session, report_data: ReportHistoryCreate) -> ReportHistoryListItem:
        """Yeni bir raporu geçmişe kaydeder veya mükerrer kaydı önler"""
        data = report_data.data or {}
        
        islem_no = report_data.islem_no or data.get("islem_no", "-")
        dosya_adi = report_data.dosya_adi or "reçete.xml"
        
        toplam_kalem = int(data.get("toplam_kalem", 0))
        toplam_adet = int(data.get("toplam_adet", 0))

        gruplar = data.get("gruplar", {})
        tablet = gruplar.get("tablet", {})
        serum = gruplar.get("serum", {})
        diger = gruplar.get("diger", {})

        tablet_kalem = int(tablet.get("item_count", 0))
        tablet_adet = int(tablet.get("total_quantity", 0))
        serum_kalem = int(serum.get("item_count", 0))
        serum_adet = int(serum.get("total_quantity", 0))
        diger_kalem = int(diger.get("item_count", 0))
        diger_adet = int(diger.get("total_quantity", 0))

        data_json_str = json.dumps(data, ensure_ascii=False)

        # Mükerrer kontrolü: Son 1 saat içinde aynı işlem no, aynı dosya adı ve aynı servis ile kaydedilmişse güncelle
        existing = db.query(ReportHistory).filter(
            ReportHistory.islem_no == islem_no,
            ReportHistory.dosya_adi == dosya_adi,
            ReportHistory.toplam_kalem == toplam_kalem,
            ReportHistory.toplam_adet == toplam_adet
        ).order_by(ReportHistory.id.desc()).first()

        if existing:
            # Servis değişmişse güncelle
            if report_data.service_name:
                existing.service_id = report_data.service_id
                existing.service_name = report_data.service_name
                existing.service_floor = report_data.service_floor
                existing.service_extension = report_data.service_extension
            existing.data_json = data_json_str
            existing.created_at = datetime.now()
            db.commit()
            db.refresh(existing)
            record = existing
        else:
            record = ReportHistory(
                islem_no=islem_no,
                dosya_adi=dosya_adi,
                service_id=report_data.service_id,
                service_name=report_data.service_name,
                service_floor=report_data.service_floor,
                service_extension=report_data.service_extension,
                toplam_kalem=toplam_kalem,
                toplam_adet=toplam_adet,
                tablet_kalem=tablet_kalem,
                tablet_adet=tablet_adet,
                serum_kalem=serum_kalem,
                serum_adet=serum_adet,
                diger_kalem=diger_kalem,
                diger_adet=diger_adet,
                data_json=data_json_str,
                created_at=datetime.now()
            )
            db.add(record)
            db.commit()
            db.refresh(record)

        return ReportService._to_list_item(record)

    @staticmethod
    def get_all(db: Session, limit: int = 50) -> List[ReportHistoryListItem]:
        """Tüm geçmiş raporları en yeniden eskiye listeler"""
        records = db.query(ReportHistory).order_by(ReportHistory.id.desc()).limit(limit).all()
        return [ReportService._to_list_item(r) for r in records]

    @staticmethod
    def get_by_id(db: Session, report_id: int) -> Optional[ReportHistoryDetail]:
        """Belirli bir geçmiş raporun tam verisini döner"""
        record = db.query(ReportHistory).filter(ReportHistory.id == report_id).first()
        if not record:
            return None

        data_dict = json.loads(record.data_json)
        formatted_date = record.created_at.strftime("%d.%m.%Y %H:%M") if record.created_at else "-"

        return ReportHistoryDetail(
            id=record.id,
            islem_no=record.islem_no,
            dosya_adi=record.dosya_adi,
            service_id=record.service_id,
            service_name=record.service_name,
            service_floor=record.service_floor,
            service_extension=record.service_extension,
            toplam_kalem=record.toplam_kalem,
            toplam_adet=record.toplam_adet,
            tablet_kalem=record.tablet_kalem,
            tablet_adet=record.tablet_adet,
            serum_kalem=record.serum_kalem,
            serum_adet=record.serum_adet,
            diger_kalem=record.diger_kalem,
            diger_adet=record.diger_adet,
            created_at=record.created_at,
            created_at_formatted=formatted_date,
            data=data_dict
        )

    @staticmethod
    def delete(db: Session, report_id: int) -> bool:
        """Geçmiş raporu siler"""
        record = db.query(ReportHistory).filter(ReportHistory.id == report_id).first()
        if not record:
            return False
        db.delete(record)
        db.commit()
        return True

    @staticmethod
    def clear_all(db: Session) -> bool:
        """Tüm raporlama geçmişini temizler"""
        db.query(ReportHistory).delete()
        db.commit()
        return True

    @staticmethod
    def _to_list_item(r: ReportHistory) -> ReportHistoryListItem:
        formatted_date = r.created_at.strftime("%d.%m.%Y %H:%M") if r.created_at else "-"
        return ReportHistoryListItem(
            id=r.id,
            islem_no=r.islem_no,
            dosya_adi=r.dosya_adi,
            service_id=r.service_id,
            service_name=r.service_name,
            service_floor=r.service_floor,
            service_extension=r.service_extension,
            toplam_kalem=r.toplam_kalem,
            toplam_adet=r.toplam_adet,
            tablet_kalem=r.tablet_kalem,
            tablet_adet=r.tablet_adet,
            serum_kalem=r.serum_kalem,
            serum_adet=r.serum_adet,
            diger_kalem=r.diger_kalem,
            diger_adet=r.diger_adet,
            created_at=r.created_at,
            created_at_formatted=formatted_date
        )
