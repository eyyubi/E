"""Dinamik Tablet ve Blister Etiket Baskı Modülü"""
