from typing import Optional, List
from pydantic import BaseModel, ConfigDict, Field, AliasChoices

class BlisterTemplateCreate(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    id: Optional[str] = None
    name: str = Field(..., min_length=1, max_length=100)
    orientation: str = Field("dikey", pattern="^(dikey|yatay)$")
    medicineName: str = Field("", validation_alias=AliasChoices("medicineName", "medicine_name"), max_length=300)
    expiry: str = Field("", max_length=100)
    rows: int = Field(7, ge=1, le=15)
    columns: int = Field(7, ge=1, le=15)
    fontSize: Optional[float] = Field(None, validation_alias=AliasChoices("fontSize", "font_size"), ge=2.0, le=36.0)

class BlisterTemplateResponse(BaseModel):
    model_config = ConfigDict(populate_by_name=True, from_attributes=True)

    id: str
    name: str
    orientation: str
    medicineName: str = Field("", validation_alias=AliasChoices("medicineName", "medicine_name"))
    expiry: str
    rows: int
    columns: int
    fontSize: Optional[float] = Field(None, validation_alias=AliasChoices("fontSize", "font_size"))
    createdAt: Optional[str] = None
    updatedAt: Optional[str] = None

class BatchTemplatesPayload(BaseModel):
    templates: List[BlisterTemplateCreate]
