import uuid
from datetime import datetime, timezone
from sqlalchemy import Column, String, Integer, Float, DateTime
from core.database import EtiketBase

def _utcnow():
    return datetime.now(timezone.utc)

class BlisterTemplate(EtiketBase):
    __tablename__ = "blister_templates"

    id = Column(String(120), primary_key=True, default=lambda: str(uuid.uuid4()))
    name = Column(String(100), unique=True, nullable=False, index=True)
    orientation = Column(String(10), nullable=False, default="dikey")  # 'dikey' veya 'yatay'
    medicine_name = Column(String(300), nullable=False, default="")
    expiry = Column(String(100), nullable=False, default="")
    rows = Column(Integer, nullable=False, default=7)
    columns = Column(Integer, nullable=False, default=7)
    font_size = Column(Float, nullable=True, default=None)  # None: Otomatik sığdır, sayı: pt cinsinden sabit yazı boyutu
    created_at = Column(DateTime, default=_utcnow)
    updated_at = Column(DateTime, default=_utcnow, onupdate=_utcnow)

    def to_dict(self):
        return {
            "id": self.id,
            "name": self.name,
            "orientation": self.orientation,
            "medicineName": self.medicine_name,
            "expiry": self.expiry,
            "rows": self.rows,
            "columns": self.columns,
            "fontSize": self.font_size,
            "createdAt": self.created_at.isoformat() if self.created_at else None,
            "updatedAt": self.updated_at.isoformat() if self.updated_at else None,
        }
