import uuid
from typing import List, Set
from fastapi import APIRouter, Depends, HTTPException, WebSocket, WebSocketDisconnect
from sqlalchemy.orm import Session

from core.database import get_etiket_db
from etiket.models import BlisterTemplate
from etiket.schemas import (
    BlisterTemplateCreate,
    BlisterTemplateResponse,
    BatchTemplatesPayload,
)

# ── WEBSOCKET BAĞLANTI YÖNETİCİSİ (Anlık Eşzamanlama) ─────────────────────────
class EtiketConnectionManager:
    """Ağdaki tüm aktif istemcilere anlık şablon güncellemelerini yayınlar."""
    def __init__(self):
        self.active_connections: Set[WebSocket] = set()

    async def connect(self, websocket: WebSocket):
        await websocket.accept()
        self.active_connections.add(websocket)

    def disconnect(self, websocket: WebSocket):
        self.active_connections.discard(websocket)

    async def broadcast(self, message: str = "templates_updated"):
        for connection in list(self.active_connections):
            try:
                await connection.send_text(message)
            except Exception:
                self.active_connections.discard(connection)

etiket_ws_manager = EtiketConnectionManager()

router = APIRouter(prefix="/api/etiket", tags=["Tablet & Blister Etiket"])

@router.websocket("/ws")
async def websocket_etiket_endpoint(websocket: WebSocket):
    """Anlık şablon senkronizasyonu için WebSocket kanalı"""
    await etiket_ws_manager.connect(websocket)
    try:
        while True:
            msg = await websocket.receive_text()
            if msg == "refresh":
                await etiket_ws_manager.broadcast("templates_updated")
    except (WebSocketDisconnect, Exception):
        etiket_ws_manager.disconnect(websocket)


@router.get("/templates", response_model=List[BlisterTemplateResponse])
def get_all_templates(db: Session = Depends(get_etiket_db)):
    """Tüm ortak kayıtlı şablonları alfabetik listeler"""
    items = db.query(BlisterTemplate).order_by(BlisterTemplate.name.asc()).all()
    return [item.to_dict() for item in items]


@router.post("/templates", response_model=BlisterTemplateResponse)
async def create_or_update_template(
    payload: BlisterTemplateCreate,
    db: Session = Depends(get_etiket_db),
):
    """Ortak şablon oluşturur veya mevcut olanı günceller (Upsert)"""
    normalized_name = payload.name.strip()
    if not normalized_name:
        raise HTTPException(status_code=400, detail="Şablon adı boş olamaz.")

    # İsim veya ID üzerinden mevcut kaydı bul
    existing = None
    if payload.id:
        existing = db.query(BlisterTemplate).filter(BlisterTemplate.id == payload.id).first()
    if not existing:
        existing = (
            db.query(BlisterTemplate)
            .filter(BlisterTemplate.name.ilike(normalized_name))
            .first()
        )

    if existing:
        existing.name = normalized_name
        existing.orientation = payload.orientation
        existing.medicine_name = payload.medicineName.strip()
        existing.expiry = payload.expiry.strip()
        existing.rows = payload.rows
        existing.columns = payload.columns
        existing.font_size = payload.fontSize
        target = existing
    else:
        target = BlisterTemplate(
            id=payload.id or str(uuid.uuid4()),
            name=normalized_name,
            orientation=payload.orientation,
            medicine_name=payload.medicineName.strip(),
            expiry=payload.expiry.strip(),
            rows=payload.rows,
            columns=payload.columns,
            font_size=payload.fontSize,
        )
        db.add(target)

    db.commit()
    db.refresh(target)

    # Ağdaki tüm açık istemcilere anlık yenileme sinyali gönder
    await etiket_ws_manager.broadcast("templates_updated")
    return target.to_dict()


@router.delete("/templates/{template_id}")
async def delete_template(template_id: str, db: Session = Depends(get_etiket_db)):
    """Seçili şablonu ortak veritabanından kalıcı olarak siler"""
    item = db.query(BlisterTemplate).filter(BlisterTemplate.id == template_id).first()
    if not item:
        raise HTTPException(status_code=404, detail="Şablon bulunamadı.")

    db.delete(item)
    db.commit()

    # Ağdaki tüm açık istemcilere anlık silinme sinyali gönder
    await etiket_ws_manager.broadcast("templates_updated")
    return {"success": True, "message": "Şablon silindi", "id": template_id}


@router.post("/templates/batch")
async def import_batch_templates(
    payload: BatchTemplatesPayload,
    db: Session = Depends(get_etiket_db),
):
    """Toplu şablon aktarımı (JSON yedekten veya tarayıcı senkronizasyonundan)"""
    imported_count = 0
    for tpl in payload.templates:
        norm_name = tpl.name.strip()
        if not norm_name:
            continue
        existing = None
        if tpl.id:
            existing = db.query(BlisterTemplate).filter(BlisterTemplate.id == tpl.id).first()
        if not existing:
            existing = (
                db.query(BlisterTemplate)
                .filter(BlisterTemplate.name.ilike(norm_name))
                .first()
            )

        if existing:
            existing.name = norm_name
            existing.orientation = tpl.orientation
            existing.medicine_name = tpl.medicineName.strip()
            existing.expiry = tpl.expiry.strip()
            existing.rows = tpl.rows
            existing.columns = tpl.columns
            existing.font_size = tpl.fontSize
        else:
            new_item = BlisterTemplate(
                id=tpl.id or str(uuid.uuid4()),
                name=norm_name,
                orientation=tpl.orientation,
                medicine_name=tpl.medicineName.strip(),
                expiry=tpl.expiry.strip(),
                rows=tpl.rows,
                columns=tpl.columns,
                font_size=tpl.fontSize,
            )
            db.add(new_item)
        imported_count += 1

    db.commit()
    await etiket_ws_manager.broadcast("templates_updated")
    return {"success": True, "count": imported_count}
