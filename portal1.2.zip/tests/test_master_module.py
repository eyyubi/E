import importlib.util
import unittest
from pathlib import Path

MODULE_PATH = Path(__file__).resolve().parent.parent / "modules" / "master-ilac-backend" / "main.py"


class TestMasterIlacCleanArchitectureAndPermissions(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        spec = importlib.util.spec_from_file_location("master_backend_main", str(MODULE_PATH))
        cls.mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(cls.mod)

    def test_01_health_check_returns_clean_architecture_metadata(self):
        res = self.mod.health_check()
        self.assertEqual(res["status"], "healthy")
        self.assertEqual(res["details"]["architecture"], "clean-architecture")
        self.assertGreater(res["details"]["total_drugs"], 10000)

    def test_02_stats_capability(self):
        st = self.mod.execute("drug-catalog", "stats")
        self.assertGreater(st["total_products"], 10000)
        self.assertGreater(st["total_generics"], 1000)
        self.assertGreater(st["total_substances"], 1000)

    def test_03_search_drugs_pagination(self):
        sr = self.mod.execute("drug-catalog", "search_drugs", {"query": "parol", "limit": 5})
        self.assertGreater(sr["total"], 0)
        self.assertLessEqual(len(sr["items"]), 5)
        self.assertIn("urun_adi", sr["items"][0])

    def test_04_bilingual_substance_resolution(self):
        res = self.mod.execute("drug-catalog", "resolve_substance", {"term": "Paracetamol"})
        self.assertGreater(len(res["items"]), 0)
        first = res["items"][0]
        self.assertIn("Parasetamol", first["tr_name"])

    def test_05_granular_permission_allow_create_drug(self):
        # drug:create izni olan bağlam
        payload = {
            "urun_adi": "TEMIZ MIMARI TEST ILAC",
            "barkod": "9999999999991",
            "ambalaj": "10 Kapsül",
            "context": {"permissions": ["drug:read", "drug:create"]}
        }
        res = self.mod.execute("drug-catalog", "create_drug", payload)
        self.assertTrue(res["success"])
        new_id = res["urun_id"]

        # Temizlik
        self.mod.execute("drug-catalog", "delete_drug", {
            "urun_id": new_id,
            "context": {"permissions": ["drug:delete"]}
        })

    def test_06_granular_permission_forbidden_create_drug(self):
        # !drug:create ile engellenmiş bağlam
        payload = {
            "urun_adi": "YASAKLI ILAC",
            "context": {"permissions": ["drug:read", "!drug:create"]}
        }
        with self.assertRaises(Exception) as ctx:
            self.mod.execute("drug-catalog", "create_drug", payload)
        self.assertIn("açıkça kısıtlanmıştır", str(ctx.exception))

    def test_07_granular_permission_forbidden_update_drug(self):
        # !drug:update ile engellenmiş bağlam
        payload = {
            "urun_id": 1,
            "urun_adi": "GUNCELLEME DENEMESI",
            "context": {"permissions": ["drug:read", "!drug:update"]}
        }
        with self.assertRaises(Exception) as ctx:
            self.mod.execute("drug-catalog", "update_drug", payload)
        self.assertIn("açıkça kısıtlanmıştır", str(ctx.exception))

    def test_08_granular_permission_forbidden_delete_drug(self):
        # !drug:delete ile engellenmiş bağlam
        payload = {
            "urun_id": 1,
            "context": {"permissions": ["drug:read", "!drug:delete"]}
        }
        with self.assertRaises(Exception) as ctx:
            self.mod.execute("drug-catalog", "delete_drug", payload)
        self.assertIn("açıkça kısıtlanmıştır", str(ctx.exception))

    def test_09_unknown_capability_fails(self):
        with self.assertRaises(ValueError):
            self.mod.execute("unknown-capability", "action")
