import unittest
from fastapi.testclient import TestClient
from main import app
from core.database import EtiketSessionLocal, init_all_databases
from etiket.models import BlisterTemplate

class TestEtiketTemplates(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        init_all_databases()
        cls.client = TestClient(app)

    def setUp(self):
        # Her testten önce test şablonlarını temizle
        db = EtiketSessionLocal()
        try:
            db.query(BlisterTemplate).delete()
            db.commit()
        finally:
            db.close()

    def test_01_create_and_list_template(self):
        """SQLAlchemy ile yeni şablon oluşturma ve listeleme testi"""
        payload = {
            "name": "Parol 500mg 7x7",
            "orientation": "dikey",
            "medicineName": "Parol 500 mg Tablet",
            "expiry": "12/2028",
            "rows": 7,
            "columns": 7,
        }
        res = self.client.post("/api/etiket/templates", json=payload)
        self.assertEqual(res.status_code, 200)
        data = res.json()
        self.assertEqual(data["name"], "Parol 500mg 7x7")
        self.assertEqual(data["medicineName"], "Parol 500 mg Tablet")
        self.assertEqual(data["orientation"], "dikey")
        self.assertEqual(data["rows"], 7)
        self.assertEqual(data["columns"], 7)
        template_id = data["id"]
        self.assertTrue(bool(template_id))

        # Listeleme
        list_res = self.client.get("/api/etiket/templates")
        self.assertEqual(list_res.status_code, 200)
        items = list_res.json()
        self.assertEqual(len(items), 1)
        self.assertEqual(items[0]["id"], template_id)

    def test_02_update_existing_template(self):
        """Aynı isimde şablon kaydedildiğinde üzerine güncelleme (upsert) testi"""
        payload1 = {
            "name": "Augmentin 1g",
            "orientation": "dikey",
            "medicineName": "Augmentin 1000 mg",
            "expiry": "06/2027",
            "rows": 6,
            "columns": 5,
        }
        res1 = self.client.post("/api/etiket/templates", json=payload1)
        self.assertEqual(res1.status_code, 200)
        id1 = res1.json()["id"]

        # Güncelleme
        payload2 = {
            "id": id1,
            "name": "Augmentin 1g",
            "orientation": "yatay",
            "medicineName": "Augmentin BID 1000 mg Film Tablet",
            "expiry": "08/2027",
            "rows": 5,
            "columns": 6,
        }
        res2 = self.client.post("/api/etiket/templates", json=payload2)
        self.assertEqual(res2.status_code, 200)
        data2 = res2.json()
        self.assertEqual(data2["id"], id1)
        self.assertEqual(data2["orientation"], "yatay")
        self.assertEqual(data2["medicineName"], "Augmentin BID 1000 mg Film Tablet")

        # Veritabanında tek kayıt kalmalı
        list_res = self.client.get("/api/etiket/templates")
        items = list_res.json()
        self.assertEqual(len(items), 1)

    def test_03_delete_template(self):
        """Şablon silme uç noktası testi"""
        res = self.client.post("/api/etiket/templates", json={
            "name": "Silinecek İlaç",
            "orientation": "dikey",
            "medicineName": "Test 100 mg",
            "expiry": "01/2026",
            "rows": 4,
            "columns": 4,
        })
        self.assertEqual(res.status_code, 200)
        tpl_id = res.json()["id"]

        # Sil
        del_res = self.client.delete(f"/api/etiket/templates/{tpl_id}")
        self.assertEqual(del_res.status_code, 200)
        self.assertTrue(del_res.json()["success"])

        # Tekrar listele
        list_res = self.client.get("/api/etiket/templates")
        self.assertEqual(len(list_res.json()), 0)

        # Olmayan kaydı silme 404
        del_404 = self.client.delete("/api/etiket/templates/olmayan-id")
        self.assertEqual(del_404.status_code, 404)

    def test_04_batch_import(self):
        """Toplu şablon aktarım testi"""
        batch_payload = {
            "templates": [
                {
                    "name": "Aferin Sinus",
                    "orientation": "dikey",
                    "medicineName": "A-Ferin Sinus Tablet",
                    "expiry": "11/2026",
                    "rows": 5,
                    "columns": 5,
                },
                {
                    "name": "Coraspin 100",
                    "orientation": "yatay",
                    "medicineName": "Coraspin 100 mg",
                    "expiry": "05/2029",
                    "rows": 8,
                    "columns": 8,
                }
            ]
        }
        res = self.client.post("/api/etiket/templates/batch", json=batch_payload)
        self.assertEqual(res.status_code, 200)
        self.assertEqual(res.json()["count"], 2)

        list_res = self.client.get("/api/etiket/templates")
        self.assertEqual(len(list_res.json()), 2)

    def test_05_websocket_connection_and_broadcast(self):
        """Anlık senkronizasyon için WebSocket bağlantı testi"""
        with self.client.websocket_connect("/api/etiket/ws") as websocket:
            websocket.send_text("refresh")
            # Yayın mesajı test edilir
            data = websocket.receive_text()
            self.assertEqual(data, "templates_updated")

    def test_06_template_font_size(self):
        """Şablonlarda özel yazı boyutu (fontSize) kaydetme ve güncelleme testi"""
        payload = {
            "name": "Majezik 100mg Özel Puntolu",
            "orientation": "dikey",
            "medicineName": "Majezik 100 mg Film Tablet",
            "expiry": "09/2028",
            "rows": 5,
            "columns": 3,
            "fontSize": 7.5,
        }
        res = self.client.post("/api/etiket/templates", json=payload)
        self.assertEqual(res.status_code, 200)
        data = res.json()
        self.assertEqual(data["fontSize"], 7.5)
        tpl_id = data["id"]

        # Otomatik moda (fontSize: None) geri döndürme
        payload_auto = {
            "id": tpl_id,
            "name": "Majezik 100mg Özel Puntolu",
            "orientation": "dikey",
            "medicineName": "Majezik 100 mg Film Tablet",
            "expiry": "09/2028",
            "rows": 5,
            "columns": 3,
            "fontSize": None,
        }
        res2 = self.client.post("/api/etiket/templates", json=payload_auto)
        self.assertEqual(res2.status_code, 200)
        self.assertIsNone(res2.json()["fontSize"])

if __name__ == "__main__":
    unittest.main()
