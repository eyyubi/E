#!/usr/bin/env python3
import sys
import uvicorn
from core.config import settings, HOST, PORT, get_lan_ip

def main():
    lan_ip = get_lan_ip()
    border = "═" * 68
    
    print(f"\n{border}")
    print(f"  🏥  {settings.PROJECT_NAME}  v{settings.VERSION}")
    print(f"  🔗  Ortak Master Veritabanı ile Güçlendirildi (17.608 İlaç)")
    print(f"{border}")
    print(f"  ► Yerel Erişim (Localhost):  http://127.0.0.1:{PORT}")
    print(f"  ► Yerel Ağ Erişimi (LAN):    http://{lan_ip}:{PORT}")
    print(f"{border}")
    print(f"  Uygulama Modülleri:")
    print(f"   🏠  Merkezi Portal:          http://{lan_ip}:{PORT}/")
    print(f"   🩺  Medikal Reçete:          http://{lan_ip}:{PORT}/recete")
    print(f"   📦  Numune İlaç & Miad:      http://{lan_ip}:{PORT}/numune")
    print(f"   🧪  Serum & İlaç Filtre:     http://{lan_ip}:{PORT}/serum")
    print(f"   🏷️  Tablet & Blister Etiket: http://{lan_ip}:{PORT}/etiket")
    print(f"   📚  Master İlaç Düzenleme:   http://{lan_ip}:{PORT}/master")
    print(f"   📘  API Dokümantasyonu:      http://{lan_ip}:{PORT}/docs")
    print(f"{border}\n")

    uvicorn.run(
        "main:app",
        host=HOST,
        port=PORT,
        reload=True
    )

if __name__ == "__main__":
    main()
