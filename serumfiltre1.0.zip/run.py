import uvicorn
from app.core.config import settings

if __name__ == "__main__":
    print(f"=====================================================")
    print(f" {settings.PROJECT_NAME} v{settings.VERSION} Başlatılıyor...")
    print(f" Yerel Erişim:      http://127.0.0.1:{settings.PORT}")
    print(f" Yerel Ağ (LAN):   http://0.0.0.0:{settings.PORT}")
    print(f"=====================================================")
    uvicorn.run(
        "app.main:app",
        host=settings.HOST,
        port=settings.PORT,
        reload=True
    )
