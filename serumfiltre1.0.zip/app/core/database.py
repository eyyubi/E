from sqlalchemy import create_engine
from sqlalchemy.orm import declarative_base, sessionmaker
from app.core.config import settings

# SQLite bağlantısı
engine = create_engine(
    settings.DATABASE_URL,
    connect_args={"check_same_thread": False}
)

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

Base = declarative_base()

def get_db():
    """FastAPI bağımlılık enjeksiyonu için veritabanı oturumu sağlayıcı"""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
