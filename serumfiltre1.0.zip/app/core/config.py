import os
from pathlib import Path
from pydantic import BaseModel
from typing import List

# Dizin yolları
BASE_DIR = Path(__file__).resolve().parent.parent.parent
DB_PATH = BASE_DIR / "masterdrugs" / "medication_db.sqlite"
SETTINGS_FILE = BASE_DIR / "masterdrugs" / "filter_settings.json"

class FilterConfig(BaseModel):
    """Kategori kuralları için yapılandırma modeli"""
    group1_name: str = "Tablet Grubu"
    group1_nfc_prefixes: List[str] = ["A", "B"]
    
    group2_name: str = "Serum & Mama Grubu"
    group2_atc_prefixes: List[str] = ["B05", "V06"]
    
    group3_name: str = "Diğer İlaçlar"

class Settings:
    PROJECT_NAME: str = "İlaç Filtreleme"
    VERSION: str = "1.0.0"
    HOST: str = os.getenv("HOST", "0.0.0.0")
    PORT: int = int(os.getenv("PORT", 8000))
    DATABASE_URL: str = f"sqlite:///{DB_PATH}"

settings = Settings()
