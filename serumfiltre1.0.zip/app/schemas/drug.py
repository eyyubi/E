from pydantic import BaseModel, Field
from typing import Optional, List

class RawRec(BaseModel):
    """XML içinden okunan tekil <REC> kaydı"""
    miktar: int = Field(default=1, description="Adet / Miktar")
    orjkod: str = Field(description="İlaç barkodu / orijinal kodu")
    tb_key: Optional[int] = Field(default=None, description="Kayıt tekil anahtarı")
    bi_rafid: Optional[str] = Field(default="", description="Raf / depo konumu")
    islemno: Optional[int] = Field(default=None, description="İşlem / sipariş numarası")

class AggregatedDrug(BaseModel):
    """Aynı barkoda sahip kayıtların birleştirilmiş hali ve master veritabanı eşleşmesi"""
    barkod: str
    toplam_miktar: int
    raf_konumu: str = ""
    raf_konumlari: List[str] = []
    islem_no: Optional[int] = None
    
    # Master veritabanı alanları
    urun_id: Optional[int] = None
    urun_adi: str = "Kayıtsız İlaç / Tanımsız Barkod"
    ambalaj: Optional[str] = None
    firma_adi: Optional[str] = None
    nfc_kodu: Optional[str] = None
    atc_kodu: Optional[str] = None
    recete_turu: Optional[str] = None
    
    # Kategori bilgisi
    kategori_key: str = "diger"  # "tablet", "serum", "diger"
    kategori_adi: str = "Diğer İlaçlar"
    bulundu: bool = False
