from pydantic import BaseModel, Field
from typing import List, Dict
from app.schemas.drug import AggregatedDrug

class CategoryGroup(BaseModel):
    """Her bir kategorinin liste ve istatistik özeti"""
    key: str
    name: str
    item_count: int = 0
    total_quantity: int = 0
    percentage: float = 0.0
    items: List[AggregatedDrug] = []

class CategorizeRequest(BaseModel):
    """Tarayıcıdan gönderilen ayrıştırma istek modeli"""
    records: List[dict] = Field(description="XML'den parse edilen ham kayıtlar")

class CategorizeResponse(BaseModel):
    """Frontend'e dönen nihai ayrıştırma yanıtı"""
    islem_no: str = "-"
    toplam_kalem: int = 0
    toplam_adet: int = 0
    gruplar: Dict[str, CategoryGroup]
    tum_liste: List[AggregatedDrug] = []
