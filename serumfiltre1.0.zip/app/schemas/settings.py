from pydantic import BaseModel
from typing import List

class FilterSettingsUpdate(BaseModel):
    """Kullanıcının güncelleyebileceği kategori kuralları"""
    group1_name: str = "Tablet Grubu"
    group1_nfc_prefixes: List[str] = ["A", "B"]
    
    group2_name: str = "Serum & Mama Grubu"
    group2_atc_prefixes: List[str] = ["B05", "V06"]
    
    group3_name: str = "Diğer İlaçlar"
