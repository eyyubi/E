from typing import List, Optional
from sqlalchemy.orm import Session
from app.models.service import HospitalService
from app.schemas.service import ServiceCreate, ServiceUpdate

class HospitalServiceService:
    @staticmethod
    def get_all(db: Session) -> List[HospitalService]:
        return db.query(HospitalService).order_by(HospitalService.name.asc()).all()

    @staticmethod
    def get_by_id(db: Session, service_id: int) -> Optional[HospitalService]:
        return db.query(HospitalService).filter(HospitalService.id == service_id).first()

    @staticmethod
    def create(db: Session, data: ServiceCreate) -> HospitalService:
        new_svc = HospitalService(
            name=data.name.strip(),
            floor=data.floor.strip(),
            code=data.code.strip() if data.code else ""
        )
        db.add(new_svc)
        db.commit()
        db.refresh(new_svc)
        return new_svc

    @staticmethod
    def update(db: Session, service_id: int, data: ServiceUpdate) -> Optional[HospitalService]:
        svc = db.query(HospitalService).filter(HospitalService.id == service_id).first()
        if not svc:
            return None
        svc.name = data.name.strip()
        svc.floor = data.floor.strip()
        svc.code = data.code.strip() if data.code else ""
        db.commit()
        db.refresh(svc)
        return svc

    @staticmethod
    def delete(db: Session, service_id: int) -> bool:
        svc = db.query(HospitalService).filter(HospitalService.id == service_id).first()
        if not svc:
            return False
        db.delete(svc)
        db.commit()
        return True
