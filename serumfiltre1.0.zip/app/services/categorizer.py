from typing import Tuple
from app.core.config import FilterConfig

class DrugCategorizer:
    """İlaçları NFC ve ATC kodlarına göre 3 ayrı gruba ayıran servis"""

    @staticmethod
    def classify(nfc_code: str | None, atc_code: str | None, config: FilterConfig) -> Tuple[str, str]:
        """
        İlacın NFC ve ATC kodunu yapılandırma kurallarına göre değerlendirir.
        Dönüş: (kategori_key, kategori_adi)
        Örn: ('tablet', 'Tablet Grubu')
        """
        nfc = (nfc_code or "").strip().upper()
        atc = (atc_code or "").strip().upper()

        # 1. Grup: Tablet Grubu (NFC kod önekleri, örn: A, B)
        for prefix in config.group1_nfc_prefixes:
            clean_pref = prefix.strip().upper()
            if clean_pref and nfc.startswith(clean_pref):
                return "tablet", config.group1_name

        # 2. Grup: Serum & Mama Grubu (ATC kod önekleri, örn: B05, V06)
        for prefix in config.group2_atc_prefixes:
            clean_pref = prefix.strip().upper()
            if clean_pref and atc.startswith(clean_pref):
                return "serum", config.group2_name

        # 3. Grup: Diğer İlaçlar
        return "diger", config.group3_name
