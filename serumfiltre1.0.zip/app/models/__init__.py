from app.models.drug import MasterIlac
from app.models.service import HospitalService
from app.models.report import ReportHistory

__all__ = ["MasterIlac", "HospitalService", "ReportHistory"]
