from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List

from app.core.database import get_db
from app.schemas.category import CategorizeRequest, CategorizeResponse
from app.schemas.settings import FilterSettingsUpdate
from app.schemas.service import ServiceCreate, ServiceUpdate, ServiceResponse
from app.schemas.report import ReportHistoryCreate, ReportHistoryListItem, ReportHistoryDetail
from app.core.config import FilterConfig
from app.services.drug_service import DrugService
from app.services.settings_service import SettingsService
from app.services.hospital_service import HospitalServiceService
from app.services.report_service import ReportService

router = APIRouter(prefix="/api", tags=["İlaç Filtreleme API"])

@router.get("/health")
def health_check():
    """Sistem sağlık kontrolü"""
    return {"status": "ok", "app": "İlaç Filtreleme"}

@router.post("/categorize", response_model=CategorizeResponse)
def categorize_medications(request: CategorizeRequest, db: Session = Depends(get_db)):
    """
    Tarayıcıdan iletilen XML kayıtlarını gruplar, miktarları toplar,
    master veritabanı ile eşleştirir ve 3 kategoriye ayırır.
    """
    try:
        response = DrugService.process_records(request.records, db)
        return response
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Ayrıştırma hatası: {str(e)}")

@router.get("/settings", response_model=FilterConfig)
def get_filter_settings():
    """Mevcut kategori ve filtre kurallarını getirir"""
    return SettingsService.get_settings()

@router.post("/settings", response_model=FilterConfig)
def update_filter_settings(settings_data: FilterSettingsUpdate):
    """Kategori ve filtre kurallarını günceller"""
    try:
        updated = SettingsService.save_settings(settings_data)
        return updated
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Ayarlar kaydedilemedi: {str(e)}")

# -------------------------------------------------------------
# Servis ve Kat Yönetimi Uç Noktaları
# -------------------------------------------------------------
@router.get("/services", response_model=List[ServiceResponse])
def get_services(db: Session = Depends(get_db)):
    """Tüm hastane servis ve kat kayıtlarını listeler"""
    return HospitalServiceService.get_all(db)

@router.post("/services", response_model=ServiceResponse)
def create_service(data: ServiceCreate, db: Session = Depends(get_db)):
    """Yeni servis ve kat kaydı ekler"""
    try:
        return HospitalServiceService.create(db, data)
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Servis eklenemedi: {str(e)}")

@router.put("/services/{service_id}", response_model=ServiceResponse)
def update_service(service_id: int, data: ServiceUpdate, db: Session = Depends(get_db)):
    """Mevcut servis ve kat bilgisini günceller"""
    svc = HospitalServiceService.update(db, service_id, data)
    if not svc:
        raise HTTPException(status_code=404, detail="Servis bulunamadı.")
    return svc

@router.delete("/services/{service_id}")
def delete_service(service_id: int, db: Session = Depends(get_db)):
    """Servis kaydını siler"""
    success = HospitalServiceService.delete(db, service_id)
    if not success:
        raise HTTPException(status_code=404, detail="Servis bulunamadı.")
    return {"status": "success", "message": "Servis silindi."}

# -------------------------------------------------------------
# Raporlama Geçmişi (Report History) Uç Noktaları
# -------------------------------------------------------------
@router.get("/reports", response_model=List[ReportHistoryListItem])
def get_reports(limit: int = 50, db: Session = Depends(get_db)):
    """Tüm geçmiş raporları listeler"""
    return ReportService.get_all(db, limit)

@router.get("/reports/{report_id}", response_model=ReportHistoryDetail)
def get_report_detail(report_id: int, db: Session = Depends(get_db)):
    """Belirli bir geçmiş raporun tam verisini döner"""
    report = ReportService.get_by_id(db, report_id)
    if not report:
        raise HTTPException(status_code=404, detail="Geçmiş rapor kaydı bulunamadı.")
    return report

@router.post("/reports", response_model=ReportHistoryListItem)
def save_report_history(data: ReportHistoryCreate, db: Session = Depends(get_db)):
    """Yeni bir raporu geçmişe kaydeder"""
    try:
        return ReportService.save_report(db, data)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Rapor kaydedilemedi: {str(e)}")

@router.delete("/reports/{report_id}")
def delete_report_history(report_id: int, db: Session = Depends(get_db)):
    """Belirli bir geçmiş raporu siler"""
    success = ReportService.delete(db, report_id)
    if not success:
        raise HTTPException(status_code=404, detail="Geçmiş rapor bulunamadı.")
    return {"status": "success", "message": "Rapor geçmişten silindi."}

@router.delete("/reports")
def clear_all_reports_history(db: Session = Depends(get_db)):
    """Tüm raporlama geçmişini temizler"""
    ReportService.clear_all(db)
    return {"status": "success", "message": "Tüm rapor geçmişi temizlendi."}
