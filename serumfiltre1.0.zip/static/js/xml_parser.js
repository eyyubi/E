/**
 * XML Parser Modülü
 * Tarayıcı üzerinde yerel olarak XML dosyasını okur ve REC kayıtlarını JSON dizisine dönüştürür.
 */
class XmlDrugParser {
  /**
   * XML metnini parse eder
   * @param {string} xmlText 
   * @returns {Array<{miktar: number, orjkod: string, tb_key: number|null, bi_rafid: string, islemno: number|null}>}
   */
  static parse(xmlText) {
    if (!xmlText || typeof xmlText !== 'string') {
      throw new Error("Geçerli bir XML metni sağlanmadı.");
    }

    const parser = new DOMParser();
    const xmlDoc = parser.parseFromString(xmlText, "application/xml");

    // Ayrıştırma hatası kontrolü
    const parserError = xmlDoc.querySelector("parsererror");
    if (parserError) {
      throw new Error("XML Ayrıştırma Hatası: " + parserError.textContent);
    }

    const recNodes = xmlDoc.querySelectorAll("RECORDS > REC, REC");
    if (!recNodes || recNodes.length === 0) {
      throw new Error("XML içinde <REC> kaydı bulunamadı. Lütfen dosya şablonunu kontrol edin.");
    }

    const records = [];

    recNodes.forEach((node) => {
      const getTagVal = (tagName) => {
        const el = node.querySelector(tagName);
        return el ? el.textContent.trim() : "";
      };

      const miktarStr = getTagVal("MIKTAR");
      const orjkod = getTagVal("ORJKOD");
      const tbKeyStr = getTagVal("TB_KEY");
      const biRafId = getTagVal("BI_RAFID");
      const islemNoStr = getTagVal("ISLEMNO");

      // Temel doğrulama: barkod olmalı
      if (orjkod) {
        records.push({
          miktar: miktarStr ? parseInt(miktarStr, 10) || 1 : 1,
          orjkod: orjkod.replace(/['"]/g, ""),
          tb_key: tbKeyStr ? parseInt(tbKeyStr, 10) || null : null,
          bi_rafid: biRafId || "",
          islemno: islemNoStr ? parseInt(islemNoStr, 10) || null : null
        });
      }
    });

    return records;
  }

  /**
   * File nesnesini okuyup parse eder
   * @param {File} file 
   * @returns {Promise<Array>}
   */
  static async parseFile(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const res = XmlDrugParser.parse(e.target.result);
          resolve(res);
        } catch (err) {
          reject(err);
        }
      };
      reader.onerror = () => reject(new Error("Dosya okunamadı."));
      reader.readAsText(file);
    });
  }
}

window.XmlDrugParser = XmlDrugParser;
