# 🏥 Klinik Eczane & İlaç Yönetim Platformu

Yerel ağda (LAN) çalışan 3 bağımsız klinik uygulamanın, özelliklerini ve iş mantıklarını birebir koruyarak **ortak master ilaç veritabanı** ve **merkezi portal** çatısı altında birleştirilmiş modern mimarisi.

---

## 📌 İçindekiler
- [Genel Bakış](#-genel-bakış)
- [Mimari ve Veritabanı Yapısı](#-mimari-ve-veritabanı-yapısı)
- [Uygulama Modülleri ve Rotalar](#-uygulama-modülleri-ve-rotalar)
- [Dizin Yapısı](#-dizin-yapısı)
- [Kurulum](#-kurulum)
- [Çalıştırma](#-çalıştırma)
  - [1. Birleşik Platform Olarak Çalıştırma (Önerilen)](#1-birleşik-platform-olarak-çalıştırma-önerilen)
  - [2. Uygulamaları Bağımsız (Standalone) Çalıştırma](#2-uygulamaları-bağımsız-standalone-çalıştırma)
- [Yerel Ağ (LAN) Erişimi](#-yerel-ağ-lan-erişimi)
- [Test ve Doğrulama](#-test-ve-doğrulama)

---

## 🌟 Genel Bakış

Bu proje; klinik eczane süreçlerinde hekim, eczacı ve klinik personeli tarafından kullanılan 3 temel yazılımı tek bir yerel sunucuda (`0.0.0.0:8000`) birleştirir:

1. **🩺 MedRecete (`/recete`)**: Hekim bazlı reçete kayıt, akıllı ilaç arama, hızlı reçete şablonları ve tüketim analizleri.
2. **📦 Numune İlaçlar (`/numune`)**: 2D GS1 DataMatrix (Karekod) ayrıştırıcı, numune stok giriş/çıkış, otomatik miad (SKT) kontrolü ve son kullanma tarihi arşivi.
3. **🧪 Serum & İlaç Filtreleme (`/serum`)**: Hastane otomasyon sistemlerinden (HBYS) alınan XML ilaç listelerini ayrıştırma, hastane servislerine göre otomatik sınıflandırma ve Excel raporlama.

Tüm uygulamalar artık **tek bir master ilaç veritabanı** (`data/medication_db.sqlite`) üzerinden beslenir. Bu sayede veri mükerrerliği ve kopukluğu tamamen ortadan kaldırılmıştır.

---

## 🗄️ Mimari ve Veritabanı Yapısı

Sistem, ayrık veritabanlarını merkezi bir `data/` dizini altında toplar:

```
data/
├── medication_db.sqlite    <-- Ortak Master İlaç Veritabanı (17.608 İlaç, 6.943 Jenerik, 6.411 Etken Madde)
├── stok.db                 <-- Numune İlaç Stok, Miad Geçmişi ve Barkod Kayıtları
├── data.db                 <-- Medikal Reçete ve Kalem Veritabanı
└── filter_settings.json    <-- Serum Filtre Servis ve Kategori Kuralları
```

- **`medication_db.sqlite`**: Tek Gerçeklik Kaynağı (Single Source of Truth). İlaç adları, barkodları (GTIN), formları, jenerikleri, etken maddeleri, ATC/NFC kodları, hastane servisleri ve ilaç takma adları (alias) bu veritabanında tutulur ve 3 uygulama tarafından ortaklaşa sorgulanır.
- **Modüler Bağımsızlık**: `numuneilaclar` ve `serumfiltre` dizinlerindeki sembolik bağlar (symlink) sayesinde, uygulamalar tek başlarına (`standalone`) çalıştırılsalar dahi merkezi `data/` dosyalarını kullanmaya devam eder.
- **SQLAlchemy & SQLite Hibrit**: Numune İlaçlar ve Serum Filtre ortak SQLAlchemy bağlantı havuzundan (`core/database.py`), MedRecete ise yüksek performanslı SQLite WAL modlu doğrudan bağlantıdan beslenir.

---

## 🚀 Uygulama Modülleri ve Rotalar

Birleşik sistem başlatıldığında sunulan uç noktalar:

| Modül / Arayüz | Birleşik URL | Açıklama |
| :--- | :--- | :--- |
| **🏠 Merkezi Portal** | `http://<LAN_IP>:8000/` | Sistem telemetrisi, canlı master/stok sayaçları ve 1-tıkla geçiş hub'ı. |
| **🩺 MedRecete** | `http://<LAN_IP>:8000/recete` | Reçete yazımı, hekim seçimi, dinamik ilaç arama ve raporlama. |
| **📦 Numune İlaçlar** | `http://<LAN_IP>:8000/numune` | Stok yönetimi, barkod okutma, miad listesi ve yedekleme. |
| **🧪 Serum Filtre** | `http://<LAN_IP>:8000/serum` | XML yükleme, servis bazlı filtreleme, alias yönetimi ve Excel çıktısı. |
| **📚 Master İlaç Düzenleme** | `http://<LAN_IP>:8000/master` | 17.608 ilaçlık ortak kataloğu canlı arama, düzenleme ve yeni ilaç tanımlama. |
| **📘 API Dokümantasyonu** | `http://<LAN_IP>:8000/docs` | Tüm alt sistemlerin birleşik OpenAPI / Swagger dokümantasyonu. |

> **Açık Temalı Sol Menü (Side Bar)**: Tüm uygulamaların sol tarafında, sayfa dikey alanını işgal etmeyen, tek tıkla açılıp kapanan açık temalı çekmece navigasyon menüsü (`.suite-bar`) entegre edilmiştir.

---

## 📁 Dizin Yapısı

```
.
├── core/                       # Merkezi Konfigürasyon ve Veritabanı Motoru
│   ├── config.py               # Ortak ayarlar, LAN IP tespiti, port (8000)
│   ├── database.py             # Master & Stok SQLAlchemy motorları, session factories
│   └── __init__.py
├── data/                       # Merkezi Veri Deposu (Tüm uygulamaların ortak DB'leri)
│   ├── medication_db.sqlite
│   ├── stok.db
│   ├── data.db
│   └── filter_settings.json
├── portal/                     # Birleşik Karşılama ve Hızlı Erişim Portalı
│   ├── router.py               # / ve /api/portal/stats rotaları
│   └── templates/portal.html   # Modern responsive portal arayüzü
├── medrecete/                  # Medikal Reçete Alt Sistemi
│   ├── app/                    # Clean Architecture: domain, services, infrastructure
│   ├── static/                 # Arayüz dosyaları ve vendor fontlar
│   ├── tests/                  # Medrecete birim ve entegrasyon testleri
│   └── main.py                 # Standalone çalıştırıcı
├── numuneilaclar/              # Numune İlaç Alt Sistemi
│   ├── app/                    # DDD: domain, application, infrastructure, presentation
│   ├── tests/                  # QR ve stok testleri
│   └── main.py                 # Standalone çalıştırıcı
├── serumfiltre/                # Serum & İlaç Filtre Alt Sistemi
│   ├── app/                    # API, modeller, servisler, şemalar
│   ├── templates/ & static/    # Arayüz şablonları ve stilleri
│   ├── tests/                  # Kategorizasyon ve servis testleri
│   └── run.py                  # Standalone çalıştırıcı
├── tests/                      # Birleşik Sistem Testleri
│   └── test_unified_app.py     # 3 modülün entegrasyon ve rota testleri
├── main.py                     # Tüm uygulamaları bağlayan ana FastAPI uygulaması
├── run.py                      # Ağ bilgilerini gösteren konsol çalıştırıcı
├── requirements.txt            # Tüm sistemin birleşik bağımlılıkları
└── pytest.ini                  # Otomatik test yapılandırması
```

---

## 💻 Kurulum

### 1. Gereksinimler
- Python 3.10 veya üzeri (Python 3.11, 3.12, 3.14 ile tam uyumlu)
- Yerel ağ (LAN) bağlantısı

### 2. Sanal Ortam Oluşturma ve Bağımlılıkları Yükleme
```bash
# Proje kök dizinine geçin
cd /home/yusuf/Projeler/new

# Sanal ortam oluşturun ve aktif edin
python3 -m venv .venv
source .venv/bin/activate

# Gerekli kütüphaneleri yükleyin
pip install -r requirements.txt
```

---

## 🏃‍♂️ Çalıştırma

### 1. Birleşik Platform Olarak Çalıştırma (Önerilen)

Tüm 3 uygulamayı, ortak veritabanını ve merkezi portalı tek bir portta (`8000`) çalıştırmak için:

```bash
python run.py
```

Başlatıldığında terminalde yerel ağ IP adresinizi gösteren bir bilgi panosu açılır:

```text
════════════════════════════════════════════════════════════════════
  🏥  Klinik Eczane & İlaç Yönetim Platformu  v2.5.0
  🔗  Ortak Master Veritabanı ile Güçlendirildi (17.608 İlaç)
════════════════════════════════════════════════════════════════════
  ► Yerel Erişim (Localhost):  http://127.0.0.1:8000
  ► Yerel Ağ Erişimi (LAN):    http://192.168.1.105:8000
════════════════════════════════════════════════════════════════════
  Uygulama Modülleri:
   🏠  Merkezi Portal:          http://192.168.1.105:8000/
   🩺  Medikal Reçete:          http://192.168.1.105:8000/recete
   📦  Numune İlaç & Miad:      http://192.168.1.105:8000/numune
   🧪  Serum & İlaç Filtre:     http://192.168.1.105:8000/serum
   📘  API Dokümantasyonu:      http://192.168.1.105:8000/docs
════════════════════════════════════════════════════════════════════
```

### 2. Uygulamaları Bağımsız (Standalone) Çalıştırma

Geliştirme veya özel ihtiyaç halinde herhangi bir modülü tek başına da çalıştırabilirsiniz. Her modül ortak `data/` dizinini kullanmaya devam eder:

- **Sadece MedRecete:**
  ```bash
  python medrecete/main.py
  # http://localhost:8000 veya http://localhost:8001
  ```
- **Sadece Numune İlaçlar:**
  ```bash
  python numuneilaclar/main.py
  # http://localhost:8000 veya http://localhost:8002
  ```
- **Sadece Serum Filtreleme:**
  ```bash
  python serumfiltre/run.py
  # http://localhost:8000 veya http://localhost:8003
  ```

---

## 🌐 Yerel Ağ (LAN) Erişimi

Uygulama `0.0.0.0` arabirimine bağlanarak çalışacak şekilde yapılandırılmıştır. Aynı Wi-Fi veya Ethernet ağına bağlı:
- Eczane veya servis bilgisayarlarından,
- Mobil cihazlardan veya tabletlerden,
- Karekod okuyucu terminallerinden

tarayıcıya doğrudan `http://<SUNUCU_IP_ADRESI>:8000` yazılarak anında erişilebilir.

---

## 🧪 Test ve Doğrulama

Sistemdeki tüm alt uygulamaların ve birleşik rotaların doğruluğunu tek komutla test edebilirsiniz:

```bash
# Tüm test paketlerini çalıştır (37 test)
pytest

# Sadece birleşik entegrasyon testlerini çalıştır
pytest tests/test_unified_app.py
```

Tüm testler izole veritabanı kopyalarında çalışır; üretim veritabanınız (`data/`) asla etkilenmez.
