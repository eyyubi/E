import sqlite3
from pathlib import Path
from fastapi import APIRouter, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates

from core.config import settings, HOST, PORT, get_lan_ip, MASTER_DB_PATH, STOK_DB_PATH, RECETE_DB_PATH, SERUM_DB_PATH

TEMPLATES_DIR = Path(__file__).resolve().parent / "templates"
templates = Jinja2Templates(directory=str(TEMPLATES_DIR))

router = APIRouter(tags=["Portal & Sistem"])

@router.get("/", response_class=HTMLResponse)
def portal_home(request: Request):
    """Merkezi Portal Ana Sayfası - 3 Uygulama İçin Tek Giriş Noktası"""
    lan_ip = get_lan_ip()
    return templates.TemplateResponse(
        request=request,
        name="portal.html",
        context={
            "project_name": settings.PROJECT_NAME,
            "version": settings.VERSION,
            "host": HOST,
            "port": PORT,
            "lan_ip": lan_ip,
            "lan_url": f"http://{lan_ip}:{PORT}",
        }
    )

@router.get("/api/portal/stats")
def portal_stats():
    """Tüm sistemlerin canlı durum ve sayaç istatistikleri"""
    master_count = 0
    generics_count = 0
    services_count = 0
    aliases_count = 0
    stok_items_count = 0
    stok_total_qty = 0
    expired_count = 0
    prescriptions_count = 0

    # 1. Master DB istatistikleri
    try:
        with sqlite3.connect(f"file:{MASTER_DB_PATH}?mode=ro", uri=True) as conn:
            cur = conn.cursor()
            master_count = cur.execute("SELECT count(*) FROM products").fetchone()[0]
            generics_count = cur.execute("SELECT count(*) FROM generics").fetchone()[0]
    except Exception:
        pass

    # 1b. Serum Filtre DB istatistikleri
    try:
        with sqlite3.connect(f"file:{SERUM_DB_PATH}?mode=ro", uri=True) as conn:
            cur = conn.cursor()
            services_count = cur.execute("SELECT count(*) FROM hospital_services").fetchone()[0]
            try:
                aliases_count = cur.execute("SELECT count(*) FROM drug_aliases").fetchone()[0]
            except Exception:
                aliases_count = 0
    except Exception:
        pass

    # 2. Stok DB istatistikleri
    try:
        with sqlite3.connect(f"file:{STOK_DB_PATH}?mode=ro", uri=True) as conn:
            cur = conn.cursor()
            stok_items_count = cur.execute("SELECT count(DISTINCT barkod) FROM stok").fetchone()[0]
            qty_res = cur.execute("SELECT sum(miktar) FROM stok").fetchone()[0]
            stok_total_qty = qty_res if qty_res else 0
            expired_count = cur.execute("SELECT count(*) FROM miad_gecmis").fetchone()[0]
    except Exception:
        pass

    # 3. Reçete DB istatistikleri
    try:
        with sqlite3.connect(f"file:{RECETE_DB_PATH}?mode=ro", uri=True) as conn:
            cur = conn.cursor()
            prescriptions_count = cur.execute("SELECT count(*) FROM prescriptions").fetchone()[0]
    except Exception:
        pass

    lan_ip = get_lan_ip()
    return {
        "master": {
            "total_products": master_count,
            "total_generics": generics_count,
            "total_services": services_count,
            "total_aliases": aliases_count,
        },
        "stok": {
            "distinct_drugs": stok_items_count,
            "total_quantity": stok_total_qty,
            "expired_items": expired_count,
        },
        "recete": {
            "total_prescriptions": prescriptions_count,
        },
        "network": {
            "lan_ip": lan_ip,
            "port": PORT,
            "lan_url": f"http://{lan_ip}:{PORT}",
        }
    }
