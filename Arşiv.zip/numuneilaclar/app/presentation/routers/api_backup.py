from fastapi import APIRouter, Depends, UploadFile, File, HTTPException
from fastapi.responses import Response
from sqlalchemy.orm import Session
from datetime import datetime
from numuneilaclar.app.infrastructure.database import get_stok_db, get_master_db
from numuneilaclar.app.infrastructure.repositories.stok_repository import SQLAlchemyStokRepository
from numuneilaclar.app.infrastructure.repositories.master_repository import SQLAlchemyMasterIlacRepository
from numuneilaclar.app.application.services.backup_service import BackupService

router = APIRouter(prefix="/api/backup", tags=["Backup API"])

def get_backup_service(
    stok_db: Session = Depends(get_stok_db),
    master_db: Session = Depends(get_master_db),
) -> BackupService:
    stok_repo = SQLAlchemyStokRepository(stok_db)
    master_repo = SQLAlchemyMasterIlacRepository(master_db)
    return BackupService(stok_repo, master_repo=master_repo)

@router.get("/export")
def export_stock(service: BackupService = Depends(get_backup_service)):
    excel_bytes = service.export_stock_excel()
    date_str = datetime.now().strftime("%d_%m_%Y")
    filename = f"Stok_Yedek_{date_str}.xlsx"
    return Response(
        content=excel_bytes,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'}
    )

@router.post("/import")
async def import_stock(
    file: UploadFile = File(...),
    service: BackupService = Depends(get_backup_service)
):
    if not file.filename.endswith((".xlsx", ".xls")):
        raise HTTPException(status_code=400, detail="Lütfen geçerli bir Excel (.xlsx) dosyası yükleyin.")
    try:
        content = await file.read()
        res = service.import_stock_excel(content)
        return res
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Geri yükleme hatası: {str(e)}")
