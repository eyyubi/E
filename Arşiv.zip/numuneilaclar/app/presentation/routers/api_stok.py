from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from typing import Optional, List, Dict, Any
from numuneilaclar.app.infrastructure.database import get_stok_db, get_master_db
from numuneilaclar.app.infrastructure.repositories.stok_repository import SQLAlchemyStokRepository
from numuneilaclar.app.infrastructure.repositories.master_repository import SQLAlchemyMasterIlacRepository
from numuneilaclar.app.application.services.stok_service import StokService
from numuneilaclar.app.application.schemas.stok_schema import StokCreateRequest, BatchUpdateRequest, DispenseRequest


router = APIRouter(prefix="/api/stok", tags=["Stok API"])

def get_stok_service(
    stok_db: Session = Depends(get_stok_db),
    master_db: Session = Depends(get_master_db)
) -> StokService:
    stok_repo = SQLAlchemyStokRepository(stok_db)
    master_repo = SQLAlchemyMasterIlacRepository(master_db)
    return StokService(stok_repo=stok_repo, master_repo=master_repo)

@router.get("", response_model=List[Dict[str, Any]])
def list_stock(
    search: Optional[str] = Query(None, description="Arama terimi"),
    service: StokService = Depends(get_stok_service)
):
    return service.get_stock_dashboard(search=search)

@router.get("/batches/{barkod}")
def list_batches(
    barkod: str,
    service: StokService = Depends(get_stok_service)
):
    batches = service.get_batches(barkod)
    return [
        {
            "id": b.id,
            "barkod": b.barkod,
            "ad": b.ad,
            "miktar": b.miktar,
            "skt": b.skt,
            "firma": b.firma,
            "atc": b.atc,
            "tr_etken": b.tr_etken,
            "atc_etken": b.atc_etken
        } for b in batches
    ]

@router.post("")
def add_stock_item(
    req: StokCreateRequest,
    service: StokService = Depends(get_stok_service)
):
    try:
        created = service.add_stock(req)
        return {"success": True, "data": created}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.put("/batch/{item_id}")
def update_batch(
    item_id: int,
    req: BatchUpdateRequest,
    service: StokService = Depends(get_stok_service)
):
    updated = service.update_batch(item_id, req)
    if not updated:
        raise HTTPException(status_code=404, detail="Parti bulunamadı.")
    return {"success": True, "data": updated}

@router.delete("/batch/{item_id}")
def delete_batch(
    item_id: int,
    service: StokService = Depends(get_stok_service)
):
    success = service.delete_batch(item_id)
    if not success:
        raise HTTPException(status_code=404, detail="Parti bulunamadı.")
    return {"success": True}

@router.get("/expired")
def list_expired(
    search: Optional[str] = Query(None),
    service: StokService = Depends(get_stok_service)
):
    items = service.get_expired_items(search=search)
    return [
        {
            "id": it.id,
            "barkod": it.barkod,
            "ad": it.ad,
            "miktar": it.miktar,
            "skt": it.skt,
            "tarih_gecme": it.tarih_gecme,
            "firma": it.firma,
            "atc": it.atc,
            "tr_etken": it.tr_etken,
            "atc_etken": it.atc_etken
        } for it in items
    ]

@router.delete("/expired")
def clear_expired(
    service: StokService = Depends(get_stok_service)
):
    count = service.clear_expired_items()
    return {"success": True, "cleared_count": count}

@router.post("/dispense")
def dispense_stock_item(
    req: DispenseRequest,
    service: StokService = Depends(get_stok_service)
):
    try:
        result = service.dispense_stock(req.barkod, req.miktar)
        return result
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Düşüm sırasında hata oluştu: {str(e)}")

