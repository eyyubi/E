from fastapi import APIRouter, Request
from fastapi.templating import Jinja2Templates
from pathlib import Path

TEMPLATES_DIR = Path(__file__).resolve().parent.parent / "templates"
templates = Jinja2Templates(directory=str(TEMPLATES_DIR))

router = APIRouter(tags=["Numune Stok Views"])

@router.get("/numune")
@router.get("/stok")
def numune_index_view(request: Request):
    return templates.TemplateResponse(
        request=request,
        name="index.html",
        context={"active_tab": "stok", "base_prefix": "/numune"}
    )

@router.get("/numune/miad")
@router.get("/miad")
def numune_miad_view(request: Request):
    return templates.TemplateResponse(
        request=request,
        name="miad.html",
        context={"active_tab": "miad", "base_prefix": "/numune"}
    )

from fastapi.responses import RedirectResponse

@router.get("/numune/master", include_in_schema=False)
def numune_master_redirect():
    return RedirectResponse(url="/master", status_code=307)

@router.get("/numune/backup")
@router.get("/backup")
def numune_backup_view(request: Request):
    return templates.TemplateResponse(
        request=request,
        name="backup.html",
        context={"active_tab": "backup", "base_prefix": "/numune"}
    )
