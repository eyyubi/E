from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from numuneilaclar.app.core.qr_parser import parse_qr_code
from numuneilaclar.app.infrastructure.database import get_master_db
from numuneilaclar.app.infrastructure.repositories.master_repository import SQLAlchemyMasterIlacRepository
from numuneilaclar.app.application.schemas.stok_schema import QRParseRequest, QRParseResponse

router = APIRouter(prefix="/api/qr", tags=["QR Parser API"])

@router.post("/parse", response_model=QRParseResponse)
def parse_qr(
    req: QRParseRequest,
    master_db: Session = Depends(get_master_db)
):
    parsed = parse_qr_code(req.raw_code)
    gtin = parsed.get("gtin")
    skt = parsed.get("skt")
    lot = parsed.get("lot")
    sn = parsed.get("sn")

    resp = QRParseResponse(
        raw=req.raw_code,
        gtin=gtin,
        skt=skt,
        lot=lot,
        sn=sn,
        found_in_master=False
    )

    barcode_to_search = parsed.get("barkod") or (gtin.lstrip("0") if gtin else None)
    if barcode_to_search:
        repo = SQLAlchemyMasterIlacRepository(master_db)
        master_item = repo.get_by_barkod(barcode_to_search)
        if not master_item and gtin:
            master_item = repo.get_by_barkod(gtin)

        if master_item:
            resp.found_in_master = True
            resp.urun_adi = master_item.urun_adi
            resp.firma_adi = master_item.firma_adi
            resp.tr_etken = master_item.jenerik_adi
            resp.atc_kodu = master_item.atc_kodu

    return resp

