from fastapi import APIRouter, Depends, Query, HTTPException
from sqlalchemy.orm import Session
from typing import List, Optional
from numuneilaclar.app.infrastructure.database import get_master_db
from numuneilaclar.app.infrastructure.repositories.master_repository import SQLAlchemyMasterIlacRepository
from numuneilaclar.app.application.services.master_service import MasterService
from numuneilaclar.app.application.schemas.master_schema import MasterIlacResponse

router = APIRouter(prefix="/api/master", tags=["Master Ilac API"])

def get_master_service(master_db: Session = Depends(get_master_db)) -> MasterService:
    repo = SQLAlchemyMasterIlacRepository(master_db)
    return MasterService(repo)

@router.get("/search", response_model=List[MasterIlacResponse])
def search_master(
    q: str = Query("", description="İlaç adı, barkod, etken madde veya firma"),
    limit: int = Query(50, ge=1, le=200),
    service: MasterService = Depends(get_master_service)
):
    items = service.search_medications(query=q, limit=limit)
    return [
        MasterIlacResponse(
            urun_id=it.urun_id,
            barkod=it.barkod,
            urun_adi=it.urun_adi,
            ambalaj=it.ambalaj,
            firma_adi=it.firma_adi,
            jenerik_adi=it.jenerik_adi,
            atc_kodu=it.atc_kodu,
            recete_turu=it.recete_turu
        ) for it in items
    ]

@router.get("/barcode/{barkod}", response_model=Optional[MasterIlacResponse])
def get_by_barcode(
    barkod: str,
    service: MasterService = Depends(get_master_service)
):
    it = service.get_by_barcode(barkod)
    if not it:
        raise HTTPException(status_code=404, detail="İlaç bulunamadı.")
    return MasterIlacResponse(
        urun_id=it.urun_id,
        barkod=it.barkod,
        urun_adi=it.urun_adi,
        ambalaj=it.ambalaj,
        firma_adi=it.firma_adi,
        jenerik_adi=it.jenerik_adi,
        atc_kodu=it.atc_kodu,
        recete_turu=it.recete_turu
    )
