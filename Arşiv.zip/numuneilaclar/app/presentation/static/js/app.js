// Toast Bildirim Sistemi
function showToast(message, type = "info") {
  let container = document.getElementById("toast-container");
  if (!container) {
    container = document.createElement("div");
    container.id = "toast-container";
    container.className = "toast-container";
    document.body.appendChild(container);
  }

  const toast = document.createElement("div");
  toast.className = `toast toast-${type}`;
  toast.textContent = message;
  container.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = "0";
    toast.style.transition = "opacity 0.3s";
    setTimeout(() => toast.remove(), 300);
  }, 3500);
}

// Masaüstü Versiyonu Miad Arka Plan Renk Mantığı
function getMiadRowClass(sktDateStr) {
  if (!sktDateStr) return "row-safe";
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const target = new Date(sktDateStr);
  const diffTime = target - today;
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

  if (diffDays < 0) {
    return "row-expired";   // Kırmızımsı (miadı geçmiş)
  } else if (diffDays <= 60) {
    return "row-critical";  // Turuncumsu (60 gün altı)
  } else if (diffDays <= 180) {
    return "row-limit";     // Sarımsı (180 gün altı)
  }
  return "row-safe";
}

// SKT Rozeti ve Renk Mantığı
function getSktBadge(sktDateStr) {
  if (!sktDateStr) return '<span class="badge">-</span>';
  
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const target = new Date(sktDateStr);
  const diffTime = target - today;
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

  if (diffDays < 0) {
    return `<span class="badge badge-expired">${sktDateStr} (Süresi Doldu)</span>`;
  } else if (diffDays <= 60) {
    return `<span class="badge badge-critical">${sktDateStr} (${diffDays}g)</span>`;
  } else if (diffDays <= 180) {
    return `<span class="badge badge-warning">${sktDateStr} (${diffDays}g)</span>`;
  } else {
    return `<span class="badge badge-safe">${sktDateStr}</span>`;
  }
}

// Modal Kontrolleri
function openModal(id) {
  const el = document.getElementById(id);
  if (el) el.classList.add("active");
}

function closeModal(id) {
  const el = document.getElementById(id);
  if (el) el.classList.remove("active");
}

// --- STOK SAYFASI İŞLEMLERİ & SIRALAMA ---
let stockSearchTimeout = null;
let currentStockData = [];
let currentSortCol = "ad";
let currentSortAsc = true;

function handleSortClick(column) {
  if (currentSortCol === column) {
    currentSortAsc = !currentSortAsc;
  } else {
    currentSortCol = column;
    currentSortAsc = true;
  }
  updateSortIcons();
  sortAndRenderStockTable();
}

function updateSortIcons() {
  const cols = ["ad", "barkod", "etken", "toplam_miktar", "min_skt"];
  cols.forEach(c => {
    const icon = document.getElementById(`sort-icon-${c}`);
    if (icon) {
      if (c === currentSortCol) {
        icon.textContent = currentSortAsc ? "▲" : "▼";
        icon.style.opacity = "1";
        icon.style.color = "var(--primary)";
      } else {
        icon.textContent = "⇅";
        icon.style.opacity = "0.5";
        icon.style.color = "inherit";
      }
    }
  });
}

function sortAndRenderStockTable() {
  const tableBody = document.getElementById("stock-tbody");
  if (!tableBody) return;

  if (!currentStockData || currentStockData.length === 0) {
    tableBody.innerHTML = `<tr><td colspan="7" class="empty-state">Kayıtlı stok bulunamadı.</td></tr>`;
    return;
  }

  // Sıralama işlemi
  currentStockData.sort((a, b) => {
    let valA, valB;
    if (currentSortCol === "ad") {
      valA = a.ad || "";
      valB = b.ad || "";
      return currentSortAsc 
        ? valA.localeCompare(valB, "tr", { sensitivity: "base" })
        : valB.localeCompare(valA, "tr", { sensitivity: "base" });
    } else if (currentSortCol === "barkod") {
      valA = a.barkod || "";
      valB = b.barkod || "";
      return currentSortAsc ? valA.localeCompare(valB) : valB.localeCompare(valA);
    } else if (currentSortCol === "etken") {
      valA = a.tr_etken || a.atc_etken || "";
      valB = b.tr_etken || b.atc_etken || "";
      return currentSortAsc 
        ? valA.localeCompare(valB, "tr", { sensitivity: "base" })
        : valB.localeCompare(valA, "tr", { sensitivity: "base" });
    } else if (currentSortCol === "toplam_miktar") {
      valA = Number(a.toplam_miktar) || 0;
      valB = Number(b.toplam_miktar) || 0;
      return currentSortAsc ? valA - valB : valB - valA;
    } else if (currentSortCol === "min_skt") {
      valA = a.min_skt || "9999-99-99";
      valB = b.min_skt || "9999-99-99";
      return currentSortAsc ? valA.localeCompare(valB) : valB.localeCompare(valA);
    }
    return 0;
  });

  // Render satırları
  tableBody.innerHTML = currentStockData.map((item, index) => {
    const rowClass = getMiadRowClass(item.min_skt);
    const etkenText = item.tr_etken || item.atc_etken || "-";
    return `
      <tr class="${rowClass}" style="cursor: pointer;" ondblclick="openDispenseModal('${item.barkod}', '${escapeHtml(item.ad)}', ${item.toplam_miktar})" title="Çift tıklayarak reçete düşümü yapabilirsiniz">
        <td class="col-num text-center">${index + 1}</td>
        <td title="${escapeHtml(item.ad)}"><strong>${escapeHtml(item.ad)}</strong></td>
        <td class="text-center" title="${escapeHtml(item.barkod)}"><span class="badge badge-outline">${escapeHtml(item.barkod)}</span></td>
        <td title="${escapeHtml(etkenText)}">${escapeHtml(etkenText)}</td>
        <td class="text-center"><strong>${item.toplam_miktar}</strong> adet</td>
        <td class="text-center">${getSktBadge(item.min_skt)}</td>
        <td class="text-center">
          <button class="btn-edit" onclick="event.stopPropagation(); openBatchModal('${item.barkod}', '${escapeHtml(item.ad)}')">
            🛠️ Düzenle
          </button>
        </td>
      </tr>
    `;
  }).join("");



}

async function loadStockTable() {
  const tableBody = document.getElementById("stock-tbody");
  if (!tableBody) return;

  const searchInput = document.getElementById("stock-search");
  const query = searchInput ? encodeURIComponent(searchInput.value.trim()) : "";

  try {
    const res = await fetch(`/api/stok?search=${query}`);
    if (!res.ok) throw new Error("Stok verileri alınamadı.");
    currentStockData = await res.json();
    updateSortIcons();
    sortAndRenderStockTable();
  } catch (err) {
    tableBody.innerHTML = `<tr><td colspan="7" class="empty-state" style="color: var(--danger)">Hata: ${err.message}</td></tr>`;
  }
}


// Karekod Okuma ve Otomatik Form Doldurma
async function handleQRInput() {
  const qrInput = document.getElementById("modal-qr-input");
  const raw = qrInput.value.trim();
  if (!raw) return;

  try {
    const res = await fetch("/api/qr/parse", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ raw_code: raw })
    });
    const parsed = await res.json();

    if (parsed.gtin) {
      document.getElementById("modal-barkod").value = parsed.gtin.replace(/^0+/, '');
    } else {
      document.getElementById("modal-barkod").value = raw;
    }


    if (parsed.skt) {
      document.getElementById("modal-skt").value = parsed.skt;
    }

    if (parsed.found_in_master) {
      document.getElementById("modal-ad").value = parsed.urun_adi || "";
      document.getElementById("modal-firma").value = parsed.firma_adi || "";
      document.getElementById("modal-tr-etken").value = parsed.tr_etken || "";
      document.getElementById("modal-atc").value = parsed.atc_kodu || "";
      showToast(`Master veriden eşleşti: ${parsed.urun_adi}`, "success");
    } else {
      showToast("Karekod çözüldü, ilaç adını kontrol ediniz.", "info");
    }

    // Miktar alanına odaklan
    const miktarInput = document.getElementById("modal-miktar");
    if (miktarInput) {
      miktarInput.focus();
      miktarInput.select();
    }
  } catch (err) {
    showToast("Karekod işlenirken hata oluştu: " + err.message, "error");
  }
}

// Form Kaydetme
async function submitAddStockForm(event) {
  event.preventDefault();
  const payload = {
    barkod: document.getElementById("modal-barkod").value.trim(),
    ad: document.getElementById("modal-ad").value.trim(),
    miktar: parseInt(document.getElementById("modal-miktar").value) || 1,
    skt: document.getElementById("modal-skt").value.trim(),
    firma: document.getElementById("modal-firma").value.trim(),
    tr_etken: document.getElementById("modal-tr-etken").value.trim(),
    atc: document.getElementById("modal-atc").value.trim()
  };

  if (!payload.barkod || !payload.ad || !payload.skt) {
    showToast("Lütfen İlaç Adı, Barkod ve SKT alanlarını doldurun.", "error");
    return;
  }

  try {
    const res = await fetch("/api/stok", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.detail || "Kayıt başarısız.");
    }

    showToast("Stok başarıyla eklendi / güncellendi.", "success");
    closeModal("add-stock-modal");
    document.getElementById("add-stock-form").reset();
    loadStockTable();
  } catch (err) {
    showToast("Hata: " + err.message, "error");
  }
}

// --- REÇETE / STOKTAN DÜŞÜM İŞLEMLERİ ---
function openDispenseModal(barkod, ad, mevcutStok) {
  document.getElementById("dispense-barkod").value = barkod;
  document.getElementById("dispense-ad").textContent = ad;
  document.getElementById("dispense-barkod-lbl").textContent = barkod;
  document.getElementById("dispense-mevcut-stok").textContent = mevcutStok;
  
  const miktarInput = document.getElementById("dispense-miktar");
  miktarInput.value = 1;
  miktarInput.max = mevcutStok;

  openModal("dispense-modal");
  setTimeout(() => {
    miktarInput.focus();
    miktarInput.select();
  }, 100);
}

function changeDispenseMiktar(delta) {
  const input = document.getElementById("dispense-miktar");
  let val = (parseInt(input.value) || 0) + delta;
  if (val < 1) val = 1;
  input.value = val;
}

async function submitDispenseForm(event) {
  event.preventDefault();
  const barkod = document.getElementById("dispense-barkod").value.trim();
  const miktar = parseInt(document.getElementById("dispense-miktar").value) || 1;
  const ad = document.getElementById("dispense-ad").textContent;

  if (!barkod || miktar < 1) {
    showToast("Lütfen geçerli bir düşüm miktarı girin.", "error");
    return;
  }

  try {
    const res = await fetch("/api/stok/dispense", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ barkod, miktar })
    });

    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.detail || "Düşüm yapılamadı.");
    }

    const data = await res.json();
    showToast(`✅ ${data.dusulen_miktar} adet ${data.ad} reçeteden düşüldü. Kalan: ${data.kalan_stok}`, "success");
    closeModal("dispense-modal");
    loadStockTable();
  } catch (err) {
    showToast("Hata: " + err.message, "error");
  }
}

// Parti Yönetimi Modalı
let currentActiveBarcode = "";

async function openBatchModal(barkod, ad) {
  currentActiveBarcode = barkod;
  document.getElementById("batch-modal-title").textContent = `Parti ve Stok Yönetimi: ${ad}`;
  openModal("batch-modal");

  const tbody = document.getElementById("batch-tbody");
  tbody.innerHTML = `<tr><td colspan="4" class="empty-state">Partiler yükleniyor...</td></tr>`;

  try {
    const res = await fetch(`/api/stok/batches/${barkod}`);
    const batches = await res.json();

    if (batches.length === 0) {
      tbody.innerHTML = `<tr><td colspan="4" class="empty-state">Bu ilaca ait parti kalmadı.</td></tr>`;
      return;
    }

    tbody.innerHTML = batches.map(b => `
      <tr id="batch-row-${b.id}">
        <td><input type="date" class="form-control form-control-sm" id="batch-skt-${b.id}" value="${b.skt}"></td>
        <td><input type="number" class="form-control form-control-sm text-center" id="batch-mik-${b.id}" value="${b.miktar}" min="1"></td>
        <td class="text-center">${getSktBadge(b.skt)}</td>
        <td class="text-center">
          <div class="action-btn-group">
            <button class="btn btn-success btn-sm" onclick="saveBatch(${b.id})">💾 Kaydet</button>
            <button class="btn btn-danger btn-sm" onclick="deleteBatch(${b.id})">🗑️ Sil</button>
          </div>
        </td>
      </tr>
    `).join("");

  } catch (err) {
    tbody.innerHTML = `<tr><td colspan="4" class="empty-state" style="color:var(--danger)">Hata: ${err.message}</td></tr>`;
  }
}

async function saveBatch(batchId) {
  const skt = document.getElementById(`batch-skt-${batchId}`).value;
  const miktar = parseInt(document.getElementById(`batch-mik-${batchId}`).value);

  if (!skt || !miktar || miktar < 1) {
    showToast("Geçerli bir SKT ve en az 1 miktar giriniz.", "error");
    return;
  }

  try {
    const res = await fetch(`/api/stok/batch/${batchId}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ skt, miktar })
    });
    if (!res.ok) throw new Error("Güncelleme başarısız.");

    showToast("Parti başarıyla güncellendi.", "success");
    loadStockTable();
  } catch (err) {
    showToast("Hata: " + err.message, "error");
  }
}

async function deleteBatch(batchId) {
  if (!confirm("Bu partiyi stoktan tamamen silmek istediğinize emin misiniz?")) return;

  try {
    const res = await fetch(`/api/stok/batch/${batchId}`, { method: "DELETE" });
    if (!res.ok) throw new Error("Silme başarısız.");

    showToast("Parti silindi.", "success");
    const row = document.getElementById(`batch-row-${batchId}`);
    if (row) row.remove();
    loadStockTable();
  } catch (err) {
    showToast("Hata: " + err.message, "error");
  }
}

// --- MİAD GEÇMİŞ İŞLEMLERİ ---
async function loadExpiredTable() {
  const tbody = document.getElementById("expired-tbody");
  if (!tbody) return;

  const searchInput = document.getElementById("expired-search");
  const query = searchInput ? encodeURIComponent(searchInput.value.trim()) : "";

  try {
    const res = await fetch(`/api/stok/expired?search=${query}`);
    const data = await res.json();

    if (data.length === 0) {
      tbody.innerHTML = `<tr><td colspan="6" class="empty-state">Miadı geçmiş kayıt bulunmamaktadır.</td></tr>`;
      return;
    }

    tbody.innerHTML = data.map(item => `
      <tr>
        <td><strong>${escapeHtml(item.ad)}</strong></td>
        <td><span class="badge badge-outline">${escapeHtml(item.barkod)}</span></td>
        <td><strong>${item.miktar}</strong> adet</td>
        <td><span class="badge badge-expired">${item.skt}</span></td>
        <td>${item.tarih_gecme || "-"}</td>
        <td>${escapeHtml(item.firma || "-")}</td>
      </tr>
    `).join("");
  } catch (err) {
    tbody.innerHTML = `<tr><td colspan="6" class="empty-state" style="color:var(--danger)">Hata: ${err.message}</td></tr>`;
  }
}

async function clearAllExpired() {
  if (!confirm("Tüm miadı geçmiş kayıtlar arşivi kalıcı olarak silinecektir. Emin misiniz?")) return;

  try {
    const res = await fetch("/api/stok/expired", { method: "DELETE" });
    const data = await res.json();
    showToast(`${data.cleared_count} adet kayıt temizlendi.`, "success");
    loadExpiredTable();
  } catch (err) {
    showToast("Hata: " + err.message, "error");
  }
}

// --- MASTER ARAMA İŞLEMLERİ ---
let masterSearchTimeout = null;

async function searchMasterMedications() {
  const tbody = document.getElementById("master-tbody");
  if (!tbody) return;

  const input = document.getElementById("master-search-input");
  const q = input ? encodeURIComponent(input.value.trim()) : "";

  try {
    const res = await fetch(`/api/master/search?q=${q}&limit=60`);
    const data = await res.json();

    const info = document.getElementById("master-count-info");
    if (info) info.textContent = `Toplam ${data.length} sonuç listeleniyor`;

    if (data.length === 0) {
      tbody.innerHTML = `<tr><td colspan="6" class="empty-state">Eşleşen ilaç bulunamadı.</td></tr>`;
      return;
    }

    tbody.innerHTML = data.map(m => `
      <tr>
        <td><strong>${escapeHtml(m.urun_adi)}</strong></td>
        <td><span class="badge badge-outline">${escapeHtml(m.barkod)}</span></td>
        <td>${escapeHtml(m.jenerik_adi || "-")}</td>
        <td>${escapeHtml(m.atc_kodu || "-")}</td>
        <td>${escapeHtml(m.firma_adi || "-")}</td>
        <td><span class="badge badge-safe">${escapeHtml(m.recete_turu || "BEYAZ")}</span></td>
      </tr>
    `).join("");
  } catch (err) {
    tbody.innerHTML = `<tr><td colspan="6" class="empty-state" style="color:var(--danger)">Hata: ${err.message}</td></tr>`;
  }
}

// --- EXCEL YEDEKLEME VE GERİ YÜKLEME ---
async function handleExcelImport(event) {
  event.preventDefault();
  const fileInput = document.getElementById("excel-file-input");
  if (!fileInput.files || fileInput.files.length === 0) {
    showToast("Lütfen bir dosya seçin.", "error");
    return;
  }

  if (!confirm("⚠️ UYARI: Geri yükleme işlemi mevcut stok tablosunu tamamen silecek ve Excel'deki kayıtları yükleyecektir!\nOnaylıyor musunuz?")) {
    return;
  }

  const formData = new FormData();
  formData.append("file", fileInput.files[0]);

  try {
    showToast("Excel yükleniyor ve işleniyor...", "info");
    const res = await fetch("/api/backup/import", {
      method: "POST",
      body: formData
    });

    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.detail || "Yükleme başarısız.");
    }

    const data = await res.json();
    showToast(`Başarılı! ${data.imported_count} adet stok kaydı içeri aktarıldı.`, "success");
    fileInput.value = "";
  } catch (err) {
    showToast("Hata: " + err.message, "error");
  }
}

// XSS Koruması
function escapeHtml(text) {
  if (!text) return "";
  return text
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

// --- MANUEL İLAÇ EKLEME: MASTER AUTOCOMPLETE & BARKOD SORGUSU ---
let modalAdSearchTimeout = null;

function initMasterAutocomplete() {
  const adInput = document.getElementById("modal-ad");
  const dropdown = document.getElementById("modal-ad-autocomplete");
  const barkodInput = document.getElementById("modal-barkod");

  if (!adInput || !dropdown) return;

  adInput.addEventListener("input", () => {
    clearTimeout(modalAdSearchTimeout);
    const q = adInput.value.trim();
    if (q.length < 2) {
      dropdown.innerHTML = "";
      dropdown.classList.remove("active");
      return;
    }

    modalAdSearchTimeout = setTimeout(async () => {
      try {
        const res = await fetch(`/api/master/search?q=${encodeURIComponent(q)}&limit=10`);
        const items = await res.json();

        if (items.length === 0) {
          dropdown.innerHTML = `<div class="autocomplete-item" style="color: var(--text-muted); cursor: default;">Eşleşen ilaç bulunamadı</div>`;
          dropdown.classList.add("active");
          return;
        }

        dropdown.innerHTML = items.map(m => `
          <div class="autocomplete-item" data-barkod="${escapeHtml(m.barkod)}" data-ad="${escapeHtml(m.urun_adi)}" data-firma="${escapeHtml(m.firma_adi || '')}" data-etken="${escapeHtml(m.jenerik_adi || '')}" data-atc="${escapeHtml(m.atc_kodu || '')}">
            <div class="autocomplete-item-title">${escapeHtml(m.urun_adi)}</div>
            <div class="autocomplete-item-sub">
              <span>Barkod: <b>${escapeHtml(m.barkod)}</b></span>
              <span>${escapeHtml(m.firma_adi || '-')}</span>
              <span>${escapeHtml(m.recete_turu || '')}</span>
            </div>
          </div>
        `).join("");
        dropdown.classList.add("active");

        dropdown.querySelectorAll(".autocomplete-item").forEach(el => {
          el.addEventListener("click", () => {
            selectMasterItem({
              barkod: el.dataset.barkod,
              ad: el.dataset.ad,
              firma: el.dataset.firma,
              tr_etken: el.dataset.etken,
              atc: el.dataset.atc
            });
            dropdown.classList.remove("active");
          });
        });
      } catch (err) {
        console.error("Autocomplete error:", err);
      }
    }, 250);
  });

  // Dışarı tıklanınca dropdown'ı kapat
  document.addEventListener("click", (e) => {
    if (!adInput.contains(e.target) && !dropdown.contains(e.target)) {
      dropdown.classList.remove("active");
    }
  });

  // Barkod kutusuna manuel barkod yazılıp çıkıldığında master'dan sorgula
  if (barkodInput) {
    barkodInput.addEventListener("change", async () => {
      const b = barkodInput.value.trim();
      if (b.length >= 8 && (!adInput.value.trim() || adInput.value === b)) {
        try {
          const res = await fetch(`/api/master/barcode/${encodeURIComponent(b)}`);
          if (res.ok) {
            const m = await res.json();
            selectMasterItem({
              barkod: m.barkod,
              ad: m.urun_adi,
              firma: m.firma_adi || "",
              tr_etken: m.jenerik_adi || "",
              atc: m.atc_kodu || ""
            });
            showToast(`Master veriden dolduruldu: ${m.urun_adi}`, "success");
          }
        } catch (err) {}
      }
    });
  }
}

function selectMasterItem(item) {
  const adInput = document.getElementById("modal-ad");
  const barkodInput = document.getElementById("modal-barkod");
  const firmaInput = document.getElementById("modal-firma");
  const etkenInput = document.getElementById("modal-tr-etken");
  const atcInput = document.getElementById("modal-atc");
  const sktInput = document.getElementById("modal-skt");

  if (adInput) adInput.value = item.ad || "";
  if (barkodInput) barkodInput.value = item.barkod || "";
  if (firmaInput) firmaInput.value = item.firma || "";
  if (etkenInput) etkenInput.value = item.tr_etken || "";
  if (atcInput) atcInput.value = item.atc || "";

  if (sktInput) {
    sktInput.focus();
  }
}

// Event Listeners
document.addEventListener("DOMContentLoaded", () => {
  // Stok arama debounce
  const stockSearch = document.getElementById("stock-search");
  if (stockSearch) {
    stockSearch.addEventListener("input", () => {
      clearTimeout(stockSearchTimeout);
      stockSearchTimeout = setTimeout(loadStockTable, 300);
    });
    loadStockTable();
  }

  // QR okuma enter veya blur
  const qrInput = document.getElementById("modal-qr-input");
  if (qrInput) {
    qrInput.addEventListener("keydown", (e) => {
      if (e.key === "Enter") {
        e.preventDefault();
        handleQRInput();
      }
    });
  }

  // Manuel İlaç Ekleme Otomatik Tamamlama
  initMasterAutocomplete();

  // Miad arama
  const expiredSearch = document.getElementById("expired-search");
  if (expiredSearch) {
    expiredSearch.addEventListener("input", () => {
      clearTimeout(stockSearchTimeout);
      stockSearchTimeout = setTimeout(loadExpiredTable, 300);
    });
    loadExpiredTable();
  }

  // Master arama
  const masterSearch = document.getElementById("master-search-input");
  if (masterSearch) {
    masterSearch.addEventListener("input", () => {
      clearTimeout(masterSearchTimeout);
      masterSearchTimeout = setTimeout(searchMasterMedications, 350);
    });
    searchMasterMedications();
  }
});

