from typing import List, Optional
from numuneilaclar.app.domain.interfaces import IMasterIlacRepository
from numuneilaclar.app.domain.models import MasterIlacItem

class MasterService:
    def __init__(self, master_repo: IMasterIlacRepository):
        self.master_repo = master_repo

    def search_medications(self, query: str, limit: int = 50) -> List[MasterIlacItem]:
        return self.master_repo.search(query=query, limit=limit)

    def get_by_barcode(self, barkod: str) -> Optional[MasterIlacItem]:
        return self.master_repo.get_by_barkod(barkod)
