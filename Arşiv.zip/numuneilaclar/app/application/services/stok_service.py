from typing import List, Dict, Any, Optional
from numuneilaclar.app.domain.interfaces import IStokRepository, IMasterIlacRepository
from numuneilaclar.app.domain.models import StokItem, MiadGecmisItem
from numuneilaclar.app.application.schemas.stok_schema import StokCreateRequest, BatchUpdateRequest

class StokService:
    def __init__(self, stok_repo: IStokRepository, master_repo: Optional[IMasterIlacRepository] = None):
        self.stok_repo = stok_repo
        self.master_repo = master_repo

    def get_stock_dashboard(self, search: Optional[str] = None) -> List[Dict[str, Any]]:
        return self.stok_repo.get_grouped_by_barkod(search=search)

    def get_batches(self, barkod: str) -> List[StokItem]:
        return self.stok_repo.get_batches_by_barkod(barkod)

    def add_stock(self, req: StokCreateRequest) -> StokItem:
        # Eğer master_repo varsa ve ad/firma eksikse master'dan tamamlayalım
        barkod = req.barkod.strip()
        ad = req.ad.strip()
        tr_etken = req.tr_etken or ""
        atc_etken = req.atc_etken or ""
        atc = req.atc or ""
        firma = req.firma or ""

        if self.master_repo:
            master_item = self.master_repo.get_by_barkod(barkod)
            if master_item:
                if not ad:
                    ad = master_item.urun_adi
                if not firma:
                    firma = master_item.firma_adi or ""
                if not atc and master_item.atc_kodu:
                    atc = master_item.atc_kodu

                # Etken madde tanımlıysa eklensin, yoksa jenerik olabilir
                if not tr_etken:
                    if master_item.etkin_maddeler and master_item.etkin_maddeler.strip():
                        raw_sub = master_item.etkin_maddeler.strip()
                        if raw_sub.startswith("[") and raw_sub.endswith("]"):
                            try:
                                import json
                                j_list = json.loads(raw_sub)
                                sub_parts = []
                                for j_item in j_list:
                                    if isinstance(j_item, dict):
                                        m = j_item.get("madde") or ""
                                        d = j_item.get("doz") or ""
                                        b = j_item.get("birim") or ""
                                        du = f"{d} {b}".strip()
                                        sub_parts.append(f"{m} {du}".strip() if du else m)
                                    elif isinstance(j_item, str):
                                        sub_parts.append(j_item)
                                tr_etken = " + ".join(p for p in sub_parts if p)
                            except Exception:
                                tr_etken = raw_sub
                        else:
                            tr_etken = raw_sub
                    elif master_item.jenerik_adi and master_item.jenerik_adi.strip():
                        tr_etken = master_item.jenerik_adi.strip()
                    elif master_item.jenerik_kodu and master_item.jenerik_kodu.strip():
                        tr_etken = master_item.jenerik_kodu.strip()

                if not atc_etken:
                    atc_etken = tr_etken

        item = StokItem(
            id=None,
            barkod=barkod,
            ad=ad,
            miktar=req.miktar,
            skt=req.skt,
            tr_etken=tr_etken,
            atc_etken=atc_etken,
            atc=atc,
            firma=firma
        )
        return self.stok_repo.add_or_increment(item)

    def update_batch(self, item_id: int, req: BatchUpdateRequest) -> Optional[StokItem]:
        return self.stok_repo.update_batch(item_id, req.skt, req.miktar)

    def delete_batch(self, item_id: int) -> bool:
        return self.stok_repo.delete_batch(item_id)

    def run_expiration_check(self) -> int:
        return self.stok_repo.process_expired_batches()

    def get_expired_items(self, search: Optional[str] = None) -> List[MiadGecmisItem]:
        return self.stok_repo.get_expired_items(search=search)

    def clear_expired_items(self) -> int:
        return self.stok_repo.clear_expired_items()

    def dispense_stock(self, barkod: str, miktar: int) -> Dict[str, Any]:
        return self.stok_repo.dispense_stock(barkod, miktar)

