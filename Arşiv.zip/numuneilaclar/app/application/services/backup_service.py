from typing import Dict, Any, Optional
from numuneilaclar.app.domain.interfaces import IStokRepository, IMasterIlacRepository
from numuneilaclar.app.infrastructure.excel_service import ExcelService

class BackupService:
    def __init__(self, stok_repo: IStokRepository, master_repo: Optional[IMasterIlacRepository] = None):
        self.stok_repo = stok_repo
        self.master_repo = master_repo

    def export_stock_excel(self) -> bytes:
        all_items = self.stok_repo.get_all()
        return ExcelService.export_stok_to_excel(all_items)

    def import_stock_excel(self, file_bytes: bytes) -> Dict[str, Any]:
        records = ExcelService.import_stok_from_excel(file_bytes, master_repo=self.master_repo)
        count = self.stok_repo.replace_all_from_records(records)
        return {"success": True, "imported_count": count}
