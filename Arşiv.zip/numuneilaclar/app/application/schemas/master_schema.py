from pydantic import BaseModel
from typing import Optional

class MasterIlacResponse(BaseModel):
    urun_id: int
    barkod: str
    urun_adi: str
    ambalaj: Optional[str] = None
    firma_adi: Optional[str] = None
    jenerik_adi: Optional[str] = None
    atc_kodu: Optional[str] = None
    recete_turu: Optional[str] = None
