from pydantic import BaseModel, Field
from typing import Optional, List

class StokCreateRequest(BaseModel):
    barkod: str = Field(..., description="İlaç barkodu")
    ad: str = Field(..., description="İlaç adı")
    miktar: int = Field(1, ge=1, description="Eklenecek adet")
    skt: str = Field(..., description="Son kullanma tarihi YYYY-MM-DD")
    tr_etken: Optional[str] = ""
    atc_etken: Optional[str] = ""
    atc: Optional[str] = ""
    firma: Optional[str] = ""

class BatchUpdateRequest(BaseModel):
    skt: str = Field(..., description="Yeni SKT YYYY-MM-DD")
    miktar: int = Field(..., ge=1, description="Yeni Miktar")

class QRParseRequest(BaseModel):
    raw_code: str = Field(..., description="Okutulan karekod veya barkod metni")

class QRParseResponse(BaseModel):
    raw: str
    gtin: Optional[str] = None
    skt: Optional[str] = None
    lot: Optional[str] = None
    sn: Optional[str] = None
    found_in_master: bool = False
    urun_adi: Optional[str] = None
    firma_adi: Optional[str] = None
    tr_etken: Optional[str] = None
    atc_kodu: Optional[str] = None

class DispenseRequest(BaseModel):
    barkod: str = Field(..., description="Düşülecek ilaç barkodu")
    miktar: int = Field(1, ge=1, description="Düşülecek adet")

