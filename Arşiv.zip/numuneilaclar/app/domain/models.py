from dataclasses import dataclass
from typing import Optional
from datetime import datetime, date

@dataclass
class StokItem:
    id: Optional[int]
    barkod: str
    ad: str
    miktar: int
    skt: str  # YYYY-MM-DD
    atc_etken: Optional[str] = ""
    tr_etken: Optional[str] = ""
    atc: Optional[str] = ""
    firma: Optional[str] = ""

@dataclass
class MiadGecmisItem:
    id: Optional[int]
    barkod: str
    ad: str
    miktar: int
    skt: str
    tarih_gecme: Optional[str] = None
    atc_etken: Optional[str] = ""
    tr_etken: Optional[str] = ""
    atc: Optional[str] = ""
    firma: Optional[str] = ""

@dataclass
class MasterIlacItem:
    urun_id: int
    barkod: str
    urun_adi: str
    ambalaj: Optional[str] = None
    firma_id: Optional[str] = None
    firma_adi: Optional[str] = None
    etkin_maddeler: Optional[str] = None
    jenerik_kodu: Optional[str] = None
    nfc: Optional[str] = None
    recete_turu: Optional[str] = None
    jenerik_adi: Optional[str] = None
    atc_kodu: Optional[str] = None

@dataclass
class ReceteItem:
    id: Optional[int]
    barkod: str
    ad: str
    miktar: int
    tarih: Optional[str] = None

