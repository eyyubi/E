from abc import ABC, abstractmethod
from typing import List, Optional, Dict, Any
from numuneilaclar.app.domain.models import StokItem, MiadGecmisItem, MasterIlacItem

class IStokRepository(ABC):
    @abstractmethod
    def get_all(self, search: Optional[str] = None) -> List[StokItem]:
        pass

    @abstractmethod
    def get_by_id(self, item_id: int) -> Optional[StokItem]:
        pass

    @abstractmethod
    def get_grouped_by_barkod(self, search: Optional[str] = None) -> List[Dict[str, Any]]:
        pass

    @abstractmethod
    def get_batches_by_barkod(self, barkod: str) -> List[StokItem]:
        pass

    @abstractmethod
    def add_or_increment(self, item: StokItem) -> StokItem:
        pass

    @abstractmethod
    def update_batch(self, item_id: int, skt: str, miktar: int) -> Optional[StokItem]:
        pass

    @abstractmethod
    def delete_batch(self, item_id: int) -> bool:
        pass

    @abstractmethod
    def process_expired_batches(self) -> int:
        """Günü geçen stokları miad_gecmis tablosuna taşır."""
        pass

    @abstractmethod
    def get_expired_items(self, search: Optional[str] = None) -> List[MiadGecmisItem]:
        pass

    @abstractmethod
    def clear_expired_items(self) -> int:
        pass

    @abstractmethod
    def replace_all_from_records(self, records: List[Dict[str, Any]]) -> int:
        pass

    @abstractmethod
    def dispense_stock(self, barkod: str, miktar: int) -> Dict[str, Any]:
        """FEFO (İlk son kullanma tarihi yaklaşan) kuralına göre stok düşümü yapar."""
        pass


class IMasterIlacRepository(ABC):
    @abstractmethod
    def search(self, query: str, limit: int = 50) -> List[MasterIlacItem]:
        pass

    @abstractmethod
    def get_by_barkod(self, barkod: str) -> Optional[MasterIlacItem]:
        pass
