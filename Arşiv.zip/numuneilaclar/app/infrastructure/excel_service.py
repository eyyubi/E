import io
import re
from datetime import datetime, date
from typing import List, Dict, Any, Optional
import pandas as pd
from numuneilaclar.app.domain.models import StokItem

def normalize_text_key(text: str) -> str:
    """Türkçe karakterleri ve boşlukları normalize edip küçük harfe çevirir."""
    if not text:
        return ""
    d = {'İ': 'i', 'I': 'ı', 'Ş': 's', 'Ğ': 'g', 'Ü': 'u', 'Ö': 'o', 'Ç': 'c',
         'ı': 'i', 'ş': 's', 'ğ': 'g', 'ü': 'u', 'ö': 'o', 'ç': 'c'}
    t = str(text).strip()
    for k, v in d.items():
        t = t.replace(k, v)
    t = re.sub(r'[^a-zA-Z0-9]', '', t.lower())
    return t

def parse_skt_date(val: Any) -> Optional[str]:
    """Her türlü tarih formatını (Timestamp, GG.AA.YYYY, YYYY-MM-DD vs.) YYYY-MM-DD formatına dönüştürür."""
    if pd.isna(val) or val is None:
        return None
    if isinstance(val, (pd.Timestamp, date, datetime)):
        return val.strftime('%Y-%m-%d')

    s = str(val).strip()
    if not s or s.lower() == "nan":
        return None

    # YYYY-MM-DD
    if re.match(r'^\d{4}-\d{2}-\d{2}', s):
        return s[:10]

    # GG.AA.YYYY, GG/AA/YYYY, GG-AA-YYYY
    m = re.match(r'^(\d{1,2})[./\-](\d{1,2})[./\-](\d{2,4})', s)
    if m:
        gg, aa, yyyy = m.groups()
        if len(yyyy) == 2:
            yyyy = "20" + yyyy
        try:
            d_obj = datetime(int(yyyy), int(aa), int(gg))
            return d_obj.strftime("%Y-%m-%d")
        except ValueError:
            pass

    # Pandas esnek parser denemesi
    try:
        dt = pd.to_datetime(s, dayfirst=True)
        return dt.strftime('%Y-%m-%d')
    except Exception:
        pass

    return s[:10]

def parse_miktar_val(val: Any) -> int:
    """Excel'deki miktar / adet değerini güvenle pozitif tamsayıya dönüştürür."""
    if pd.isna(val) or val is None:
        return 1
    if isinstance(val, (int, float)):
        try:
            int_val = int(round(val))
            return int_val if int_val > 0 else 1
        except Exception:
            return 1

    s = str(val).strip()
    if not s or s.lower() == "nan":
        return 1

    # Sayısal kısmı ayıkla (Örn: "15 Kutu", "20 Adet", "10,0", "10.0")
    s_clean = s.replace(",", ".").replace(" ", "")
    m = re.search(r'([\d\.]+)', s_clean)
    if m:
        try:
            flt = float(m.group(1))
            int_val = int(round(flt))
            return int_val if int_val > 0 else 1
        except Exception:
            pass

    return 1


class ExcelService:
    @staticmethod
    def export_stok_to_excel(items: List[StokItem]) -> bytes:
        data = []
        for it in items:
            data.append({
                "barkod": it.barkod,
                "ad": it.ad,
                "miktar": it.miktar,
                "skt": it.skt,
                "tr_etken": it.tr_etken or "",
                "atc_etken": it.atc_etken or "",
                "atc": it.atc or "",
                "firma": it.firma or ""
            })
        df = pd.DataFrame(data)
        if df.empty:
            df = pd.DataFrame(columns=["barkod", "ad", "miktar", "skt", "tr_etken", "atc_etken", "atc", "firma"])

        output = io.BytesIO()
        with pd.ExcelWriter(output, engine="openpyxl") as writer:
            df.to_excel(writer, index=False, sheet_name="Stok_Listesi")
        return output.getvalue()

    @staticmethod
    def import_stok_from_excel(file_bytes: bytes, master_repo: Optional[Any] = None) -> List[Dict[str, Any]]:
        """
        Excel'den barkod, miat (SKT) ve miktar (adet) bilgilerini eksiksiz olarak çeker; 
        geriye kalan tüm ürün bilgilerini (ilaç adı, firma, etken madde/jenerik, ATC) 
        master veritabanından tamamlar.
        """
        df = pd.read_excel(io.BytesIO(file_bytes))
        if df.empty:
            return []

        # Kolon eşleme sözlüğü
        col_map = {}
        for orig_col in df.columns:
            norm = normalize_text_key(orig_col)
            # Barkod eşleme
            if norm in ("barkod", "barcode", "gtin", "karekod"):
                col_map["barkod"] = orig_col
            # İlaç Adı eşleme (varsa opsiyonel alınır)
            elif norm in ("ad", "ilacadi", "ilac", "urunadi", "urun"):
                col_map["ad"] = orig_col
            # Miktar / Adet / Stok eşleme (Öncelikli alan)
            elif norm in (
                "miktar", "adet", "adedi", "sayi", "sayisi", "stok", "stokmiktari", "stokadedi",
                "toplam", "toplammiktar", "toplammik", "toplamadet", "miktaradet",
                "mevcut", "mevcutmiktar", "kalan", "kalanmiktar", "bakiye", "bakiyemiktar",
                "kutu", "kutusayisi", "ambalaj", "ambalajsayisi", "depo", "depomiktari",
                "qty", "quantity", "count"
            ):
                col_map["miktar"] = orig_col
            # SKT / Miat eşleme
            elif norm in ("skt", "sonkullanmatarihi", "sonkullanma", "miad", "miat", "minskt", "tarih"):
                col_map["skt"] = orig_col
            # Etken maddeler
            elif norm in ("tretken", "etkenmadde", "etken"):
                col_map["tr_etken"] = orig_col
            elif norm in ("atcetken",):
                col_map["atc_etken"] = orig_col
            # ATC kodu
            elif norm in ("atc", "atckodu"):
                col_map["atc"] = orig_col
            # Firma
            elif norm in ("firma", "firmaadi", "uretici"):
                col_map["firma"] = orig_col

        # Zorunlu alan kontrolü: Barkod ve miat (skt)
        missing = []
        if "barkod" not in col_map: missing.append("Barkod")
        if "skt" not in col_map: missing.append("Son Kullanma Tarihi / Miat (skt)")

        if missing:
            raise ValueError(f"Excel dosyasında zorunlu sütunlar tespit edilemedi: {', '.join(missing)}")

        records = []
        for _, row in df.iterrows():
            raw_barkod = row[col_map["barkod"]]
            if pd.isna(raw_barkod):
                continue
            barkod = str(raw_barkod).split('.')[0].replace("'", "").replace('"', '').strip()
            if not barkod or barkod.lower() == "nan":
                continue

            # SKT / Miat
            raw_skt = row[col_map["skt"]]
            skt_str = parse_skt_date(raw_skt)
            if not skt_str:
                continue

            # Miktar (Adet) - Excel'den kesinlikle ve doğru formatta çekilir
            miktar = 1
            if "miktar" in col_map:
                raw_miktar = row[col_map["miktar"]]
                miktar = parse_miktar_val(raw_miktar)

            # Excel'deki ham alanlar (opsiyonel)
            def get_val(key):
                if key in col_map and pd.notna(row[col_map[key]]):
                    v = str(row[col_map[key]]).strip()
                    return "" if v == "nan" else v
                return ""

            excel_ad = get_val("ad")
            ad = excel_ad
            firma = get_val("firma")
            atc = get_val("atc")
            tr_etken = get_val("tr_etken")
            atc_etken = get_val("atc_etken")

            # Geriye kalan bilgileri master veritabanından çek
            if master_repo:
                try:
                    master_item = master_repo.get_by_barkod(barkod)
                    if master_item:
                        ad = master_item.urun_adi or ad
                        firma = master_item.firma_adi or firma
                        atc = master_item.atc_kodu or atc

                        # Etken madde tanımlıysa eklensin, yoksa jenerik olabilir
                        if not tr_etken:
                            if master_item.etkin_maddeler and master_item.etkin_maddeler.strip():
                                raw_sub = master_item.etkin_maddeler.strip()
                                if raw_sub.startswith("[") and raw_sub.endswith("]"):
                                    try:
                                        import json
                                        j_list = json.loads(raw_sub)
                                        sub_parts = []
                                        for j_item in j_list:
                                            if isinstance(j_item, dict):
                                                m = j_item.get("madde") or ""
                                                d = j_item.get("doz") or ""
                                                b = j_item.get("birim") or ""
                                                du = f"{d} {b}".strip()
                                                sub_parts.append(f"{m} {du}".strip() if du else m)
                                            elif isinstance(j_item, str):
                                                sub_parts.append(j_item)
                                        tr_etken = " + ".join(p for p in sub_parts if p)
                                    except Exception:
                                        tr_etken = raw_sub
                                else:
                                    tr_etken = raw_sub
                            elif master_item.jenerik_adi and master_item.jenerik_adi.strip():
                                tr_etken = master_item.jenerik_adi.strip()
                            elif master_item.jenerik_kodu and master_item.jenerik_kodu.strip():
                                tr_etken = master_item.jenerik_kodu.strip()

                        if not atc_etken:
                            atc_etken = tr_etken
                except Exception as e:
                    print(f"[Excel Import Master Lookup] Uyarı: {e}")

            if not ad:
                ad = f"İlaç ({barkod})"

            records.append({
                "barkod": barkod,
                "ad": ad,
                "miktar": miktar,
                "skt": skt_str,
                "tr_etken": tr_etken,
                "atc_etken": atc_etken,
                "atc": atc,
                "firma": firma
            })

        return records
