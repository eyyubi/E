from datetime import datetime
from typing import List, Optional, Dict, Any
from sqlalchemy.orm import Session
from sqlalchemy import func, or_
from numuneilaclar.app.domain.interfaces import IStokRepository
from numuneilaclar.app.domain.models import StokItem, MiadGecmisItem
from numuneilaclar.app.infrastructure.orm_models import StokORM, MiadGecmisORM, ReceteORM

def tr_upper(text: Optional[str]) -> str:
    if not text:
        return ""
    d = {'i': 'İ', 'ı': 'I', 'ş': 'Ş', 'ğ': 'Ğ', 'ü': 'Ü', 'ö': 'Ö', 'ç': 'Ç'}
    t = str(text)
    for k, v in d.items():
        t = t.replace(k, v)
    return t.upper()

class SQLAlchemyStokRepository(IStokRepository):
    def __init__(self, db: Session):
        self.db = db

    def get_all(self, search: Optional[str] = None) -> List[StokItem]:
        query = self.db.query(StokORM)
        if search:
            s = f"%{search.strip()}%"
            query = query.filter(
                or_(
                    StokORM.ad.ilike(s),
                    StokORM.barkod.ilike(s),
                    StokORM.tr_etken.ilike(s),
                    StokORM.atc_etken.ilike(s),
                    StokORM.firma.ilike(s)
                )
            )
        records = query.all()
        return [
            StokItem(
                id=r.id,
                barkod=r.barkod,
                ad=r.ad,
                miktar=r.miktar,
                skt=r.skt,
                atc_etken=r.atc_etken,
                tr_etken=r.tr_etken,
                atc=r.atc,
                firma=r.firma
            ) for r in records
        ]

    def get_by_id(self, item_id: int) -> Optional[StokItem]:
        r = self.db.query(StokORM).filter(StokORM.id == item_id).first()
        if not r:
            return None
        return StokItem(
            id=r.id,
            barkod=r.barkod,
            ad=r.ad,
            miktar=r.miktar,
            skt=r.skt,
            atc_etken=r.atc_etken,
            tr_etken=r.tr_etken,
            atc=r.atc,
            firma=r.firma
        )

    def get_grouped_by_barkod(self, search: Optional[str] = None) -> List[Dict[str, Any]]:
        query = self.db.query(
            StokORM.barkod,
            StokORM.ad,
            StokORM.tr_etken,
            StokORM.atc_etken,
            StokORM.atc,
            StokORM.firma,
            func.sum(StokORM.miktar).label("toplam_miktar"),
            func.min(StokORM.skt).label("min_skt"),
            func.max(StokORM.skt).label("max_skt")
        ).group_by(StokORM.barkod)

        if search:
            s = f"%{search.strip()}%"
            query = query.filter(
                or_(
                    StokORM.ad.ilike(s),
                    StokORM.barkod.ilike(s),
                    StokORM.tr_etken.ilike(s),
                    StokORM.atc_etken.ilike(s),
                    StokORM.firma.ilike(s)
                )
            )

        rows = query.order_by(StokORM.ad.asc()).all()
        return [
            {
                "barkod": r.barkod,
                "ad": r.ad,
                "tr_etken": r.tr_etken or "",
                "atc_etken": r.atc_etken or "",
                "atc": r.atc or "",
                "firma": r.firma or "",
                "toplam_miktar": r.toplam_miktar or 0,
                "min_skt": r.min_skt or "",
                "max_skt": r.max_skt or ""
            } for r in rows
        ]

    def get_batches_by_barkod(self, barkod: str) -> List[StokItem]:
        rows = self.db.query(StokORM).filter(StokORM.barkod == barkod).order_by(StokORM.skt.asc()).all()
        return [
            StokItem(
                id=r.id,
                barkod=r.barkod,
                ad=r.ad,
                miktar=r.miktar,
                skt=r.skt,
                atc_etken=r.atc_etken,
                tr_etken=r.tr_etken,
                atc=r.atc,
                firma=r.firma
            ) for r in rows
        ]

    def add_or_increment(self, item: StokItem) -> StokItem:
        # Aynı barkod ve aynı SKT var mı?
        existing = self.db.query(StokORM).filter(
            StokORM.barkod == item.barkod,
            StokORM.skt == item.skt
        ).first()

        if existing:
            existing.miktar += item.miktar
            self.db.commit()
            self.db.refresh(existing)
            target = existing
        else:
            new_record = StokORM(
                barkod=item.barkod,
                ad=item.ad,
                miktar=item.miktar,
                skt=item.skt,
                atc_etken=item.atc_etken,
                tr_etken=item.tr_etken,
                atc=item.atc,
                firma=item.firma
            )
            self.db.add(new_record)
            self.db.commit()
            self.db.refresh(new_record)
            target = new_record

        return StokItem(
            id=target.id,
            barkod=target.barkod,
            ad=target.ad,
            miktar=target.miktar,
            skt=target.skt,
            atc_etken=target.atc_etken,
            tr_etken=target.tr_etken,
            atc=target.atc,
            firma=target.firma
        )

    def update_batch(self, item_id: int, skt: str, miktar: int) -> Optional[StokItem]:
        record = self.db.query(StokORM).filter(StokORM.id == item_id).first()
        if not record:
            return None
        record.skt = skt
        record.miktar = miktar
        self.db.commit()
        self.db.refresh(record)
        return StokItem(
            id=record.id,
            barkod=record.barkod,
            ad=record.ad,
            miktar=record.miktar,
            skt=record.skt,
            atc_etken=record.atc_etken,
            tr_etken=record.tr_etken,
            atc=record.atc,
            firma=record.firma
        )

    def delete_batch(self, item_id: int) -> bool:
        record = self.db.query(StokORM).filter(StokORM.id == item_id).first()
        if not record:
            return False
        self.db.delete(record)
        self.db.commit()
        return True

    def process_expired_batches(self) -> int:
        today_str = datetime.now().strftime("%Y-%m-%d")
        expired_list = self.db.query(StokORM).filter(StokORM.skt < today_str).all()
        if not expired_list:
            return 0

        count = len(expired_list)
        for r in expired_list:
            gecmis = MiadGecmisORM(
                barkod=r.barkod,
                ad=r.ad,
                atc_etken=r.atc_etken,
                tr_etken=r.tr_etken,
                atc=r.atc,
                firma=r.firma,
                miktar=r.miktar,
                skt=r.skt
            )
            self.db.add(gecmis)
            self.db.delete(r)

        self.db.commit()
        return count

    def get_expired_items(self, search: Optional[str] = None) -> List[MiadGecmisItem]:
        query = self.db.query(MiadGecmisORM)
        if search:
            s = f"%{search.strip()}%"
            query = query.filter(
                or_(
                    MiadGecmisORM.ad.ilike(s),
                    MiadGecmisORM.barkod.ilike(s),
                    MiadGecmisORM.tr_etken.ilike(s),
                    MiadGecmisORM.atc_etken.ilike(s)
                )
            )
        rows = query.order_by(MiadGecmisORM.tarih_gecme.desc()).all()
        return [
            MiadGecmisItem(
                id=r.id,
                barkod=r.barkod,
                ad=r.ad,
                miktar=r.miktar,
                skt=r.skt,
                tarih_gecme=r.tarih_gecme.strftime("%Y-%m-%d %H:%M:%S") if r.tarih_gecme else "",
                atc_etken=r.atc_etken,
                tr_etken=r.tr_etken,
                atc=r.atc,
                firma=r.firma
            ) for r in rows
        ]

    def clear_expired_items(self) -> int:
        count = self.db.query(MiadGecmisORM).delete()
        self.db.commit()
        return count

    def replace_all_from_records(self, records: List[Dict[str, Any]]) -> int:
        self.db.query(StokORM).delete()
        for r in records:
            obj = StokORM(
                barkod=str(r.get("barkod", "")).strip(),
                ad=str(r.get("ad", "")).strip(),
                atc_etken=str(r.get("atc_etken", "") or ""),
                tr_etken=str(r.get("tr_etken", "") or ""),
                atc=str(r.get("atc", "") or ""),
                firma=str(r.get("firma", "") or ""),
                miktar=int(r.get("miktar", 1)),
                skt=str(r.get("skt", "")).strip()
            )
            self.db.add(obj)
        self.db.commit()
        return len(records)

    def dispense_stock(self, barkod: str, miktar: int) -> Dict[str, Any]:
        clean_barkod = barkod.strip()
        if miktar <= 0:
            raise ValueError("Düşülecek miktar en az 1 olmalıdır.")

        today_str = datetime.now().strftime("%Y-%m-%d")

        # Yalnızca miadı geçerli (SKT >= bugün) olanları en yakın tarihten başlayarak getir
        active_batches = self.db.query(StokORM).filter(
            StokORM.barkod == clean_barkod,
            StokORM.skt >= today_str
        ).order_by(StokORM.skt.asc()).all()

        total_available = sum(b.miktar for b in active_batches)

        if not active_batches or total_available < miktar:
            raise ValueError(
                f"Yetersiz stok! Miadı geçerli toplam stok: {total_available} adet."
            )

        ad = active_batches[0].ad
        kalan = miktar

        for b in active_batches:
            if kalan <= 0:
                break
            if b.miktar <= kalan:
                kalan -= b.miktar
                self.db.delete(b)
            else:
                b.miktar -= kalan
                kalan = 0

        # Reçete düşüm kaydı oluştur
        recete = ReceteORM(
            barkod=clean_barkod,
            ad=ad,
            miktar=miktar
        )
        self.db.add(recete)
        self.db.commit()

        return {
            "success": True,
            "barkod": clean_barkod,
            "ad": ad,
            "dusulen_miktar": miktar,
            "kalan_stok": total_available - miktar
        }

