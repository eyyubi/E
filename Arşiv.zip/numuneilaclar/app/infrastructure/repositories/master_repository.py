from typing import List, Optional
from sqlalchemy.orm import Session
from sqlalchemy import or_
from numuneilaclar.app.domain.interfaces import IMasterIlacRepository
from numuneilaclar.app.domain.models import MasterIlacItem
from numuneilaclar.app.infrastructure.orm_models import MasterIlacORM

class SQLAlchemyMasterIlacRepository(IMasterIlacRepository):
    def __init__(self, db: Session):
        self.db = db

    def search(self, query: str, limit: int = 50) -> List[MasterIlacItem]:
        q = query.strip()
        db_query = self.db.query(MasterIlacORM)
        if q:
            pattern = f"%{q}%"
            db_query = db_query.filter(
                or_(
                    MasterIlacORM.urun_adi.ilike(pattern),
                    MasterIlacORM.barkod.ilike(pattern),
                    MasterIlacORM.jenerik_adi.ilike(pattern),
                    MasterIlacORM.firma_adi.ilike(pattern),
                    MasterIlacORM.atc_kodu.ilike(pattern)
                )
            )
        records = db_query.limit(limit).all()
        return [
            MasterIlacItem(
                urun_id=r.urun_id,
                barkod=r.barkod or "",
                urun_adi=r.urun_adi or "",
                ambalaj=r.ambalaj,
                firma_id=r.firma_id,
                firma_adi=r.firma_adi,
                etkin_maddeler=r.etkin_maddeler,
                jenerik_kodu=r.jenerik_kodu,
                nfc=r.nfc,
                recete_turu=r.recete_turu,
                jenerik_adi=r.jenerik_adi,
                atc_kodu=r.atc_kodu
            ) for r in records
        ]

    def get_by_barkod(self, barkod: str) -> Optional[MasterIlacItem]:
        clean_barkod = barkod.strip()
        r = self.db.query(MasterIlacORM).filter(MasterIlacORM.barkod == clean_barkod).first()
        if not r:
            return None
        return MasterIlacItem(
            urun_id=r.urun_id,
            barkod=r.barkod or "",
            urun_adi=r.urun_adi or "",
            ambalaj=r.ambalaj,
            firma_id=r.firma_id,
            firma_adi=r.firma_adi,
            etkin_maddeler=r.etkin_maddeler,
            jenerik_kodu=r.jenerik_kodu,
            nfc=r.nfc,
            recete_turu=r.recete_turu,
            jenerik_adi=r.jenerik_adi,
            atc_kodu=r.atc_kodu
        )
