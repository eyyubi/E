from sqlalchemy import Column, Integer, String, Text, DateTime, func
from numuneilaclar.app.infrastructure.database import StokBase, MasterBase

class StokORM(StokBase):
    __tablename__ = "stok"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    barkod = Column(String(50), index=True, nullable=False)
    ad = Column(String(255), nullable=False)
    atc_etken = Column(Text, nullable=True, default="")
    tr_etken = Column(Text, nullable=True, default="")
    atc = Column(String(50), nullable=True, default="")
    firma = Column(String(255), nullable=True, default="")
    miktar = Column(Integer, nullable=False, default=1)
    skt = Column(String(20), nullable=False)  # YYYY-MM-DD

class MiadGecmisORM(StokBase):
    __tablename__ = "miad_gecmis"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    barkod = Column(String(50), index=True, nullable=False)
    ad = Column(String(255), nullable=False)
    atc_etken = Column(Text, nullable=True, default="")
    tr_etken = Column(Text, nullable=True, default="")
    atc = Column(String(50), nullable=True, default="")
    firma = Column(String(255), nullable=True, default="")
    miktar = Column(Integer, nullable=False)
    skt = Column(String(20), nullable=False)
    tarih_gecme = Column(DateTime, default=func.now())

class ReceteORM(StokBase):
    __tablename__ = "receteler"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    barkod = Column(String(50), index=True, nullable=False)
    ad = Column(String(255), nullable=False)
    miktar = Column(Integer, nullable=False)
    tarih = Column(DateTime, default=func.now())

class MasterIlacORM(MasterBase):

    __tablename__ = "master_ilaclar"
    __table_args__ = {"extend_existing": True}

    urun_id = Column(Integer, primary_key=True)
    barkod = Column(String(50), index=True)
    urun_adi = Column(String(255), index=True)
    ambalaj = Column(String(255), nullable=True)
    firma_id = Column(String(50), nullable=True)
    firma_adi = Column(String(255), nullable=True)
    etkin_maddeler = Column(Text, nullable=True)
    jenerik_kodu = Column(String(50), nullable=True)
    nfc = Column(String(50), nullable=True)
    recete_turu = Column(String(100), nullable=True)
    jenerik_adi = Column(Text, nullable=True)
    atc_kodu = Column(String(50), nullable=True)
