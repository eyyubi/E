import re
from datetime import datetime
from typing import Optional, Dict, Any
from abc import ABC, abstractmethod

class BaseQRParser(ABC):
    @abstractmethod
    def parse(self, raw_data: str) -> Dict[str, Any]:
        """
        Karekod/Barkod verisini ayrıştırıp sözlük olarak döner.
        Örnek dönüş: {'gtin': '...', 'barkod': '...', 'skt': 'YYYY-MM-DD', 'sn': '...', 'lot': '...'}
        """
        pass

class GS1MedicationQRParser(BaseQRParser):
    """
    Türkiye İlaç Takip Sistemi (İTS) ve GS1 standart karekod ayrıştırıcısı.
    Yapı: 01[GTIN:14]21[SN:Değişken]17[EXP_DATE:YYAAGG]10[BN:Batch]
    Değişken uzunluktaki SN içerisinde yer alabilecek sahte '17'leri ayırt etmek için
    gerçek takvim tarihi (MM: 01-12, DD: 01-31) ve arkasından gelen '10' seperatörü doğrulanır.
    """

    @staticmethod
    def _is_valid_date(yy: str, mm: str, dd: str) -> bool:
        try:
            m_int = int(mm)
            d_int = int(dd)
            if not (1 <= m_int <= 12 and 0 <= d_int <= 31):
                return False
            # Gün 00 ise GS1 kuralı gereği ayın son günüdür veya geçerli aydır
            gun_test = "01" if d_int == 0 else dd
            datetime.strptime(f"20{yy}-{mm}-{gun_test}", "%Y-%m-%d")
            return True
        except ValueError:
            return False

    def parse(self, raw: str) -> Dict[str, Any]:
        if not raw:
            return {"raw": "", "gtin": None, "barkod": None, "skt": None, "lot": None, "sn": None, "success": False}

        # GS1 ASCII 29 (Group Separator) ve kontrol karakterlerini temizle
        clean = raw.strip().replace("\x1d", "").replace("\u001d", "").replace("\r", "").replace("\n", "")

        res: Dict[str, Any] = {
            "raw": clean,
            "gtin": None,
            "barkod": None,
            "skt": None,
            "lot": None,
            "sn": None,
            "success": False
        }

        # 1. 01[GTIN:14] Eşleştirmesi
        # GTIN genelde 01 ile başlar ve 14 hanelidir (0 + 13 haneli barkod)
        gtin_match = re.search(r'01(\d{14})', clean)
        if gtin_match:
            gtin_14 = gtin_match.group(1)
            res["gtin"] = gtin_14
            res["barkod"] = gtin_14.lstrip("0")
            after_gtin = clean[gtin_match.end():]
        else:
            # Düz barkod girilmiş olabilir (EAN-13, EAN-8)
            digits_only = re.sub(r'\D', '', clean)
            if len(digits_only) in (8, 13, 14):
                res["gtin"] = digits_only
                res["barkod"] = digits_only.lstrip("0")
                return res
            after_gtin = clean

        # 2. Kullanıcının belirttiği kalıp: 21[SN]17[YYAAGG]10[BN]
        if after_gtin.startswith("21"):
            after_21 = after_gtin[2:]
            
            # after_21 içinde '17' geçen tüm olası pozisyonları tara
            # Hedef: 17[YYAAGG]10[BN] kalıbı
            for i in range(len(after_21) - 8):
                if after_21[i:i+2] == "17":
                    candidate = after_21[i:]
                    m = re.match(r'^17(\d{2})(\d{2})(\d{2})10(.*)$', candidate)
                    if m:
                        yy, mm, dd, bn = m.groups()
                        if self._is_valid_date(yy, mm, dd):
                            # Gerçek 17 EXP_DATE seperatörü bulundu!
                            res["sn"] = after_21[:i]
                            gun_str = "01" if dd == "00" else dd
                            res["skt"] = f"20{yy}-{mm}-{gun_str}"
                            res["lot"] = bn
                            res["success"] = True
                            return res

        # 3. Fallback: Sıra farklıysa veya 10 sonda değilse en mantıklı 17[YYAAGG] kalıbını ara
        # SN içinde sahte 17 geçebileceği için arkasında 10 veya 21 olan geçerli tarihi önceliklendir
        candidates = []
        for m in re.finditer(r'17(\d{2})(\d{2})(\d{2})', clean):
            yy, mm, dd = m.groups()
            if self._is_valid_date(yy, mm, dd):
                pos = m.end()
                # Arkasından '10' veya '21' geliyor mu?
                has_subsequent_ai = clean[pos:pos+2] in ("10", "21")
                candidates.append((has_subsequent_ai, m.start(), yy, mm, dd, pos))

        if candidates:
            # Öncelik: arkasından AI (10 veya 21) gelen, yoksa ilk geçerli tarih
            candidates.sort(key=lambda c: (not c[0], c[1]))
            _, _, yy, mm, dd, pos = candidates[0]
            gun_str = "01" if dd == "00" else dd
            res["skt"] = f"20{yy}-{mm}-{gun_str}"

            # Eğer lot veya sn henüz bulunamadıysa
            if not res["lot"] and clean[pos:pos+2] == "10":
                res["lot"] = clean[pos+2:]

        return res

# Aktif parser
active_qr_parser: BaseQRParser = GS1MedicationQRParser()

def parse_qr_code(raw: str) -> Dict[str, Any]:
    return active_qr_parser.parse(raw)
