import unittest
from numuneilaclar.app.core.qr_parser import parse_qr_code
from numuneilaclar.app.domain.models import StokItem
from numuneilaclar.app.infrastructure.database import StokBase, stok_engine, StokSessionLocal
from numuneilaclar.app.infrastructure.repositories.stok_repository import SQLAlchemyStokRepository
from numuneilaclar.app.application.services.stok_service import StokService
from numuneilaclar.app.application.schemas.stok_schema import StokCreateRequest, BatchUpdateRequest

class TestNumuneQRAndStok(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        StokBase.metadata.create_all(bind=stok_engine)

    def setUp(self):
        self.db = StokSessionLocal()
        self.repo = SQLAlchemyStokRepository(self.db)
        self.service = StokService(self.repo)

    def tearDown(self):
        self.db.close()

    def test_gs1_qr_parser_standard(self):
        # 01 (GTIN) + 21 (SN) + 17 (EXP) + 10 (LOT)
        raw = "0108699606692195211234561727123110BATCH99"
        res = parse_qr_code(raw)
        self.assertTrue(res.get("success"))
        self.assertEqual(res.get("gtin"), "08699606692195")
        self.assertEqual(res.get("barkod"), "8699606692195")
        self.assertEqual(res.get("skt"), "2027-12-31")
        self.assertEqual(res.get("lot"), "BATCH99")
        self.assertEqual(res.get("sn"), "123456")

    def test_gs1_plain_barcode(self):
        raw = "8699606692195"
        res = parse_qr_code(raw)
        self.assertEqual(res.get("barkod"), "8699606692195")

    def test_stok_crud_operations(self):
        # 1. Add stock
        req = StokCreateRequest(
            barkod="TESTBARCODE01",
            ad="Test İlaç 500mg",
            miktar=10,
            skt="2028-05-20",
            firma="Test Pharma"
        )
        item = self.service.add_stock(req)
        self.assertIsNotNone(item.id)
        self.assertEqual(item.barkod, "TESTBARCODE01")
        self.assertEqual(item.miktar, 10)

        # 2. Increment stock with same barkod and skt
        item2 = self.service.add_stock(req)
        self.assertEqual(item2.id, item.id)
        self.assertEqual(item2.miktar, 20)

        # 3. Update batch
        updated = self.service.update_batch(item.id, BatchUpdateRequest(skt="2028-06-01", miktar=15))
        self.assertIsNotNone(updated)
        self.assertEqual(updated.miktar, 15)
        self.assertEqual(updated.skt, "2028-06-01")

        # 4. Dispense stock
        disp = self.service.dispense_stock("TESTBARCODE01", 5)
        self.assertTrue(disp["success"])
        self.assertEqual(disp["kalan_stok"], 10)

        # 5. Clean up
        self.service.delete_batch(item.id)

    def test_excel_import_with_miktar_and_master_hydration(self):
        """Excel'den barkod, skt ve miktar bilgilerinin doğru çekildiğini ve master'dan zenginleştirildiğini test eder."""
        import io
        import pandas as pd
        from numuneilaclar.app.infrastructure.excel_service import ExcelService
        from core.database import MasterSessionLocal
        from numuneilaclar.app.infrastructure.repositories.master_repository import SQLAlchemyMasterIlacRepository

        # Test Excel tablosu oluştur: farklı miktar formatları içeren sütunlar
        df = pd.DataFrame([
            {"Barkod": "8699606692195", "Son Kullanma Tarihi": "2027-12-31", "Miktar (Adet)": 25.0},
            {"Barkod": "8699606692201", "Son Kullanma Tarihi": "2028-06-30", "Miktar (Adet)": "50 Kutu"},
            {"Barkod": "8699606692171", "Son Kullanma Tarihi": "2026-10-15", "Miktar (Adet)": "10,0"},
        ])
        buf = io.BytesIO()
        df.to_excel(buf, index=False)
        excel_bytes = buf.getvalue()

        m_db = MasterSessionLocal()
        try:
            master_repo = SQLAlchemyMasterIlacRepository(m_db)
            records = ExcelService.import_stok_from_excel(excel_bytes, master_repo=master_repo)
        finally:
            m_db.close()

        self.assertEqual(len(records), 3)

        # Miktar bilgilerinin kesinlikle doğru çekildiğini doğrula
        self.assertEqual(records[0]["miktar"], 25)
        self.assertEqual(records[1]["miktar"], 50)
        self.assertEqual(records[2]["miktar"], 10)

        # Barkod ve SKT
        self.assertEqual(records[0]["barkod"], "8699606692195")
        self.assertEqual(records[0]["skt"], "2027-12-31")

        # Master veritabanından çekilen bilgileri doğrula
        self.assertIn("POLIFLEKS", records[0]["ad"].upper())
        self.assertTrue(bool(records[0]["firma"]))
        self.assertTrue(bool(records[0]["tr_etken"]))


if __name__ == "__main__":
    unittest.main()
