import sys
from pathlib import Path
ROOT_DIR = Path(__file__).resolve().parent.parent
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

import uvicorn
from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles

from numuneilaclar.app.core.config import HOST, PORT
from numuneilaclar.app.infrastructure.database import stok_engine, StokBase, StokSessionLocal
from numuneilaclar.app.infrastructure.repositories.stok_repository import SQLAlchemyStokRepository
from numuneilaclar.app.application.services.stok_service import StokService
from numuneilaclar.app.presentation.routers import views, api_stok, api_master, api_qr, api_backup

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Veritabanı tablolarını oluştur
    StokBase.metadata.create_all(bind=stok_engine)

    # Başlangıçta miad kontrolü (SKT'si geçen ürünleri taşı)
    db = StokSessionLocal()
    try:
        service = StokService(stok_repo=SQLAlchemyStokRepository(db))
        moved = service.run_expiration_check()
        if moved > 0:
            print(f"[Açılış Kontrolü] {moved} adet miadı geçmiş ürün arşive taşındı.")
    finally:
        db.close()

    yield

app = FastAPI(
    title="Numune İlaç Stok Yönetimi",
    description="FastAPI + Clean Architecture Yerel Ağ Stok ve Miad Yönetim Sistemi",
    version="2.0.0",
    lifespan=lifespan
)

# Statik dosyaları mount et
STATIC_DIR = Path(__file__).resolve().parent / "app" / "presentation" / "static"
app.mount("/static/numune", StaticFiles(directory=str(STATIC_DIR)), name="static_numune")
app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")

# Rotaları dahil et
app.include_router(views.router)
app.include_router(api_stok.router)
app.include_router(api_master.router)
app.include_router(api_qr.router)
app.include_router(api_backup.router)

if __name__ == "__main__":
    print(f"Numune İlaç Uygulaması başlatılıyor: http://{HOST}:{PORT}")
    uvicorn.run("main:app", host=HOST, port=PORT, reload=True)
