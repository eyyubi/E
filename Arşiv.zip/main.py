import os
import sys
from pathlib import Path
from contextlib import asynccontextmanager

import uvicorn
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse, FileResponse, Response
from fastapi.staticfiles import StaticFiles

# Proje kökünü sys.path'e ekle
ROOT_DIR = Path(__file__).resolve().parent
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

# Core imports
from core.config import settings, HOST, PORT, BASE_DIR
from core.database import (
    init_all_databases,
    StokSessionLocal,
    StokBase,
    stok_engine,
    MasterBase,
    master_engine,
)

# Medrecete imports
from medrecete.app.api.endpoints import router as medrecete_router, manager
from medrecete.app.infrastructure.database import init_db as init_recete_db

# Numune İlaçlar imports
from numuneilaclar.app.infrastructure.repositories.stok_repository import SQLAlchemyStokRepository
from numuneilaclar.app.application.services.stok_service import StokService
from numuneilaclar.app.presentation.routers import (
    views as numune_views,
    api_stok,
    api_master,
    api_qr,
    api_backup,
)

# Serum Filtre imports
import serumfiltre.app.models  # Modelleri MasterBase'e bağlar
from serumfiltre.app.api.router import api_router as serum_router

# Portal imports
from portal.router import router as portal_router

# Master İlaç Yönetimi imports
from master_manager.router import router as master_manager_router

# Static directories
MEDRECETE_STATIC_DIR = ROOT_DIR / "medrecete" / "static"
NUMUNE_STATIC_DIR = ROOT_DIR / "numuneilaclar" / "app" / "presentation" / "static"
SERUM_STATIC_DIR = ROOT_DIR / "serumfiltre" / "static"
SERUM_TEMPLATES_DIR = ROOT_DIR / "serumfiltre" / "templates"
PORTAL_STATIC_DIR = ROOT_DIR / "portal" / "static"


@asynccontextmanager
async def lifespan(app: FastAPI):
    print("=" * 65)
    print(f" {settings.PROJECT_NAME} v{settings.VERSION}")
    print(" Tüm veritabanları başlatılıyor ve doğrulanıyor...")
    print("=" * 65)

    # 1. Ortak ve modüler veritabanlarını başlat
    init_all_databases()
    init_recete_db()

    # 2. Numune stok miad kontrolü (açılışta SKT'si geçenleri arşive taşı)
    stok_db = StokSessionLocal()
    try:
        service = StokService(stok_repo=SQLAlchemyStokRepository(stok_db))
        moved = service.run_expiration_check()
        if moved > 0:
            print(f" [Açılış Kontrolü] {moved} adet miadı geçmiş numune ürün arşive taşındı.")
    except Exception as e:
        print(f" [Açılış Kontrolü Uyarı] Stok kontrolü hatası: {e}")
    finally:
        stok_db.close()

    print(" Sistem hazır! Yerel ağdaki tüm cihazlardan erişilebilir.")
    yield


app = FastAPI(
    title=settings.PROJECT_NAME,
    description="Ortak Master Veritabanlı Klinik Reçete, Numune Stok ve Serum Filtreleme Platformu",
    version=settings.VERSION,
    lifespan=lifespan,
)

# CORS Middleware (Yerel ağdaki tüm istemcilerden güvenli erişim)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ── ROTA TANIMLARI ────────────────────────────────────────────────────────────

# 1. Portal & Hub Rotaları (Ana sayfa / ve sistem istatistikleri)
app.include_router(portal_router)

# 2. Medikal Reçete Rotaları
app.include_router(medrecete_router, prefix="/api")

# Medrecete WebSocket bağlantısı
@app.websocket("/api/ws")
async def websocket_endpoint(websocket: WebSocket):
    await manager.connect(websocket)
    try:
        while True:
            await websocket.receive_text()
    except (WebSocketDisconnect, Exception):
        manager.disconnect(websocket)

@app.get("/recete", response_class=HTMLResponse, include_in_schema=False)
@app.get("/medrecete", response_class=HTMLResponse, include_in_schema=False)
async def read_medrecete_ui():
    """Medikal Reçete Uygulama Arayüzü"""
    index_file = MEDRECETE_STATIC_DIR / "index.html"
    return FileResponse(str(index_file), media_type="text/html; charset=utf-8")


# 3. Numune İlaç Rotaları
app.include_router(numune_views.router)
app.include_router(api_stok.router)
app.include_router(api_master.router)
app.include_router(api_qr.router)
app.include_router(api_backup.router)


# 4. Serum & İlaç Filtreleme Rotaları
app.include_router(serum_router)

@app.get("/serum", response_class=HTMLResponse, include_in_schema=False)
@app.get("/serumfiltre", response_class=HTMLResponse, include_in_schema=False)
async def read_serum_ui():
    """Serum ve İlaç Filtreleme Uygulama Arayüzü"""
    template_path = SERUM_TEMPLATES_DIR / "index.html"
    if template_path.exists():
        with open(template_path, "r", encoding="utf-8") as f:
            return HTMLResponse(content=f.read())
    return HTMLResponse(content="<h1>Serum Filtreleme Sistemi Yükleniyor...</h1>")


# 5. Master İlaç Yönetim & Canlı Düzenleme Rotaları
app.include_router(master_manager_router)


# ── AKILLI STATİK DOSYA YÖNETİMİ ──────────────────────────────────────────────
# Modüllere özgü ad alanlı bağlamalar
app.mount("/static/medrecete", StaticFiles(directory=str(MEDRECETE_STATIC_DIR)), name="static_medrecete")
app.mount("/static/numune", StaticFiles(directory=str(NUMUNE_STATIC_DIR)), name="static_numune")
app.mount("/static/serum", StaticFiles(directory=str(SERUM_STATIC_DIR)), name="static_serum")

@app.get("/static/{file_path:path}", include_in_schema=False)
async def serve_static_fallback(file_path: str):
    """Geriye dönük uyumluluk: Tüm modüllerin statik dosyalarını akıllıca çözer."""
    # 1. Numune statik dosyaları
    cand_numune = NUMUNE_STATIC_DIR / file_path
    if cand_numune.is_file():
        return FileResponse(str(cand_numune))

    # 2. Serum filtre statik dosyaları
    cand_serum = SERUM_STATIC_DIR / file_path
    if cand_serum.is_file():
        return FileResponse(str(cand_serum))

    # 3. Medrecete statik dosyaları (vendor vb.)
    cand_med = MEDRECETE_STATIC_DIR / file_path
    if cand_med.is_file():
        return FileResponse(str(cand_med))

    # 4. Portal statik dosyaları
    cand_portal = PORTAL_STATIC_DIR / file_path
    if cand_portal.is_file():
        return FileResponse(str(cand_portal))

    return Response(content="File Not Found", status_code=404)


if __name__ == "__main__":
    from core.config import get_lan_ip
    lan_ip = get_lan_ip()
    print("=" * 65)
    print(f" {settings.PROJECT_NAME} Başlatılıyor...")
    print(f" Yerel Erişim (Localhost):  http://127.0.0.1:{PORT}")
    print(f" Yerel Ağ Erişimi (LAN):    http://{lan_ip}:{PORT}")
    print(f"   ├─ Portal (Ana Sayfa):   http://{lan_ip}:{PORT}/")
    print(f"   ├─ Medikal Reçete:       http://{lan_ip}:{PORT}/recete")
    print(f"   ├─ Numune Stok:          http://{lan_ip}:{PORT}/numune")
    print(f"   ├─ Serum Filtreleme:     http://{lan_ip}:{PORT}/serum")
    print(f"   └─ Master İlaç Yönetimi: http://{lan_ip}:{PORT}/master")
    print("=" * 65)
    uvicorn.run("main:app", host=HOST, port=PORT, reload=True)
