import unittest
from fastapi.testclient import TestClient
from main import app

class TestMasterManager(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.client = TestClient(app)

    def test_01_master_page_ui(self):
        """Master İlaç Yönetim Arayüzünün (/master) 200 döndüğünü ve açık temalı menüyü içerdiğini doğrular."""
        res = self.client.get("/master")
        self.assertEqual(res.status_code, 200)
        self.assertIn("Master İlaç", res.text)
        self.assertIn("suite-bar", res.text)
        self.assertIn("Düzenle", res.text)

    def test_02_master_stats_summary(self):
        """Master istatistik özetinin doğru sayıları döndürdüğünü doğrular."""
        res = self.client.get("/api/master/stats-summary")
        self.assertEqual(res.status_code, 200)
        data = res.json()
        self.assertGreaterEqual(data["total_products"], 17000)
        self.assertGreaterEqual(data["total_generics"], 6000)
        self.assertGreaterEqual(data["total_atc_codes"], 6000)
        self.assertIn("prescription_types", data)

    def test_03_master_list_pagination_and_search(self):
        """Katalog listeleme, arama ve sayfalama parametrelerini test eder."""
        # 1. Sayfalı listeleme
        res = self.client.get("/api/master/list?page=1&limit=10")
        self.assertEqual(res.status_code, 200)
        data = res.json()
        self.assertEqual(len(data["items"]), 10)
        self.assertGreaterEqual(data["total"], 17000)
        self.assertGreaterEqual(data["total_pages"], 1700)

        # 2. Arama filtresi
        res_search = self.client.get("/api/master/list?q=POLIFLEKS&limit=5")
        self.assertEqual(res_search.status_code, 200)
        search_data = res_search.json()
        self.assertGreater(len(search_data["items"]), 0)
        for it in search_data["items"]:
            self.assertTrue(
                "POLIFLEKS" in it["urun_adi"].upper() or
                "POLIFLEKS" in (it["jenerik_adi"] or "").upper() or
                "POLİFARMA" in (it["firma_adi"] or "").upper()
            )

    def test_04_get_single_drug(self):
        """Tekil bir ilacın detaylarının getirilmesini test eder."""
        res = self.client.get("/api/master/drug/10775")
        self.assertEqual(res.status_code, 200)
        drug = res.json()
        self.assertEqual(drug["urun_id"], 10775)
        self.assertIn("POLIFLEKS", drug["urun_adi"])

    def test_05_create_update_and_delete_drug_lifecycle(self):
        """Yeni ilaç oluşturma, güncelleme ve silme döngüsünü tam olarak test eder."""
        # 1. Yeni Test İlacı Ekle
        create_payload = {
            "urun_adi": "TEST KLINIK ILAC 500 MG",
            "barkod": "8699999999999",
            "ambalaj": "30 Tablet",
            "firma_adi": "TEST PHARMA A.S.",
            "etkin_maddeler": "Test Etkin Madde 500 mg",
            "jenerik_kodu": "J9999",
            "jenerik_adi": "Test Jenerik Grubu 500 mg",
            "atc_kodu": "N02BE99",
            "recete_turu": "KIRMIZI REÇETE"
        }
        res_create = self.client.post("/api/master/drug", json=create_payload)
        self.assertEqual(res_create.status_code, 200)
        created_data = res_create.json()
        self.assertTrue(created_data["success"])
        new_id = created_data["data"]["urun_id"]
        self.assertIsNotNone(new_id)

        try:
            # 2. Eklenen ilacın arama ile bulunduğunu doğrula
            res_find = self.client.get(f"/api/master/drug/{new_id}")
            self.assertEqual(res_find.status_code, 200)
            self.assertEqual(res_find.json()["urun_adi"], "TEST KLINIK ILAC 500 MG")
            self.assertEqual(res_find.json()["recete_turu"], "KIRMIZI REÇETE")

            # 3. İlaç Bilgilerini Güncelle (PUT)
            update_payload = {
                "urun_adi": "TEST KLINIK ILAC FORTE 1000 MG",
                "barkod": "8699999999999",
                "ambalaj": "60 Film Tablet",
                "firma_adi": "TEST PHARMA GUNCEL",
                "etkin_maddeler": "Test Etkin Madde 1000 mg",
                "jenerik_kodu": "J9999",
                "jenerik_adi": "Test Jenerik Grubu 1000 mg",
                "atc_kodu": "N02BE99",
                "recete_turu": "YEŞİL REÇETE"
            }
            res_update = self.client.put(f"/api/master/drug/{new_id}", json=update_payload)
            self.assertEqual(res_update.status_code, 200)
            update_res_data = res_update.json()
            self.assertTrue(update_res_data["success"])
            self.assertEqual(update_res_data["data"]["urun_adi"], "TEST KLINIK ILAC FORTE 1000 MG")
            self.assertEqual(update_res_data["data"]["ambalaj"], "60 Film Tablet")
            self.assertEqual(update_res_data["data"]["firma_adi"], "TEST PHARMA GUNCEL")
            self.assertEqual(update_res_data["data"]["recete_turu"], "YEŞİL REÇETE")

            # 4. Tekrar GET ile güncellendiğini teyit et
            res_get_updated = self.client.get(f"/api/master/drug/{new_id}")
            self.assertEqual(res_get_updated.status_code, 200)
            self.assertEqual(res_get_updated.json()["urun_adi"], "TEST KLINIK ILAC FORTE 1000 MG")
            self.assertEqual(res_get_updated.json()["ambalaj"], "60 Film Tablet")

        finally:
            # 5. Temizlik: Test ilacını sil
            res_del = self.client.delete(f"/api/master/drug/{new_id}")
            self.assertEqual(res_del.status_code, 200)
            self.assertTrue(res_del.json()["success"])

            # Silindiğini doğrula (404 dönmeli)
            res_check_del = self.client.get(f"/api/master/drug/{new_id}")
            self.assertEqual(res_check_del.status_code, 404)

    def test_06_numune_master_redirect(self):
        """Numune master yönlendirmesini (/numune/master -> /master) ve Numune menüsünden master rehberin kaldırıldığını test eder."""
        res = self.client.get("/numune/master", follow_redirects=False)
        self.assertIn(res.status_code, [307, 302, 301])
        self.assertEqual(res.headers.get("location"), "/master")

        # Numune ana sayfasında eski Master İlaç Rehberi linki olmadığını doğrula
        res_numune = self.client.get("/numune")
        self.assertEqual(res_numune.status_code, 200)
        self.assertNotIn("Master İlaç Rehberi", res_numune.text)

    def test_07_generics_crud_and_search(self):
        """Jenerik grup arama, ekleme, güncelleme ve silme döngüsünü test eder."""
        # 1. Canlı arama
        res_search = self.client.get("/api/master/generics/search?q=J0001")
        self.assertEqual(res_search.status_code, 200)
        self.assertGreater(len(res_search.json()), 0)

        # 2. Sayfalı listeleme
        res_list = self.client.get("/api/master/generics?limit=5")
        self.assertEqual(res_list.status_code, 200)
        self.assertGreaterEqual(res_list.json()["total"], 6000)

        # 3. Yeni jenerik grup oluştur
        test_code = "JTEST99"
        create_payload = {
            "jenerik_kodu": test_code,
            "jenerik_adi": "Test Jenerik Grubu 500 mg",
            "atc_kodu": "N02BE01"
        }
        res_c = self.client.post("/api/master/generics", json=create_payload)
        self.assertEqual(res_c.status_code, 200)
        self.assertTrue(res_c.json()["success"])

        try:
            # 4. Detay oku
            res_g = self.client.get(f"/api/master/generics/{test_code}")
            self.assertEqual(res_g.status_code, 200)
            self.assertEqual(res_g.json()["jenerik_adi"], "Test Jenerik Grubu 500 mg")

            # 5. Güncelle
            update_payload = {
                "jenerik_adi": "Test Jenerik Grubu Güncel 1000 mg",
                "atc_kodu": "N02BE02"
            }
            res_u = self.client.put(f"/api/master/generics/{test_code}", json=update_payload)
            self.assertEqual(res_u.status_code, 200)
            self.assertEqual(res_u.json()["data"]["jenerik_adi"], "Test Jenerik Grubu Güncel 1000 mg")

        finally:
            # 6. Sil
            res_d = self.client.delete(f"/api/master/generics/{test_code}")
            self.assertEqual(res_d.status_code, 200)
            self.assertTrue(res_d.json()["success"])

    def test_08_substances_crud_and_search(self):
        """Etken madde arama, ekleme, güncelleme ve silme döngüsünü test eder."""
        # 1. Ototamamla arama
        res_search = self.client.get("/api/master/substances/search?q=Parasetamol")
        self.assertEqual(res_search.status_code, 200)
        self.assertGreater(len(res_search.json()), 0)

        # 2. Sayfalı listeleme
        res_list = self.client.get("/api/master/substances?limit=5")
        self.assertEqual(res_list.status_code, 200)
        self.assertGreaterEqual(res_list.json()["total"], 6000)

        # 3. Yeni etken madde oluştur
        create_payload = {
            "etkin_madde": "Test Etken Madde Klinik",
            "dil": "tr"
        }
        res_c = self.client.post("/api/master/substances", json=create_payload)
        self.assertEqual(res_c.status_code, 200)
        new_sub_id = res_c.json()["data"]["etkin_madde_id"]
        self.assertIsNotNone(new_sub_id)

        try:
            # 4. Güncelle
            update_payload = {
                "etkin_madde": "Test Etken Madde Klinik Güncel",
                "dil": "tr"
            }
            res_u = self.client.put(f"/api/master/substances/{new_sub_id}", json=update_payload)
            self.assertEqual(res_u.status_code, 200)
            self.assertEqual(res_u.json()["data"]["etkin_madde"], "Test Etken Madde Klinik Güncel")

        finally:
            # 5. Sil
            res_d = self.client.delete(f"/api/master/substances/{new_sub_id}")
            self.assertEqual(res_d.status_code, 200)
            self.assertTrue(res_d.json()["success"])

    def test_09_drug_with_structured_active_ingredients_and_generic_assignment(self):
        """İlaç üzerinde yapılandırılmış etken madde, doz, birim ve jenerik seçimi döngüsünü test eder."""
        payload = {
            "urun_adi": "KOMBINASYON TEST ILACI",
            "barkod": "8699999998888",
            "ambalaj": "20 Efervesan Tablet",
            "firma_adi": "KLINIK PHARMA",
            "etkin_maddeler_list": [
                {"madde": "Parasetamol", "doz": "500", "birim": "mg"},
                {"madde": "Kafein", "doz": "30", "birim": "mg"}
            ],
            "jenerik_kodu": "J5704",
            "jenerik_adi": "%5 Dekstroz Laktatlı Ringer 1000 ml",
            "atc_kodu": "B05BB02",
            "recete_turu": "BEYAZ REÇETE"
        }
        res_create = self.client.post("/api/master/drug", json=payload)
        self.assertEqual(res_create.status_code, 200)
        drug_id = res_create.json()["data"]["urun_id"]

        try:
            # İlaç detayını oku ve etken madde/dozaj yapısını doğrula
            res_get = self.client.get(f"/api/master/drug/{drug_id}")
            self.assertEqual(res_get.status_code, 200)
            data = res_get.json()
            self.assertEqual(len(data["active_ingredients"]), 2)
            self.assertEqual(data["active_ingredients"][0]["madde"], "Parasetamol")
            self.assertEqual(data["active_ingredients"][0]["doz"], "500")
            self.assertEqual(data["active_ingredients"][0]["birim"], "mg")
            self.assertIn("Parasetamol 500 mg", data["etkin_maddeler_ozet"])
            self.assertIn("Kafein 30 mg", data["etkin_maddeler_ozet"])
            self.assertEqual(data["jenerik_kodu"], "J5704")

            # Güncelle: Doz ve madde değiştir
            update_payload = {
                "urun_adi": "KOMBINASYON TEST ILACI FORTE",
                "barkod": "8699999998888",
                "ambalaj": "30 Efervesan Tablet",
                "firma_adi": "KLINIK PHARMA GUNCEL",
                "etkin_maddeler_list": [
                    {"madde": "Parasetamol", "doz": "1000", "birim": "mg"},
                    {"madde": "Kafein", "doz": "50", "birim": "mg"},
                    {"madde": "C Vitamini", "doz": "300", "birim": "mg"}
                ],
                "jenerik_kodu": "J5704",
                "jenerik_adi": "%5 Dekstroz Laktatlı Ringer 1000 ml",
                "atc_kodu": "B05BB02",
                "recete_turu": "YEŞİL REÇETE"
            }
            res_up = self.client.put(f"/api/master/drug/{drug_id}", json=update_payload)
            self.assertEqual(res_up.status_code, 200)
            up_data = res_up.json()["data"]
            self.assertEqual(len(up_data["active_ingredients"]), 3)
            self.assertIn("C Vitamini 300 mg", up_data["etkin_maddeler_ozet"])

        finally:
            self.client.delete(f"/api/master/drug/{drug_id}")

    def test_10_html_ui_contains_tabs_and_builders(self):
        """Web arayüzünde sekmelerin, etken madde tablosunun ve jenerik seçicinin mevcut olduğunu doğrular."""
        res = self.client.get("/master")
        self.assertEqual(res.status_code, 200)
        self.assertIn("tabBtnDrugs", res.text)
        self.assertIn("tabBtnGenerics", res.text)
        self.assertIn("tabBtnSubstances", res.text)
        self.assertIn("ingredients-builder", res.text)
        self.assertIn("GenericPickerInput", res.text)
        self.assertIn("unitsDatalist", res.text)
        self.assertIn("ing-madde-en", res.text)

    def test_11_bilingual_substance_search_and_resolve(self):
        """Türkçe ve İngilizce etken madde arama ve kod eşleştirme doğrulaması."""
        # 1. İngilizce arama -> Türkçe ve İngilizce karşılık döner
        res_en = self.client.get("/api/master/substances/search", params={"q": "glucose"})
        self.assertEqual(res_en.status_code, 200)
        items_en = res_en.json()
        self.assertGreater(len(items_en), 0)
        found_dekstroz = any("Dekstroz" in it["tr_name"] for it in items_en)
        self.assertTrue(found_dekstroz, "İngilizce 'glucose' araması Türkçe 'Dekstroz' karşılığını getirmeli.")

        # 2. Türkçe arama -> İngilizce karşılık döner
        res_tr = self.client.get("/api/master/substances/search", params={"q": "dekstroz"})
        self.assertEqual(res_tr.status_code, 200)
        items_tr = res_tr.json()
        self.assertGreater(len(items_tr), 0)
        found_glucose = any("Glucose" in it.get("en_full", "") or "Glucose" in it.get("en_name", "") for it in items_tr)
        self.assertTrue(found_glucose, "Türkçe 'dekstroz' araması İngilizce 'Glucose' karşılığını getirmeli.")

        # 3. İki dilli çözümleme (resolve): Paracetamol (EN) -> Parasetamol (TR), aynı ID
        res_res_en = self.client.get("/api/master/substances/resolve", params={"q": "paracetamol"})
        self.assertEqual(res_res_en.status_code, 200)
        data_res_en = res_res_en.json()
        self.assertTrue(data_res_en["found"])
        self.assertEqual(data_res_en["etkin_madde_id"], 215)
        self.assertIn("Parasetamol", data_res_en["tr_name"])

        # 4. İki dilli çözümleme (resolve): Parasetamol (TR) -> Acetaminophen / Paracetamol (EN), aynı ID
        res_res_tr = self.client.get("/api/master/substances/resolve", params={"q": "parasetamol"})
        self.assertEqual(res_res_tr.status_code, 200)
        data_res_tr = res_res_tr.json()
        self.assertTrue(data_res_tr["found"])
        self.assertEqual(data_res_tr["etkin_madde_id"], 215)
        self.assertTrue("Acetaminophen" in data_res_tr["en_name"] or "Paracetamol" in data_res_tr["en_name"])

        # 5. ID ile çözümleme
        res_res_id = self.client.get("/api/master/substances/resolve", params={"q": "9"})
        self.assertEqual(res_res_id.status_code, 200)
        data_res_id = res_res_id.json()
        self.assertTrue(data_res_id["found"])
        self.assertIn("Dekstroz", data_res_id["tr_name"])
        self.assertIn("Glucose", data_res_id["en_name"])


if __name__ == "__main__":
    unittest.main()


