import unittest
from fastapi.testclient import TestClient
from main import app

class TestUnifiedApplication(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.client = TestClient(app)

    def test_portal_home_page(self):
        """Portal ana sayfasının (/) 200 döndüğünü ve 3 uygulamayı sunduğunu doğrular."""
        res = self.client.get("/")
        self.assertEqual(res.status_code, 200)
        self.assertIn("Klinik Eczane", res.text)
        self.assertIn("/recete", res.text)
        self.assertIn("/numune", res.text)
        self.assertIn("/serum", res.text)

    def test_portal_stats_api(self):
        """Portal canlı istatistik uç noktasının master DB verilerini doğru verdiğini doğrular."""
        res = self.client.get("/api/portal/stats")
        self.assertEqual(res.status_code, 200)
        data = res.json()
        self.assertIn("master", data)
        self.assertGreaterEqual(data["master"]["total_products"], 17000)
        self.assertGreaterEqual(data["master"]["total_generics"], 6000)
        self.assertGreaterEqual(data["master"]["total_services"], 6)

    def test_all_three_uis_accessible(self):
        """3 uygulamanın da kendi web arayüzlerine erişildiğini doğrular."""
        # 1. Medrecete
        res_recete = self.client.get("/recete")
        self.assertEqual(res_recete.status_code, 200)
        self.assertIn("MedRecete", res_recete.text)

        # 2. Numune İlaçlar
        res_numune = self.client.get("/numune")
        self.assertEqual(res_numune.status_code, 200)
        self.assertIn("Numune İlaç Sistemi", res_numune.text)

        res_miad = self.client.get("/numune/miad")
        self.assertEqual(res_miad.status_code, 200)

        res_master = self.client.get("/numune/master", follow_redirects=True)
        self.assertEqual(res_master.status_code, 200)

        res_master_direct = self.client.get("/master")
        self.assertEqual(res_master_direct.status_code, 200)

        res_backup = self.client.get("/numune/backup")
        self.assertEqual(res_backup.status_code, 200)

        # 3. Serum Filtreleme
        res_serum = self.client.get("/serum")
        self.assertEqual(res_serum.status_code, 200)
        self.assertIn("İlaç Filtreleme", res_serum.text)

    def test_shared_master_database_queries(self):
        """Ortak Master DB sorgularının 3 modülde de çalıştığını doğrular."""
        # Numune master arama
        res1 = self.client.get("/api/master/search?q=POLIFLEKS&limit=5")
        self.assertEqual(res1.status_code, 200)
        data1 = res1.json()
        self.assertGreater(len(data1), 0)
        self.assertIn("POLIFLEKS", data1[0]["urun_adi"].upper())

        # Medrecete ürün arama
        res2 = self.client.get("/api/products/search?q=POLIFLEKS&limit=5")
        self.assertEqual(res2.status_code, 200)
        data2 = res2.json()
        self.assertGreater(len(data2), 0)

        # Serum jenerik arama
        res3 = self.client.get("/api/aliases/search-jenerik?q=Dekstroz&limit=5")
        self.assertEqual(res3.status_code, 200)
        data3 = res3.json()
        self.assertGreater(len(data3), 0)

    def test_static_files_resolution(self):
        """Statik dosyaların ad alanlı ve geriye dönük fallback ile çözüldüğünü doğrular."""
        # Medrecete vendor font
        r1 = self.client.get("/static/medrecete/vendor/fonts/plus-jakarta-sans.css")
        self.assertEqual(r1.status_code, 200)

        # Numune css
        r2 = self.client.get("/static/numune/css/style.css")
        self.assertEqual(r2.status_code, 200)

        # Serum css
        r3 = self.client.get("/static/serum/css/app.css")
        self.assertEqual(r3.status_code, 200)

        # Fallback (doğrudan /static/...)
        r4 = self.client.get("/static/vendor/fonts/plus-jakarta-sans.css")
        self.assertEqual(r4.status_code, 200)

if __name__ == "__main__":
    unittest.main()
