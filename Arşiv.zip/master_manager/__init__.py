"""Master İlaç Düzenleme & Yönetim Modülü"""
from master_manager.router import router

__all__ = ["router"]
