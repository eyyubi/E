import os
import re
import json
import sqlite3
import unicodedata
from pathlib import Path
from typing import Optional, List, Dict, Any

from fastapi import APIRouter, HTTPException, Query, Request
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel, Field

from core.config import settings

router = APIRouter(tags=["Master İlaç Yönetimi"])

TEMPLATES_DIR = Path(__file__).resolve().parent / "templates"
templates = Jinja2Templates(directory=str(TEMPLATES_DIR))

_TR_TRANS = str.maketrans("İIÜÖŞĞÇ", "IIUOSGC")

def _normalize_text(s: Optional[str]) -> str:
    if s is None:
        return ""
    s = str(s).strip().upper().translate(_TR_TRANS)
    s = unicodedata.normalize("NFKD", s)
    return "".join(ch for ch in s if not unicodedata.combining(ch))

def _get_master_conn() -> sqlite3.Connection:
    conn = sqlite3.connect(str(settings.MASTER_DB_PATH), timeout=30)
    conn.row_factory = sqlite3.Row
    conn.create_function("NORMALIZE", 1, _normalize_text, deterministic=True)
    return conn


# ── Standart Medikal Birimler & Etken Madde Ayrıştırma ─────────────────────────

COMMON_UNITS = [
    "mg/ml", "mcg/ml", "g/ml", "mg/5ml", "g/500ml", "mg/100ml", "mg/2ml",
    "mg", "mcg", "g", "kg", "ml", "lt",
    "%", "IU", "meq", "mEq", "ünite", "damla", "flakon", "kapsül", "tablet", "ampul", "doz"
]
_UNIT_REGEX = "|".join(re.escape(u) for u in sorted(COMMON_UNITS, key=len, reverse=True))

def parse_active_ingredients(text_or_json: Optional[str]) -> List[Dict[str, str]]:
    """JSON veya metin halindeki etken maddeleri [{'madde': ..., 'doz': ..., 'birim': ...}] yapısına ayrıştırır."""
    if not text_or_json:
        return []
    raw = str(text_or_json).strip()
    if not raw:
        return []

    # 1. JSON kontrolü
    if (raw.startswith("[") and raw.endswith("]")) or (raw.startswith("{") and raw.endswith("}")):
        try:
            data = json.loads(raw)
            if isinstance(data, list):
                res = []
                for item in data:
                    if isinstance(item, dict):
                        res.append({
                            "madde": str(item.get("madde") or item.get("name") or item.get("etkin_madde") or "").strip(),
                            "madde_en": str(item.get("madde_en") or item.get("en_name") or "").strip(),
                            "etkin_madde_id": item.get("etkin_madde_id"),
                            "doz": str(item.get("doz") or item.get("dose") or "").strip(),
                            "birim": str(item.get("birim") or item.get("unit") or "").strip()
                        })
                    elif isinstance(item, str) and item.strip():
                        res.append({"madde": item.strip(), "madde_en": "", "etkin_madde_id": None, "doz": "", "birim": ""})
                if res:
                    return res
        except Exception:
            pass

    # 2. Metin ayrıştırma (Örn: "Parasetamol 500 mg + Kafein 30 mg" veya "Dekstroz 5 % + Sodyum klorür 0.45 %")
    text_fixed = re.sub(r'(\d+),(\d+)', r'\1.\2', raw)
    parts = re.split(r'\s*\+\s*|\s*;\s*', text_fixed)
    results = []
    for part in parts:
        part = part.strip()
        if not part:
            continue
        m = re.search(r'^(.*?)\s*([\d\.]+)\s*(' + _UNIT_REGEX + r')(?:\s+(.*))?$', part, re.IGNORECASE)
        if m:
            prefix = m.group(1).strip()
            suffix = (m.group(4) or "").strip()
            madde = f"{prefix} {suffix}".strip() if suffix and not suffix.startswith("(") else (prefix or suffix)
            doz = m.group(2).strip()
            birim = m.group(3).strip()
            results.append({"madde": madde, "madde_en": "", "etkin_madde_id": None, "doz": doz, "birim": birim})
        else:
            results.append({"madde": part, "madde_en": "", "etkin_madde_id": None, "doz": "", "birim": ""})
    return results

def format_ingredients_summary(ingredients: List[Dict[str, Any]]) -> str:
    """Etken maddeler listesinden okunabilir özet oluşturur (Örn: 'Parasetamol 500 mg + Kafein 30 mg')."""
    parts = []
    for it in ingredients:
        madde = (it.get("madde") or "").strip()
        doz = (it.get("doz") or "").strip()
        birim = (it.get("birim") or "").strip()
        if not madde:
            continue
        dose_unit = f"{doz} {birim}".strip()
        if dose_unit:
            parts.append(f"{madde} {dose_unit}")
        else:
            parts.append(madde)
    return " + ".join(parts)


# ── Pydantic Şemaları ─────────────────────────────────────────────────────────

class ActiveIngredientItem(BaseModel):
    madde: str = Field(..., description="Etken madde adı (Türkçe)")
    madde_en: Optional[str] = Field("", description="Etken madde adı (İngilizce)")
    etkin_madde_id: Optional[int] = Field(None, description="TEB Etkin Madde Kodu")
    doz: Optional[str] = Field("", description="Doz / Miktar (Örn: 500)")
    birim: Optional[str] = Field("", description="Birim (Örn: mg, g, ml, %)")


class DrugUpdateSchema(BaseModel):
    urun_adi: str = Field(..., min_length=2, description="İlaç Ticari Adı")
    barkod: Optional[str] = Field("", description="Barkod / GTIN")
    ambalaj: Optional[str] = Field("", description="Ambalaj ve Form")
    firma_adi: Optional[str] = Field("", description="Ruhsat Sahibi Firma")
    etkin_maddeler: Optional[str] = Field("", description="Etkin Maddeler (Metin)")
    etkin_maddeler_list: Optional[List[ActiveIngredientItem]] = Field(default=None, description="Yapılandırılmış etken madde listesi")
    jenerik_kodu: Optional[str] = Field("", description="Jenerik Grubu Kodu")
    jenerik_adi: Optional[str] = Field("", description="Jenerik Grubu Açıklaması")
    atc_kodu: Optional[str] = Field("", description="ATC Sınıflandırma Kodu")
    nfc: Optional[str] = Field("", description="NFC Kodu")
    recete_turu: Optional[str] = Field("", description="Reçete Türü (Beyaz, Kırmızı vb.)")


class DrugCreateSchema(DrugUpdateSchema):
    pass


class GenericCreateSchema(BaseModel):
    jenerik_kodu: str = Field(..., min_length=1, description="Jenerik Kodu (Örn: J0001)")
    jenerik_adi: str = Field(..., min_length=2, description="Jenerik Grup Tanımı / Adı")
    atc_kodu: Optional[str] = Field("", description="ATC Kodu")


class GenericUpdateSchema(BaseModel):
    jenerik_adi: str = Field(..., min_length=2, description="Jenerik Grup Tanımı / Adı")
    atc_kodu: Optional[str] = Field("", description="ATC Kodu")


class SubstanceCreateSchema(BaseModel):
    etkin_madde: str = Field(..., min_length=2, description="Etken Madde Adı")
    dil: Optional[str] = Field("tr", description="Dil (tr veya en)")


class SubstanceUpdateSchema(BaseModel):
    etkin_madde: str = Field(..., min_length=2, description="Etken Madde Adı")
    dil: Optional[str] = Field("tr", description="Dil (tr veya en)")


# ── Web Arayüzü ───────────────────────────────────────────────────────────────

@router.get("/master", response_class=HTMLResponse, include_in_schema=False)
async def get_master_ui(request: Request):
    """Master İlaç Yönetim, Jenerik ve Etken Madde Arayüzü"""
    return templates.TemplateResponse(
        request=request,
        name="master_manager.html",
        context={"active_suite": "master"}
    )


# ── 1. İlaç Yönetim API Uç Noktaları ─────────────────────────────────────────

@router.get("/api/master/list")
async def list_master_drugs(
    q: str = Query("", description="Arama terimi"),
    recete_turu: str = Query("", description="Reçete türü filtresi"),
    page: int = Query(1, ge=1, description="Sayfa numarası"),
    limit: int = Query(50, ge=1, le=100, description="Sayfa başı kayıt"),
):
    """Master ilaç kataloğunu sayfalı ve normalize edilmiş çoklu kelime aramasıyla listeler."""
    conn = _get_master_conn()
    try:
        where_clauses = []
        params = []

        q_clean = q.strip()
        if q_clean:
            tokens = [t for t in q_clean.split() if t]
            for token in tokens:
                token_norm = _normalize_text(token)
                token_wildcard = f"%{token_norm}%"
                raw_wildcard = f"%{token}%"
                where_clauses.append(
                    "(NORMALIZE(urun_adi) LIKE ? OR REPLACE(barkod, '''', '') LIKE ? OR "
                    "NORMALIZE(COALESCE(etkin_maddeler, '')) LIKE ? OR NORMALIZE(COALESCE(firma_adi, '')) LIKE ? OR "
                    "NORMALIZE(COALESCE(jenerik_adi, '')) LIKE ? OR atc_kodu LIKE ? OR jenerik_kodu LIKE ?)"
                )
                params.extend([
                    token_wildcard,
                    raw_wildcard,
                    token_wildcard,
                    token_wildcard,
                    token_wildcard,
                    raw_wildcard,
                    raw_wildcard
                ])

        if recete_turu.strip():
            where_clauses.append("recete_turu = ?")
            params.append(recete_turu.strip())

        where_sql = ("WHERE " + " AND ".join(where_clauses)) if where_clauses else ""

        count_sql = f"SELECT COUNT(*) FROM master_ilaclar {where_sql}"
        total_items = conn.execute(count_sql, params).fetchone()[0]

        offset = (page - 1) * limit
        data_sql = f"""
            SELECT 
                urun_id,
                barkod,
                urun_adi,
                ambalaj,
                firma_adi,
                etkin_maddeler,
                jenerik_kodu,
                jenerik_adi,
                atc_kodu,
                nfc,
                recete_turu
            FROM master_ilaclar
            {where_sql}
            ORDER BY urun_id ASC
            LIMIT ? OFFSET ?
        """
        rows = conn.execute(data_sql, params + [limit, offset]).fetchall()

        items = []
        for r in rows:
            d = dict(r)
            # Etken maddeler JSON ise okunabilir özeti hazırla
            raw_etkin = d.get("etkin_maddeler") or ""
            if raw_etkin.startswith("[") or raw_etkin.startswith("{"):
                parsed = parse_active_ingredients(raw_etkin)
                d["etkin_maddeler_ozet"] = format_ingredients_summary(parsed) or raw_etkin
            else:
                d["etkin_maddeler_ozet"] = raw_etkin
            items.append(d)

        total_pages = (total_items + limit - 1) // limit if total_items > 0 else 1

        return {
            "items": items,
            "total": total_items,
            "page": page,
            "limit": limit,
            "total_pages": total_pages,
        }
    finally:
        conn.close()


@router.get("/api/master/drug/{urun_id}")
async def get_master_drug(urun_id: int):
    """Tekil ilaç detayını ve yapılandırılmış etken madde listesini döndürür."""
    conn = _get_master_conn()
    try:
        row = conn.execute("SELECT * FROM master_ilaclar WHERE urun_id = ?", (urun_id,)).fetchone()
        if not row:
            raise HTTPException(status_code=404, detail="İlaç bulunamadı.")
        drug_data = dict(row)

        raw_etkin = drug_data.get("etkin_maddeler") or ""
        if not raw_etkin:
            raw_etkin = drug_data.get("jenerik_adi") or ""

        parsed_ingredients = parse_active_ingredients(raw_etkin)
        for it in parsed_ingredients:
            if it.get("madde") and not it.get("madde_en"):
                sub_row = conn.execute(
                    """
                    SELECT etkin_madde_id, tr_name, en_name 
                    FROM substances_bilingual 
                    WHERE LOWER(tr_name) = LOWER(?) OR LOWER(en_name) = LOWER(?)
                       OR tr_name LIKE ? OR en_name LIKE ?
                    LIMIT 1
                    """,
                    (it["madde"], it["madde"], f"%{it['madde']}%", f"%{it['madde']}%")
                ).fetchone()
                if sub_row:
                    it["etkin_madde_id"] = sub_row[0]
                    it["madde_en"] = (sub_row[2] or "").splitlines()[0].strip() if sub_row[2] else ""
                    if not it["madde"] and sub_row[1]:
                        it["madde"] = sub_row[1]

        drug_data["active_ingredients"] = parsed_ingredients
        drug_data["etkin_maddeler_ozet"] = format_ingredients_summary(parsed_ingredients) or raw_etkin
        return drug_data
    finally:
        conn.close()


@router.put("/api/master/drug/{urun_id}")
async def update_master_drug(urun_id: int, payload: DrugUpdateSchema):
    """İlaç bilgilerini ve yapılandırılmış etken maddeleri günceller, tüm sistemlerle senkronize eder."""
    master_conn = _get_master_conn()
    try:
        existing = master_conn.execute("SELECT * FROM products WHERE urun_id = ?", (urun_id,)).fetchone()
        if not existing:
            raise HTTPException(status_code=404, detail=f"ID={urun_id} olan ilaç bulunamadı.")

        barkod_clean = (payload.barkod or "").replace("'", "").strip()
        urun_adi_clean = payload.urun_adi.strip()
        ambalaj_clean = (payload.ambalaj or "").strip()
        firma_adi_clean = (payload.firma_adi or "").strip()
        jenerik_kodu_clean = (payload.jenerik_kodu or "").strip().upper()
        jenerik_adi_clean = (payload.jenerik_adi or "").strip()
        atc_kodu_clean = (payload.atc_kodu or "").strip().upper()
        nfc_clean = (payload.nfc or "").strip().upper()
        recete_turu_clean = (payload.recete_turu or "").strip()

        # Etken madde listesi veya metin işleme
        active_list: List[Dict[str, str]] = []
        if payload.etkin_maddeler_list is not None:
            active_list = [
                {"madde": it.madde.strip(), "doz": (it.doz or "").strip(), "birim": (it.birim or "").strip()}
                for it in payload.etkin_maddeler_list
                if it.madde.strip()
            ]
        elif payload.etkin_maddeler:
            active_list = parse_active_ingredients(payload.etkin_maddeler)

        etkin_summary = format_ingredients_summary(active_list) if active_list else (payload.etkin_maddeler or "").strip()
        etkin_db_value = json.dumps(active_list, ensure_ascii=False) if active_list else (etkin_summary or None)

        # 1. products tablosunu güncelle
        master_conn.execute(
            """
            UPDATE products SET
                urun_adi = ?,
                barkod = ?,
                ambalaj = ?,
                firma_adi = ?,
                etkin_maddeler = ?,
                jenerik_kodu = ?,
                nfc = ?,
                recete_turu = ?
            WHERE urun_id = ?
            """,
            (
                urun_adi_clean,
                barkod_clean,
                ambalaj_clean,
                firma_adi_clean,
                etkin_db_value,
                jenerik_kodu_clean or None,
                nfc_clean or None,
                recete_turu_clean or None,
                urun_id,
            ),
        )

        # 2. Generics tablosunu senkronize et
        if jenerik_kodu_clean:
            gen_row = master_conn.execute(
                "SELECT * FROM generics WHERE jenerik_kodu = ?", (jenerik_kodu_clean,)
            ).fetchone()
            if gen_row:
                master_conn.execute(
                    """
                    UPDATE generics SET
                        jenerik_adi = COALESCE(NULLIF(?, ''), jenerik_adi),
                        atc_kodu = COALESCE(NULLIF(?, ''), atc_kodu)
                    WHERE jenerik_kodu = ?
                    """,
                    (jenerik_adi_clean, atc_kodu_clean, jenerik_kodu_clean),
                )
            else:
                master_conn.execute(
                    """
                    INSERT INTO generics (jenerik_kodu, jenerik_adi, atc_kodu)
                    VALUES (?, ?, ?)
                    """,
                    (jenerik_kodu_clean, jenerik_adi_clean, atc_kodu_clean),
                )

        master_conn.commit()

        updated_row = master_conn.execute(
            "SELECT * FROM master_ilaclar WHERE urun_id = ?", (urun_id,)
        ).fetchone()

        res_data = dict(updated_row)
        res_data["active_ingredients"] = active_list
        res_data["etkin_maddeler_ozet"] = etkin_summary

        return {
            "success": True,
            "message": f"'{urun_adi_clean}' başarıyla güncellendi.",
            "data": res_data,
        }
    finally:
        master_conn.close()


@router.post("/api/master/drug")
async def create_master_drug(payload: DrugCreateSchema):
    """Master kataloğuna yeni bir ilaç ekler ve MedReçete ile senkronize eder."""
    master_conn = _get_master_conn()
    try:
        max_id = master_conn.execute("SELECT COALESCE(MAX(urun_id), 0) FROM products").fetchone()[0]
        next_id = max_id + 1

        barkod_clean = (payload.barkod or "").replace("'", "").strip()
        urun_adi_clean = payload.urun_adi.strip()
        ambalaj_clean = (payload.ambalaj or "").strip()
        firma_adi_clean = (payload.firma_adi or "").strip()
        jenerik_kodu_clean = (payload.jenerik_kodu or "").strip().upper()
        jenerik_adi_clean = (payload.jenerik_adi or "").strip()
        atc_kodu_clean = (payload.atc_kodu or "").strip().upper()
        nfc_clean = (payload.nfc or "").strip().upper()
        recete_turu_clean = (payload.recete_turu or "").strip()

        active_list: List[Dict[str, str]] = []
        if payload.etkin_maddeler_list is not None:
            active_list = [
                {"madde": it.madde.strip(), "doz": (it.doz or "").strip(), "birim": (it.birim or "").strip()}
                for it in payload.etkin_maddeler_list
                if it.madde.strip()
            ]
        elif payload.etkin_maddeler:
            active_list = parse_active_ingredients(payload.etkin_maddeler)

        etkin_summary = format_ingredients_summary(active_list) if active_list else (payload.etkin_maddeler or "").strip()
        etkin_db_value = json.dumps(active_list, ensure_ascii=False) if active_list else (etkin_summary or None)

        master_conn.execute(
            """
            INSERT INTO products (
                urun_id, barkod, urun_adi, ambalaj, firma_adi, etkin_maddeler,
                jenerik_kodu, nfc, recete_turu
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                next_id,
                barkod_clean,
                urun_adi_clean,
                ambalaj_clean,
                firma_adi_clean,
                etkin_db_value,
                jenerik_kodu_clean or None,
                nfc_clean or None,
                recete_turu_clean or None,
            ),
        )

        if jenerik_kodu_clean:
            gen_exists = master_conn.execute(
                "SELECT 1 FROM generics WHERE jenerik_kodu = ?", (jenerik_kodu_clean,)
            ).fetchone()
            if not gen_exists:
                master_conn.execute(
                    "INSERT INTO generics (jenerik_kodu, jenerik_adi, atc_kodu) VALUES (?, ?, ?)",
                    (jenerik_kodu_clean, jenerik_adi_clean, atc_kodu_clean),
                )

        master_conn.commit()

        created_row = master_conn.execute(
            "SELECT * FROM master_ilaclar WHERE urun_id = ?", (next_id,)
        ).fetchone()

        res_data = dict(created_row)
        res_data["active_ingredients"] = active_list
        res_data["etkin_maddeler_ozet"] = etkin_summary

        return {
            "success": True,
            "message": f"'{urun_adi_clean}' başarıyla kataloğa eklendi.",
            "data": res_data,
        }
    finally:
        master_conn.close()


@router.delete("/api/master/drug/{urun_id}")
async def delete_master_drug(urun_id: int):
    """Katalogdan ilaç siler."""
    master_conn = _get_master_conn()
    try:
        row = master_conn.execute("SELECT urun_adi FROM products WHERE urun_id = ?", (urun_id,)).fetchone()
        if not row:
            raise HTTPException(status_code=404, detail="İlaç bulunamadı.")
        name = row[0]

        master_conn.execute("DELETE FROM products WHERE urun_id = ?", (urun_id,))
        master_conn.commit()

        return {"success": True, "message": f"'{name}' (ID: {urun_id}) katalogdan silindi."}
    finally:
        master_conn.close()


# ── 2. Jenerik Grup Yönetimi API Uç Noktaları ────────────────────────────────

@router.get("/api/master/generics/search")
async def search_master_generics(
    q: str = Query("", description="Arama terimi (Jenerik kodu, adı veya ATC)"),
    limit: int = Query(30, ge=1, le=100, description="Maksimum sonuç sayısı")
):
    """İlaç düzenleme modalında jenerik kod seçimi için hızlı canlı arama/ototamamla."""
    conn = _get_master_conn()
    try:
        q_clean = q.strip()
        if not q_clean:
            rows = conn.execute(
                "SELECT jenerik_kodu, jenerik_adi, atc_kodu FROM generics ORDER BY jenerik_kodu ASC LIMIT ?",
                (limit,)
            ).fetchall()
        else:
            q_norm = _normalize_text(q_clean)
            wild = f"%{q_norm}%"
            raw_wild = f"%{q_clean}%"
            rows = conn.execute(
                """
                SELECT jenerik_kodu, jenerik_adi, atc_kodu 
                FROM generics 
                WHERE jenerik_kodu LIKE ? OR NORMALIZE(COALESCE(jenerik_adi, '')) LIKE ? OR atc_kodu LIKE ?
                ORDER BY jenerik_kodu ASC LIMIT ?
                """,
                (raw_wild, wild, raw_wild, limit)
            ).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


@router.get("/api/master/generics")
async def list_master_generics(
    q: str = Query("", description="Jenerik kod, ad veya ATC ara"),
    page: int = Query(1, ge=1, description="Sayfa no"),
    limit: int = Query(25, ge=1, le=100, description="Limit")
):
    """Jenerik grupları sayfalı ve arama destekli olarak listeler (ilişkili ilaç sayısı dahil)."""
    conn = _get_master_conn()
    try:
        where_clauses = []
        params = []
        q_clean = q.strip()
        if q_clean:
            tokens = [t for t in q_clean.split() if t]
            for token in tokens:
                t_norm = _normalize_text(token)
                where_clauses.append("(jenerik_kodu LIKE ? OR NORMALIZE(COALESCE(jenerik_adi, '')) LIKE ? OR atc_kodu LIKE ?)")
                params.extend([f"%{token}%", f"%{t_norm}%", f"%{token}%"])
        where_sql = ("WHERE " + " AND ".join(where_clauses)) if where_clauses else ""

        count_sql = f"SELECT COUNT(*) FROM generics {where_sql}"
        total = conn.execute(count_sql, params).fetchone()[0]

        offset = (page - 1) * limit
        data_sql = f"""
            SELECT 
                g.jenerik_kodu, 
                g.jenerik_adi, 
                g.atc_kodu,
                (SELECT COUNT(*) FROM products p WHERE p.jenerik_kodu = g.jenerik_kodu) AS drug_count
            FROM generics g
            {where_sql}
            ORDER BY g.jenerik_kodu ASC
            LIMIT ? OFFSET ?
        """
        rows = conn.execute(data_sql, params + [limit, offset]).fetchall()
        total_pages = (total + limit - 1) // limit if total > 0 else 1

        return {
            "items": [dict(r) for r in rows],
            "total": total,
            "page": page,
            "limit": limit,
            "total_pages": total_pages,
        }
    finally:
        conn.close()


@router.get("/api/master/generics/{jenerik_kodu}")
async def get_master_generic(jenerik_kodu: str):
    """Tekil jenerik grup detayını döndürür."""
    conn = _get_master_conn()
    try:
        code = jenerik_kodu.strip().upper()
        row = conn.execute(
            """
            SELECT g.jenerik_kodu, g.jenerik_adi, g.atc_kodu,
                   (SELECT COUNT(*) FROM products p WHERE p.jenerik_kodu = g.jenerik_kodu) AS drug_count
            FROM generics g WHERE g.jenerik_kodu = ?
            """,
            (code,)
        ).fetchone()
        if not row:
            raise HTTPException(status_code=404, detail="Jenerik grup bulunamadı.")
        return dict(row)
    finally:
        conn.close()


@router.post("/api/master/generics")
async def create_master_generic(payload: GenericCreateSchema):
    """Yeni bir jenerik grup oluşturur ve sistemlere senkronize eder."""
    code = payload.jenerik_kodu.strip().upper()
    name = payload.jenerik_adi.strip()
    atc = (payload.atc_kodu or "").strip().upper()
    if not code or not name:
        raise HTTPException(status_code=400, detail="Jenerik kodu ve grup adı zorunludur.")

    conn = _get_master_conn()
    try:
        exists = conn.execute("SELECT 1 FROM generics WHERE jenerik_kodu = ?", (code,)).fetchone()
        if exists:
            raise HTTPException(status_code=400, detail=f"'{code}' jenerik kodu zaten kayıtlı.")

        conn.execute("INSERT INTO generics (jenerik_kodu, jenerik_adi, atc_kodu) VALUES (?, ?, ?)", (code, name, atc))
        conn.commit()

        return {
            "success": True,
            "message": f"'{code} - {name}' jenerik grubu başarıyla eklendi.",
            "data": {"jenerik_kodu": code, "jenerik_adi": name, "atc_kodu": atc}
        }
    finally:
        conn.close()


@router.put("/api/master/generics/{jenerik_kodu}")
async def update_master_generic(jenerik_kodu: str, payload: GenericUpdateSchema):
    """Mevcut jenerik grup tanımını ve ATC kodunu günceller."""
    code = jenerik_kodu.strip().upper()
    name = payload.jenerik_adi.strip()
    atc = (payload.atc_kodu or "").strip().upper()
    if not name:
        raise HTTPException(status_code=400, detail="Jenerik grup adı boş olamaz.")

    conn = _get_master_conn()
    try:
        exists = conn.execute("SELECT 1 FROM generics WHERE jenerik_kodu = ?", (code,)).fetchone()
        if not exists:
            raise HTTPException(status_code=404, detail="Jenerik grup bulunamadı.")

        conn.execute("UPDATE generics SET jenerik_adi = ?, atc_kodu = ? WHERE jenerik_kodu = ?", (name, atc, code))
        conn.commit()

        return {
            "success": True,
            "message": f"'{code}' jenerik grubu başarıyla güncellendi.",
            "data": {"jenerik_kodu": code, "jenerik_adi": name, "atc_kodu": atc}
        }
    finally:
        conn.close()


@router.delete("/api/master/generics/{jenerik_kodu}")
async def delete_master_generic(jenerik_kodu: str):
    """Jenerik grubu siler (kullanımda olan ilaç varsa engeller)."""
    code = jenerik_kodu.strip().upper()
    conn = _get_master_conn()
    try:
        usage = conn.execute("SELECT COUNT(*) FROM products WHERE jenerik_kodu = ?", (code,)).fetchone()[0]
        if usage > 0:
            raise HTTPException(
                status_code=400,
                detail=f"Bu jenerik kod ({code}) şu anda {usage} adet ilaç tarafından kullanılmaktadır. Önce ilgili ilaçların jenerik kodunu değiştirin veya kaldırın."
            )

        conn.execute("DELETE FROM generics WHERE jenerik_kodu = ?", (code,))
        conn.commit()

        return {"success": True, "message": f"'{code}' jenerik grubu başarıyla silindi."}
    finally:
        conn.close()


# ── 3. Etken Madde Kataloğu API Uç Noktaları ────────────────────────────────

@router.get("/api/master/substances/search")
async def search_master_substances(
    q: str = Query("", description="Etken madde adı (Türkçe veya İngilizce)"),
    limit: int = Query(30, ge=1, le=100, description="Limit")
):
    """Etken maddelerde Türkçe veya İngilizce arama yapar ve iki dilli karşılıklarını döner."""
    conn = _get_master_conn()
    try:
        q_clean = q.strip()
        if not q_clean:
            rows = conn.execute(
                """
                SELECT etkin_madde_id, tr_name, en_name 
                FROM substances_bilingual 
                WHERE tr_name IS NOT NULL AND tr_name != ''
                ORDER BY tr_name ASC LIMIT ?
                """,
                (limit,)
            ).fetchall()
        else:
            q_norm = _normalize_text(q_clean)
            wild = f"%{q_norm}%"
            raw_wild = f"%{q_clean}%"
            rows = conn.execute(
                """
                SELECT etkin_madde_id, tr_name, en_name 
                FROM substances_bilingual 
                WHERE tr_name LIKE ? OR en_name LIKE ? 
                   OR NORMALIZE(tr_name) LIKE ? OR NORMALIZE(en_name) LIKE ?
                   OR CAST(etkin_madde_id AS TEXT) = ?
                ORDER BY 
                   CASE 
                       WHEN NORMALIZE(tr_name) LIKE ? THEN 1
                       WHEN NORMALIZE(en_name) LIKE ? THEN 2
                       ELSE 3 
                   END,
                   COALESCE(tr_name, en_name) ASC 
                LIMIT ?
                """,
                (raw_wild, raw_wild, wild, wild, q_clean, wild, wild, limit)
            ).fetchall()

        results = []
        for r in rows:
            em_id, tr, en = r[0], r[1] or "", r[2] or ""
            clean_en = en.splitlines()[0].strip() if en else ""
            results.append({
                "etkin_madde_id": em_id,
                "etkin_madde": tr or clean_en,
                "tr_name": tr or clean_en,
                "en_name": clean_en,
                "en_full": en,
                "display_name": f"{tr} (EN: {clean_en})" if (tr and clean_en) else (tr or clean_en),
            })
        return results
    finally:
        conn.close()


@router.get("/api/master/substances/resolve")
async def resolve_master_substance(
    q: str = Query(..., description="Etken madde adı (Türkçe veya İngilizce) veya ID")
):
    """Verilen Türkçe veya İngilizce ada göre karşılık gelen iki dilli etken madde kaydını çözer."""
    conn = _get_master_conn()
    try:
        q_clean = q.strip()
        if not q_clean:
            return {"found": False}

        if q_clean.isdigit():
            row = conn.execute(
                "SELECT etkin_madde_id, tr_name, en_name FROM substances_bilingual WHERE etkin_madde_id = ?",
                (int(q_clean),)
            ).fetchone()
        else:
            q_norm = _normalize_text(q_clean)
            wild = f"%{q_norm}%"
            raw_wild = f"%{q_clean}%"
            row = conn.execute(
                """
                SELECT etkin_madde_id, tr_name, en_name 
                FROM substances_bilingual 
                WHERE LOWER(tr_name) = LOWER(?) OR LOWER(en_name) = LOWER(?)
                   OR NORMALIZE(tr_name) = ?
                LIMIT 1
                """,
                (q_clean, q_clean, q_norm)
            ).fetchone()
            if not row:
                row = conn.execute(
                    """
                    SELECT etkin_madde_id, tr_name, en_name 
                    FROM substances_bilingual 
                    WHERE tr_name LIKE ? OR en_name LIKE ? OR NORMALIZE(tr_name) LIKE ? OR NORMALIZE(en_name) LIKE ?
                    LIMIT 1
                    """,
                    (raw_wild, raw_wild, wild, wild)
                ).fetchone()

        if row:
            em_id, tr, en = row[0], row[1] or "", row[2] or ""
            clean_en = en.splitlines()[0].strip() if en else ""
            return {
                "found": True,
                "etkin_madde_id": em_id,
                "tr_name": tr,
                "en_name": clean_en,
                "en_full": en,
                "display_name": f"{tr} (EN: {clean_en})" if (tr and clean_en) else (tr or clean_en),
            }
        return {"found": False}
    finally:
        conn.close()


@router.get("/api/master/substances")
async def list_master_substances(
    q: str = Query("", description="Etken madde adı veya ID ara"),
    page: int = Query(1, ge=1, description="Sayfa no"),
    limit: int = Query(25, ge=1, le=100, description="Limit")
):
    """Etken maddeleri sayfalı listeler."""
    conn = _get_master_conn()
    try:
        where_clauses = []
        params = []
        q_clean = q.strip()
        if q_clean:
            tokens = [t for t in q_clean.split() if t]
            for token in tokens:
                t_norm = _normalize_text(token)
                where_clauses.append("(NORMALIZE(etkin_madde) LIKE ? OR etkin_madde LIKE ? OR CAST(etkin_madde_id AS TEXT) LIKE ?)")
                params.extend([f"%{t_norm}%", f"%{token}%", f"%{token}%"])
        where_sql = ("WHERE " + " AND ".join(where_clauses)) if where_clauses else ""

        count_sql = f"SELECT COUNT(*) FROM teb_active_ingredients {where_sql}"
        total = conn.execute(count_sql, params).fetchone()[0]

        offset = (page - 1) * limit
        data_sql = f"""
            SELECT etkin_madde_id, etkin_madde, dil
            FROM teb_active_ingredients
            {where_sql}
            ORDER BY etkin_madde ASC
            LIMIT ? OFFSET ?
        """
        rows = conn.execute(data_sql, params + [limit, offset]).fetchall()
        total_pages = (total + limit - 1) // limit if total > 0 else 1

        return {
            "items": [dict(r) for r in rows],
            "total": total,
            "page": page,
            "limit": limit,
            "total_pages": total_pages,
        }
    finally:
        conn.close()


@router.post("/api/master/substances")
async def create_master_substance(payload: SubstanceCreateSchema):
    """Kataloğa yeni bir etken madde ekler."""
    name = payload.etkin_madde.strip()
    dil = (payload.dil or "tr").strip().lower()
    if not name:
        raise HTTPException(status_code=400, detail="Etken madde adı zorunludur.")

    conn = _get_master_conn()
    try:
        max_id = conn.execute("SELECT COALESCE(MAX(etkin_madde_id), 0) FROM teb_active_ingredients").fetchone()[0]
        next_id = max_id + 1

        conn.execute(
            "INSERT INTO teb_active_ingredients (etkin_madde_id, etkin_madde, dil) VALUES (?, ?, ?)",
            (next_id, name, dil)
        )
        conn.commit()

        return {
            "success": True,
            "message": f"'{name}' etken maddesi başarıyla eklendi (ID: {next_id}).",
            "data": {"etkin_madde_id": next_id, "etkin_madde": name, "dil": dil}
        }
    finally:
        conn.close()


@router.put("/api/master/substances/{etkin_madde_id}")
async def update_master_substance(etkin_madde_id: int, payload: SubstanceUpdateSchema):
    """Etken madde adını ve dilini günceller."""
    name = payload.etkin_madde.strip()
    dil = (payload.dil or "tr").strip().lower()
    if not name:
        raise HTTPException(status_code=400, detail="Etken madde adı boş olamaz.")

    conn = _get_master_conn()
    try:
        exists = conn.execute("SELECT 1 FROM teb_active_ingredients WHERE etkin_madde_id = ?", (etkin_madde_id,)).fetchone()
        if not exists:
            raise HTTPException(status_code=404, detail="Etken madde bulunamadı.")

        conn.execute(
            "UPDATE teb_active_ingredients SET etkin_madde = ?, dil = ? WHERE etkin_madde_id = ?",
            (name, dil, etkin_madde_id)
        )
        conn.commit()

        return {
            "success": True,
            "message": "Etken madde güncellendi.",
            "data": {"etkin_madde_id": etkin_madde_id, "etkin_madde": name, "dil": dil}
        }
    finally:
        conn.close()


@router.delete("/api/master/substances/{etkin_madde_id}")
async def delete_master_substance(etkin_madde_id: int):
    """Etken maddeyi katalogdan siler."""
    conn = _get_master_conn()
    try:
        row = conn.execute("SELECT etkin_madde FROM teb_active_ingredients WHERE etkin_madde_id = ?", (etkin_madde_id,)).fetchone()
        if not row:
            raise HTTPException(status_code=404, detail="Etken madde bulunamadı.")
        name = row[0]

        conn.execute("DELETE FROM teb_active_ingredients WHERE etkin_madde_id = ?", (etkin_madde_id,))
        conn.commit()

        return {"success": True, "message": f"'{name}' (ID: {etkin_madde_id}) etken maddesi silindi."}
    finally:
        conn.close()


# ── 4. Genel İstatistikler ───────────────────────────────────────────────────

@router.get("/api/master/stats-summary")
async def get_master_stats():
    """Master kataloğunun temel istatistiklerini döndürür."""
    conn = _get_master_conn()
    try:
        p_count = conn.execute("SELECT COUNT(*) FROM products").fetchone()[0]
        g_count = conn.execute("SELECT COUNT(*) FROM generics").fetchone()[0]
        atc_count = conn.execute("SELECT COUNT(*) FROM atc_codes").fetchone()[0]
        sub_count = conn.execute("SELECT COUNT(*) FROM teb_active_ingredients").fetchone()[0]

        recete_types = conn.execute(
            "SELECT COALESCE(NULLIF(recete_turu, ''), 'BELİRTİLMEMİŞ'), COUNT(*) "
            "FROM products GROUP BY 1 ORDER BY 2 DESC"
        ).fetchall()

        return {
            "total_products": p_count,
            "total_generics": g_count,
            "total_atc_codes": atc_count,
            "total_substances": sub_count,
            "prescription_types": [{"type": r[0], "count": r[1]} for r in recete_types],
        }
    finally:
        conn.close()
