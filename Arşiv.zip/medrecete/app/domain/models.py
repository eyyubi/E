import re
from datetime import datetime
from typing import List, Optional

from pydantic import BaseModel, Field, field_validator

_DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")


class Product(BaseModel):
    barcode: str
    product_name: str
    atc_code: Optional[str] = None
    atc_etken: Optional[str] = None
    tr_etken: Optional[str] = None
    firma: Optional[str] = None
    recete_turu: Optional[str] = None
    status: Optional[str] = "AKTİF"
    ambalaj: Optional[str] = None
    urun_id: Optional[int] = None

class Generic(BaseModel):
    generic_code: str
    generic_name: str

class GenericProductMapping(BaseModel):
    generic_code: str
    product_barcode: str

class Substance(BaseModel):
    vapi_id: int
    name: str
    synonyms: Optional[str] = None

class GenericSubstanceMapping(BaseModel):
    generic_code: str
    vapi_id: int

class PrescriptionItem(BaseModel):
    product_name: str = Field(min_length=1, max_length=500)
    product_barcode: Optional[str] = Field(default=None, max_length=32)
    quantity: int = Field(ge=1, le=9999)
    notes: Optional[str] = Field(default=None, max_length=1000)

    @field_validator("product_name")
    @classmethod
    def _strip_name(cls, v: str) -> str:
        v = v.strip()
        if not v:
            raise ValueError("İlaç adı boş olamaz")
        return v

    @field_validator("product_barcode", "notes")
    @classmethod
    def _blank_to_none(cls, v: Optional[str]) -> Optional[str]:
        if v is None:
            return None
        v = v.strip()
        return v or None

class Prescription(BaseModel):
    id: Optional[int] = None
    patient_name: Optional[str] = Field(default=None, max_length=200)
    doctor_name: str = Field(min_length=1, max_length=200)
    prescription_date: str = Field(default_factory=lambda: datetime.now().strftime("%Y-%m-%d"))
    items: List[PrescriptionItem] = Field(min_length=1)

    @field_validator("doctor_name")
    @classmethod
    def _strip_doctor(cls, v: str) -> str:
        v = v.strip()
        if not v:
            raise ValueError("Doktor adı boş olamaz")
        return v

    @field_validator("patient_name")
    @classmethod
    def _blank_patient_to_none(cls, v: Optional[str]) -> Optional[str]:
        if v is None:
            return None
        v = v.strip()
        return v or None

    @field_validator("prescription_date")
    @classmethod
    def _valid_date(cls, v: str) -> str:
        v = v.strip()
        if not _DATE_RE.match(v):
            raise ValueError("Tarih YYYY-MM-DD biçiminde olmalıdır")
        try:
            datetime.strptime(v, "%Y-%m-%d")
        except ValueError:
            raise ValueError("Geçersiz tarih değeri")
        return v
