"""Rapor/arşiv dönemleri için tarih aralığı yardımcıları (YYYY-MM-DD, her iki uç dahil)."""
import calendar
from typing import Tuple


def month_bounds(year: str, month: str) -> Tuple[str, str]:
    last_day = calendar.monthrange(int(year), int(month))[1]
    return f"{year}-{month}-01", f"{year}-{month}-{last_day:02d}"


def year_bounds(year: str) -> Tuple[str, str]:
    return f"{year}-01-01", f"{year}-12-31"
