import sqlite3
from typing import Dict, Iterable, List, Optional, Tuple

from medrecete.app.domain.models import Prescription, PrescriptionItem, Product
from medrecete.app.domain.periods import month_bounds, year_bounds
from medrecete.app.infrastructure.database import db_session, normalize_text, rebuild_search_index

_CHUNK = 500


def _escape_like(value: str) -> str:
    return value.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")


# ── Katalog ──────────────────────────────────────────────────────────────────

_UPSERT_PRODUCT_SQL = """
    INSERT INTO products (
        barcode, product_name, atc_code, atc_etken, tr_etken, firma, recete_turu, status, ambalaj, urun_id
    ) VALUES (
        :barcode, :product_name, :atc_code, :atc_etken, :tr_etken, :firma, :recete_turu, :status, :ambalaj, :urun_id
    )
    ON CONFLICT(barcode) DO UPDATE SET
        product_name = excluded.product_name,
        atc_code     = COALESCE(NULLIF(excluded.atc_code, ''),  products.atc_code),
        atc_etken    = COALESCE(NULLIF(excluded.atc_etken, ''), products.atc_etken),
        tr_etken     = COALESCE(NULLIF(excluded.tr_etken, ''),  products.tr_etken),
        firma        = COALESCE(NULLIF(excluded.firma, ''),     products.firma),
        recete_turu  = COALESCE(NULLIF(excluded.recete_turu, ''), products.recete_turu),
        status       = COALESCE(excluded.status, products.status),
        ambalaj      = COALESCE(excluded.ambalaj, products.ambalaj),
        urun_id      = COALESCE(excluded.urun_id, products.urun_id)
"""


def _upsert_products(conn: sqlite3.Connection, data: List[Dict]) -> None:
    conn.executemany(_UPSERT_PRODUCT_SQL, data)


def _upsert_generics(conn: sqlite3.Connection, data: List[Dict]) -> None:
    conn.executemany(
        """
        INSERT INTO generics (generic_code, generic_name) VALUES (:generic_code, :generic_name)
        ON CONFLICT(generic_code) DO UPDATE SET generic_name = excluded.generic_name
        """,
        data,
    )


def _upsert_substances(conn: sqlite3.Connection, data: List[Dict]) -> None:
    conn.executemany(
        """
        INSERT INTO substances (vapi_id, name, synonyms) VALUES (:vapi_id, :name, :synonyms)
        ON CONFLICT(vapi_id) DO UPDATE SET name = excluded.name, synonyms = excluded.synonyms
        """,
        data,
    )


class ProductRepository:
    def search(self, query: str, limit: int = 50) -> List[Product]:
        """
        Ad, etken madde, firma ve barkod üzerinde (Türkçe karakterden bağımsız) arama yapar.
        İki dilli etken madde eşleştirme: Türkçe yazıldığında İngilizce karşılığı da taranır ve tam tersi geçerlidir.
        """
        q_clean = query.strip()
        if not q_clean:
            sql = """
                SELECT p.barcode, p.product_name, p.atc_code, p.atc_etken,
                       p.tr_etken, p.firma, p.recete_turu, p.status, p.ambalaj, p.urun_id
                FROM products p
                ORDER BY p.product_name
                LIMIT ?
            """
            with db_session() as conn:
                rows = conn.execute(sql, (limit,)).fetchall()
            return [Product(**dict(row)) for row in rows]

        normalized = normalize_text(q_clean)
        tokens = normalized.split()

        # İki dilli etken madde terim genişletme (Türkçe <-> İngilizce)
        token_clauses = []
        params: List = []

        with db_session() as conn:
            for token in tokens:
                token_escaped = _escape_like(token)
                sub_alts = []
                if len(token) >= 3:
                    try:
                        matches = conn.execute("""
                            SELECT tr_name, en_name 
                            FROM substances 
                            WHERE NORMALIZE(COALESCE(name, '')) LIKE ? OR NORMALIZE(COALESCE(synonyms, '')) LIKE ?
                            LIMIT 3
                        """, (f"%{token_escaped}%", f"%{token_escaped}%")).fetchall()
                        for m in matches:
                            tr_str = normalize_text(m["tr_name"]) if m["tr_name"] else ""
                            en_str = normalize_text(m["en_name"]) if m["en_name"] else ""
                            if tr_str and tr_str != token:
                                sub_alts.append(tr_str.split()[0])
                            if en_str and en_str != token:
                                sub_alts.append(en_str.split()[0])
                    except Exception:
                        pass

                clause_parts = ["p.search_text LIKE ? ESCAPE '\\'"]
                params.append(f"%{token_escaped}%")
                for alt in sub_alts:
                    clause_parts.append("p.search_text LIKE ? ESCAPE '\\'")
                    params.append(f"%{_escape_like(alt)}%")

                token_clauses.append("(" + " OR ".join(clause_parts) + ")")

        where = " AND ".join(token_clauses)
        params += [f"{_escape_like(normalized)}%", limit]

        sql = f"""
            SELECT p.barcode, p.product_name, p.atc_code, p.atc_etken,
                   p.tr_etken, p.firma, p.recete_turu, p.status, p.ambalaj, p.urun_id
            FROM products p
            WHERE {where}
            ORDER BY CASE WHEN p.search_text LIKE ? ESCAPE '\\' THEN 0 ELSE 1 END, p.product_name
            LIMIT ?
        """
        with db_session() as conn:
            rows = conn.execute(sql, params).fetchall()
        return [Product(**dict(row)) for row in rows]

    def upsert_bulk(self, data: List[Dict], refresh_index: bool = True) -> None:
        """Master DB tek kaynak olduğu için reçete db'ye ürün kopyalanmaz."""
        pass

    def add_basic_products(self, products: List[Tuple[str, str]]) -> None:
        pass

    def import_catalog(
        self,
        generics: List[Dict],
        products: List[Dict],
        mappings: List[Dict],
        substances: List[Dict],
        generic_substances: List[Dict],
        sync_info: Dict,
    ) -> None:
        pass

    def update_sync_status(self, sync_info: Dict) -> None:
        pass

    def get_sync_status(self) -> Dict:
        """Canlı master veritabanı durumunu ve mevcut toplam ilaç sayısını döner."""
        count = 0
        try:
            with db_session() as conn:
                row = conn.execute("SELECT COUNT(*) FROM products").fetchone()
                if row:
                    count = row[0]
        except Exception:
            pass
        return {
            "status": "connected",
            "last_sync": "Canlı Master (medication_db.sqlite)",
            "item_count": count
        }

    def clear_catalog(self) -> None:
        pass


# ── Reçeteler ────────────────────────────────────────────────────────────────

class PrescriptionRepository:
    @staticmethod
    def _item_rows(p: Prescription, prescription_id: int) -> List[Tuple]:
        return [
            (prescription_id, item.product_barcode, item.product_name, item.quantity, item.notes)
            for item in p.items
        ]

    _INSERT_ITEMS_SQL = (
        "INSERT INTO prescription_items (prescription_id, product_barcode, product_name, quantity, notes) "
        "VALUES (?, ?, ?, ?, ?)"
    )

    def create(self, p: Prescription) -> int:
        with db_session() as conn:
            cursor = conn.execute(
                "INSERT INTO prescriptions (patient_name, doctor_name, prescription_date) VALUES (?, ?, ?)",
                (p.patient_name, p.doctor_name, p.prescription_date),
            )
            prescription_id = cursor.lastrowid
            conn.executemany(self._INSERT_ITEMS_SQL, self._item_rows(p, prescription_id))
        return prescription_id

    def update(self, prescription_id: int, p: Prescription) -> bool:
        with db_session() as conn:
            cursor = conn.execute(
                "UPDATE prescriptions SET patient_name = ?, doctor_name = ?, prescription_date = ?, "
                "updated_at = strftime('%Y-%m-%dT%H:%M:%S', 'now', 'localtime') WHERE id = ?",
                (p.patient_name, p.doctor_name, p.prescription_date, prescription_id),
            )
            if cursor.rowcount == 0:
                return False
            conn.execute("DELETE FROM prescription_items WHERE prescription_id = ?", (prescription_id,))
            conn.executemany(self._INSERT_ITEMS_SQL, self._item_rows(p, prescription_id))
        return True

    def delete(self, prescription_id: int) -> bool:
        with db_session() as conn:
            # prescription_items kayıtları ON DELETE CASCADE ile silinir
            return conn.execute("DELETE FROM prescriptions WHERE id = ?", (prescription_id,)).rowcount > 0

    def clear_all(self) -> None:
        with db_session() as conn:
            conn.execute("DELETE FROM prescriptions")

    def list_doctors(self) -> List[str]:
        """Doktor adlarını kullanım sıklığına göre (en çok kullanılan önce) döndürür."""
        with db_session() as conn:
            rows = conn.execute(
                """
                SELECT doctor_name FROM prescriptions
                WHERE doctor_name <> ''
                GROUP BY doctor_name
                ORDER BY COUNT(*) DESC, MAX(prescription_date) DESC, doctor_name
                """
            ).fetchall()
        return [r["doctor_name"] for r in rows]

    # -- okuma --

    @staticmethod
    def _hydrate(conn: sqlite3.Connection, p_rows: Iterable[sqlite3.Row]) -> List[Prescription]:
        """Reçeteleri kalemleriyle birlikte yükler (reçete başına sorgu yerine toplu sorgu)."""
        p_rows = list(p_rows)
        items_by_id: Dict[int, List[PrescriptionItem]] = {row["id"]: [] for row in p_rows}
        ids = list(items_by_id)
        for i in range(0, len(ids), _CHUNK):
            chunk = ids[i:i + _CHUNK]
            placeholders = ",".join("?" * len(chunk))
            for r in conn.execute(
                f"SELECT prescription_id, product_barcode, product_name, quantity, notes "
                f"FROM prescription_items WHERE prescription_id IN ({placeholders}) ORDER BY id",
                chunk,
            ):
                items_by_id[r["prescription_id"]].append(
                    PrescriptionItem.model_construct(
                        product_name=r["product_name"], product_barcode=r["product_barcode"],
                        quantity=r["quantity"], notes=r["notes"],
                    )
                )
        return [
            Prescription.model_construct(
                id=row["id"], patient_name=row["patient_name"], doctor_name=row["doctor_name"],
                prescription_date=row["prescription_date"], items=items_by_id[row["id"]],
            )
            for row in p_rows
        ]

    def get_all(self, limit: int = 100) -> List[Prescription]:
        with db_session() as conn:
            rows = conn.execute(
                "SELECT id, patient_name, doctor_name, prescription_date FROM prescriptions "
                "ORDER BY prescription_date DESC, id DESC LIMIT ?",
                (limit,),
            ).fetchall()
            return self._hydrate(conn, rows)

    def get_by_range(self, start_date: str, end_date: str) -> List[Prescription]:
        with db_session() as conn:
            rows = conn.execute(
                "SELECT id, patient_name, doctor_name, prescription_date FROM prescriptions "
                "WHERE prescription_date BETWEEN ? AND ? ORDER BY prescription_date DESC, id DESC",
                (start_date, end_date),
            ).fetchall()
            return self._hydrate(conn, rows)

    def get_by_date(self, date: str) -> List[Prescription]:
        return self.get_by_range(date, date)

    def get_by_month(self, year: str, month: str) -> List[Prescription]:
        return self.get_by_range(*month_bounds(year, month))

    def get_by_year(self, year: str) -> List[Prescription]:
        return self.get_by_range(*year_bounds(year))


# ── Raporlar ─────────────────────────────────────────────────────────────────

# Reçete kalemini katalogdaki bir barkoda çözer: önce kayıtlı barkod, sonra (eski kayıtlar için)
# ürün adı / barkod eşleşmesi. Böylece aynı adı taşıyan ürünler miktarı çoğaltmaz.
_ITEMS_CTE = """
    WITH items AS (
        SELECT pi.id AS item_id, pi.quantity, pi.product_name,
               COALESCE(
                   NULLIF(pi.product_barcode, ''),
                   (SELECT MIN(barkod) FROM master_db.products WHERE urun_adi = pi.product_name),
                   (SELECT barkod FROM master_db.products WHERE barkod = pi.product_name)
               ) AS barcode
        FROM prescription_items pi
        JOIN prescriptions p ON p.id = pi.prescription_id
        WHERE p.prescription_date BETWEEN :start AND :end
    )
"""


class ReportRepository:
    def general(self, start: str, end: str) -> Tuple[int, List[Tuple[str, int]]]:
        with db_session() as conn:
            total = conn.execute(
                "SELECT COUNT(*) FROM prescriptions WHERE prescription_date BETWEEN ? AND ?", (start, end)
            ).fetchone()[0]
            rows = conn.execute(
                """
                SELECT pi.product_name, SUM(pi.quantity) AS qty
                FROM prescription_items pi
                JOIN prescriptions p ON p.id = pi.prescription_id
                WHERE p.prescription_date BETWEEN ? AND ?
                GROUP BY pi.product_name
                ORDER BY qty DESC, pi.product_name
                """,
                (start, end),
            ).fetchall()
        return total, [(r["product_name"], r["qty"]) for r in rows]

    def by_generic(self, start: str, end: str) -> List[sqlite3.Row]:
        """(jenerik, ürün) bazında toplam adet."""
        sql = _ITEMS_CTE + """
            SELECT 
                COALESCE(g.atc_kodu, 'J00') AS generic_code,
                COALESCE(NULLIF(g.jenerik_adi, ''), i.product_name) AS generic_name,
                i.product_name,
                SUM(i.quantity) AS qty
            FROM items i
            LEFT JOIN master_db.products p ON p.barkod = i.barcode
            LEFT JOIN master_db.generics g ON p.jenerik_kodu = g.jenerik_kodu
            GROUP BY generic_code, i.product_name
        """
        with db_session() as conn:
            return conn.execute(sql, {"start": start, "end": end}).fetchall()

    def by_substance(self, start: str, end: str) -> List[sqlite3.Row]:
        """(etken madde, ürün) bazında toplam adet."""
        sql = _ITEMS_CTE + """
            SELECT 
                COALESCE(p.urun_id, 1) AS vapi_id,
                COALESCE(NULLIF(p.etkin_maddeler, ''), NULLIF(g.jenerik_adi, ''), i.product_name) AS substance_name,
                i.product_name,
                SUM(i.quantity) AS qty
            FROM items i
            LEFT JOIN master_db.products p ON p.barkod = i.barcode
            LEFT JOIN master_db.generics g ON p.jenerik_kodu = g.jenerik_kodu
            GROUP BY substance_name, i.product_name
        """
        with db_session() as conn:
            return conn.execute(sql, {"start": start, "end": end}).fetchall()

    def top_products_since(self, since_date: str, limit: int = 10) -> List[Tuple[str, int]]:
        with db_session() as conn:
            rows = conn.execute(
                """
                SELECT pi.product_name, SUM(pi.quantity) AS qty
                FROM prescription_items pi
                JOIN prescriptions p ON p.id = pi.prescription_id
                WHERE p.prescription_date >= ?
                GROUP BY pi.product_name
                ORDER BY qty DESC, pi.product_name
                LIMIT ?
                """,
                (since_date, limit),
            ).fetchall()
        return [(r["product_name"], r["qty"]) for r in rows]
