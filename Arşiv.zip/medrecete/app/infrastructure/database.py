import hashlib
import hmac
import logging
import os
import secrets
import sqlite3
import unicodedata
from contextlib import contextmanager
from typing import Iterator, Optional

logger = logging.getLogger(__name__)

# Proje kökü: çalışma dizininden bağımsız olması için mutlak yol kullanılır.
BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
_CENTRAL_RECETE_DB = os.path.abspath(os.path.join(BASE_DIR, "..", "data", "recete.db"))
_CENTRAL_DATA_DB = os.path.abspath(os.path.join(BASE_DIR, "..", "data", "data.db"))
DB_NAME = os.getenv("MEDRECETE_DB", _CENTRAL_RECETE_DB if os.path.exists(os.path.dirname(_CENTRAL_RECETE_DB)) else os.path.join(BASE_DIR, "recete.db"))

SCHEMA_VERSION = 2
_PBKDF2_ITERATIONS = 200_000

_TR_TRANS = str.maketrans("İIÜÖŞĞÇ", "IIUOSGC")


# ── Metin normalizasyonu ─────────────────────────────────────────────────────

def normalize_text(s) -> str:
    """Türkçe karakterleri ve aksanları sadeleştirip BÜYÜK harfe çevirir."""
    if s is None:
        return ""
    s = str(s).strip().upper().translate(_TR_TRANS)
    # Kalan aksanlı harfleri (Â, Î, Û ...) ASCII karşılığına indir
    s = unicodedata.normalize("NFKD", s)
    return "".join(ch for ch in s if not unicodedata.combining(ch))


# ── Bağlantı yönetimi ────────────────────────────────────────────────────────

def _configure(conn: sqlite3.Connection) -> sqlite3.Connection:
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute("PRAGMA busy_timeout = 30000")
    conn.execute("PRAGMA synchronous = NORMAL")
    conn.execute("PRAGMA temp_store = MEMORY")
    conn.create_function("NORMALIZE", 1, normalize_text, deterministic=True)

    # Master DB'yi salt okunur olarak bağla ve canlı ürün görünümlerini hazırla
    master_db_path = os.getenv(
        "MASTER_DB_PATH",
        os.path.abspath(os.path.join(BASE_DIR, "..", "data", "medication_db.sqlite"))
    )
    if os.path.exists(master_db_path):
        try:
            conn.execute("ATTACH DATABASE ? AS master_db", (master_db_path,))
            conn.executescript("""
            CREATE TEMP VIEW IF NOT EXISTS products AS 
            SELECT 
                p.barkod AS barcode,
                p.urun_adi AS product_name,
                g.atc_kodu AS atc_code,
                g.jenerik_adi AS atc_etken,
                COALESCE(p.etkin_maddeler, g.jenerik_adi, '') AS tr_etken,
                p.firma_adi AS firma,
                p.recete_turu,
                'AKTİF' AS status,
                p.ambalaj,
                p.urun_id,
                NORMALIZE(COALESCE(p.urun_adi, '') || ' ' || COALESCE(p.etkin_maddeler, '') || ' ' || COALESCE(g.jenerik_adi, '') || ' ' || COALESCE(p.firma_adi, '') || ' ' || COALESCE(p.barkod, '')) AS search_text
            FROM master_db.products p
            LEFT JOIN master_db.generics g ON p.jenerik_kodu = g.jenerik_kodu;

            CREATE TEMP VIEW IF NOT EXISTS generics AS
            SELECT 
                jenerik_kodu AS generic_code,
                jenerik_adi AS generic_name
            FROM master_db.generics;

            CREATE TEMP VIEW IF NOT EXISTS substances AS
            SELECT 
                etkin_madde_id AS vapi_id,
                COALESCE(tr_name, en_name) AS name,
                en_name AS synonyms,
                tr_name,
                en_name
            FROM master_db.substances_bilingual;

            CREATE TEMP VIEW IF NOT EXISTS generic_product_mapping AS
            SELECT 
                jenerik_kodu AS generic_code,
                barkod AS product_barcode
            FROM master_db.products
            WHERE jenerik_kodu IS NOT NULL AND jenerik_kodu != '';
            """)
        except Exception:
            pass
    return conn


def get_db_path() -> str:
    return os.getenv("MEDRECETE_DB", DB_NAME)


def get_db() -> sqlite3.Connection:
    """Yeni bir bağlantı döndürür. Çağıran kapatmaktan sorumludur; tercihen db_session() kullanın."""
    return _configure(sqlite3.connect(get_db_path(), timeout=30))


@contextmanager
def db_session() -> Iterator[sqlite3.Connection]:
    """Başarıda commit, hatada rollback yapan ve bağlantıyı her koşulda kapatan bağlam yöneticisi."""
    conn = get_db()
    try:
        yield conn
        conn.commit()
    except BaseException:
        conn.rollback()
        raise
    finally:
        conn.close()


# ── Admin şifresi ────────────────────────────────────────────────────────────

def _hash_password(password: str, salt: Optional[bytes] = None, iterations: int = _PBKDF2_ITERATIONS) -> str:
    salt = salt or secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, iterations)
    return f"pbkdf2_sha256${iterations}${salt.hex()}${digest.hex()}"


def _verify_hash(password: str, stored: str) -> bool:
    try:
        _, iterations, salt_hex, digest_hex = stored.split("$")
        expected = hashlib.pbkdf2_hmac(
            "sha256", password.encode("utf-8"), bytes.fromhex(salt_hex), int(iterations)
        )
        return hmac.compare_digest(expected.hex(), digest_hex)
    except (ValueError, TypeError):
        return False


def _get_stored_password() -> Optional[str]:
    with db_session() as conn:
        row = conn.execute("SELECT value FROM app_settings WHERE key = 'admin_password'").fetchone()
    return row["value"] if row and row["value"] else None


def verify_admin_password(password: str) -> bool:
    """Gönderilen şifreyi doğrular. Eski (düz metin) kayıtları ilk başarılı girişte hash'e yükseltir."""
    if not password:
        return False
    stored = _get_stored_password()
    if stored is None:
        return hmac.compare_digest(password, os.getenv("CATALOG_ADMIN_PASSWORD", "admin"))
    if stored.startswith("pbkdf2_sha256$"):
        return _verify_hash(password, stored)
    # Eski düz metin kayıt
    if hmac.compare_digest(password, stored):
        set_admin_password(password)
        return True
    return False


def set_admin_password(new_password: str) -> None:
    with db_session() as conn:
        conn.execute(
            "INSERT INTO app_settings (key, value) VALUES ('admin_password', ?) "
            "ON CONFLICT(key) DO UPDATE SET value = excluded.value",
            (_hash_password(new_password),),
        )


# ── Şema ─────────────────────────────────────────────────────────────────────

_BASE_SCHEMA = [
    """
    CREATE TABLE IF NOT EXISTS prescriptions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        patient_name TEXT,
        doctor_name TEXT NOT NULL,
        prescription_date TEXT NOT NULL,
        created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%S', 'now', 'localtime')),
        updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%S', 'now', 'localtime'))
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS prescription_items (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        prescription_id INTEGER NOT NULL,
        product_barcode TEXT,
        product_name TEXT NOT NULL,
        quantity INTEGER NOT NULL CHECK (quantity > 0),
        notes TEXT,
        FOREIGN KEY (prescription_id) REFERENCES prescriptions (id) ON DELETE CASCADE
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS app_settings (
        key TEXT PRIMARY KEY,
        value TEXT
    )
    """,
]

_INDEXES = [
    "CREATE INDEX IF NOT EXISTS idx_prescriptions_date ON prescriptions (prescription_date)",
    "CREATE INDEX IF NOT EXISTS idx_prescriptions_doctor ON prescriptions (doctor_name)",
    "CREATE INDEX IF NOT EXISTS idx_prescription_items_prescription_id ON prescription_items (prescription_id)",
    "CREATE INDEX IF NOT EXISTS idx_prescription_items_product_name ON prescription_items (product_name)",
    "CREATE INDEX IF NOT EXISTS idx_prescription_items_product_barcode ON prescription_items (product_barcode)",
]

_REDUNDANT_INDEXES = [
    "idx_generic_product_mapping_generic_code",
    "idx_generic_substance_mapping_generic_code",
]


def _table_exists(conn: sqlite3.Connection, table: str) -> bool:
    return conn.execute(
        "SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = ?", (table,)
    ).fetchone() is not None


def _columns(conn: sqlite3.Connection, table: str) -> set:
    try:
        return {row["name"] for row in conn.execute(f"PRAGMA table_info({table})")}
    except Exception:
        return set()


def rebuild_search_index(conn: sqlite3.Connection) -> int:
    """Canlı master görünümünden ürün sayısını doğrular."""
    try:
        row = conn.execute("SELECT COUNT(*) FROM products").fetchone()
        return row[0] if row else 0
    except Exception:
        return 0


def _migrate_prescriptions_v2(conn: sqlite3.Connection) -> None:
    """Eski reçete tablolarını yeni şemaya (FK CASCADE, barkod, CHECK, zaman damgası) taşır."""
    if not _table_exists(conn, "prescription_items") or not _table_exists(conn, "prescriptions"):
        return

    if "product_barcode" in _columns(conn, "prescription_items") and "created_at" in _columns(conn, "prescriptions"):
        return  # zaten güncel

    legacy_items_cols = _columns(conn, "prescription_items")
    logger.info("Reçete tabloları yeni şemaya taşınıyor...")
    conn.execute("PRAGMA foreign_keys = OFF")
    try:
        conn.execute("BEGIN")
        conn.execute("DROP TABLE IF EXISTS prescriptions_new")
        conn.execute("DROP TABLE IF EXISTS prescription_items_new")
        conn.execute(
            """
            CREATE TABLE prescriptions_new (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                patient_name TEXT,
                doctor_name TEXT NOT NULL,
                prescription_date TEXT NOT NULL,
                created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%S', 'now', 'localtime')),
                updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%S', 'now', 'localtime'))
            )
            """
        )
        conn.execute(
            """
            INSERT INTO prescriptions_new (id, patient_name, doctor_name, prescription_date)
            SELECT id, NULLIF(TRIM(patient_name), ''), COALESCE(TRIM(doctor_name), ''), COALESCE(prescription_date, '')
            FROM prescriptions
            """
        )
        conn.execute(
            """
            CREATE TABLE prescription_items_new (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                prescription_id INTEGER NOT NULL,
                product_barcode TEXT,
                product_name TEXT NOT NULL,
                quantity INTEGER NOT NULL CHECK (quantity > 0),
                notes TEXT,
                FOREIGN KEY (prescription_id) REFERENCES prescriptions (id) ON DELETE CASCADE
            )
            """
        )
        barcode_expr = (
            "i.product_barcode"
            if "product_barcode" in legacy_items_cols
            else """CASE WHEN (SELECT COUNT(*) FROM products WHERE product_name = i.product_name) = 1
                         THEN (SELECT barcode FROM products WHERE product_name = i.product_name) END"""
        )
        conn.execute(
            f"""
            INSERT INTO prescription_items_new (id, prescription_id, product_barcode, product_name, quantity, notes)
            SELECT i.id, i.prescription_id, {barcode_expr}, COALESCE(i.product_name, ''),
                   MAX(COALESCE(i.quantity, 1), 1), i.notes
            FROM prescription_items i
            WHERE i.prescription_id IN (SELECT id FROM prescriptions)
            """
        )
        conn.execute("DROP TABLE prescription_items")
        conn.execute("DROP TABLE prescriptions")
        conn.execute("ALTER TABLE prescriptions_new RENAME TO prescriptions")
        conn.execute("ALTER TABLE prescription_items_new RENAME TO prescription_items")
        violations = conn.execute("PRAGMA foreign_key_check").fetchall()
        if violations:
            raise sqlite3.IntegrityError(f"Migrasyon sonrası FK ihlali: {len(violations)} kayıt")
        conn.execute("COMMIT")
    except BaseException:
        conn.execute("ROLLBACK")
        raise
    finally:
        conn.execute("PRAGMA foreign_keys = ON")


def init_db() -> None:
    path = get_db_path()
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    conn = _configure(sqlite3.connect(path, timeout=30, isolation_level=None))
    try:
        conn.execute("PRAGMA journal_mode = WAL")

        # Reçete veritabanında eski fiziksel katalog tabloları varsa temizle
        # (İlaç bilgileri artık master_db üzerinden canlı olarak okunur)
        for tbl in ["generic_product_mapping", "generic_substance_mapping", "substances", "generics", "products", "sync_status"]:
            if _table_exists(conn, tbl):
                conn.execute(f"DROP TABLE IF EXISTS {tbl}")

        for statement in _BASE_SCHEMA:
            conn.execute(statement)

        if conn.execute("PRAGMA user_version").fetchone()[0] < SCHEMA_VERSION:
            _migrate_prescriptions_v2(conn)
            conn.execute(f"PRAGMA user_version = {SCHEMA_VERSION}")

        for name in _REDUNDANT_INDEXES:
            conn.execute(f"DROP INDEX IF EXISTS {name}")
        for statement in _INDEXES:
            conn.execute(statement)
        conn.execute("PRAGMA optimize")
    finally:
        conn.close()
