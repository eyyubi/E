import io
import os
import re as _re
import sqlite3
import tempfile
import time
import zipfile
import logging
import pandas as pd
from datetime import datetime
from typing import Dict, List, Optional, Set
from fastapi import APIRouter, BackgroundTasks, Depends, File, Header, HTTPException, Query, Request, UploadFile, WebSocket
from fastapi.concurrency import run_in_threadpool
from fastapi.responses import FileResponse, Response, StreamingResponse
from pydantic import BaseModel, Field

from medrecete.app.api.excel_export import build_excel_workbook
from medrecete.app.domain.models import Prescription
from medrecete.app.infrastructure.database import BASE_DIR, DB_NAME, set_admin_password, verify_admin_password
from medrecete.app.infrastructure.repositories import PrescriptionRepository, ProductRepository, ReportRepository
from medrecete.app.services.prescription_service import PrescriptionService
import json
from medrecete.app.services.backup_service import BackupService
from medrecete.app.services.catalog_service import CatalogService, normalize_barcode

router = APIRouter()
logger = logging.getLogger(__name__)

# --- Repositories and Services ---
p_repo = PrescriptionRepository()
prod_repo = ProductRepository()
report_repo = ReportRepository()
p_service = PrescriptionService(p_repo, prod_repo, report_repo)
cat_service = CatalogService(prod_repo)

# --- Regex Validations ---
_DATE_RE = _re.compile(r'^\d{4}-\d{2}-\d{2}$')
_YEAR_RE = _re.compile(r'^\d{4}$')
_MONTH_RE = _re.compile(r'^(0[1-9]|1[0-2])$')

_XLSX_MEDIA_TYPE = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
_MAX_UPLOAD_BYTES = 20 * 1024 * 1024

# --- WEBSOCKETS ---
class ConnectionManager:
    def __init__(self):
        self.active_connections: Set[WebSocket] = set()

    async def connect(self, websocket: WebSocket):
        await websocket.accept()
        self.active_connections.add(websocket)

    def disconnect(self, websocket: WebSocket):
        self.active_connections.discard(websocket)

    async def broadcast_refresh(self, message: str = "refresh"):
        dead = set()
        for connection in list(self.active_connections):
            try:
                await connection.send_text(message)
            except Exception:
                dead.add(connection)
        self.active_connections -= dead

manager = ConnectionManager()

async def _notify(message: str = "refresh"):
    """Bildirim hatası, tamamlanmış bir işlemin başarısız görünmesine yol açmamalı."""
    try:
        await manager.broadcast_refresh(message)
    except Exception as e:
        logger.warning(f"WebSocket bildirimi gönderilemedi: {e}")

# --- HELPERS & VALIDATIONS ---
def _validate_year(year: str):
    if not _YEAR_RE.match(year):
        raise HTTPException(status_code=400, detail="Geçersiz yıl formatı (YYYY bekleniyor)")

def _validate_month(month: str):
    if not _MONTH_RE.match(month):
        raise HTTPException(status_code=400, detail="Geçersiz ay formatı (MM bekleniyor)")

def _validate_year_month(year: str, month: str) -> str:
    _validate_year(year)
    month = month.zfill(2)
    _validate_month(month)
    return month

def _parse_date(value: str):
    try:
        return datetime.strptime(value, "%Y-%m-%d").date()
    except ValueError:
        raise HTTPException(status_code=400, detail="Geçersiz tarih değeri")

def _validate_range(start: str, end: str):
    if not (_DATE_RE.match(start) and _DATE_RE.match(end)):
        raise HTTPException(status_code=400, detail="Geçersiz tarih formatı (YYYY-MM-DD bekleniyor)")
    if _parse_date(start) > _parse_date(end):
        raise HTTPException(status_code=400, detail="Başlangıç tarihi bitiş tarihinden büyük olamaz")

def _validate_date(value: str):
    if not _DATE_RE.match(value):
        raise HTTPException(status_code=400, detail="Geçersiz tarih formatı (YYYY-MM-DD bekleniyor)")
    _parse_date(value)

# Basit kaba kuvvet koruması: IP başına 5 dakikada en fazla 10 hatalı şifre denemesi
_FAIL_WINDOW_SECONDS = 300
_FAIL_LIMIT = 10
_failed_attempts: Dict[str, List[float]] = {}

def _client_key(request: Request) -> str:
    return request.client.host if request.client else "unknown"

def _check_admin(request: Request, password: str) -> bool:
    """Şifreyi doğrular; çok fazla hatalı denemede 429 döner."""
    key = _client_key(request)
    now = time.monotonic()
    attempts = [t for t in _failed_attempts.get(key, []) if now - t < _FAIL_WINDOW_SECONDS]
    if len(attempts) >= _FAIL_LIMIT:
        _failed_attempts[key] = attempts
        raise HTTPException(status_code=429, detail="Çok fazla hatalı deneme. Lütfen birkaç dakika sonra tekrar deneyin.")
    if verify_admin_password(password):
        _failed_attempts.pop(key, None)
        return True
    attempts.append(now)
    _failed_attempts[key] = attempts
    return False

def _require_admin_password(request: Request, x_admin_password: str = Header(default="")):
    if not _check_admin(request, x_admin_password):
        raise HTTPException(status_code=403, detail="Bu işlem için yönetici şifresi gerekli")

def _excel_response(buf: io.BytesIO, filename: str) -> Response:
    return Response(
        content=buf.getvalue(),
        media_type=_XLSX_MEDIA_TYPE,
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )

# --- PRESCRIPTION ENDPOINTS ---
@router.post("/prescriptions")
async def create_prescription(p: Prescription):
    try:
        p_id = await run_in_threadpool(p_service.create_prescription, p)
    except sqlite3.Error as e:
        logger.error(f"Failed to create prescription: {e}")
        raise HTTPException(status_code=500, detail="Reçete kaydedilemedi")
    await _notify()
    return {"status": "success", "id": p_id}

@router.get("/prescriptions")
def get_prescriptions(
    limit: int = Query(50, ge=1, le=500),
    year: Optional[str] = None,
    month: Optional[str] = None,
    date: Optional[str] = None,
    start: Optional[str] = None,
    end: Optional[str] = None,
):
    if date:
        _validate_date(date)
        return p_repo.get_by_date(date)
    if start or end:
        if not (start and end):
            raise HTTPException(status_code=400, detail="Başlangıç ve bitiş tarihleri birlikte verilmelidir")
        _validate_range(start, end)
        return p_repo.get_by_range(start, end)
    if year and month:
        month = _validate_year_month(year, month)
        return p_repo.get_by_month(year, month)
    if year:
        _validate_year(year)
        return p_repo.get_by_year(year)
    return p_service.get_recent_prescriptions(limit)

@router.put("/prescriptions/{prescription_id}")
async def update_prescription(prescription_id: int, p: Prescription):
    updated = await run_in_threadpool(p_repo.update, prescription_id, p)
    if not updated:
        raise HTTPException(status_code=404, detail="Reçete bulunamadı")
    await _notify()
    return {"status": "success"}

@router.delete("/prescriptions/{prescription_id}")
async def delete_prescription(prescription_id: int):
    deleted = await run_in_threadpool(p_repo.delete, prescription_id)
    if not deleted:
        raise HTTPException(status_code=404, detail="Reçete bulunamadı")
    await _notify()
    return {"status": "success"}

@router.get("/doctors")
def get_doctors():
    """Daha önce kullanılmış doktor isimlerini (en sık kullanılan önce) döndür."""
    return p_repo.list_doctors()

# --- REPORT VIEW ENDPOINTS ---
@router.get("/report/yearly/{year}")
def get_yearly_report(year: str):
    _validate_year(year)
    return p_service.get_yearly_report(year)

@router.get("/report/generic-yearly/{year}")
def get_generic_yearly_report(year: str):
    _validate_year(year)
    return p_service.get_generic_yearly_report(year)

@router.get("/report/substance-yearly/{year}")
def get_substance_yearly_report(year: str):
    _validate_year(year)
    return p_service.get_substance_yearly_report(year)

@router.get("/report/range")
def get_range_report(start: str, end: str):
    _validate_range(start, end)
    return p_service.get_range_report(start, end)

@router.get("/report/generic-range")
def get_generic_range_report(start: str, end: str):
    _validate_range(start, end)
    return p_service.get_generic_range_report(start, end)

@router.get("/report/substance-range")
def get_substance_range_report(start: str, end: str):
    _validate_range(start, end)
    return p_service.get_substance_range_report(start, end)

@router.get("/predictions")
def get_predictions():
    return p_service.get_predictions()

# --- EXCEL EXPORT ENDPOINTS ---
@router.get("/report/export/yearly/{year}")
def export_yearly_report_excel(year: str):
    """Yıllık raporu Excel olarak dışa aktarır."""
    _validate_year(year)
    buf = build_excel_workbook(
        p_service.get_yearly_report(year),
        p_service.get_generic_yearly_report(year),
        p_service.get_substance_yearly_report(year),
        year,
    )
    return _excel_response(buf, f"rapor_{year}.xlsx")

@router.get("/report/export/range")
def export_range_report_excel(start: str, end: str):
    """Tarih aralığı raporunu Excel olarak dışa aktarır."""
    _validate_range(start, end)
    buf = build_excel_workbook(
        p_service.get_range_report(start, end),
        p_service.get_generic_range_report(start, end),
        p_service.get_substance_range_report(start, end),
        f"{start} / {end}",
    )
    return _excel_response(buf, f"rapor_{start}_{end}.xlsx")

@router.get("/report/export/{year}/{month}")
def export_report_excel(year: str, month: str):
    """Aylık raporu üç sayfalı Excel dosyası olarak dışa aktarır."""
    month = _validate_year_month(year, month)
    buf = build_excel_workbook(
        p_service.get_monthly_report(year, month),
        p_service.get_generic_report(year, month),
        p_service.get_substance_report(year, month),
        f"{year}-{month}",
    )
    return _excel_response(buf, f"rapor_{year}_{month}.xlsx")

@router.get("/report/{year}/{month}")
def get_report(year: str, month: str):
    month = _validate_year_month(year, month)
    return p_service.get_monthly_report(year, month)

@router.get("/report/generic/{year}/{month}")
def get_generic_report(year: str, month: str):
    month = _validate_year_month(year, month)
    return p_service.get_generic_report(year, month)

@router.get("/report/substance/{year}/{month}")
def get_substance_report(year: str, month: str):
    month = _validate_year_month(year, month)
    return p_service.get_substance_report(year, month)

# --- ADMIN PASSWORD MANAGEMENT ---
class ChangePasswordBody(BaseModel):
    new_password: str = Field(default="", max_length=200)

@router.put("/admin/password")
def change_admin_password(request: Request, body: ChangePasswordBody, x_admin_password: str = Header(default="")):
    """Mevcut şifre doğrulanınca yeni şifre kaydeder."""
    if not _check_admin(request, x_admin_password):
        raise HTTPException(status_code=403, detail="Mevcut şifre yanlış")
    new_password = body.new_password.strip()
    if len(new_password) < 4:
        raise HTTPException(status_code=400, detail="Yeni şifre en az 4 karakter olmalıdır")
    set_admin_password(new_password)
    return {"status": "success", "message": "Şifre güncellendi"}

# --- PRODUCT & CATALOG ENDPOINTS ---
@router.get("/products/search")
def search_products(q: str = Query("", max_length=200), limit: int = Query(50, ge=1, le=200)):
    return prod_repo.search(q, limit)

@router.get("/catalog/status")
def get_catalog_status():
    return prod_repo.get_sync_status()

def _parse_catalog_excel(content: bytes):
    """Excel'den (barkod, ürün adı) çiftlerini okur; başlık/boş/geçersiz satırları atlar."""
    df = pd.read_excel(io.BytesIO(content), header=None, dtype=str)
    products = {}
    for row in df.itertuples(index=False):
        if len(row) < 2 or pd.isna(row[0]) or pd.isna(row[1]):
            continue
        barcode = normalize_barcode(row[0])
        name = str(row[1]).strip()
        if barcode and name:
            products[barcode] = name
    return list(products.items())

@router.post("/upload-excel")
async def upload_excel(file: UploadFile = File(...), _: None = Depends(_require_admin_password)):
    content = await file.read()
    if len(content) > _MAX_UPLOAD_BYTES:
        raise HTTPException(status_code=413, detail="Dosya çok büyük (en fazla 20 MB)")
    try:
        products = await run_in_threadpool(_parse_catalog_excel, content)
    except Exception as e:
        logger.error(f"Excel parse failed: {e}")
        raise HTTPException(status_code=400, detail="Excel dosyası okunamadı")
    if not products:
        raise HTTPException(status_code=400, detail="Dosyada geçerli (barkod, ürün adı) satırı bulunamadı")
    await run_in_threadpool(prod_repo.add_basic_products, products)
    await _notify()
    return {"status": "success", "count": len(products)}

# --- DATABASE MANAGEMENT ---
@router.delete("/db/prescriptions")
async def clear_prescriptions(_: None = Depends(_require_admin_password)):
    """Tüm reçeteleri ve kalemlerini siler."""
    await run_in_threadpool(p_repo.clear_all)
    await _notify()
    return {"status": "success", "message": "Tüm reçeteler silindi"}

@router.delete("/db/catalog")
async def clear_catalog(_: None = Depends(_require_admin_password)):
    """Ürün kataloğunu, jenerikleri ve eşleştirmeleri siler."""
    await run_in_threadpool(prod_repo.clear_catalog)
    await _notify("catalog_synced")
    return {"status": "success", "message": "Katalog temizlendi"}

@router.delete("/db/all")
async def reset_database(_: None = Depends(_require_admin_password)):
    """Tüm veriyi sıfırlar (reçeteler + katalog)."""
    await run_in_threadpool(p_repo.clear_all)
    await run_in_threadpool(prod_repo.clear_catalog)
    await _notify()
    return {"status": "success", "message": "Veritabanı sıfırlandı"}

def _create_backup_file() -> str:
    """SQLite online backup API ile tutarlı bir veritabanı kopyası oluşturur (WAL ile de güvenlidir)."""
    fd, path = tempfile.mkstemp(suffix=".db", prefix="medrecete_backup_")
    os.close(fd)
    src = sqlite3.connect(DB_NAME)
    dst = sqlite3.connect(path)
    try:
        src.backup(dst)
    finally:
        dst.close()
        src.close()
    return path

@router.get("/admin/backup")
async def download_backup(background_tasks: BackgroundTasks, _: None = Depends(_require_admin_password)):
    """Veritabanının tutarlı bir yedeğini indirir (SQLite dosya formatı)."""
    path = await run_in_threadpool(_create_backup_file)
    background_tasks.add_task(os.remove, path)
    filename = f"medrecete_yedek_{datetime.now().strftime('%Y%m%d_%H%M%S')}.db"
    return FileResponse(path, media_type="application/octet-stream", filename=filename)

@router.get("/admin/backup/json")
def download_json_backup(_: None = Depends(_require_admin_password)):
    """Reçeteler ve ayarları içeren JSON yedeği indirir."""
    data = BackupService.export_json()
    content = json.dumps(data, ensure_ascii=False, indent=2).encode("utf-8")
    filename = f"medrecete_yedek_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
    return Response(
        content=content,
        media_type="application/json; charset=utf-8",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'}
    )

@router.post("/admin/restore/json")
async def restore_json_backup(
    file: UploadFile = File(...),
    mode: str = Query("replace", pattern="^(replace|merge)$"),
    _: None = Depends(_require_admin_password)
):
    """JSON yedeğini sisteme yükler (mode: replace | merge)."""
    content = await file.read()
    if len(content) > _MAX_UPLOAD_BYTES:
        raise HTTPException(status_code=413, detail="Dosya çok büyük (en fazla 20 MB)")
    try:
        data = json.loads(content.decode("utf-8"))
    except Exception as e:
        raise HTTPException(status_code=400, detail="Geçersiz JSON formatı")

    try:
        result = await run_in_threadpool(BackupService.restore_json, data, mode)
    except Exception as e:
        logger.error(f"Restore JSON failed: {e}")
        raise HTTPException(status_code=400, detail=str(e))

    await _notify()
    return result

@router.post("/admin/migrate-legacy-db")
async def migrate_legacy_db(
    file: UploadFile = File(...),
    mode: str = Query("merge", pattern="^(replace|merge)$"),
    _: None = Depends(_require_admin_password)
):
    """Eski sürümden kalma bir data.db dosyasını yeni sürüme aktarır (mode: merge | replace)."""
    content = await file.read()
    if len(content) > 50 * 1024 * 1024:
        raise HTTPException(status_code=413, detail="Dosya çok büyük (en fazla 50 MB)")

    fd, temp_path = tempfile.mkstemp(suffix=".db", prefix="legacy_migrate_")
    os.close(fd)
    with open(temp_path, "wb") as f:
        f.write(content)

    try:
        result = await run_in_threadpool(BackupService.migrate_legacy_db, temp_path, mode)
    except Exception as e:
        logger.error(f"Legacy DB migration failed: {e}")
        raise HTTPException(status_code=400, detail=str(e))
    finally:
        if os.path.exists(temp_path):
            os.remove(temp_path)

    await _notify()
    return result

# --- PROJECT DOWNLOAD ---
@router.get("/download/project")
def download_project(_: None = Depends(_require_admin_password)):
    """Proje kaynak kodunu zip olarak indir (veritabanı ve sanal ortam dahil değildir)."""
    exclude_dirs = {".git", ".local", ".agents", "__pycache__", ".upm", ".config", ".venv", "venv", "node_modules"}
    exclude_ext = {".pyc", ".db", ".db-wal", ".db-shm", ".sqlite", ".bak"}
    fixed_time = (2024, 1, 1, 0, 0, 0)

    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        for root, dirs, files in os.walk(BASE_DIR):
            dirs[:] = [d for d in dirs if d not in exclude_dirs]
            for file in files:
                if any(file.endswith(e) for e in exclude_ext) or ".bak" in file:
                    continue
                abs_path = os.path.join(root, file)
                arcname = os.path.relpath(abs_path, BASE_DIR)
                info = zipfile.ZipInfo(arcname, date_time=fixed_time)
                info.compress_type = zipfile.ZIP_DEFLATED
                with open(abs_path, "rb") as f:
                    zf.writestr(info, f.read())
    buf.seek(0)
    return StreamingResponse(
        buf,
        media_type="application/zip",
        headers={"Content-Disposition": "attachment; filename=MedRecete.zip"},
    )
