import io
import re
import zipfile
from typing import List

_XML_INVALID_CHARS = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f]")


def build_excel_workbook(general: dict, generic: dict, substance: dict, period_label: str):
    from xml.sax.saxutils import escape

    def safe_text(value, fallback=""):
        if value is None:
            return fallback
        return str(value)

    def safe_number(value):
        return value if isinstance(value, (int, float)) else 0

    def column_name(index: int) -> str:
        name = ""
        while index:
            index, remainder = divmod(index - 1, 26)
            name = chr(65 + remainder) + name
        return name

    def cell_xml(row_idx: int, col_idx: int, value) -> str:
        ref = f"{column_name(col_idx)}{row_idx}"
        if value is None or value == "":
            return f'<c r="{ref}"/>'
        if isinstance(value, (int, float)):
            return f'<c r="{ref}"><v>{value}</v></c>'
        text = escape(_XML_INVALID_CHARS.sub("", str(value)), {'"': '&quot;', "'": '&apos;'})
        return f'<c r="{ref}" t="inlineStr"><is><t>{text}</t></is></c>'

    def worksheet_xml(rows: List[List], widths: List[int]) -> str:
        cols = "".join(
            f'<col min="{idx}" max="{idx}" width="{width}" customWidth="1"/>'
            for idx, width in enumerate(widths, start=1)
        )
        sheet_rows = []
        for row_idx, row in enumerate(rows, start=1):
            cells = "".join(cell_xml(row_idx, col_idx, value) for col_idx, value in enumerate(row, start=1))
            sheet_rows.append(f'<row r="{row_idx}">{cells}</row>')
        return (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" '
            'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
            f'<cols>{cols}</cols><sheetData>{"".join(sheet_rows)}</sheetData></worksheet>'
        )

    general_rows = [
        [f"Genel Rapor - {period_label}", ""],
        [],
        ["İlaç Adı", "Toplam Adet"],
    ]
    for name, qty in (general or {}).get("drug_summary", {}).items():
        general_rows.append([safe_text(name, "Bilinmeyen Ürün"), safe_number(qty)])
    general_rows.extend([[], ["Toplam Reçete", safe_number((general or {}).get("total_prescriptions", 0))]])

    generic_rows = [
        [f"Jenerik Bazlı Rapor - {period_label}", "", "", ""],
        [],
        ["Jenerik Kod", "Jenerik Adı", "Toplam Adet", "Kapsanan Ürünler"],
    ]
    for item in (generic or {}).get("data", []):
        products = [safe_text(p) for p in item.get("associated_products", []) if p]
        generic_rows.append([
            safe_text(item.get("generic_code"), "-"),
            safe_text(item.get("generic_name"), "Bilinmeyen Jenerik"),
            safe_number(item.get("total_quantity")),
            ", ".join(products)
        ])

    substance_rows = [
        [f"Etken Madde Raporu - {period_label}", "", ""],
        [],
        ["Etken Madde", "Toplam Adet", "Kapsanan Ürünler"],
    ]
    for item in (substance or {}).get("data", []):
        products = [safe_text(p) for p in item.get("associated_products", []) if p]
        substance_rows.append([
            safe_text(item.get("substance_name"), "Bilinmeyen Etken Madde"),
            safe_number(item.get("total_quantity")),
            ", ".join(products)
        ])

    buf = io.BytesIO()
    sheets = [
        ("Genel Özet", general_rows, [50, 16]),
        ("Jenerik Kod", generic_rows, [14, 45, 16, 60]),
        ("Etken Madde", substance_rows, [45, 16, 60]),
    ]
    workbook_sheets = "".join(
        f'<sheet name="{escape(name)}" sheetId="{idx}" r:id="rId{idx}"/>'
        for idx, (name, _, _) in enumerate(sheets, start=1)
    )
    workbook_rels = "".join(
        f'<Relationship Id="rId{idx}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet{idx}.xml"/>'
        for idx in range(1, len(sheets) + 1)
    )
    overrides = "".join(
        f'<Override PartName="/xl/worksheets/sheet{idx}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'
        for idx in range(1, len(sheets) + 1)
    )

    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.writestr("[Content_Types].xml", (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
            '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
            '<Default Extension="xml" ContentType="application/xml"/>'
            '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
            f'{overrides}</Types>'
        ))
        zf.writestr("_rels/.rels", (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>'
            '</Relationships>'
        ))
        zf.writestr("xl/workbook.xml", (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" '
            'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
            f'<sheets>{workbook_sheets}</sheets></workbook>'
        ))
        zf.writestr("xl/_rels/workbook.xml.rels", (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            f'{workbook_rels}</Relationships>'
        ))
        for idx, (_, rows, widths) in enumerate(sheets, start=1):
            zf.writestr(f"xl/worksheets/sheet{idx}.xml", worksheet_xml(rows, widths))
    buf.seek(0)
    return buf
