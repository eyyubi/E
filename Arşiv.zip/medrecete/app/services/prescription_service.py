from collections import defaultdict
from datetime import datetime, timedelta
from typing import Dict, List

from medrecete.app.domain.models import Prescription
from medrecete.app.domain.periods import month_bounds, year_bounds
from medrecete.app.infrastructure.repositories import PrescriptionRepository, ProductRepository, ReportRepository


class PrescriptionService:
    def __init__(
        self,
        prescription_repo: PrescriptionRepository,
        product_repo: ProductRepository,
        report_repo: ReportRepository,
    ):
        self.prescription_repo = prescription_repo
        self.product_repo = product_repo
        self.report_repo = report_repo

    def create_prescription(self, p: Prescription) -> int:
        return self.prescription_repo.create(p)

    def get_recent_prescriptions(self, limit: int = 20) -> List[Prescription]:
        return self.prescription_repo.get_all(limit)

    # ── Rapor üreticileri (tarih aralığı bazlı) ──────────────────────────────

    def _general(self, start: str, end: str, period_label: str) -> Dict:
        total, rows = self.report_repo.general(start, end)
        return {
            "period": period_label,
            "total_prescriptions": total,
            "drug_summary": {name: qty for name, qty in rows},
        }

    @staticmethod
    def _aggregate(rows, key_fields: tuple, name_field: str) -> List[Dict]:
        """(grup, ürün) satırlarını grup bazında toplar; adet sırasına göre döndürür."""
        groups: Dict = {}
        products = defaultdict(set)
        for r in rows:
            key = r[key_fields[0]]
            if key not in groups:
                groups[key] = {field: r[field] for field in key_fields}
                groups[key]["total_quantity"] = 0
            groups[key]["total_quantity"] += r["qty"]
            if r["product_name"]:
                products[key].add(r["product_name"])
        result = []
        for key, group in groups.items():
            group["associated_products"] = sorted(products[key])
            result.append(group)
        result.sort(key=lambda g: (-g["total_quantity"], str(g.get(name_field) or "")))
        return result

    def _generic(self, start: str, end: str, period_label: str) -> Dict:
        rows = self.report_repo.by_generic(start, end)
        return {
            "period": period_label,
            "report_type": "generic",
            "data": self._aggregate(rows, ("generic_code", "generic_name"), "generic_name"),
        }

    def _substance(self, start: str, end: str, period_label: str) -> Dict:
        rows = self.report_repo.by_substance(start, end)
        return {
            "period": period_label,
            "report_type": "substance",
            "data": self._aggregate(rows, ("vapi_id", "substance_name"), "substance_name"),
        }

    # ── Aylık ────────────────────────────────────────────────────────────────

    def get_monthly_report(self, year: str, month: str) -> Dict:
        return self._general(*month_bounds(year, month), f"{year}-{month}")

    def get_generic_report(self, year: str, month: str) -> Dict:
        return self._generic(*month_bounds(year, month), f"{year}-{month}")

    def get_substance_report(self, year: str, month: str) -> Dict:
        return self._substance(*month_bounds(year, month), f"{year}-{month}")

    # ── Yıllık ───────────────────────────────────────────────────────────────

    def get_yearly_report(self, year: str) -> Dict:
        return self._general(*year_bounds(year), year)

    def get_generic_yearly_report(self, year: str) -> Dict:
        return self._generic(*year_bounds(year), year)

    def get_substance_yearly_report(self, year: str) -> Dict:
        return self._substance(*year_bounds(year), year)

    # ── Tarih aralığı ────────────────────────────────────────────────────────

    def get_range_report(self, start: str, end: str) -> Dict:
        return self._general(start, end, f"{start} / {end}")

    def get_generic_range_report(self, start: str, end: str) -> Dict:
        return self._generic(start, end, f"{start} / {end}")

    def get_substance_range_report(self, start: str, end: str) -> Dict:
        return self._substance(start, end, f"{start} / {end}")

    def get_predictions(self) -> List[Dict]:
        """
        Basit tahmin: Son 30 günde en çok reçete edilen 10 ilacı listeler.
        Toplam adet 10'dan büyükse 'Yüksek Talep', değilse 'Normal Talep' olarak işaretler.
        """
        since = (datetime.now() - timedelta(days=30)).strftime("%Y-%m-%d")
        return [
            {
                "product_name": name,
                "estimated_monthly": qty,
                "status": "Yüksek Talep" if qty > 10 else "Normal Talep",
            }
            for name, qty in self.report_repo.top_products_since(since, 10)
        ]
