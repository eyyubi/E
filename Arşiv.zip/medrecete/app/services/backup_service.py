import json
import logging
import os
import sqlite3
import tempfile
from datetime import datetime
from typing import Dict, Any, List, Optional
from medrecete.app.infrastructure.database import db_session, BASE_DIR
from medrecete.app.domain.models import Prescription, PrescriptionItem

logger = logging.getLogger(__name__)

class BackupService:
    @staticmethod
    def export_json() -> Dict[str, Any]:
        """Tüm reçeteleri, kalemlerini ve sistem ayarlarını içeren JSON yedeği üretir."""
        with db_session() as conn:
            # 1. Prescriptions & Items
            p_rows = conn.execute(
                "SELECT id, patient_name, doctor_name, prescription_date FROM prescriptions ORDER BY id ASC"
            ).fetchall()

            # Kalemleri çek
            i_rows = conn.execute(
                "SELECT prescription_id, product_barcode, product_name, quantity, notes FROM prescription_items ORDER BY id ASC"
            ).fetchall()

            items_by_p: Dict[int, List[Dict[str, Any]]] = {}
            for row in i_rows:
                pid = row["prescription_id"]
                if pid not in items_by_p:
                    items_by_p[pid] = []
                items_by_p[pid].append({
                    "product_name": row["product_name"],
                    "product_barcode": row["product_barcode"],
                    "quantity": row["quantity"],
                    "notes": row["notes"] or ""
                })

            prescriptions_data = []
            for p in p_rows:
                prescriptions_data.append({
                    "patient_name": p["patient_name"],
                    "doctor_name": p["doctor_name"],
                    "prescription_date": p["prescription_date"],
                    "items": items_by_p.get(p["id"], [])
                })

            # 2. App Settings
            s_rows = conn.execute("SELECT key, value FROM app_settings").fetchall()
            settings_data = [{"key": r["key"], "value": r["value"]} for r in s_rows]

        return {
            "format": "medrecete_backup",
            "version": 1,
            "exported_at": datetime.now().isoformat(),
            "app_settings": settings_data,
            "prescriptions": prescriptions_data
        }

    @staticmethod
    def restore_json(data: Dict[str, Any], mode: str = "replace") -> Dict[str, Any]:
        """JSON yedeğini veritabanına geri yükler. mode='replace' veya 'merge'."""
        if not isinstance(data, dict) or "prescriptions" not in data:
            raise ValueError("Geçersiz yedek dosyası formatı: 'prescriptions' listesi bulunamadı.")

        prescriptions = data.get("prescriptions", [])
        settings = data.get("app_settings", [])

        restored_prescriptions = 0
        restored_items = 0
        skipped = 0

        with db_session() as conn:
            if mode == "replace":
                conn.execute("DELETE FROM prescriptions")  # CASCADE ile prescription_items da silinir

            # Ayarları yükle
            for s in settings:
                if s.get("key") and s.get("value"):
                    conn.execute(
                        "INSERT INTO app_settings (key, value) VALUES (?, ?) "
                        "ON CONFLICT(key) DO UPDATE SET value = excluded.value",
                        (s["key"], s["value"])
                    )

            # Mevcut kayıtlar (merge modunda mükerrer eklememek için kontrol listesi)
            existing_signatures = set()
            if mode == "merge":
                rows = conn.execute("SELECT patient_name, doctor_name, prescription_date FROM prescriptions").fetchall()
                for r in rows:
                    sig = (r["patient_name"] or "", r["doctor_name"] or "", r["prescription_date"] or "")
                    existing_signatures.add(sig)

            for p_dict in prescriptions:
                p_name = (p_dict.get("patient_name") or "").strip() or None
                d_name = (p_dict.get("doctor_name") or "").strip()
                p_date = (p_dict.get("prescription_date") or "").strip()
                raw_items = p_dict.get("items", [])

                if not d_name or not p_date or not raw_items:
                    continue

                sig = (p_name or "", d_name, p_date)
                if mode == "merge" and sig in existing_signatures:
                    skipped += 1
                    continue

                cur = conn.execute(
                    "INSERT INTO prescriptions (patient_name, doctor_name, prescription_date) VALUES (?, ?, ?)",
                    (p_name, d_name, p_date)
                )
                pid = cur.lastrowid
                restored_prescriptions += 1
                if mode == "merge":
                    existing_signatures.add(sig)

                item_tuples = []
                for item in raw_items:
                    prod_name = (item.get("product_name") or "").strip()
                    if not prod_name:
                        continue
                    prod_barcode = (item.get("product_barcode") or "").strip() or None
                    qty = max(1, int(item.get("quantity") or 1))
                    notes = item.get("notes") or None
                    item_tuples.append((pid, prod_barcode, prod_name, qty, notes))

                if item_tuples:
                    conn.executemany(
                        "INSERT INTO prescription_items (prescription_id, product_barcode, product_name, quantity, notes) "
                        "VALUES (?, ?, ?, ?, ?)",
                        item_tuples
                    )
                    restored_items += len(item_tuples)

        return {
            "status": "success",
            "mode": mode,
            "prescriptions_restored": restored_prescriptions,
            "items_restored": restored_items,
            "skipped": skipped
        }

    @staticmethod
    def migrate_legacy_db(legacy_db_path: str, mode: str = "merge") -> Dict[str, Any]:
        """
        Eski sürümden kalma bir data.db dosyasından reçeteleri okur ve yeni sisteme taşır.
        """
        if not os.path.exists(legacy_db_path):
            raise FileNotFoundError("Yüklenen veritabanı dosyası bulunamadı.")

        legacy_conn = sqlite3.connect(legacy_db_path)
        legacy_conn.row_factory = sqlite3.Row
        try:
            # Eski tabloları kontrol et
            tables = {r[0] for r in legacy_conn.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()}
            if "prescriptions" not in tables or "prescription_items" not in tables:
                raise ValueError("Seçilen dosya geçerli bir MedReçete veritabanı değil (prescriptions veya prescription_items tablosu yok).")

            legacy_cols = {r["name"] for r in legacy_conn.execute("PRAGMA table_info(prescription_items)").fetchall()}
            has_barcode = "product_barcode" in legacy_cols

            p_rows = legacy_conn.execute("SELECT id, patient_name, doctor_name, prescription_date FROM prescriptions").fetchall()

            imported_p = 0
            imported_items = 0
            skipped = 0

            with db_session() as target_conn:
                if mode == "replace":
                    target_conn.execute("DELETE FROM prescriptions")

                existing_signatures = set()
                if mode == "merge":
                    rows = target_conn.execute("SELECT patient_name, doctor_name, prescription_date FROM prescriptions").fetchall()
                    for r in rows:
                        sig = (r["patient_name"] or "", r["doctor_name"] or "", r["prescription_date"] or "")
                        existing_signatures.add(sig)

                for p in p_rows:
                    p_name = (p["patient_name"] or "").strip() or None
                    d_name = (p["doctor_name"] or "").strip()
                    p_date = (p["prescription_date"] or "").strip()

                    if not d_name or not p_date:
                        continue

                    sig = (p_name or "", d_name, p_date)
                    if mode == "merge" and sig in existing_signatures:
                        skipped += 1
                        continue

                    cur = target_conn.execute(
                        "INSERT INTO prescriptions (patient_name, doctor_name, prescription_date) VALUES (?, ?, ?)",
                        (p_name, d_name, p_date)
                    )
                    new_pid = cur.lastrowid
                    imported_p += 1
                    if mode == "merge":
                        existing_signatures.add(sig)

                    # Eski kalemleri oku
                    items = legacy_conn.execute(
                        "SELECT * FROM prescription_items WHERE prescription_id = ?",
                        (p["id"],)
                    ).fetchall()

                    item_tuples = []
                    for it in items:
                        prod_name = (it["product_name"] or "").strip()
                        if not prod_name:
                            continue
                        qty = max(1, int(it["quantity"]) if it["quantity"] else 1)
                        notes = it["notes"] if "notes" in it.keys() else None
                        barcode = None
                        if has_barcode and it["product_barcode"]:
                            barcode = str(it["product_barcode"]).strip()
                        else:
                            # Katalogdan barkodu bulmayı dene
                            b_row = target_conn.execute(
                                "SELECT barcode FROM products WHERE product_name = ? LIMIT 1",
                                (prod_name,)
                            ).fetchone()
                            if b_row:
                                barcode = b_row["barcode"]

                        item_tuples.append((new_pid, barcode, prod_name, qty, notes))

                    if item_tuples:
                        target_conn.executemany(
                            "INSERT INTO prescription_items (prescription_id, product_barcode, product_name, quantity, notes) "
                            "VALUES (?, ?, ?, ?, ?)",
                            item_tuples
                        )
                        imported_items += len(item_tuples)

            return {
                "status": "success",
                "mode": mode,
                "prescriptions_imported": imported_p,
                "items_imported": imported_items,
                "skipped": skipped
            }
        finally:
            legacy_conn.close()
