import logging
import os
import sqlite3
from typing import Dict, Optional
import pandas as pd
from medrecete.app.infrastructure.repositories import ProductRepository
from core.config import MASTER_DB_PATH

logger = logging.getLogger(__name__)


def _clean(value) -> str:
    """NaN/None değerlerini boş string yapıp metni sadeleştirir."""
    if value is None or pd.isna(value):
        return ""
    return str(value).strip()


def normalize_barcode(b) -> Optional[str]:
    """Barkodu standart 14 haneye normalize eder; geçersizse None döner."""
    if b is None:
        return None
    b = str(b).strip().split('.')[0]
    if b.isdigit():
        return b.zfill(14)
    return None


class CatalogService:
    """
    Medreçete İlaç Katalog Servisi.
    İlaç bilgileri doğrudan ortak master veritabanından (medication_db.sqlite) okunur.
    TİTCK ve eski master aktarımı kaldırılmıştır; master veritabanı tek gerçeklik kaynağıdır.
    """
    def __init__(self, product_repo: ProductRepository):
        self.product_repo = product_repo
        self.master_db_path = str(MASTER_DB_PATH)

    def get_status(self) -> Dict:
        """Ortak master veritabanı canlı bağlantı ve ilaç sayısı durumunu döner."""
        return self.product_repo.get_sync_status()
