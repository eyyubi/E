"""Uçtan uca testler. Çalıştırmak için: .venv/bin/python -m unittest discover -s tests -v

Gerçek katalog verisi içeren eski şemalı bir veritabanı kopyası üzerinde çalışır (migrasyonu da sınar).
"""
import os
import shutil
import sqlite3
import sys
import tempfile
import unittest

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, ROOT)

_TMP = tempfile.mkdtemp(prefix="medrecete_test_")
_DB = os.path.join(_TMP, "test.db")
_MASTER = os.path.abspath(os.path.join(ROOT, "..", "data", "medication_db.sqlite"))
os.environ["MASTER_DB_PATH"] = _MASTER
os.environ["MEDRECETE_DB"] = _DB

from medrecete.app.infrastructure import database as dbmod


def _make_legacy(path):
    """DB'yi eski (v1) şemaya geri döndürüp birkaç eski kayıt ekler."""
    conn = dbmod._configure(sqlite3.connect(path))
    conn.executescript(
        """
        DROP TABLE IF EXISTS prescription_items;
        DROP TABLE IF EXISTS prescriptions;
        CREATE TABLE prescriptions (id INTEGER PRIMARY KEY AUTOINCREMENT, patient_name TEXT, doctor_name TEXT, prescription_date TEXT);
        CREATE TABLE prescription_items (id INTEGER PRIMARY KEY AUTOINCREMENT, prescription_id INTEGER, product_name TEXT, quantity INTEGER, notes TEXT,
            FOREIGN KEY (prescription_id) REFERENCES prescriptions (id));
        """
    )
    # Katalogdan bir ürün adı al
    row = conn.execute("SELECT product_name FROM products WHERE product_name LIKE '%,%' LIMIT 1").fetchone()
    name = row[0] if row else "POLIFLEKS %5 DEKSTROZ"
    conn.execute("PRAGMA foreign_keys = OFF")
    conn.execute("INSERT INTO prescriptions (patient_name, doctor_name, prescription_date) VALUES ('  ', 'Dr. Eski', '2025-03-10')")
    conn.execute("INSERT INTO prescription_items (prescription_id, product_name, quantity) VALUES (1, ?, 3)", (name,))
    conn.execute("INSERT INTO prescription_items (prescription_id, product_name, quantity) VALUES (999, 'YETIM', 1)")  # yetim kalem
    conn.execute("PRAGMA user_version = 0")
    conn.commit()
    conn.close()
    return name


LEGACY_PRODUCT = _make_legacy(_DB)

from fastapi.testclient import TestClient  # noqa: E402
from medrecete.main import app  # noqa: E402
_ORIG_DB_NAME = dbmod.DB_NAME
dbmod.DB_NAME = _DB


class ApiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.ctx = TestClient(app)
        cls.client = cls.ctx.__enter__()  # lifespan -> init_db

    @classmethod
    def tearDownClass(cls):
        cls.ctx.__exit__(None, None, None)
        os.environ.pop("MEDRECETE_DB", None)
        dbmod.DB_NAME = _ORIG_DB_NAME
        shutil.rmtree(_TMP, ignore_errors=True)

    # -- migrasyon --
    def test_00_migration(self):
        conn = dbmod.get_db()
        try:
            self.assertEqual(conn.execute("PRAGMA user_version").fetchone()[0], dbmod.SCHEMA_VERSION)
            self.assertEqual(conn.execute("PRAGMA journal_mode").fetchone()[0], "wal")
            self.assertEqual(conn.execute("PRAGMA foreign_keys").fetchone()[0], 1)
            self.assertEqual(conn.execute("PRAGMA foreign_key_check").fetchall(), [])
            self.assertEqual(conn.execute("PRAGMA integrity_check").fetchone()[0], "ok")
            # eski reçete taşındı, yetim kalem atıldı, boş hasta adı NULL oldu
            p = conn.execute("SELECT * FROM prescriptions").fetchall()
            self.assertEqual(len(p), 1)
            self.assertIsNone(p[0]["patient_name"])
            items = conn.execute("SELECT * FROM prescription_items").fetchall()
            self.assertEqual(len(items), 1)
            self.assertEqual(items[0]["product_name"], LEGACY_PRODUCT)
            self.assertEqual(conn.execute("SELECT COUNT(*) FROM products WHERE search_text = ''").fetchone()[0], 0)
        finally:
            conn.close()

    def test_01_init_is_idempotent(self):
        dbmod.init_db()
        dbmod.init_db()

    # -- arama --
    def test_search_turkish_and_tokens(self):
        r = self.client.get("/api/products/search", params={"q": "polifleks dekstroz"})
        self.assertEqual(r.status_code, 200)
        self.assertTrue(len(r.json()) > 0)
        for p in r.json():
            self.assertIn("POLIFLEKS", p["product_name"].upper())
        self.assertLessEqual(len(self.client.get("/api/products/search", params={"q": "", "limit": 5}).json()), 5)

    def test_search_special_chars_do_not_break(self):
        for q in ["%", "_", "'", "\\", "a%b", "\"; DROP TABLE products;--"]:
            self.assertEqual(self.client.get("/api/products/search", params={"q": q}).status_code, 200)

    def test_search_barcode_without_leading_zero(self):
        barcode = self.client.get("/api/products/search", params={"q": "", "limit": 1}).json()[0]["barcode"]
        found = self.client.get("/api/products/search", params={"q": barcode.lstrip("0")}).json()
        self.assertIn(barcode, [p["barcode"] for p in found])

    # -- reçete CRUD + validasyon --
    def _payload(self, **kw):
        base = {"patient_name": " Ali ", "doctor_name": " Dr. Test ", "prescription_date": "2025-04-15",
                "items": [{"product_name": LEGACY_PRODUCT, "quantity": 2, "notes": ""}]}
        base.update(kw)
        return base

    def test_prescription_validation(self):
        bad = [
            self._payload(items=[]),
            self._payload(doctor_name="   "),
            self._payload(prescription_date="2025-02-30"),
            self._payload(prescription_date="15.04.2025"),
            self._payload(items=[{"product_name": "A", "quantity": 0}]),
            self._payload(items=[{"product_name": "A", "quantity": -1}]),
            self._payload(items=[{"product_name": "  ", "quantity": 1}]),
        ]
        for payload in bad:
            self.assertEqual(self.client.post("/api/prescriptions", json=payload).status_code, 422, payload)

    def test_prescription_crud_and_reports(self):
        r = self.client.post("/api/prescriptions", json=self._payload())
        self.assertEqual(r.status_code, 200)
        pid = r.json()["id"]

        listed = self.client.get("/api/prescriptions", params={"start": "2025-04-01", "end": "2025-04-30"}).json()
        mine = [p for p in listed if p["id"] == pid][0]
        self.assertEqual(mine["patient_name"], "Ali")
        self.assertEqual(mine["doctor_name"], "Dr. Test")
        self.assertEqual(mine["items"][0]["quantity"], 2)

        # aylık rapor ve ürün adındaki virgül bozulmuyor mu?
        rep = self.client.get("/api/report/2025/04").json()
        self.assertEqual(rep["drug_summary"][LEGACY_PRODUCT], 2)
        self.assertEqual(rep["total_prescriptions"], 1)

        # güncelle
        upd = self._payload(items=[{"product_name": LEGACY_PRODUCT, "quantity": 5}])
        self.assertEqual(self.client.put(f"/api/prescriptions/{pid}", json=upd).status_code, 200)
        self.assertEqual(self.client.get("/api/report/2025/04").json()["drug_summary"][LEGACY_PRODUCT], 5)
        self.assertEqual(self.client.put("/api/prescriptions/987654", json=upd).status_code, 404)

        # eski (migrate edilmiş) kayıt raporda görünüyor
        legacy = self.client.get("/api/report/yearly/2025").json()
        self.assertEqual(legacy["drug_summary"][LEGACY_PRODUCT], 5 + 3)

        # doktorlar
        self.assertIn("Dr. Test", self.client.get("/api/doctors").json())

        # sil (kalemler cascade ile silinmeli)
        self.assertEqual(self.client.delete(f"/api/prescriptions/{pid}").status_code, 200)
        self.assertEqual(self.client.delete(f"/api/prescriptions/{pid}").status_code, 404)
        conn = dbmod.get_db()
        try:
            self.assertEqual(conn.execute("SELECT COUNT(*) FROM prescription_items WHERE prescription_id = ?", (pid,)).fetchone()[0], 0)
        finally:
            conn.close()

    def test_generic_and_substance_reports_do_not_double_count(self):
        # Aynı adı taşıyan birden fazla barkodlu bir ürün seç
        conn = dbmod.get_db()
        try:
            row = conn.execute(
                "SELECT p.urun_adi AS product_name, COUNT(*) c FROM master_db.products p "
                "WHERE p.jenerik_kodu IS NOT NULL AND p.jenerik_kodu != '' "
                "GROUP BY p.urun_adi HAVING c > 1 LIMIT 1"
            ).fetchone()
        finally:
            conn.close()
        self.assertIsNotNone(row)
        name = row["product_name"]
        pid = self.client.post("/api/prescriptions", json=self._payload(
            prescription_date="2025-06-01", items=[{"product_name": name, "quantity": 4}])).json()["id"]
        gen = self.client.get("/api/report/generic/2025/06").json()
        for g in gen["data"]:
            if name in g["associated_products"]:
                self.assertEqual(g["total_quantity"], 4, g)
        sub = self.client.get("/api/report/substance/2025/06").json()
        for s in sub["data"]:
            if name in s["associated_products"]:
                self.assertEqual(s["total_quantity"], 4, s)
        self.assertEqual(self.client.delete(f"/api/prescriptions/{pid}").status_code, 200)

    def test_report_validation_and_ranges(self):
        self.assertEqual(self.client.get("/api/report/2025/13").status_code, 400)
        self.assertEqual(self.client.get("/api/report/range", params={"start": "2025-02-01", "end": "2025-01-01"}).status_code, 400)
        self.assertEqual(self.client.get("/api/report/yearly/20x5").status_code, 400)
        # Şubat 2024 (artık yıl) sınırı
        for d in ("2024-02-29", "2024-03-01"):
            self.client.post("/api/prescriptions", json=self._payload(prescription_date=d))
        self.assertEqual(self.client.get("/api/report/2024/02").json()["total_prescriptions"], 1)
        self.assertEqual(self.client.get("/api/report/2024/03").json()["total_prescriptions"], 1)
        self.assertEqual(self.client.get("/api/prescriptions", params={"limit": 0}).status_code, 422)

    def test_excel_export(self):
        for url in ("/api/report/export/2025/04", "/api/report/export/yearly/2025",
                    "/api/report/export/range?start=2025-01-01&end=2025-12-31"):
            r = self.client.get(url)
            self.assertEqual(r.status_code, 200, url)
            self.assertTrue(r.content.startswith(b"PK"))

    def test_predictions(self):
        self.assertEqual(self.client.get("/api/predictions").status_code, 200)

    # -- admin --
    def test_admin_protection_and_password_hash(self):
        self.assertEqual(self.client.delete("/api/db/prescriptions").status_code, 403)
        self.assertEqual(self.client.get("/api/download/project").status_code, 403)
        self.assertEqual(self.client.get("/api/admin/backup").status_code, 403)

        h = {"X-Admin-Password": "admin"}
        self.assertEqual(self.client.put("/api/admin/password", json={"new_password": "abc"}, headers=h).status_code, 400)
        self.assertEqual(self.client.put("/api/admin/password", json={"new_password": "yeni1234"}, headers=h).status_code, 200)
        stored = dbmod._get_stored_password()
        self.assertTrue(stored.startswith("pbkdf2_sha256$"))
        self.assertNotIn("yeni1234", stored)
        self.assertEqual(self.client.get("/api/admin/backup", headers=h).status_code, 403)
        h2 = {"X-Admin-Password": "yeni1234"}

        # yedek geçerli bir SQLite dosyası mı?
        r = self.client.get("/api/admin/backup", headers=h2)
        self.assertEqual(r.status_code, 200)
        self.assertTrue(r.content.startswith(b"SQLite format 3"))

        # proje indirmesi veritabanı içermemeli
        import io, zipfile
        z = zipfile.ZipFile(io.BytesIO(self.client.get("/api/download/project", headers=h2).content))
        names = z.namelist()
        self.assertFalse(any(n.endswith((".db", ".sqlite")) or ".bak" in n for n in names), names)
        self.assertFalse(any(n.startswith(".venv") for n in names))

        self.assertEqual(self.client.put("/api/admin/password", json={"new_password": "admin"}, headers=h2).status_code, 200)

    def test_legacy_plaintext_password_is_upgraded(self):
        conn = dbmod.get_db()
        conn.execute("INSERT OR REPLACE INTO app_settings (key, value) VALUES ('admin_password', 'duzmetin')")
        conn.commit(); conn.close()
        self.assertTrue(dbmod.verify_admin_password("duzmetin"))
        self.assertTrue(dbmod._get_stored_password().startswith("pbkdf2_sha256$"))
        self.assertTrue(dbmod.verify_admin_password("duzmetin"))
        self.assertFalse(dbmod.verify_admin_password("yanlis"))
        dbmod.set_admin_password("admin")

    def test_zz_99_live_master_catalog(self):
        # 1. Canlı master katalog durumu kontrolü
        status = self.client.get("/api/catalog/status").json()
        self.assertEqual(status["status"], "connected")
        self.assertGreater(status["item_count"], 17000)

        # 2. Ürün araması canlı master veritabanından döner
        res = self.client.get("/api/products/search", params={"q": "DEKSTROZ", "limit": 5})
        self.assertEqual(res.status_code, 200)
        items = res.json()
        self.assertGreater(len(items), 0)

        # 3. İki dilli etken madde araması (İngilizce yazıldığında Türkçe master ilacını bulur)
        res_bilingual = self.client.get("/api/products/search", params={"q": "Glucose", "limit": 5})
        self.assertEqual(res_bilingual.status_code, 200)
        self.assertGreater(len(res_bilingual.json()), 0)

        # 4. Reçete ekleme ve silme işlemleri reçete DB'sinde izoledir
        h = {"X-Admin-Password": "admin"}
        self.client.post("/api/prescriptions", json=self._payload(prescription_date="2025-09-09"))
        self.assertGreater(self.client.get("/api/report/2025/09").json()["total_prescriptions"], 0)
        self.assertEqual(self.client.delete("/api/db/all", headers=h).status_code, 200)
        self.assertEqual(self.client.get("/api/prescriptions").json(), [])

    def test_websocket_refresh(self):
        with self.client.websocket_connect("/api/ws") as ws:
            pid = self.client.post("/api/prescriptions", json=self._payload(prescription_date="2025-05-05")).json()["id"]
            self.assertEqual(ws.receive_text(), "refresh")
            self.client.delete(f"/api/prescriptions/{pid}")
            self.assertEqual(ws.receive_text(), "refresh")

    def test_root_serves_index(self):
        r = self.client.get("/")
        self.assertEqual(r.status_code, 200)
        self.assertIn("MedRecete", r.text)

    def test_offline_vendor_assets_available(self):
        """Çevrimdışı yerel CSS ve font dosyalarının sunulduğunu doğrular."""
        assets = [
            "/static/vendor/tailwind.min.css",
            "/static/vendor/fontawesome/css/all.min.css",
            "/static/vendor/fonts/plus-jakarta-sans.css",
            "/static/vendor/fontawesome/webfonts/fa-solid-900.woff2",
        ]
        for path in assets:
            res = self.client.get(path)
            self.assertEqual(res.status_code, 200, f"Varlık bulunamadı: {path}")

    def test_zz_01_json_backup_and_restore(self):
        """JSON yedeği alma, geri yükleme ve mükerrer kayıt kontrolü."""
        h = {"X-Admin-Password": "admin"}
        # 1. Reçete oluştur
        p = self._payload(doctor_name="Dr. JSON Test", prescription_date="2025-10-10")
        pid = self.client.post("/api/prescriptions", json=p).json()["id"]

        # 2. JSON yedeği indir
        res = self.client.get("/api/admin/backup/json", headers=h)
        self.assertEqual(res.status_code, 200)
        backup_data = res.json()
        self.assertEqual(backup_data["format"], "medrecete_backup")
        self.assertIn("prescriptions", backup_data)
        self.assertTrue(any(x["doctor_name"] == "Dr. JSON Test" for x in backup_data["prescriptions"]))

        # 3. Reçeteleri temizle
        self.client.delete("/api/db/prescriptions", headers=h)
        self.assertEqual(len(self.client.get("/api/prescriptions").json()), 0)

        # 4. JSON yedeğini geri yükle (replace)
        import json
        file_bytes = json.dumps(backup_data).encode("utf-8")
        restore_res = self.client.post(
            "/api/admin/restore/json?mode=replace",
            headers=h,
            files={"file": ("backup.json", file_bytes, "application/json")}
        )
        self.assertEqual(restore_res.status_code, 200)
        self.assertGreater(restore_res.json()["prescriptions_restored"], 0)

        # Geri geldiğini doğrula
        prescriptions = self.client.get("/api/prescriptions").json()
        self.assertTrue(any(x["doctor_name"] == "Dr. JSON Test" for x in prescriptions))

        # 5. Merge modunda tekrar yükle -> aynı reçeteler atlanmalı
        merge_res = self.client.post(
            "/api/admin/restore/json?mode=merge",
            headers=h,
            files={"file": ("backup.json", file_bytes, "application/json")}
        )
        self.assertEqual(merge_res.status_code, 200)
        self.assertGreater(merge_res.json()["skipped"], 0)

    def test_zz_02_migrate_legacy_db_endpoint(self):
        """Eski v1 şemalı bir SQLite dosyasını yükleyip aktarma."""
        import tempfile, sqlite3
        fd, path = tempfile.mkstemp(suffix=".db")
        os.close(fd)
        try:
            conn = sqlite3.connect(path)
            conn.executescript("""
                CREATE TABLE prescriptions (id INTEGER PRIMARY KEY AUTOINCREMENT, patient_name TEXT, doctor_name TEXT, prescription_date TEXT);
                CREATE TABLE prescription_items (id INTEGER PRIMARY KEY AUTOINCREMENT, prescription_id INTEGER, product_name TEXT, quantity INTEGER, notes TEXT);
                INSERT INTO prescriptions (patient_name, doctor_name, prescription_date) VALUES ('Eski Hasta', 'Dr. Eski Versiyon', '2024-01-15');
                INSERT INTO prescription_items (prescription_id, product_name, quantity, notes) VALUES (1, 'PAROL 500 MG', 2, 'tok karnına');
            """)
            conn.commit()
            conn.close()

            with open(path, "rb") as f:
                db_bytes = f.read()

            h = {"X-Admin-Password": "admin"}
            res = self.client.post(
                "/api/admin/migrate-legacy-db?mode=merge",
                headers=h,
                files={"file": ("old_data.db", db_bytes, "application/octet-stream")}
            )
            self.assertEqual(res.status_code, 200)
            self.assertEqual(res.json()["prescriptions_imported"], 1)
            self.assertEqual(res.json()["items_imported"], 1)

            # Reçetenin sisteme eklendiğini doğrula
            prescriptions = self.client.get("/api/prescriptions", params={"year": "2024", "month": "01"}).json()
            self.assertTrue(any(x["doctor_name"] == "Dr. Eski Versiyon" for x in prescriptions))
        finally:
            if os.path.exists(path):
                os.remove(path)


if __name__ == "__main__":
    unittest.main()
