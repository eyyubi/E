"""Medrecete Modülü - Reçete, Doktor ve Tüketim Raporlama Sistemi"""
