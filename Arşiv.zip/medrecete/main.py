import os
import sys
from pathlib import Path
ROOT_DIR = Path(__file__).resolve().parent.parent
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from contextlib import asynccontextmanager

import uvicorn
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from medrecete.app.api.endpoints import router, manager
from medrecete.app.infrastructure.database import BASE_DIR, init_db

STATIC_DIR = os.path.join(BASE_DIR, "static")


@asynccontextmanager
async def lifespan(_: FastAPI):
    # Initialize database (şema oluşturma / migrasyon)
    init_db()
    yield


app = FastAPI(title="Modern Medikal Reçete Sistemi", lifespan=lifespan)

# Tarayıcı çerez/kimlik bilgisi kullanılmadığı için credentials kapalı
# (allow_origins="*" ile allow_credentials=True birlikte geçerli bir kombinasyon değildir).
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include API routes
app.include_router(router, prefix="/api")

# WebSocket endpoint registered directly on app to ensure proper routing
@app.websocket("/api/ws")
async def websocket_endpoint(websocket: WebSocket):
    await manager.connect(websocket)
    try:
        while True:
            await websocket.receive_text()
    except (WebSocketDisconnect, Exception):
        manager.disconnect(websocket)

# Serve static files
app.mount("/static/medrecete", StaticFiles(directory=STATIC_DIR), name="static_medrecete")
app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")

@app.get("/", include_in_schema=False)
async def read_root():
    return FileResponse(os.path.join(STATIC_DIR, "index.html"), media_type="text/html; charset=utf-8")

if __name__ == "__main__":
    uvicorn.run(
        "main:app", host="0.0.0.0", port=5000, reload=True,
        reload_dirs=[BASE_DIR], reload_includes=["*.py"], reload_excludes=[".venv/*", "Arşiv/*"],
    )
