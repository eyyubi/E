---
name: Clinical Apothecary Core
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#3e4948'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#6e7979'
  outline-variant: '#bec9c8'
  surface-tint: '#016a6a'
  primary: '#005454'
  on-primary: '#ffffff'
  primary-container: '#0d6e6e'
  on-primary-container: '#9dedec'
  inverse-primary: '#84d4d3'
  secondary: '#006780'
  on-secondary: '#ffffff'
  secondary-container: '#76dcff'
  on-secondary-container: '#006077'
  tertiary: '#004f7a'
  on-tertiary: '#ffffff'
  tertiary-container: '#00689e'
  on-tertiary-container: '#c7e3ff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#a0f0f0'
  primary-fixed-dim: '#84d4d3'
  on-primary-fixed: '#002020'
  on-primary-fixed-variant: '#004f50'
  secondary-fixed: '#b7eaff'
  secondary-fixed-dim: '#6cd3f7'
  on-secondary-fixed: '#001f28'
  on-secondary-fixed-variant: '#004e61'
  tertiary-fixed: '#cce5ff'
  tertiary-fixed-dim: '#93ccff'
  on-tertiary-fixed: '#001d31'
  on-tertiary-fixed-variant: '#004b73'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  headline-xl:
    fontFamily: Inter
    fontSize: 2rem
    fontWeight: '700'
    lineHeight: 2.5rem
  headline-lg:
    fontFamily: Inter
    fontSize: 1.5rem
    fontWeight: '600'
    lineHeight: 2rem
  headline-md:
    fontFamily: Inter
    fontSize: 1.25rem
    fontWeight: '600'
    lineHeight: 1.75rem
  headline-sm:
    fontFamily: Inter
    fontSize: 1.125rem
    fontWeight: '600'
    lineHeight: 1.5rem
  body-lg:
    fontFamily: Inter
    fontSize: 1rem
    fontWeight: '400'
    lineHeight: 1.5rem
  body-md:
    fontFamily: Inter
    fontSize: 0.875rem
    fontWeight: '400'
    lineHeight: 1.25rem
  body-sm:
    fontFamily: Inter
    fontSize: 0.75rem
    fontWeight: '400'
    lineHeight: 1rem
  label-lg:
    fontFamily: JetBrains Mono
    fontSize: 0.875rem
    fontWeight: '500'
    lineHeight: 1.25rem
  label-md:
    fontFamily: JetBrains Mono
    fontSize: 0.75rem
    fontWeight: '500'
    lineHeight: 1rem
  label-sm:
    fontFamily: JetBrains Mono
    fontSize: 0.6875rem
    fontWeight: '600'
    lineHeight: 0.875rem
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1rem
  margin: 1.5rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1rem
  space-xl: 1.5rem
---

## Brand & Style

This design system is engineered for high-throughput hospital pharmacy management, clinical medication verification, and unit-dose dispensaries. The target audience comprises inpatient pharmacists, clinical pharmacology specialists, pharmacy technicians, and floor nurses operating under time-critical, zero-error parameters.

The visual style is **Corporate / Modern Clinical**: disciplined, hyper-legible, ergonomic, and quiet. It avoids unnecessary decorative flair in favor of structural clarity, high data density, and cognitive safety. The aesthetic pairs sterile crisp whites and soft slate-gray architectural layers with deep clinical teal and precise cyan accents. Visual hierarchy prioritizes unambiguous legibility of active ingredients, dosages, expiration dates, unit counts, and critical contraindications.

## Colors

The palette delivers strict clinical authority, high contrast, and ergonomic viewing across 12-hour shifts.

- **Primary (`#0D6E6E`)**: Deep Clinical Teal. Used for primary operational actions (Dispense, Verify, Batch Release), navigation active states, and structural focus elements.
- **Secondary (`#0891B2`)**: Fresh Cyan. Used for secondary active elements, category indicators, telemetry progress indicators, and interactive highlights.
- **Tertiary (`#0284C7`)**: Clinical Cerulean. Dedicated to informational metadata, print previews, and secondary workflow milestones.
- **Neutral (`#64748B`)**: Slate Gray. Drives tabular grid lines, inactive states, secondary labels, and soft backdrop surfaces (`#F8FAFC` base background, `#FFFFFF` elevated cards).

### Semantic & Status Colors
- **Critical / Depleted / Expired**: `#BE123C` (Crimson) on `#FFE4E6` tint.
- **Warning / Low Stock / Near Expiry**: `#B45309` (Amber) on `#FEF3C7` tint.
- **Verified / Safe Stock / Active**: `#047857` (Emerald) on `#D1FAE5` tint.
- **Controlled Substance / Narcotic Flag**: `#6D28D9` (Deep Violet) on `#EDE9FE` tint.

## Typography

The typography leverages **Inter** for all prose, headings, and interactive elements to maintain neutral geometric clarity at varied viewing distances. For drug dosages, serial numbers, ATC codes, barcode equivalents, and expiration timestamps, the system mandates **JetBrains Mono** to guarantee tabular number alignment and avoid mistaking glyphs (such as '0' vs 'O', '1' vs 'I').

- Always use tabular lining numbers (`tnum`) in inventory quantities and dosage units (e.g., `500 mg`, `100 ml`).
- Critical drug names must use sentence case with bold font weights; avoid full uppercase strings to comply with patient safety standards and ISMP Tall Man lettering conventions where applicable.

## Layout & Spacing

The layout is built for high-density, multi-window desktop operational environments (1440px+ native target, responsive down to 1024px workstation consoles). 

- **Structure**: Multi-pane fixed master-detail layout. Persistent collapsible rail navigation (64px collapsed, 240px expanded), an omni-search command bar pinned to the top (height: 56px), and a fluid 12-column work area.
- **Rhythm**: Compact 4px base increment. Padding is kept dense (`space-sm` to `space-md`) within data-heavy tables and verification queues to ensure critical clinical data stays above the fold.
- **Reflow**: Below 1280px, auxiliary verification panels collapse into slide-out drawers, retaining uninterrupted focus on active inventory tables.

## Elevation & Depth

Visual hierarchy relies on crisp borders and functional tonal depth rather than dramatic ambient drop shadows.

- **Level 0 (Canvas Base)**: `#F8FAFC`. Background for application framing, global filters, and inactive panels.
- **Level 1 (Card & Row Surfaces)**: `#FFFFFF` encased in a 1px border of `#E2E8F0`. No shadow during rest state.
- **Level 2 (Active Item / Context Flyouts)**: `#FFFFFF` with `0 2px 4px -1px rgba(15, 23, 42, 0.06), 0 4px 6px -1px rgba(15, 23, 42, 0.08)` and border `#CBD5E1`.
- **Level 3 (Modal / Verification Dialogs / Batch Barcode Scanner Overlays)**: `#FFFFFF` with `0 10px 15px -3px rgba(15, 23, 42, 0.12), 0 4px 6px -4px rgba(15, 23, 42, 0.08)` and a backplate wash of `rgba(15, 23, 42, 0.45)`.
- **Print Preview Viewports**: Neutral slate background (`#475569`) surrounding a sharp, shadowless white page canvas with high-contrast hairline dividers (`#000000` / `#94A3B8`).

## Shapes

The design system maintains a structured, clinical aesthetic with soft micro-radii (`roundedness: 1`). 

- Standard inputs, buttons, table containers, and modal dialogs use `0.25rem` (4px).
- Cards, master-detail wrappers, and floating alerts use `0.5rem` (8px).
- Status badges, category pills (*Serum & Mama Grubu*, *Tablet Grubu*, *Diğer İlaçlar*), and dosage chips are the sole exception: they use a fully rounded capsule style (`9999px`) to immediately distinguish category chips from clickable action buttons and form inputs.

## Components

### Buttons
- **Primary**: Solid `#0D6E6E` with white text. High-emphasis clinical actions (e.g., "Reçete Onayla", "Stok Güncelle"). Hover: `#0F5B5B`.
- **Secondary**: Crisp white background, `#0D6E6E` border and text. Hover: `#F0FDFA`.
- **Destructive**: Solid `#BE123C` or ghost style with red text for high-risk actions (e.g., "İmha Et", "Barkod İptal").

### Category Pill Filters
- Distinct capsule badges with an active state of `#0D6E6E` fill and white label; inactive state features `#F1F5F9` background, `#475569` text, and `#CBD5E1` border.
- Specialized category accents:
  - **Serum & Mama Grubu**: Soft cyan dot accent (`#0891B2`).
  - **Tablet Grubu**: Soft amber dot accent (`#D97706`).
  - **Diğer İlaçlar**: Soft slate dot accent (`#64748B`).

### Data Tables
- **Header**: `#F1F5F9` background, uppercase 11px font (`JetBrains Mono`), 40px height, non-distracting bottom border (`#CBD5E1`).
- **Rows**: 44px compact row height, alternating zebra striping optional; hover state transitions instantly to `#F8FAFC`. Critical alerts highlight the entire row with a 3px left border (e.g., red for expired).
- **Cells**: Mono-spaced for GTIN, barcode, batch/lot, and stock counts; regular Inter for medicine brand and active ingredients.

### Search & Filter Bar
- Pinned omni-search field equipped with barcode scanner listener icon, keyboard shortcut shortcut tag (`Ctrl + K`), and instant clear actions.
- Inline filter dropdowns (SKT Aralığı, Depo Konumu, Form Tipi) embedded inside a single unified toolbar with 1px border.

### Status Badges
- High-contrast, compact capsules featuring a 6px solid colored indicator dot beside mono text (e.g., `KRİTİK STOK: 4`, `ONAYLANDI`, `KARANTİNA`).

### Print-Friendly Layouts
- Dedicated A4 / thermal roll print simulation panel. Automatically strips background fills, swaps interactive buttons for barcode grids and signature blocks, and sets text to 100% black on white.