/**
 * Kusursuz A4 ve Etiket Baskı Yöneticisi (Print Manager)
 * 
 * - A4 tek sütun, 40 kaleme kadar okunaklı ve izlenebilir satırlar.
 * - Sütun sıralaması: İsim %72, Miktar %10, Raf %13, Tik %5.
 * - Çıktı başlıklarında Servis ve Bulunduğu Kat bilgisi gösterilir.
 * - Etiket için: İlaç İsmi, Miktar ve Raf belirgin olarak görüntülenir.
 * - İzole iframe üzerinden yazdırılır (asla bozulma olmaz).
 */
class PrintManager {
  /**
   * Tarih formatlayıcı
   */
  static getFormattedDate() {
    const now = new Date();
    const d = String(now.getDate()).padStart(2, '0');
    const m = String(now.getMonth() + 1).padStart(2, '0');
    const y = now.getFullYear();
    const h = String(now.getHours()).padStart(2, '0');
    const min = String(now.getMinutes()).padStart(2, '0');
    return `${d}.${m}.${y} ${h}:${min}`;
  }

  /**
   * İzole iframe ile yazdırma (Sıfır bozulma garantisi)
   */
  static printHtmlViaIframe(htmlContent, pageCss) {
    let iframe = document.getElementById("hiddenPrintIframe");
    if (!iframe) {
      iframe = document.createElement("iframe");
      iframe.id = "hiddenPrintIframe";
      iframe.style.position = "fixed";
      iframe.style.right = "0";
      iframe.style.bottom = "0";
      iframe.style.width = "0";
      iframe.style.height = "0";
      iframe.style.border = "none";
      document.body.appendChild(iframe);
    }

    const doc = iframe.contentWindow.document;
    doc.open();
    doc.write(`
      <!DOCTYPE html>
      <html lang="tr">
      <head>
        <meta charset="UTF-8">
        <title>İlaç Raporu Baskı</title>
        <style>
          ${pageCss}
        </style>
      </head>
      <body>
        ${htmlContent}
      </body>
      </html>
    `);
    doc.close();

    setTimeout(() => {
      iframe.contentWindow.focus();
      iframe.contentWindow.print();
    }, 250);
  }

  /**
   * A4 Baskı CSS Stilleri
   */
  static getA4PrintStyles() {
    return `
      * {
        box-sizing: border-box;
        margin: 0;
        padding: 0;
      }
      @page {
        size: A4 portrait;
        margin: 5mm 7mm;
      }
      body {
        font-family: Arial, "Helvetica Neue", Helvetica, sans-serif;
        color: #000000;
        background: #ffffff;
        font-size: 9pt;
        line-height: 1.15;
        -webkit-print-color-adjust: exact !important;
        print-color-adjust: exact !important;
      }
      .a4-container {
        width: 100%;
      }

      /* Rapor başlığı */
      .header-compact {
        border-bottom: 1.2pt solid #334155;
        padding-bottom: 1.5mm;
        margin-bottom: 2mm;
        display: flex;
        justify-content: space-between;
        align-items: center;
      }
      .header-title-main {
        font-size: 12pt;
        font-weight: 900;
        letter-spacing: -0.01em;
        text-transform: uppercase;
      }
      .header-title-sub {
        font-size: 8pt;
        color: #444444;
        font-weight: 600;
        margin-top: 0.3mm;
      }
      .header-meta {
        text-align: right;
        font-size: 8pt;
        font-family: monospace;
      }
      .header-meta strong {
        font-size: 9pt;
        color: #000000;
      }

      /* Tek Sütun Tablo */
      .med-table {
        width: 100% !important;
        border-collapse: collapse !important;
        table-layout: fixed !important;
        margin-bottom: 2mm;
      }
      .med-table thead {
        display: table-header-group;
      }
      .med-table th {
        background: #e8eef5 !important;
        border: 0.6pt solid #64748b;
        padding: 1mm 1.2mm;
        font-size: 8pt;
        font-weight: 800;
        text-align: left;
        letter-spacing: 0.02em;
      }
      .med-table th:not(:first-child) {
        text-align: center;
      }
      .med-table td {
        border: 0.45pt solid #aeb9c6;
        padding: 0.7mm 1.2mm;
        font-size: 8.5pt;
        vertical-align: middle;
        white-space: normal;
        overflow: visible;
        overflow-wrap: anywhere;
      }
      .med-table tbody tr.item-row:nth-child(even) {
        background: #f5f8fb !important;
      }
      .med-table .item-row {
        break-inside: avoid;
        page-break-inside: avoid;
      }

      /* Grup Başlık Satırı */
      .group-row {
        background-color: #e2e8f0 !important;
        font-weight: 900;
        font-size: 9pt;
        text-transform: uppercase;
        padding: 1.2mm 1.5mm !important;
        border: 0.8pt solid #64748b !important;
        break-after: avoid;
        page-break-after: avoid;
      }
      .group-row-serum  { background-color: #cffafe !important; }
      .group-row-tablet { background-color: #fef3c7 !important; }
      .group-row-diger  { background-color: #e2e8f0 !important; }

      /* Sütun Oranları: İsim %72, Miktar %10, Raf %13, Tik %5 */
      .col-drug {
        width: 72% !important;
        padding: 0.7mm 1.2mm !important;
        white-space: normal !important;
        overflow: visible !important;
        overflow-wrap: anywhere !important;
      }
      .drug-cell {
        display: flex;
        align-items: baseline;
        flex-wrap: wrap;
        column-gap: 1mm;
        width: 100%;
      }
      .drug-kisa {
        display: inline;
        font-weight: 900;
        font-size: 9pt;
        white-space: normal;
        overflow-wrap: anywhere;
      }
      .drug-tam-isim {
        display: inline;
        font-size: 7.5pt;
        color: #555555;
        font-weight: 400;
        white-space: normal;
        overflow-wrap: anywhere;
      }
      .drug-text-full {
        display: inline;
        width: 100%;
        font-weight: 700;
        font-size: 8.5pt;
        white-space: normal;
        overflow-wrap: anywhere;
      }
      .col-qty {
        width: 10% !important;
        text-align: center !important;
        font-weight: 900;
        font-family: monospace;
        white-space: nowrap;
        font-size: 9pt !important;
      }
      .col-raf {
        width: 13% !important;
        text-align: center !important;
        font-family: monospace;
        font-weight: 800;
        white-space: nowrap;
        font-size: 8pt !important;
      }
      .col-chk {
        width: 5% !important;
        text-align: center !important;
        white-space: nowrap;
      }
      .chk-box {
        display: inline-block;
        width: 11px;
        height: 11px;
        border: 1pt solid #334155;
        background-color: #ffffff !important;
        vertical-align: middle;
      }

      /* Alt Bilgi */
      .a4-footer {
        border-top: 0.8pt solid #64748b;
        padding-top: 1.5mm;
        margin-top: 2mm;
        display: flex;
        justify-content: space-between;
        align-items: center;
        font-size: 7.5pt;
        color: #333333;
      }
      .sig-block {
        display: flex;
        gap: 8mm;
      }
      .sig-cell {
        border-top: 0.8pt dashed #000000;
        width: 28mm;
        text-align: center;
        padding-top: 0.8mm;
        font-size: 7pt;
      }
    `;
  }

  /**
   * 3 Grubu Bir Arada İçeren A4 HTML Üretici (Servis ve Kat Bilgili)
   */
  static buildCombinedA4Html(categorizeData, service = null) {
    if (!categorizeData) return "";

    const islemNo = categorizeData.islem_no || "-";
    const dateStr = PrintManager.getFormattedDate();
    const totalKalem = categorizeData.toplam_kalem || 0;
    const totalAdet = categorizeData.toplam_adet || 0;

    let serviceMainTitle = "SERVİS: GENEL";
    if (service && service.name) {
      const floorPart = service.floor ? ` (${service.floor.toUpperCase()})` : "";
      serviceMainTitle = `SERVİS: ${service.name.toUpperCase()}${floorPart}`;
    }

    const groupOrder = [
      { key: "tablet", name: "1. TABLET GRUBU", class: "group-row-tablet" },
      { key: "diger", name: "2. DİĞER İLAÇLAR", class: "group-row-diger" },
      { key: "serum", name: "3. SERUM & MAMA GRUBU", class: "group-row-serum" }
    ];

    let rowsHtml = "";

    groupOrder.forEach(gDef => {
      const g = categorizeData.gruplar[gDef.key];
      const items = g ? g.items : [];
      const count = g ? g.item_count : 0;
      const qty = g ? g.total_quantity : 0;

      rowsHtml += `
        <tr>
          <td colspan="4" class="group-row ${gDef.class}">
            ${gDef.name} &nbsp;—&nbsp; ${count} KALEM / ${qty} ADET
          </td>
        </tr>
      `;

      if (items.length === 0) {
        rowsHtml += `
          <tr class="item-row">
            <td colspan="4" style="text-align: center; color: #777; font-size: 10pt; padding: 2px;">
              - Bu grupta ilaç kaydı bulunmamaktadır -
            </td>
          </tr>
        `;
      } else {
        items.forEach(item => {
          const raf = item.raf_konumu && item.raf_konumu !== "-" ? item.raf_konumu : "RAF YOK";
          const urunAdi = item.urun_adi || "Tanımsız İlaç";
          const miktar = item.toplam_miktar || 1;
          const kisaIsim = item.kisa_isim || null;

          // Kısa isim varsa: büyük+kalın kısa isim + küçük tam isim
          // Kısa isim yoksa: sadece tam isim
          const drugDisplay = kisaIsim
            ? `<span class="drug-kisa">${kisaIsim}</span><span class="drug-tam-isim">${urunAdi}</span>`
            : `<span class="drug-text-full">${urunAdi}</span>`;

          rowsHtml += `
            <tr class="item-row">
              <!-- 1. İlaç (%80 - Tam Görünüm, Kısa İsim Vurgulu) -->
              <td class="col-drug">
                <div class="drug-cell" title="${urunAdi}">${drugDisplay}</div>
              </td>
              <!-- 2. Miktar (%7) -->
              <td class="col-qty">${miktar}</td>
              <!-- 3. Raf (%9) -->
              <td class="col-raf" title="${raf}">${raf}</td>
              <!-- 4. Tik (%4) -->
              <td class="col-chk"><span class="chk-box"></span></td>
            </tr>
          `;
        });
      }
    });

    return `
      <div class="a4-container">
        <!-- Minimal üst başlık (Servis İsmi & İşlem No Odaklı) -->
        <div class="header-compact">
          <div>
            <div class="header-title-main">${serviceMainTitle}</div>
            <div class="header-title-sub">İLAÇ TOPLAMA VE DAĞITIM LİSTESİ</div>
          </div>
          <div class="header-meta">
            <div>İŞLEM NO: <strong>${islemNo}</strong></div>
            <div>${dateStr} &nbsp;|&nbsp; <strong>${totalKalem} Kalem (${totalAdet} Adet)</strong></div>
          </div>
        </div>

        <!-- Tek Sütun Tablo -->
        <table class="med-table">
          <colgroup>
            <col style="width: 72%;">
            <col style="width: 10%;">
            <col style="width: 13%;">
            <col style="width: 5%;">
          </colgroup>
          <thead>
            <tr>
              <th>İLAÇ ADI</th>
              <th>MİKTAR</th>
              <th>RAF</th>
              <th>✓</th>
            </tr>
          </thead>
          <tbody>
            ${rowsHtml}
          </tbody>
        </table>

        <!-- Alt Bilgi & İmzalar -->
        <div class="a4-footer">
          <div>* Raftan toplanan ilaçların sağındaki <strong>[ ]</strong> kutusunu işaretleyiniz.</div>
          <div class="sig-block">
            <div class="sig-cell">Hazırlayan (Teknisyen)</div>
            <div class="sig-cell">Kontrol Eden (Eczacı)</div>
          </div>
        </div>
      </div>
    `;
  }

  /**
   * 8x10 Termal Etiket Stilleri
   */
  static getLabelPrintStyles() {
    return `
      * {
        box-sizing: border-box;
        margin: 0;
        padding: 0;
      }
      @page {
        size: 80mm 100mm;
        margin: 2mm;
      }
      body {
        font-family: Arial, "Helvetica Neue", Helvetica, sans-serif;
        color: #000000;
        background: #ffffff;
        font-size: 8pt;
        -webkit-print-color-adjust: exact !important;
        print-color-adjust: exact !important;
      }
      .label-card {
        width: 76mm;
        height: 96mm;
        border: 2pt solid #000000;
        padding: 2.5mm;
        display: flex;
        flex-direction: column;
        justify-content: space-between;
        page-break-after: always;
      }
      .label-card:last-child {
        page-break-after: auto;
      }
      .lbl-top {
        border-bottom: 1.5pt solid #000000;
        padding-bottom: 1.5mm;
        text-align: center;
      }
      .lbl-service-title {
        font-size: 10pt;
        font-weight: 900;
        text-transform: uppercase;
        color: #000000;
        letter-spacing: -0.2px;
        margin-bottom: 1mm;
      }
      .lbl-grp-name {
        font-size: 10.5pt;
        font-weight: 900;
        background-color: #000000 !important;
        color: #ffffff !important;
        padding: 1mm 0;
        border-radius: 2px;
        letter-spacing: 0.5px;
        text-transform: uppercase;
      }
      .lbl-meta {
        display: flex;
        justify-content: space-between;
        border-bottom: 1pt solid #000000;
        padding: 1.2mm 0;
        font-size: 7.5pt;
        font-family: monospace;
      }
      .lbl-meta strong {
        font-size: 8.5pt;
      }
      .lbl-body {
        flex: 1;
        margin: 1.5mm 0;
        overflow: hidden;
      }
      /* İlaç İsmi, Miktar ve Raf Tablosu (Sıfır Taşma Korumalı) */
      .lbl-tbl {
        width: 100% !important;
        table-layout: fixed !important;
        border-collapse: collapse !important;
        font-size: 7.2pt;
      }
      .lbl-tbl th {
        border-bottom: 1.2pt solid #000000;
        padding: 1.5px 2px;
        text-align: left;
        font-weight: 900;
        background-color: #f1f5f9 !important;
        white-space: nowrap !important;
        overflow: hidden !important;
      }
      .lbl-tbl td {
        padding: 1.5px 2px;
        border-bottom: 0.5pt dotted #888888;
        vertical-align: middle;
      }
      .lbl-tbl-drug {
        width: 55% !important;
        max-width: 0 !important;
        overflow: hidden !important;
        white-space: nowrap !important;
      }
      .lbl-drug-clipped {
        display: block !important;
        width: 100% !important;
        max-width: 100% !important;
        white-space: nowrap !important;
        overflow: hidden !important;
        text-overflow: ellipsis !important;
        font-weight: 800 !important;
        line-height: 1.15;
      }
      .lbl-tbl-qty {
        width: 15% !important;
        max-width: 0 !important;
        text-align: center !important;
        font-weight: 900;
        font-family: monospace;
        white-space: nowrap !important;
        overflow: hidden !important;
      }
      .lbl-tbl-raf {
        width: 30% !important;
        max-width: 0 !important;
        text-align: center !important;
        font-weight: 900;
        font-family: monospace;
        white-space: nowrap !important;
        overflow: hidden !important;
      }
      .lbl-raf-clipped {
        display: block !important;
        width: 100% !important;
        max-width: 100% !important;
        white-space: nowrap !important;
        overflow: hidden !important;
        text-overflow: ellipsis !important;
      }
      .lbl-bottom {
        border-top: 1pt solid #000000;
        padding-top: 1mm;
        display: flex;
        justify-content: space-between;
        font-size: 6.8pt;
        font-family: monospace;
      }

      /* Tekil Kalem Etiketi (İlaç, Miktar, Raf Odaklı) */
      .single-item-card {
        width: 76mm;
        height: 96mm;
        border: 2.5pt solid #000000;
        padding: 3mm;
        display: flex;
        flex-direction: column;
        justify-content: space-between;
        page-break-after: always;
        text-align: center;
      }
      .single-item-card:last-child {
        page-break-after: auto;
      }
      .single-lbl-header {
        border-bottom: 1.5pt solid #000000;
        padding-bottom: 1.5mm;
        font-size: 7.5pt;
        font-weight: bold;
        display: flex;
        justify-content: space-between;
      }
      .single-lbl-drug {
        font-size: 11.5pt;
        font-weight: 900;
        line-height: 1.25;
        max-height: 20mm;
        overflow: hidden;
        display: -webkit-box;
        -webkit-line-clamp: 3;
        -webkit-box-orient: vertical;
        word-break: break-word;
        text-overflow: ellipsis;
        margin: 1.5mm 0;
        padding: 1.5mm;
        border: 1pt solid #000000;
        background-color: #fafafa !important;
      }
      .single-lbl-qty {
        font-size: 18pt;
        font-weight: 900;
        font-family: monospace;
        border: 2pt solid #000000;
        padding: 2mm;
        margin: 1.5mm 0;
      }
      .single-lbl-raf {
        font-size: 16pt;
        font-weight: 900;
        font-family: monospace;
        background-color: #000000 !important;
        color: #ffffff !important;
        padding: 2mm;
        border-radius: 2px;
      }
    `;
  }

  /**
   * 8x10 Grup Dağıtım Etiketi: İlaç İsmi, Miktar ve Raf Tablosu
   */
  static buildSingleGroupLabelHtml(group, islemNo, service = null) {
    if (!group || !group.items || group.items.length === 0) return "";
    const dateStr = PrintManager.getFormattedDate();
    const items = group.items;

    let serviceTitle = "SERVİS: GENEL";
    if (service && service.name) {
      serviceTitle = `SERVİS: ${service.name.toUpperCase()} (KAT: ${service.floor ? service.floor.toUpperCase() : '-'})`;
    }

    const previewItems = items.slice(0, 12);
    const rest = items.length - previewItems.length;

    let rows = previewItems.map(it => `
      <tr>
        <!-- 1. İlaç İsmi (Kesin Taşma Korumalı & Tek Satır Kırpma) -->
        <td class="lbl-tbl-drug">
          <div class="lbl-drug-clipped" title="${it.urun_adi}">${it.urun_adi}</div>
        </td>
        <!-- 2. Miktar -->
        <td class="lbl-tbl-qty">${it.toplam_miktar}</td>
        <!-- 3. Raf -->
        <td class="lbl-tbl-raf">
          <div class="lbl-raf-clipped" title="${it.raf_konumu || "-"}">${it.raf_konumu || "-"}</div>
        </td>
      </tr>
    `).join("");

    if (rest > 0) {
      rows += `
        <tr>
          <td colspan="3" style="text-align: center; color: #555; font-style: italic; font-size: 6.5pt;">
            ... ve ${rest} kalem daha
          </td>
        </tr>
      `;
    }

    return `
      <div class="label-card">
        <!-- Başlık: Servis İsmi Vurgulu (Bakanlık yazısı kaldırıldı) -->
        <div class="lbl-top">
          <div class="lbl-service-title">${serviceTitle}</div>
          <div class="lbl-grp-name">${group.name}</div>
        </div>

        <div class="lbl-meta">
          <div>İŞLEM NO: <strong>${islemNo}</strong></div>
          <div>TOPLAM: <strong>${group.item_count} Kalem / ${group.total_quantity} Adet</strong></div>
        </div>

        <!-- İlaç İsmi, Miktar ve Raf Tablosu -->
        <div class="lbl-body">
          <table class="lbl-tbl">
            <colgroup>
              <col style="width: 55%;">
              <col style="width: 15%;">
              <col style="width: 30%;">
            </colgroup>
            <thead>
              <tr>
                <th style="width: 55%;">İLAÇ İSMİ</th>
                <th style="width: 15%; text-align: center;">MİKTAR</th>
                <th style="width: 30%; text-align: center;">RAF</th>
              </tr>
            </thead>
            <tbody>
              ${rows}
            </tbody>
          </table>
        </div>

        <div class="lbl-bottom">
          <div>Tarih: ${dateStr}</div>
          <div>Koli/Sepet No: [ &nbsp;&nbsp;&nbsp;&nbsp; ]</div>
        </div>
      </div>
    `;
  }

  /**
   * 8x10 Tekil Kalem Etiketleri: İlaç İsmi, Miktar ve Raf Vurgulu
   */
  static buildSingleItemLabelsHtml(items, islemNo, service = null) {
    if (!items || items.length === 0) return "";
    let svcText = "SERVİS: GENEL";
    if (service && service.name) {
      svcText = `SERVİS: ${service.name.toUpperCase()}${service.floor ? ' (' + service.floor.toUpperCase() + ')' : ''}`;
    }

    return items.map(item => `
      <div class="single-item-card">
        <div class="single-lbl-header">
          <span>İŞLEM NO: ${islemNo}</span>
          <span style="font-weight: 900;">${svcText}</span>
        </div>

        <!-- 1. İlaç İsmi (Taşma Korumalı & Çok Satırlı Kırpma) -->
        <div class="single-lbl-drug" title="${item.urun_adi}">
          ${item.urun_adi}
        </div>

        <!-- 2. Miktar -->
        <div class="single-lbl-qty">
          MİKTAR: ${item.toplam_miktar} ADET
        </div>

        <!-- 3. Raf -->
        <div class="single-lbl-raf">
          RAF: ${item.raf_konumu && item.raf_konumu !== "-" ? item.raf_konumu : "RAF YOK"}
        </div>

        <div style="font-size: 7.5pt; font-family: monospace; border-top: 1pt solid #000; padding-top: 1mm; display: flex; justify-content: space-between;">
          <span>Barkod: ${item.barkod}</span>
          <span>${item.kategori_adi || ""}</span>
        </div>
      </div>
    `).join("");
  }

  /**
   * A4 Raporunu Yazdırır (Servis ve Kat Bilgisi Dahil)
   */
  static printA4(categorizeData, service = null) {
    if (!categorizeData) {
      alert("Yazdırılacak veri bulunamadı. Lütfen önce XML yükleyin.");
      return;
    }
    const html = PrintManager.buildCombinedA4Html(categorizeData, service);
    const css = PrintManager.getA4PrintStyles();
    PrintManager.printHtmlViaIframe(html, css);
  }

  /**
   * Belirli bir grubun 8x10 Etiketini Yazdırır (İlaç İsmi, Miktar ve Raf)
   */
  static printGroupLabel(group, islemNo, service = null) {
    if (!group || !group.items || group.items.length === 0) {
      alert("Bu grupta yazdırılacak ilaç kaydı bulunamadı.");
      return;
    }
    const html = PrintManager.buildSingleGroupLabelHtml(group, islemNo, service);
    const css = PrintManager.getLabelPrintStyles();
    PrintManager.printHtmlViaIframe(html, css);
  }

  /**
   * Ekranda Canlı Önizleme Modalı Açar
   */
  static showPreview(contentHtml, title) {
    const modal = document.getElementById("previewModal");
    const titleEl = document.getElementById("previewModalTitle");
    const bodyEl = document.getElementById("previewModalBody");
    if (!modal || !bodyEl) return;

    titleEl.textContent = title;
    const previewFrame = document.createElement("iframe");
    previewFrame.className = "a4-preview-frame";
    previewFrame.title = title;
    previewFrame.setAttribute("sandbox", "");
    previewFrame.srcdoc = `
      <!doctype html>
      <html lang="tr">
        <head>
          <meta charset="UTF-8">
          <style>
            ${PrintManager.getA4PrintStyles()}
            html, body { min-width: 0; min-height: 100%; }
            body {
              display: flex;
              justify-content: center;
              padding: 12px !important;
              background: #64748b !important;
            }
            .preview-a4-page {
              background: #ffffff;
              width: 210mm;
              max-width: 100%;
              min-height: 297mm;
              padding: 6mm 8mm;
              box-shadow: 0 4px 15px rgba(0,0,0,0.3);
              margin: 0 auto;
              font-family: Arial, sans-serif;
            }
          </style>
        </head>
        <body><main class="preview-a4-page">${contentHtml}</main></body>
      </html>
    `;
    bodyEl.replaceChildren(previewFrame);
    modal.classList.add("open");
  }
}

window.PrintManager = PrintManager;
