from typing import Tuple
from serumfiltre.app.core.config import FilterConfig

class DrugCategorizer:
    """İlaçları NFC ve açıkça seçilmiş jenerik kodlara göre gruplandırır."""

    @staticmethod
    def classify(
        nfc_code: str | None,
        generic_code: str | None,
        config: FilterConfig,
        barcode_code: str | None = None
    ) -> Tuple[str, str]:
        """
        Serum grubuna seçili jenerik kodlar atanır; eşleşme tablet NFC kuralından
        önce değerlendirilerek açık kullanıcı ataması korunur.
        Dönüş: (kategori_key, kategori_adi)
        Örn: ('tablet', 'Tablet Grubu')
        """
        nfc = (nfc_code or "").strip().upper()
        generic = (generic_code or "").strip().upper()
        barcode = (barcode_code or "").strip().replace("'", "").upper()

        # Açık serum/mama ataması jenerik kod üzerinden yapılır.
        serum_codes = {
            str(code).strip().upper()
            for code in config.group2_generic_codes
            if str(code).strip()
        }
        serum_barcodes = {
            str(code).strip().replace("'", "").upper()
            for code in config.group2_barcodes
            if str(code).strip()
        }
        if (generic and generic in serum_codes) or (barcode and barcode in serum_barcodes):
            return "serum", config.group2_name

        # 1. Grup: Tablet Grubu (NFC kod önekleri, örn: A, B)
        for prefix in config.group1_nfc_prefixes:
            clean_pref = prefix.strip().upper()
            if clean_pref and nfc.startswith(clean_pref):
                return "tablet", config.group1_name

        # ATC kodu kategori tayininde kullanılmaz; eşleşmeyenler diğer gruptadır.
        return "diger", config.group3_name
