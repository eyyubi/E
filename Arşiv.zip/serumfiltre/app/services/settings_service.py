import json
from pathlib import Path
from serumfiltre.app.core.config import SETTINGS_FILE, FilterConfig
from serumfiltre.app.schemas.settings import FilterSettingsUpdate

class SettingsService:
    @staticmethod
    def get_settings() -> FilterConfig:
        """Kayıtlı filtre ayarlarını döner, dosya yoksa varsayılanları oluşturur"""
        if Path(SETTINGS_FILE).exists():
            try:
                with open(SETTINGS_FILE, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    return FilterConfig(**data)
            except Exception:
                pass
        
        # Varsayılan ayarları oluştur ve kaydet
        default_cfg = FilterConfig()
        SettingsService.save_settings(default_cfg)
        return default_cfg

    @staticmethod
    def save_settings(config: FilterConfig | FilterSettingsUpdate) -> FilterConfig:
        """Filtre ayarlarını JSON dosyasına kaydeder"""
        data = config.model_dump()
        try:
            with open(SETTINGS_FILE, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
        except Exception as e:
            print(f"Ayar dosyası kaydedilemedi: {e}")
        return FilterConfig(**data)
