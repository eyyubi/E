from typing import List, Optional, Dict
from sqlalchemy.orm import Session
from sqlalchemy import func

from serumfiltre.app.models.drug_alias import DrugAlias
from serumfiltre.app.models.drug import MasterIlac
from serumfiltre.app.schemas.drug_alias import DrugAliasCreate, DrugAliasUpdate, JenerikSearchResult


class DrugAliasService:
    """Jenerik kodu bazlı ilaç kısa isim yönetimi"""

    @staticmethod
    def get_all(db: Session) -> List[DrugAlias]:
        """Tüm tanımlı kısa isimleri listeler"""
        return db.query(DrugAlias).order_by(DrugAlias.kisa_isim).all()

    @staticmethod
    def get_by_id(db: Session, alias_id: int) -> Optional[DrugAlias]:
        return db.query(DrugAlias).filter(DrugAlias.id == alias_id).first()

    @staticmethod
    def get_alias_map(db: Session) -> Dict[str, str]:
        """
        Jenerik kodu → kısa isim sözlüğü.
        DrugService tarafından toplu eşleştirmede kullanılır.
        """
        rows = db.query(DrugAlias.jenerik_kodu, DrugAlias.kisa_isim).all()
        return {row.jenerik_kodu: row.kisa_isim for row in rows}

    @staticmethod
    def search_jenerik(db: Session, q: str, limit: int = 20) -> List[JenerikSearchResult]:
        """
        Master DB'de jenerik kodu veya adı arar.
        Kullanıcı UI'dan yeni alias tanımlarken bu endpoint'i kullanır.
        """
        from serumfiltre.app.core.database import MasterSessionLocal
        q_clean = f"%{q.strip()}%"
        with MasterSessionLocal() as m_db:
            rows = (
                m_db.query(
                    MasterIlac.jenerik_kodu,
                    MasterIlac.jenerik_adi,
                    func.count(MasterIlac.barkod).label("ilac_sayisi"),
                )
                .filter(
                    MasterIlac.jenerik_kodu.isnot(None),
                    MasterIlac.jenerik_kodu != "",
                    (
                        MasterIlac.jenerik_kodu.ilike(q_clean)
                        | MasterIlac.jenerik_adi.ilike(q_clean)
                    ),
                )
                .group_by(MasterIlac.jenerik_kodu, MasterIlac.jenerik_adi)
                .limit(limit)
                .all()
            )
        return [
            JenerikSearchResult(
                jenerik_kodu=r.jenerik_kodu,
                jenerik_adi=r.jenerik_adi,
                ilac_sayisi=r.ilac_sayisi,
            )
            for r in rows
        ]

    @staticmethod
    def create(db: Session, data: DrugAliasCreate) -> DrugAlias:
        """Yeni kısa isim oluşturur; aynı jenerik_kodu varsa günceller"""
        existing = (
            db.query(DrugAlias)
            .filter(DrugAlias.jenerik_kodu == data.jenerik_kodu)
            .first()
        )
        if existing:
            existing.kisa_isim = data.kisa_isim
            if data.jenerik_adi:
                existing.jenerik_adi = data.jenerik_adi
            if data.notlar is not None:
                existing.notlar = data.notlar
            db.commit()
            db.refresh(existing)
            return existing

        alias = DrugAlias(
            jenerik_kodu=data.jenerik_kodu,
            jenerik_adi=data.jenerik_adi,
            kisa_isim=data.kisa_isim,
            notlar=data.notlar,
        )
        db.add(alias)
        db.commit()
        db.refresh(alias)
        return alias

    @staticmethod
    def update(db: Session, alias_id: int, data: DrugAliasUpdate) -> Optional[DrugAlias]:
        alias = db.query(DrugAlias).filter(DrugAlias.id == alias_id).first()
        if not alias:
            return None
        if data.kisa_isim is not None:
            alias.kisa_isim = data.kisa_isim
        if data.notlar is not None:
            alias.notlar = data.notlar
        db.commit()
        db.refresh(alias)
        return alias

    @staticmethod
    def delete(db: Session, alias_id: int) -> bool:
        alias = db.query(DrugAlias).filter(DrugAlias.id == alias_id).first()
        if not alias:
            return False
        db.delete(alias)
        db.commit()
        return True
