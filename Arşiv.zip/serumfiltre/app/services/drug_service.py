from typing import List, Dict, Any, Optional
from collections import OrderedDict
from sqlalchemy.orm import Session

from serumfiltre.app.models.drug import MasterIlac
from serumfiltre.app.schemas.drug import AggregatedDrug
from serumfiltre.app.schemas.category import CategoryGroup, CategorizeResponse
from serumfiltre.app.services.categorizer import DrugCategorizer
from serumfiltre.app.services.settings_service import SettingsService
from serumfiltre.app.services.drug_alias_service import DrugAliasService


class DrugService:
    @staticmethod
    def process_records(raw_records: List[Dict[str, Any]], db: Session) -> CategorizeResponse:
        """
        Ham XML kayıtlarını birleştirir, adetleri toplar, veritabanından ilaç detaylarını
        çeker, jenerik koda göre kısa isim eşler ve 3 kategoriye ayırır.
        """
        config = SettingsService.get_settings()

        # 1. Barkod bazında birleştirme ve miktar toplama
        grouped: Dict[str, Dict[str, Any]] = OrderedDict()
        detected_islem_no: Optional[str] = None

        for rec in raw_records:
            raw_barcode = str(rec.get("orjkod") or "").strip().replace("'", "")
            if not raw_barcode:
                continue

            try:
                miktar = int(rec.get("miktar") or 1)
            except (ValueError, TypeError):
                miktar = 1

            raw_raf = str(rec.get("bi_rafid") or "").strip()
            il_ad = str(rec.get("il_ad") or "").strip()

            if not detected_islem_no and rec.get("islemno"):
                detected_islem_no = str(rec.get("islemno")).strip()

            if raw_barcode not in grouped:
                grouped[raw_barcode] = {
                    "barkod": raw_barcode,
                    "il_ad": il_ad,
                    "toplam_miktar": 0,
                    "raf_konumlari": [],
                    "islem_no": rec.get("islemno"),
                }
            elif not grouped[raw_barcode]["il_ad"] and il_ad:
                grouped[raw_barcode]["il_ad"] = il_ad

            grouped[raw_barcode]["toplam_miktar"] += miktar
            if raw_raf and raw_raf not in grouped[raw_barcode]["raf_konumlari"]:
                grouped[raw_barcode]["raf_konumlari"].append(raw_raf)

        barcodes = list(grouped.keys())

        # 2. Barkoddan master ilaç kaydı bulma
        db_drugs_map: Dict[str, MasterIlac] = {}
        chunk_size = 500
        from serumfiltre.app.core.database import MasterSessionLocal
        with MasterSessionLocal() as master_session:
            for i in range(0, len(barcodes), chunk_size):
                chunk = barcodes[i : i + chunk_size]
                db_records = master_session.query(MasterIlac).filter(MasterIlac.barkod.in_(chunk)).all()
                for drug in db_records:
                    clean_bc = str(drug.barkod or "").strip().replace("'", "")
                    db_drugs_map[clean_bc] = drug

        # 3. Kısa isim haritası: jenerik_kodu → kisa_isim
        alias_map: Dict[str, str] = DrugAliasService.get_alias_map(db)

        # 4. Kategori grupları
        groups: Dict[str, CategoryGroup] = {
            "tablet": CategoryGroup(key="tablet", name=config.group1_name, items=[]),
            "serum": CategoryGroup(key="serum", name=config.group2_name, items=[]),
            "diger": CategoryGroup(key="diger", name=config.group3_name, items=[]),
        }

        all_aggregated_items: List[AggregatedDrug] = []
        total_quantity = 0

        for barcode, item_data in grouped.items():
            db_drug = db_drugs_map.get(barcode)

            raf_list = item_data["raf_konumlari"]
            raf_str = ", ".join(raf_list) if raf_list else "-"

            nfc_kodu = getattr(db_drug, "nfc_kodu", None) if db_drug else None
            atc_kodu = getattr(db_drug, "atc_kodu", None) if db_drug else None
            jenerik_kodu = getattr(db_drug, "jenerik_kodu", None) if db_drug else None

            # Kategori tayini
            cat_key, cat_name = DrugCategorizer.classify(
                nfc_kodu,
                jenerik_kodu,
                config,
                barcode_code=barcode
            )

            # Kısa isim: jenerik_kodu varsa alias haritasında ara
            kisa_isim: Optional[str] = None
            if jenerik_kodu:
                kisa_isim = alias_map.get(str(jenerik_kodu).strip()) or None

            agg_drug = AggregatedDrug(
                barkod=barcode,
                toplam_miktar=item_data["toplam_miktar"],
                raf_konumu=raf_str,
                raf_konumlari=raf_list,
                islem_no=item_data["islem_no"]
                or (
                    int(detected_islem_no)
                    if detected_islem_no and detected_islem_no.isdigit()
                    else None
                ),
                urun_id=getattr(db_drug, "urun_id", None) if db_drug else None,
                # İlaç adı: XML IL_AD → master DB → fallback
                urun_adi=item_data.get("il_ad")
                or (getattr(db_drug, "urun_adi", None) if db_drug else None)
                or f"Kayıtsız İlaç ({barcode})",
                ambalaj=getattr(db_drug, "ambalaj", None) if db_drug else None,
                firma_adi=getattr(db_drug, "firma_adi", None) if db_drug else None,
                nfc_kodu=nfc_kodu,
                atc_kodu=atc_kodu,
                recete_turu=getattr(db_drug, "recete_turu", None) if db_drug else None,
                jenerik_kodu=jenerik_kodu,
                kategori_key=cat_key,
                kategori_adi=cat_name,
                bulundu=bool(db_drug),
                kisa_isim=kisa_isim,
            )

            all_aggregated_items.append(agg_drug)
            groups[cat_key].items.append(agg_drug)
            total_quantity += agg_drug.toplam_miktar

        total_items = len(all_aggregated_items)

        for group in groups.values():
            group.item_count = len(group.items)
            group.total_quantity = sum(x.toplam_miktar for x in group.items)
            group.percentage = (
                round((group.item_count / total_items * 100), 1) if total_items > 0 else 0.0
            )

        return CategorizeResponse(
            islem_no=detected_islem_no or "-",
            toplam_kalem=total_items,
            toplam_adet=total_quantity,
            gruplar=groups,
            tum_liste=all_aggregated_items,
        )
