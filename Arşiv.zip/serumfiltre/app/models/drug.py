from sqlalchemy import Column, Integer, String, Text
from serumfiltre.app.core.database import MasterBase

class MasterIlac(MasterBase):
    """SQLite master_ilaclar view tablosunun SQLAlchemy ORM modeli"""
    __tablename__ = "master_ilaclar"
    __table_args__ = {"extend_existing": True}

    urun_id = Column(Integer, primary_key=True)
    barkod = Column(String(70), index=True)
    urun_adi = Column(String(255))
    ambalaj = Column(String(255), nullable=True)
    firma_id = Column(Integer, nullable=True)
    firma_adi = Column(String(255), nullable=True)
    etkin_maddeler = Column(Text, nullable=True)
    jenerik_kodu = Column(String(50), nullable=True)
    nfc = Column(String(50), nullable=True)
    nfc_kodu = Column(String(50), nullable=True)
    recete_turu = Column(String(50), nullable=True)
    jenerik_adi = Column(String(255), nullable=True)
    atc_kodu = Column(String(50), nullable=True)
