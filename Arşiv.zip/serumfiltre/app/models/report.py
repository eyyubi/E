from sqlalchemy import Column, Integer, String, Text, DateTime
from datetime import datetime
from serumfiltre.app.core.database import Base

class ReportHistory(Base):
    """Raporlama Geçmişi ORM Modeli"""
    __tablename__ = "report_history"

    id = Column(Integer, primary_key=True, autoincrement=True)
    islem_no = Column(String(50), nullable=True, index=True)
    dosya_adi = Column(String(255), nullable=True)
    
    # Servis Bilgileri (servis silinse dahi raporda sabit kalması için metin olarak da tutulur)
    service_id = Column(Integer, nullable=True)
    service_name = Column(String(100), nullable=True)
    service_floor = Column(String(50), nullable=True)

    # İstatistikler
    toplam_kalem = Column(Integer, default=0)
    toplam_adet = Column(Integer, default=0)
    tablet_kalem = Column(Integer, default=0)
    tablet_adet = Column(Integer, default=0)
    serum_kalem = Column(Integer, default=0)
    serum_adet = Column(Integer, default=0)
    diger_kalem = Column(Integer, default=0)
    diger_adet = Column(Integer, default=0)

    # Tam rapor verisi (Masaya geri yükleme ve yazdırma için JSON string)
    data_json = Column(Text, nullable=False)

    created_at = Column(DateTime, default=datetime.now, index=True)
