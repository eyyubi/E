from sqlalchemy import Column, Integer, String, DateTime
from datetime import datetime
from serumfiltre.app.core.database import Base


class DrugAlias(Base):
    """
    Jenerik koda göre kullanıcı tanımlı kısa isimler.
    
    Master DB'deki jenerik_kodu üzerinden eşleşme yapılır.
    Aynı jenerik koda ait tüm ilaçlar (farklı barkodlar / markalar) 
    bu kısa ismi paylaşır ve A4 çıktısında görünür.
    """
    __tablename__ = "drug_aliases"

    id = Column(Integer, primary_key=True, autoincrement=True)

    # Jenerik kodu (master_ilaclar.jenerik_kodu) — birincil anahtar
    jenerik_kodu = Column(String(50), unique=True, index=True, nullable=False)

    # Master DB'den otomatik doldurulan jenerik grup adı (referans)
    jenerik_adi = Column(String(255), nullable=True)

    # Kullanıcının atadığı kısa isim (A4 çıktısında kullanılır)
    kisa_isim = Column(String(100), nullable=False)

    # Opsiyonel açıklama / not
    notlar = Column(String(255), nullable=True)

    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
