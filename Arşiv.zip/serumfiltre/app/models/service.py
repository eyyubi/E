from sqlalchemy import Column, Integer, String
from serumfiltre.app.core.database import Base

class HospitalService(Base):
    """Hastane Servis ve Kat Bilgisi ORM Modeli"""
    __tablename__ = "hospital_services"

    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String(100), nullable=False)
    floor = Column(String(50), nullable=False)
    code = Column(String(20), nullable=True)
