from pydantic import BaseModel, Field
from typing import List

class FilterSettingsUpdate(BaseModel):
    """Kullanıcının güncelleyebileceği kategori kuralları"""
    group1_name: str = "Tablet Grubu"
    group1_nfc_prefixes: List[str] = ["A", "B"]
    
    group2_name: str = "Serum & Mama Grubu"
    group2_generic_codes: List[str] = Field(default_factory=list)
    group2_barcodes: List[str] = Field(default_factory=list)
    
    group3_name: str = "Diğer İlaçlar"
