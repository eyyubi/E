from pydantic import BaseModel, Field
from typing import Optional

class ServiceBase(BaseModel):
    name: str = Field(..., description="Servis / Klinik Adı (Örn: Dahiliye)")
    floor: str = Field(..., description="Bulunduğu Kat (Örn: Kat 2)")
    code: Optional[str] = Field(default="", description="Servis Kodu (Örn: DH)")

class ServiceCreate(ServiceBase):
    pass

class ServiceUpdate(ServiceBase):
    pass

class ServiceResponse(ServiceBase):
    id: int

    class Config:
        from_attributes = True
