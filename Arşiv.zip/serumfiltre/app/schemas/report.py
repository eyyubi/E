from pydantic import BaseModel
from typing import Optional, Dict, Any
from datetime import datetime
from serumfiltre.app.schemas.category import CategorizeResponse

class ReportHistoryCreate(BaseModel):
    """Rapor geçmişine kaydetme istek modeli"""
    islem_no: Optional[str] = "-"
    dosya_adi: Optional[str] = "reçete_aktarim.xml"
    service_id: Optional[int] = None
    service_name: Optional[str] = None
    service_floor: Optional[str] = None
    data: Dict[str, Any]

class ReportHistoryListItem(BaseModel):
    """Geçmiş listesi özet modeli"""
    id: int
    islem_no: Optional[str] = None
    dosya_adi: Optional[str] = None
    service_id: Optional[int] = None
    service_name: Optional[str] = None
    service_floor: Optional[str] = None
    toplam_kalem: int
    toplam_adet: int
    tablet_kalem: int
    tablet_adet: int
    serum_kalem: int
    serum_adet: int
    diger_kalem: int
    diger_adet: int
    created_at: datetime
    created_at_formatted: str

    class Config:
        from_attributes = True

class ReportHistoryDetail(BaseModel):
    """Geçmiş rapor tam detay modeli"""
    id: int
    islem_no: Optional[str] = None
    dosya_adi: Optional[str] = None
    service_id: Optional[int] = None
    service_name: Optional[str] = None
    service_floor: Optional[str] = None
    toplam_kalem: int
    toplam_adet: int
    tablet_kalem: int
    tablet_adet: int
    serum_kalem: int
    serum_adet: int
    diger_kalem: int
    diger_adet: int
    created_at: datetime
    created_at_formatted: str
    data: CategorizeResponse

    class Config:
        from_attributes = True
