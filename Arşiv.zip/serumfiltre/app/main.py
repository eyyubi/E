from fastapi import FastAPI, Request
from fastapi.staticfiles import StaticFiles
from fastapi.responses import HTMLResponse
from fastapi.middleware.cors import CORSMiddleware
from pathlib import Path

from serumfiltre.app.core.config import settings
from serumfiltre.app.core.database import Base, engine
import serumfiltre.app.models  # Modelleri Base'e kaydettir
from serumfiltre.app.api.router import api_router

BASE_DIR = Path(__file__).resolve().parent.parent

# Veritabanı tablolarını otomatik oluştur (hospital_services, report_history vb.)
Base.metadata.create_all(bind=engine)

app = FastAPI(
    title=settings.PROJECT_NAME,
    version=settings.VERSION,
    description="XML tabanlı ilaç ayrıştırma ve kategori filtreleme sistemi"
)

# Yerel ağ (LAN) erişimi için CORS izinleri
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Statik dosyaları bağlama
static_dir = BASE_DIR / "static"
static_dir.mkdir(parents=True, exist_ok=True)
app.mount("/static/serum", StaticFiles(directory=str(static_dir)), name="static_serum")
app.mount("/static", StaticFiles(directory=str(static_dir)), name="static")

# API rotalarını ekleme
app.include_router(api_router)

@app.get("/", response_class=HTMLResponse)
async def read_root():
    """Ana sayfa - Web arayüzünü döner"""
    template_path = BASE_DIR / "templates" / "index.html"
    if template_path.exists():
        with open(template_path, "r", encoding="utf-8") as f:
            return HTMLResponse(content=f.read())
    return HTMLResponse(content="<h1>İlaç Filtreleme Sistemi - Şablon Yükleniyor...</h1>")
