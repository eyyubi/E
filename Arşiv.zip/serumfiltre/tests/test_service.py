import unittest
from unittest.mock import patch
from serumfiltre.app.core.config import FilterConfig
from serumfiltre.app.core.database import SessionLocal
from serumfiltre.app.services.drug_service import DrugService

class TestDrugService(unittest.TestCase):
    def setUp(self):
        self.db = SessionLocal()

    def tearDown(self):
        self.db.close()

    def test_aggregation_and_categorization(self):
        # sample.xml içindeki kayıtların bir benzeri
        raw_records = [
            {"miktar": 2, "orjkod": "8699606694564", "tb_key": 50044123, "bi_rafid": "A-6", "islemno": 102938},
            {"miktar": 8, "orjkod": "8699606692195", "tb_key": 50044121, "bi_rafid": "koli", "islemno": 102938},
            {"miktar": 2, "orjkod": "8680881020513", "tb_key": 50044120, "bi_rafid": "", "islemno": 102938},
            {"miktar": 4, "orjkod": "8680202600073", "tb_key": 50044116, "bi_rafid": "Ç-4 (G-5)", "islemno": 102938},
            {"miktar": 2, "orjkod": "8699809018105", "tb_key": 50044117, "bi_rafid": "T-A3 (I-4)", "islemno": 102938},
            # Aynı ilaç tekrar ekleniyor: 8680881020513 (miktar 1)
            {"miktar": 1, "orjkod": "8680881020513", "tb_key": 50044118, "bi_rafid": "", "islemno": 102938},
        ]

        test_config = FilterConfig(group2_generic_codes=["J5898"])
        with patch("serumfiltre.app.services.drug_service.SettingsService.get_settings", return_value=test_config):
            response = DrugService.process_records(raw_records, self.db)

        # Toplam kalem sayısı 5 olmalı (6 kayıttan 2'si aynı barkod)
        self.assertEqual(response.toplam_kalem, 5)
        # Toplam adet: 2 + 8 + 2 + 4 + 2 + 1 = 19
        self.assertEqual(response.toplam_adet, 19)
        self.assertEqual(response.islem_no, "102938")

        # 8680881020513 barkodlu ilacın miktarı 2 + 1 = 3 olmalı
        merged_pot_k = next((x for x in response.tum_liste if x.barkod == "8680881020513"), None)
        self.assertIsNotNone(merged_pot_k)
        self.assertEqual(merged_pot_k.toplam_miktar, 3)
        self.assertEqual(merged_pot_k.kategori_key, "tablet") # NFC: AAH -> Tablet

        # POLIFLEKS (8699606692195) -> Seçilen jenerik koduyla Serum olmalı.
        polifleks = next((x for x in response.tum_liste if x.barkod == "8699606692195"), None)
        self.assertIsNotNone(polifleks)
        self.assertEqual(polifleks.kategori_key, "serum")
        self.assertEqual(polifleks.jenerik_kodu, "J5898")
        self.assertEqual(polifleks.raf_konumu, "koli")

        # DIAZOMID (8699809018105) -> Tablet olmalı (NFC: AAA)
        diazomid = next((x for x in response.tum_liste if x.barkod == "8699809018105"), None)
        self.assertIsNotNone(diazomid)
        self.assertEqual(diazomid.kategori_key, "tablet")
        self.assertEqual(diazomid.raf_konumu, "T-A3 (I-4)")

        # CIPROPOL (8699606694564) -> Diğer olmalı (NFC: FQE, ATC: J01MA02)
        cipropol = next((x for x in response.tum_liste if x.barkod == "8699606694564"), None)
        self.assertIsNotNone(cipropol)
        self.assertEqual(cipropol.kategori_key, "diger")

    def test_atc_match_without_selected_generic_stays_in_other_group(self):
        test_config = FilterConfig(group2_generic_codes=[])
        raw_records = [
            {"miktar": 1, "orjkod": "8699606692195", "bi_rafid": "", "islemno": 102938},
        ]

        with patch("serumfiltre.app.services.drug_service.SettingsService.get_settings", return_value=test_config):
            response = DrugService.process_records(raw_records, self.db)

        polifleks = next(item for item in response.tum_liste if item.barkod == "8699606692195")
        self.assertEqual(polifleks.atc_kodu, "B05BB02")
        self.assertEqual(polifleks.kategori_key, "diger")

    def test_unregistered_barcode_can_be_assigned_to_serum(self):
        barcode = "UNREGISTERED-001"
        test_config = FilterConfig(group2_barcodes=[barcode])
        raw_records = [
            {"miktar": 3, "orjkod": barcode, "bi_rafid": "RAF-YOK", "il_ad": "Kayıtsız ilaç"},
        ]

        with patch("serumfiltre.app.services.drug_service.SettingsService.get_settings", return_value=test_config):
            response = DrugService.process_records(raw_records, self.db)

        item = response.tum_liste[0]
        self.assertFalse(item.bulundu)
        self.assertIsNone(item.jenerik_kodu)
        self.assertEqual(item.barkod, barcode)
        self.assertEqual(item.kategori_key, "serum")

if __name__ == "__main__":
    unittest.main()
