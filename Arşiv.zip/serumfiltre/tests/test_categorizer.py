import unittest
from serumfiltre.app.core.config import FilterConfig
from serumfiltre.app.services.categorizer import DrugCategorizer

class TestDrugCategorizer(unittest.TestCase):
    def setUp(self):
        self.config = FilterConfig(
            group1_name="Tablet Grubu",
            group1_nfc_prefixes=["A", "B"],
            group2_name="Serum & Mama Grubu",
            group2_generic_codes=["J5898", "J3210"],
            group3_name="Diğer İlaçlar"
        )

    def test_tablet_classification(self):
        # NFC A ile başlayanlar
        cat_key, cat_name = DrugCategorizer.classify("AAA", "J0000", self.config)
        self.assertEqual(cat_key, "tablet")
        self.assertEqual(cat_name, "Tablet Grubu")

        # NFC B ile başlayanlar
        cat_key, cat_name = DrugCategorizer.classify("BAA", "J0000", self.config)
        self.assertEqual(cat_key, "tablet")

    def test_serum_and_mama_classification(self):
        # Seçilen jenerik kodlar Serum & Mama grubuna atanır.
        cat_key, cat_name = DrugCategorizer.classify("FQE", "J5898", self.config)
        self.assertEqual(cat_key, "serum")
        self.assertEqual(cat_name, "Serum & Mama Grubu")

        # Eşleşme harf büyüklüğünden bağımsızdır.
        cat_key, cat_name = DrugCategorizer.classify("ZZZ", "j3210", self.config)
        self.assertEqual(cat_key, "serum")

    def test_diger_classification(self):
        # NFC veya seçilen jenerik kodla eşleşmeyen ilaçlar diğer grubundadır.
        cat_key, cat_name = DrugCategorizer.classify("FQE", "J9999", self.config)
        self.assertEqual(cat_key, "diger")
        self.assertEqual(cat_name, "Diğer İlaçlar")

    def test_explicit_serum_assignment_takes_priority_over_tablet_nfc(self):
        cat_key, cat_name = DrugCategorizer.classify("AAA", "J5898", self.config)
        self.assertEqual(cat_key, "serum")
        self.assertEqual(cat_name, "Serum & Mama Grubu")

    def test_serum_barcode_assignment_takes_priority_over_tablet_nfc(self):
        config = FilterConfig(group2_barcodes=["UNREGISTERED-001"])
        cat_key, cat_name = DrugCategorizer.classify(
            "AAA", None, config, barcode_code="unregistered-001"
        )
        self.assertEqual(cat_key, "serum")
        self.assertEqual(cat_name, "Serum & Mama Grubu")

    def test_custom_rules(self):
        custom_config = FilterConfig(
            group1_name="Özel Tablet",
            group1_nfc_prefixes=["X"],
            group2_name="Özel Serum",
            group2_generic_codes=["G123"],
            group3_name="Kalanlar"
        )
        cat_key, cat_name = DrugCategorizer.classify("X12", "G999", custom_config)
        self.assertEqual(cat_key, "tablet")
        self.assertEqual(cat_name, "Özel Tablet")

        cat_key, cat_name = DrugCategorizer.classify("Y12", "G123", custom_config)
        self.assertEqual(cat_key, "serum")
        self.assertEqual(cat_name, "Özel Serum")

if __name__ == "__main__":
    unittest.main()
